
(function(){
'use strict';
let LISTA=[{"c":1,"n":"ESC. JESUS LAGUNES RGUEZ"},{"c":2,"n":"EMP.JESUS LAGUNES RGUEZ"},{"c":3,"n":"EL CIELO JESUS LAGUNES RGUEZ"},{"c":4,"n":"EMILIO NAVARRO SANTARROSAS"},{"c":5,"n":"NARCIZO BRAVO"},{"c":6,"n":"LUCIANO CALLES TELLO"},{"c":7,"n":"EZEQUIEL MELQUIADEZ"},{"c":8,"n":"BENIGNO LEON CARMONA"},{"c":9,"n":"FERNANDO GARCIA"},{"c":10,"n":"ERUBEY SALAZAR"},{"c":11,"n":"ELIU CORDOBA"},{"c":12,"n":"JOSE RODILES"},{"c":13,"n":"SAUL QUIÑONES"},{"c":14,"n":"ANTONIO LAGUNES"},{"c":15,"n":"VICTOR HUGO"},{"c":16,"n":"MIRANDA"},{"c":17,"n":"BELTRAN"},{"c":18,"n":"JORGE MARIN"},{"c":19,"n":"HECTOR SANCHEZ"},{"c":20,"n":"NOE BIELMA"},{"c":22,"n":"MANUEL MARTINEZ"},{"c":23,"n":"CITILAR"},{"c":27,"n":"ROBERTO ESPINOZA"},{"c":28,"n":"CANDIDO OLIVOS LARA"},{"c":29,"n":"LUIS VELAZQUEZ"},{"c":31,"n":"MACARIO SANCHEZ"},{"c":32,"n":"ROGELIO LOPEZ"},{"c":34,"n":"LUCIANO JUAREZ HERRERA"},{"c":36,"n":"ALEJANDRO VELA"},{"c":39,"n":"ANGEL SANTIAGO"},{"c":41,"n":"OSCAR BAUTISTA / PASTORA/EDITH BAUTISTA"},{"c":44,"n":"LORENZO CEJA"},{"c":46,"n":"ISAIAS NERY"},{"c":48,"n":"ANTONIO CERVANTES"},{"c":50,"n":"KARINA MARIN"},{"c":54,"n":"ANTONIO MOTA"},{"c":57,"n":"JOSE ANTONIO SANCHEZ M."},{"c":64,"n":"GABINO MORENO"},{"c":65,"n":"BENITO GARCIA"},{"c":66,"n":"BENITO MARTINEZ"},{"c":68,"n":"AMADO HERNANEZ"},{"c":70,"n":"MIGUEL ALCANTARA"},{"c":71,"n":"MARICELA VELA"},{"c":72,"n":"IGNACIO ACEVEDO/ EDGAR ACEVEDO"},{"c":73,"n":"ADALBERTO ROSALES"},{"c":74,"n":"VICTOR GUTIERREZ RODRIGUEZ"},{"c":75,"n":"ANICETO MINA SALAZAR"},{"c":80,"n":"FELIPE VAZQUEZ"},{"c":84,"n":"MISADEL VARGAS"},{"c":86,"n":"CIRO VALDIVIA ZAMORA"},{"c":89,"n":"JOSE FERNANDO RODRIGUEZ"},{"c":90,"n":"PEDRO FLORES HERNANDEZ"},{"c":91,"n":"VICTOR MANUEL PAVON"},{"c":105,"n":"ISMAEL SIVERIO DOMINGUEZ"},{"c":110,"n":"DORIS MENDOZA GARCIA"},{"c":114,"n":"EZEQUIEL USCANGA CANO"},{"c":115,"n":"HORACIO RODRIGUEZ"},{"c":118,"n":"PEDRO GALLARDO/ELIZETH GALLARDO"},{"c":129,"n":"SARA FLORES"},{"c":133,"n":"FIDEL CALLES TRUJILLO"},{"c":144,"n":"ROBERTO REBOLLAR BENITES"},{"c":147,"n":"OMAR JAVIER MORENO GARCIA"},{"c":148,"n":"GERARDO GARCIA"},{"c":152,"n":"MIRIAM JANET MENDEZ MUÑOZ"},{"c":153,"n":"ANAI PAVON CALLES"},{"c":154,"n":"MARGARITO JUAN"},{"c":155,"n":"EDGAR ACEVEDO"},{"c":156,"n":"SALATIEL"},{"c":159,"n":"REYES GARCIA"},{"c":162,"n":"ANDRES ALEJANDRO BRAVO BRAVO"},{"c":163,"n":"JOSE MARTIN PAVON RODRIGUEZ"},{"c":174,"n":"SERGIO VELA"},{"c":177,"n":"LAMBERTO MALPICA"},{"c":180,"n":"RIGOBERTO DEL VALLE"},{"c":186,"n":"JULIO FRANCO/MOISES FRANCO/EZEQUIEL LARA"},{"c":188,"n":"JULIAN REYES"},{"c":190,"n":"EDMUNDO LAGUNES"},{"c":191,"n":"AVIEL HERNANDEZ"},{"c":197,"n":"AYREL MINA VARGAS"},{"c":202,"n":"HUGO FLORES"},{"c":206,"n":"YOLANDA LAGUNES"},{"c":209,"n":"RIGOBERTO MORENO VALDIVIA"},{"c":212,"n":"PRIMITIVO TOLENTINO GONZALEZ"},{"c":213,"n":"ALEJANDRO MARTINEZ"},{"c":231,"n":"ALEJANDRO CARDENAS"},{"c":239,"n":"EVA M"},{"c":241,"n":"JULIAN MAPLICA"},{"c":242,"n":"MANUEL MEDINA"},{"c":252,"n":"TOÑO FLORES"}];
const CAL=[{k:'ctn',l:'230 CTN'},{k:'c250',l:'250'},{k:'c230',l:'230'},{k:'c200',l:'200'},{k:'c175',l:'175'},{k:'c150',l:'150'},{k:'c110',l:'110'}];
const LS='registro-empaque-v1';
const KG_DEF=17.8;
const LS_EMP='registro-empaque-emp',LS_STATS='statsF-v1',LS_CAT='empaque-catalogos';
const APP_NAME='Empaque Vera Limes';
const LOGO={VL:'img/logo-vl.jpg',EC:'img/logo-ec.jpg'};
const LOGO_F2={VL:'img/logo-vlusa.jpg',EC:'img/logo-jc.jpg'};
const EMPS={VL:{id:'VL',name:'Vera Limes',full:'Exportadora de Cítricos Vera Limes S.A. de C.V.',prov:'EXPORTADORA DE CITRICOS VERA LIMES S.A. DE C.V.',rol:'Principal',card:'#98c858',cardInk:'#10203a'},EC:{id:'EC',name:'Citrilar',full:'Exportadora Citrilar',prov:'EXPORTADORA CITRILAR SA DE CV',rol:'Secundaria',card:'#f08030',cardInk:'#2a1304'}};
const MARCAS={VL:['VERALIMES PRIMERA','VERALIMES UNO Y MEDIO'],EC:['CITRILAR PRIMERA','CITRILAR UNO Y MEDIO']};
const PCAL=['110','150','175','200','230','250','230 CTN'];
const PCAL_KEY={'230 CTN':'ctn','250':'c250','230':'c230','200':'c200','175':'c175','150':'c150','110':'c110'};
const HDR_FIELDS=[['factura','Factura#','factura'],['proveedor','Proveedor','proveedor'],['vendedor','Vendedor','vendedor'],['tel','Tel','tel'],['poCliente','PO# cliente','poCliente'],['cliente','Cliente','cliente'],['pOrder','P. Order','pOrder'],['sello','Sello','sello'],['transporte','Transporte','transporte'],['telTransporte','Teléfono del transporte','telTransporte'],['conductor','Conductor','conductor'],['placas','Placas','placas'],['caja','#Caja','caja']];
const HDR_REQ=['factura','poCliente','cliente','sello','transporte','conductor','placas','caja'];
const CAT_SEED={proveedor:['EXPORTADORA DE CITRICOS VERA LIMES S.A. DE C.V.','EXPORTADORA CITRILAR SA DE CV'],vendedor:['CLAUDIA MORALES OROZCO'],cliente:['VERALIMES USA','VILLAMEX','CITRICOS J&C LLC'],transporte:['JESUS LAGUNES RODRIGUEZ'],conductor:['JOSE FRANCISCO ROSAS DEL RIO']};
const $app=document.getElementById('app');
const $sh=document.getElementById('sheetRoot');

let orders=[],dirty=new Set(),curId=null,tab='captura',openP=null;
let showHdr=false,sheet=null,confirmKey=null,needsRender=false,scrollToP=null,flushT=null,flushing=false,focusId=null,trazHdr=true,openCal=null;
let emp='VL',view='menu',ro=false;
let statsF=loadStatsF();
try{const e=localStorage.getItem(LS_EMP);if(e==='VL'||e==='EC')emp=e}catch(x){}
function loadStatsF(){
  const d={emp:null,cal:'ALL',year:'ALL',month:'ALL',desde:'',hasta:'',view:'rend',dir:'desc',_cache:null,_per:false};
  try{
    const j=JSON.parse(localStorage.getItem(LS_STATS)||'null');
    if(j&&typeof j==='object'){
      if(j.emp==='VL'||j.emp==='EC'||j.emp==='ALL')d.emp=j.emp;
      if(['ALL','1','1.5'].indexOf(String(j.cal))>=0)d.cal=String(j.cal);
      if(/^\d{4}$/.test(String(j.year)))d.year=String(j.year);
      if(/^(0[1-9]|1[0-2])$/.test(String(j.month)))d.month=String(j.month);
      if(/^\d{4}-\d{2}-\d{2}$/.test(String(j.desde||'')))d.desde=j.desde;
      if(/^\d{4}-\d{2}-\d{2}$/.test(String(j.hasta||'')))d.hasta=j.hasta;
      if(['rend','kilos','cal'].indexOf(j.view)>=0)d.view=j.view;
      if(j.dir==='asc')d.dir='asc';
    }
  }catch(e){}
  if(d.year==='ALL')d.month='ALL';
  if(d.desde&&d.hasta&&d.desde>d.hasta){const t=d.desde;d.desde=d.hasta;d.hasta=t}
  return d;
}
function saveStatsF(){try{const s=statsF;localStorage.setItem(LS_STATS,JSON.stringify({emp:s.emp,cal:s.cal,year:s.year,month:s.month,desde:s.desde,hasta:s.hasta,view:s.view,dir:s.dir}))}catch(e){}}
function invalidateStats(){statsF._cache=null}
function applyTheme(){document.documentElement.dataset.emp=emp;const m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute('content',EMPS[emp].card)}
function setEmp(e){emp=e;try{localStorage.setItem(LS_EMP,e)}catch(x){}applyTheme()}

/* ---------- utilidades ---------- */
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=v=>{if(v===null||v===undefined||v==='')return null;const n=typeof v==='number'?v:parseFloat(String(v).replace(/,/g,''));return isFinite(n)?n:null};
const n0=v=>num(v)||0;
const fmt=(v,d)=>v==null?'–':v.toLocaleString('es-MX',{minimumFractionDigits:d||0,maximumFractionDigits:d||0});
const clone=o=>JSON.parse(JSON.stringify(o));
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
const pad=(n,l)=>String(n).padStart(l,'0');
function todayISO(){const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1,2)+'-'+pad(d.getDate(),2)}
function isoWeek(s){const d=new Date(s+'T12:00:00');if(isNaN(d))return '';const t=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));const day=t.getUTCDay()||7;t.setUTCDate(t.getUTCDate()+4-day);const y0=new Date(Date.UTC(t.getUTCFullYear(),0,1));return Math.ceil(((t-y0)/86400000+1)/7)}
function fmtDate(s){if(!s)return '';const p=s.split('-');return p.length===3?p[2]+'/'+p[1]+'/'+p[0]:s}
function fmtUS(s){if(!s)return '';const p=s.split('-');return p.length===3?p[1]+'/'+p[2]+'/'+p[0]:s}
let tt;function toast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),2400)}
const cur=()=>orders.find(o=>o.id===curId&&!o.deleted);
const visible=()=>orders.filter(o=>!o.deleted);
const mine=()=>visible().filter(o=>o.emp===emp);

/* ---------- datos ---------- */
function newOrder(f){return{id:uid(),v:3,emp:f.emp,anio:f.anio,cons:f.cons,cod:f.cod,emb:f.emb,po:f.po||'',fecha:f.fecha,semana:f.semana,customer:f.customer||'',domestic:f.domestic||'',factura:f.factura||'',variante:f.variante||'1',kgCaja:KG_DEF,manifiesto:{},productores:[],estado:'proceso',traz:null,ejemplo:!!f.ejemplo,createdAt:Date.now(),updatedAt:Date.now(),deleted:false}}
/* Los pedidos de versiones anteriores se convierten al formato nuevo al abrirse. */
function migrate(o){
  if(o.v==null||o.v<2){
    const m=String(o.ec||'').match(/^(EC|VL)-(\d{4})-(\d+)$/);
    o.emp=o.emp||(m?m[1]:'EC');
    o.anio=o.anio||(m?+m[2]:(+String(o.fecha||'').slice(0,4)||new Date().getFullYear()));
    o.cons=o.cons!=null?o.cons:(m?+m[3]:null);
    o.cod=o.cod||(o.cons!=null?o.emp+'-'+o.cons:String(o.ec||''));
    o.emb=o.emb||o.jc||'';
    delete o.ec;delete o.jc;
  }
  if(!o.estado)o.estado='proceso';
  if(o.traz===undefined)o.traz=null;
  o.v=3;
}
function normOrders(){orders.forEach(o=>{if(o&&o.v!==3)migrate(o)})}
function newProd(nombre,codigo,nota){return{id:uid(),nombre:nombre||'',codigo:codigo==null?null:codigo,k24:null,k18:null,kilos:null,acc:{},seg:null,tor:null,des:null,nota:nota||''}}

function compute(o){
  const kg=num(o.kgCaja)||KG_DEF;let prev={};CAL.forEach(c=>prev[c.k]=0);
  const rows=[];const tot={k24:0,k18:0,kilos:0,seg:0,tor:0,des:0,exp:0};
  (o.productores||[]).forEach(p=>{
    const eff={},delta={},before=Object.assign({},prev);let t=0,err=false;
    CAL.forEach(c=>{const v=num(p.acc&&p.acc[c.k]);eff[c.k]=v==null?prev[c.k]:v;delta[c.k]=eff[c.k]-prev[c.k];if(delta[c.k]<0)err=true;t+=delta[c.k]});
    prev=Object.assign({},eff);
    const kilos=num(p.kilos);const campo=kilos==null?null:kilos/kg;
    const dif=campo==null?null:campo-t-n0(p.seg)-n0(p.tor)-n0(p.des);
    /* Rendimiento de primeras: calibres + 230 CTN x 16 / kg por caja, entre las cajas campo (igual que en el Excel). */
    const eqv=t-delta.ctn+delta.ctn*16/kg;
    const rend=(campo&&campo>0)?eqv/campo:null;
    rows.push({p,before,eff,delta,t,err,campo,dif,eqv,rend});
    tot.k24+=n0(p.k24);tot.k18+=n0(p.k18);tot.kilos+=n0(p.kilos);tot.seg+=n0(p.seg);tot.tor+=n0(p.tor);tot.des+=n0(p.des);tot.exp+=t;
  });
  const man={};let manT=0,finT=0;
  CAL.forEach(c=>{man[c.k]=num(o.manifiesto&&o.manifiesto[c.k]);manT+=man[c.k]||0;finT+=prev[c.k]});
  return{rows,tot,final:prev,man,manT,finT,kg};
}

function codeLabel(c,e){return c?((e||emp)+'-'+pad(c,3)):'sin código'}

/* ---------- sobrantes entre pedidos ---------- */
/* Lo que se empacó por encima del manifiesto queda guardado y se ofrece en el siguiente pedido de la misma empresa. */
function leftoverOf(o){
  const M=compute(o),L={};let total=0;
  CAL.forEach(c=>{const m=M.man[c.k];const v=m==null?0:Math.max(0,M.final[c.k]-m);if(v>0){L[c.k]=v;total+=v}});
  return{L:L,total:total,text:CAL.filter(c=>L[c.k]).map(c=>c.l+': '+fmt(L[c.k])).join(' · ')};
}
function prevLeftover(o){
  if(!o||o.variante!=='1')return null;
  const prev=visible().filter(x=>x.emp===o.emp&&x.variante==='1'&&x.id!==o.id&&x.estado==='completo'&&(+x.anio<+o.anio||(+x.anio===+o.anio&&(x.cons||0)<(o.cons||0))))
    .sort((a,b)=>(+b.anio-+a.anio)||((b.cons||0)-(a.cons||0)))[0];
  if(!prev)return null;
  if(visible().some(x=>x.productores.some(q=>q.sobDe===prev.id)))return null;
  const lo=leftoverOf(prev);
  return lo.total>0?Object.assign({from:prev},lo):null;
}
function addLeftover(){
  const o=cur();if(!o||ro)return;const lo=prevLeftover(o);if(!lo)return;
  /* el sobrante entra primero a la línea: los acumulados que ya estaban capturados se recorren para incluirlo */
  o.productores.forEach(p=>{CAL.forEach(c=>{if(lo.L[c.k]&&p.acc&&p.acc[c.k]!=null)p.acc[c.k]=num(p.acc[c.k])+lo.L[c.k]})});
  const p=newProd(lo.from.cod,null,'Sobrante del pedido anterior');p.sob=true;p.sobDe=lo.from.id;
  CAL.forEach(c=>{if(lo.L[c.k])p.acc[c.k]=lo.L[c.k]});
  o.productores.unshift(p);touch(o);openP=null;render();
  toast('Sobrante de '+lo.from.cod+' agregado: '+fmt(lo.total)+' cajas');
}
function canComplete(o){return !!o&&!ro&&o.variante==='1'&&o.estado!=='completo'&&o.productores.length>0&&compute(o).manT>0}
function sheetsOf(o){return visible().filter(x=>x.emp===o.emp&&x.cod===o.cod).sort((a,b)=>a.variante>b.variante?1:-1)}
function mainOf(o){return sheetsOf(o).find(x=>x.variante==='1')||o}
function completeOrder(){
  const o=cur();if(!o||!canComplete(o))return;
  sheetsOf(o).forEach(x=>{x.estado='completo';x.completadoAt=Date.now();touch(x)});
  invalidateStats();
  sheet={kind:'done',cod:o.cod,id:mainOf(o).id,lo:leftoverOf(o)};renderSheet();render();
}
function reopenOrder(){
  const o=cur();if(!o||ro)return;
  sheetsOf(o).forEach(x=>{x.estado='proceso';touch(x)});render();toast('Registro reabierto');
}

/* ---------- código de trazabilidad: datos ---------- */
function ensureTraz(o){
  if(!o.traz){
    o.traz={hdr:{factura:o.factura||'',proveedor:EMPS[o.emp].prov,vendedor:'',tel:'',poCliente:o.po||'',cliente:o.customer||'',pOrder:'',sello:'',transporte:(REG.transportistas.length===1?REG.transportistas[0].n:''),telTransporte:(REG.transportistas.length===1?(REG.transportistas[0].tel||''):''),conductor:'',placas:'',caja:''},tarimas:[]};
  }
  if(!o.traz.hdr)o.traz.hdr={};if(!o.traz.tarimas)o.traz.tarimas=[];
  return o.traz;
}
function loadCat(){try{return JSON.parse(localStorage.getItem(LS_CAT)||'{}')||{}}catch(e){return {}}}
const LS_REG='empaque-registros';
let REG={vendedores:[],conductores:[],cajas:[],transportistas:null,ts:0,dirty:false};
(function(){try{const r=JSON.parse(localStorage.getItem(LS_REG)||'null');if(r&&typeof r==='object')REG=Object.assign(REG,r)}catch(e){}if(!Array.isArray(REG.transportistas))REG.transportistas=[{id:'t-jlr',n:'JESUS LAGUNES RODRIGUEZ',tel:'271 177 0112'}]})();
function saveReg(stamp){if(stamp){REG.ts=Date.now();REG.dirty=true}try{localStorage.setItem(LS_REG,JSON.stringify(REG))}catch(e){}setSync()}
function catList(field,transp){
  const s=new Set(CAT_SEED[field]||[]);(loadCat()[field]||[]).forEach(v=>s.add(v));
  if(field==='vendedor')REG.vendedores.forEach(x=>s.add(x.n));
  if(field==='conductor')REG.conductores.forEach(x=>s.add(x.n));
  if(field==='transporte'){REG.transportistas.forEach(x=>s.add(x.n));REG.cajas.forEach(x=>{if(x.transporte)s.add(x.transporte)})}
  if(field==='caja'){const t=norm(transp||'').trim();const mine=REG.cajas.filter(x=>t&&norm(x.transporte||'').trim()===t),use=mine.length?mine:REG.cajas;use.forEach(x=>s.add(x.n))}
  visible().forEach(o=>{const h=o.traz&&o.traz.hdr;if(h&&h[field])s.add(h[field])});
  return [...s].filter(Boolean).sort((a,b)=>a.localeCompare(b));
}
function learnCat(field,val){
  val=String(val||'').trim();if(val.length<2)return;
  try{const c=loadCat();const l=c[field]||[];if(l.indexOf(val)<0){l.push(val);c[field]=l.slice(-60);localStorage.setItem(LS_CAT,JSON.stringify(c))}}catch(e){}
}
const qualityOfMarca=m=>/UNO\s+Y\s+MEDIO/i.test(String(m||''))?'1.5':'1';
function prodKey(o,p){return p.codigo?o.emp+'-'+pad(p.codigo,3):(p.nombre||'')}
function resolveProd(sheetsList,s){
  s=String(s||'').trim();if(!s)return '';
  const n=norm(s).replace(/\s+/g,' ');
  const digits=/^\d+$/.test(s)?+s:null;
  for(const o of sheetsList){for(const p of o.productores){
    const k=prodKey(o,p);
    if(norm(k)===n||norm(p.nombre)===n||(digits!=null&&p.codigo===digits)||(/^(vl|ec)-?\d+$/.test(n)&&p.codigo&&norm(o.emp+'-'+pad(p.codigo,3))===n.replace(/^(vl|ec)-?/,m=>m.slice(0,2)+'-').replace(/-(\d+)$/,(x,d)=>'-'+pad(+d,3))))return k;
  }}
  return s.toUpperCase();
}
/* Todo lo que la pantalla y el Excel necesitan saber de las tarimas de un pedido */
function trazCalc(o){
  o=mainOf(o);const t=ensureTraz(o),sh=sheetsOf(o);
  const exp={'1':{},'1.5':{}},pal={'1':{},'1.5':{}},empP={},palP={},empQ={'1':{},'1.5':{}},palQ={'1':{},'1.5':{}};
  ['1','1.5'].forEach(q=>CAL.forEach(c=>{exp[q][c.k]=0;pal[q][c.k]=0}));
  sh.forEach(s=>{
    const M=compute(s);
    CAL.forEach(c=>{const m=M.man[c.k];exp[s.variante][c.k]=m==null?M.final[c.k]:Math.min(M.final[c.k],m)});
    /* el sobrante (lo que pasó del manifiesto) no se tarima: se descuenta de los últimos productores de la línea */
    const cut=M.rows.map(()=>({}));
    CAL.forEach(c=>{const m=M.man[c.k];let ex=m==null?0:Math.max(0,M.final[c.k]-m);for(let i=M.rows.length-1;i>=0&&ex>0;i--){const t=Math.min(ex,Math.max(0,M.rows[i].delta[c.k]));if(t>0){cut[i][c.k]=t;ex-=t}}});
    M.rows.forEach((r,ri)=>{const cu=cut[ri],cs=Object.keys(cu).reduce((a,k)=>a+cu[k],0);const k=prodKey(s,r.p);empP[k]=empP[k]||{nombre:r.p.nombre||k,t:0,by:{}};empP[k].t+=r.t-cs;CAL.forEach(c=>{empP[k].by[c.k]=(empP[k].by[c.k]||0)+r.delta[c.k]-(cu[c.k]||0)});const eq=empQ[s.variante][k]=empQ[s.variante][k]||{k:k,nombre:r.p.nombre||k,t:0,by:{}};eq.t+=r.t-cs;CAL.forEach(c=>{eq.by[c.k]=(eq.by[c.k]||0)+r.delta[c.k]-(cu[c.k]||0)})});
  });
  let sinProd=0,incompletas=0,cantTot=0;const info={};
  t.tarimas.forEach((p,i)=>{
    const q=qualityOfMarca(p.marca);let tot=0;
    (p.lines||[]).forEach(l=>{
      const c=n0(l.cant),key=PCAL_KEY[l.cal];
      tot+=c;cantTot+=c;
      if(key)pal[q][key]+=c;
      const pk=resolveProd(sh,l.prod);
      if(c>0&&!pk)sinProd++;
      if(!l.cal||!c||!pk)incompletas++;
      if(pk&&c>0&&key){const pq=palQ[q][pk]=palQ[q][pk]||{by:{},t:0};pq.by[key]=(pq.by[key]||0)+c;pq.t+=c;palP[pk]=palP[pk]||{by:{},t:0};palP[pk].by[key]=(palP[pk].by[key]||0)+c;palP[pk].t+=c}
    });
    info[p.id]={n:i+1,tot:tot,ok:tot===50,exc:tot===54||tot===55||tot===60};
  });
  const falta={};let faltaTot=0,sobra=0;
  ['1','1.5'].forEach(q=>CAL.forEach(c=>{const d=exp[q][c.k]-pal[q][c.k];if(d!==0)falta[q+'|'+c.k]=d;if(d>0)faltaTot+=d;else sobra+=-d}));
  const over=[];
  ['1','1.5'].forEach(q=>Object.keys(palQ[q]).forEach(k=>{
    const e=empQ[q][k],qn=q==='1.5'?' (1.5)':'';
    if(!e){over.push({k:k,msg:k+qn+': no está entre los productores de este pedido'});return}
    CAL.forEach(c=>{const a=palQ[q][k].by[c.k]||0,b=e.by[c.k]||0;if(a>b)over.push({k:k,msg:e.nombre+qn+' · '+c.l+': '+fmt(a)+' en tarimas, solo '+fmt(b)+' empacadas'})});
  }));
  const hdrMiss=HDR_REQ.filter(f=>!String(t.hdr[f]||'').trim());
  const motivos=[];
  if(!t.tarimas.length)motivos.push('no hay tarimas');
  if(hdrMiss.length)motivos.push('falta en el encabezado: '+hdrMiss.map(f=>(HDR_FIELDS.find(x=>x[0]===f)||[0,f])[1]).join(', '));
  if(incompletas)motivos.push(incompletas+' '+(incompletas===1?'línea sin calibre, cajas o productor':'líneas sin calibre, cajas o productor'));
  if(faltaTot>0)motivos.push('faltan '+fmt(faltaTot)+' cajas por tarimar');
  if(sobra>0)motivos.push('hay '+fmt(sobra)+' cajas de más en tarimas');
  if(over.length)motivos.push('hay productores con más cajas en tarimas que empacadas');
  const avail=(q,k,ck,ex)=>{const e=empQ[q]&&empQ[q][k],u=palQ[q]&&palQ[q][k];return((e&&e.by[ck])||0)-((u&&u.by[ck])||0)+(ex||0)};
  const lo=sh.map(x=>leftoverOf(x)),sobTot=lo.reduce((a,x)=>a+x.total,0),sobText=lo.map(x=>x.text).filter(Boolean).join(' · ');
  return{sobTot:sobTot,sobText:sobText,o:o,t:t,sh:sh,exp:exp,pal:pal,empP:empP,palP:palP,empQ:empQ,palQ:palQ,avail:avail,info:info,falta:falta,faltaTot:faltaTot,sobra:sobra,over:over,hdrMiss:hdrMiss,motivos:motivos,borrador:motivos.length>0,nPal:t.tarimas.length,full:t.tarimas.length>=24,cantTot:cantTot,sinProd:sinProd};
}

/* ---------- guardado local y sincronización ---------- */
const CFG=window.EMPAQUE_CONFIG||{};
const LS_SESSION='registro-empaque-sesion',LS_META='registro-empaque-meta',LS_LISTA='registro-empaque-lista';
let session=null,meta={lastSync:0},syncing=false;
try{const l=JSON.parse(localStorage.getItem(LS_LISTA)||'null');if(l&&l.length)LISTA=l}catch(e){}
function saveLocal(){try{localStorage.setItem(LS,JSON.stringify({orders,dirty:[...dirty]}))}catch(e){}}
function loadLocal(){try{const j=JSON.parse(localStorage.getItem(LS)||'null');if(j){orders=j.orders||[];(j.dirty||[]).forEach(i=>dirty.add(i))}}catch(e){}}
function saveMeta(){try{localStorage.setItem(LS_META,JSON.stringify(meta))}catch(e){}}
function loadSession(){
  try{session=JSON.parse(localStorage.getItem(LS_SESSION)||'null')}catch(e){session=null}
  try{meta=Object.assign(meta,JSON.parse(localStorage.getItem(LS_META)||'{}'))}catch(e){}
  applyRole();
}
function cfgOK(){return !!(CFG.SUPABASE_URL&&CFG.SUPABASE_KEY)}
function syncState(){if(syncing)return 'syncing';if(dirty.size||listaOps().length||REG.dirty)return 'pending';return(cfgOK()&&session)?'synced':'local'}
function syncLabel(){const s=syncState();return s==='syncing'?'Sincronizando…':s==='pending'?'Sincronizar · '+dirty.size:s==='synced'?'Al día':'Sincronizar'}
function setSync(){const el=document.getElementById('syncpill');if(el){el.dataset.s=syncState();el.textContent=syncLabel();el.disabled=syncing}}
function touch(o){o.updatedAt=Date.now();dirty.add(o.id);invalidateStats();saveLocal();setSync()}

async function sb(path,opts){
  opts=opts||{};
  const h=Object.assign({apikey:CFG.SUPABASE_KEY,'Content-Type':'application/json'},opts.headers||{});
  if(opts.auth!==false&&session)h.Authorization='Bearer '+session.access_token;
  const r=await fetch(String(CFG.SUPABASE_URL).replace(/\/$/,'')+path,{method:opts.method||'GET',headers:h,body:opts.body?JSON.stringify(opts.body):undefined});
  if(!r.ok){const err=new Error('HTTP '+r.status);err.status=r.status;throw err}
  if(r.status===204)return null;
  const ct=r.headers.get('content-type')||'';
  return ct.indexOf('json')>=0?r.json():null;
}
function roleOf(tok){try{const p=JSON.parse(atob(String(tok).split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));return (p.app_metadata&&p.app_metadata.rol)||''}catch(e){return ''}}
function applyRole(){ro=(!!session&&roleOf(session.access_token)==='lector')||(typeof authUser!=='undefined'&&!!authUser&&authUser.rol==='lector')}
function saveSession(s){session=s;applyRole();try{localStorage.setItem(LS_SESSION,JSON.stringify(s))}catch(e){}}
function sessionFrom(j){return{access_token:j.access_token,refresh_token:j.refresh_token,expires_at:Date.now()+(j.expires_in||3600)*1000-30000,email:(j.user&&j.user.email)||(session&&session.email)||''}}
async function login(email,pw){const j=await sb('/auth/v1/token?grant_type=password',{method:'POST',body:{email:email,password:pw},auth:false});saveSession(sessionFrom(j))}
async function ensureSession(){
  if(!session)throw Object.assign(new Error('login'),{code:'login'});
  if(Date.now()<session.expires_at)return;
  try{
    const j=await sb('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:{refresh_token:session.refresh_token},auth:false});
    saveSession(sessionFrom(j));
  }catch(e){
    if(e&&(e.status===400||e.status===401||e.status===403)){session=null;ro=false;try{localStorage.removeItem(LS_SESSION)}catch(x){}throw Object.assign(new Error('login'),{code:'login'})}
    throw e;
  }
}
async function doSync(){
  if(syncing)return;
  syncing=true;setSync();
  let pulled=0,pushed=0;
  try{
    await ensureSession();
    /* 1. bajar lo que esta mas nuevo en la nube */
    const idx=(await sb('/rest/v1/orders?select=id,updated_at&order=updated_at.desc&limit=1000'))||[];
    const need=idx.filter(r=>{const l=orders.find(x=>x.id===r.id);return !l||(Number(r.updated_at)||0)>(l.updatedAt||0)});
    for(let i=0;i<need.length;i+=20){
      const ids=need.slice(i,i+20).map(r=>r.id).join(',');
      const rows=(await sb('/rest/v1/orders?select=id,updated_at,data&id=in.('+ids+')'))||[];
      rows.forEach(r=>{
        if(!r.data||!Array.isArray(r.data.productores))return;
        const t=Number(r.updated_at)||0,k=orders.findIndex(x=>x.id===r.id);
        if(k<0||t>(orders[k].updatedAt||0)){
          const d=JSON.parse(JSON.stringify(r.data||{}));d.id=r.id;d.updatedAt=t;
          if(k<0)orders.push(d);else orders[k]=d;
          dirty.delete(r.id);pulled++;
        }
      });
    }
    /* 2. subir lo pendiente de este dispositivo */
    const sent=ro?[]:[...dirty].map(id=>orders.find(o=>o.id===id)).filter(Boolean).map(o=>({o:o,t:o.updatedAt}));
    for(let i=0;i<sent.length;i+=25){
      const part=sent.slice(i,i+25);
      await sb('/rest/v1/orders?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:part.map(x=>({id:x.o.id,updated_at:x.t,deleted:!!x.o.deleted,data:x.o}))});
      part.forEach(x=>{if(x.o.updatedAt===x.t)dirty.delete(x.o.id);pushed++});
    }
    /* 3. lista de productores */
    try{
      await flushLista();
      const lp=await sb('/rest/v1/productores?select=codigo,nombre&order=codigo.asc&limit=1000');
      if(lp&&lp.length){LISTA=lp.map(x=>({c:x.codigo,n:x.nombre}));localStorage.setItem(LS_LISTA,JSON.stringify(LISTA))}
    }catch(e){}
    await syncReg();
    meta.lastSync=Date.now();saveMeta();saveLocal();
    toast('Listo: '+pushed+' enviados, '+pulled+' recibidos');
  }catch(e){
    if(e&&e.code==='login'){sheet={kind:'login',lf:{email:(session&&session.email)||'',pw:''},err:'Tu sesión venció. Vuelve a entrar.'};renderSheet()}
    else toast(e&&e.status?'El servidor respondió '+e.status+'. Revisa la configuración.':'Sin conexión. Tus datos siguen guardados aquí.');
  }finally{syncing=false;invalidateStats();saveLocal();setSync();softRender()}
}
async function doLogin(){
  if(!sheet||sheet.kind!=='login'||sheet.busy)return;
  const lf=sheet.lf||{};
  if(!lf.email||!lf.pw){sheet.err='Escribe el correo y la contraseña.';renderSheet();return}
  sheet.busy=true;sheet.err='';renderSheet();
  try{await login(String(lf.email).trim(),lf.pw);sheet=null;renderSheet();doSync()}
  catch(e){
    if(!sheet||sheet.kind!=='login')return;
    sheet.busy=false;
    sheet.err=(e&&(e.status===400||e.status===401))?'Correo o contraseña incorrectos.':(e&&e.status?'El servidor respondió '+e.status+'. Revisa la configuración.':'Sin conexión. Intenta cuando tengas red.');
    renderSheet();
  }
}
function loginHtml(){
  const lf=sheet.lf||{email:'',pw:''};
  return '<h3>Entrar para sincronizar</h3><p class="note" style="margin-bottom:10px">Usa el correo y la contraseña que se creó para el equipo. Solo hace falta una vez por teléfono.</p>'
   +'<label class="fld" for="lf-email"><span>Correo</span><input class="in txt" id="lf-email" type="email" autocomplete="username" autocapitalize="none" data-lf="email" value="'+esc(lf.email)+'"></label>'
   +'<label class="fld" for="lf-pw"><span>Contraseña</span><input class="in txt" id="lf-pw" type="password" autocomplete="current-password" data-lf="pw" value="'+esc(lf.pw)+'"></label>'
   +(sheet.err?'<p class="note" style="color:var(--crit);margin-bottom:8px" role="alert">'+esc(sheet.err)+'</p>':'')
   +'<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="dologin"'+(sheet.busy?' disabled':'')+'>'+(sheet.busy?'Entrando…':'Entrar y sincronizar')+'</button></div>';
}
function syncInfoHtml(){
  return '<h3>Sincronización sin configurar</h3><p class="note">Falta poner la dirección y la clave pública de la base de datos en el archivo config.js. La guía incluida explica cómo. Mientras tanto la app guarda todo en este teléfono y puedes usar el respaldo.</p><div class="srow2"><button class="btn primary" data-act="closesheet">Entendido</button></div>';
}
function backupPanel(){
  const last=meta.lastSync?new Date(meta.lastSync).toLocaleString('es-MX',{dateStyle:'medium',timeStyle:'short'}):'nunca';
  return '<div class="sec">Sincronización y respaldo</div><div class="panel"><div class="kv"><span>Última sincronización</span><b>'+esc(last)+'</b></div><div class="kv" style="border-bottom:0"><span>Pendientes de enviar</span><b>'+dirty.size+'</b></div>'
   +(cfgOK()?'':'<p class="note" style="margin-top:8px">La sincronización aún no está configurada. Mientras tanto, usa el respaldo.</p>')
   +'<div class="pact"><button class="btn sm" data-act="exportjson">Exportar respaldo</button><button class="btn sm" data-act="importjson">Importar respaldo</button>'+(session?'<button class="btn sm" data-act="logout">Cerrar sesión</button>':'')+'</div><input type="file" id="impfile" accept=".json,application/json" hidden></div>';
}
async function exportBackup(){
  const data=JSON.stringify({app:'registro-empaque',v:1,exportado:new Date().toISOString(),orders:orders});
  await saveFile('Respaldo_Empaque_'+todayISO()+'.json',new Blob([data],{type:'application/json'}));
}
function importBackup(inp){
  const f=inp.files&&inp.files[0];if(!f)return;
  const rd=new FileReader();
  rd.onload=function(){
    try{
      const j=JSON.parse(rd.result);const list=Array.isArray(j)?j:(j&&j.orders);
      if(!Array.isArray(list))throw new Error('formato');
      let n=0;
      list.forEach(r=>{
        if(!r||!r.id||!Array.isArray(r.productores))return;
        const i=orders.findIndex(x=>x.id===r.id);
        if(i<0||(r.updatedAt||0)>(orders[i].updatedAt||0)){if(i<0)orders.push(r);else orders[i]=r;dirty.add(r.id);n++}
      });
      invalidateStats();saveLocal();setSync();render();toast(n+' pedidos importados');
    }catch(e){toast('El archivo no es un respaldo válido')}
    inp.value='';
  };
  rd.readAsText(f);
}
function registerSW(){
  try{
    const C=window.Capacitor;if(C&&C.isNativePlatform&&C.isNativePlatform())return;
    if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{});
    if('serviceWorker' in navigator&&(location.protocol==='https:'||location.hostname==='localhost'))navigator.serviceWorker.register('sw.js').catch(()=>{});
  }catch(e){}
}

/* ---------- vistas ---------- */
function topbar(title,back){
  return `<header class="top"><div class="topin">${back?`<button class="icon" data-act="${back}" aria-label="Volver">←</button>`:''}<span class="empchip" title="${esc(EMPS[emp].name)}">${emp}</span><div class="ttl">${esc(title)}</div><button class="pill" id="syncpill" data-act="sync" data-s="${syncState()}">${syncLabel()}</button></div></header>`;
}
function render(){
  needsRender=false;
  normOrders();applyTheme();
  if(!authUser){$app.className='';$app.innerHTML=loginView();return}
  if((view==='order'||view==='trazo')&&!cur()){curId=null;view=view==='trazo'?'traz':'orders'}
  $app.className=ro?'ro':'';
  $app.innerHTML=view==='order'?orderView(cur()):view==='orders'?listView():view==='stats'?statsView():view==='traz'?trazList():view==='trazo'?trazView(cur()):menuView();
  if(ro)$app.querySelectorAll('input.in,select.in').forEach(i=>{i.readOnly=true;if(i.tagName==='SELECT')i.disabled=true});
  updateDerived();if(view==='trazo')updateTraz();
  if(scrollToP){const el=document.getElementById('pc-'+scrollToP);if(el)el.scrollIntoView({block:'start',behavior:'smooth'});scrollToP=null}
  if(focusId){const el=document.getElementById(focusId);if(el){el.scrollIntoView({block:'center'});try{el.focus({preventScroll:true})}catch(x){}}focusId=null}
}
function softRender(){const a=document.activeElement;if(a&&a.matches&&a.matches('input,textarea,select')&&$app.contains(a)){needsRender=true}else render()}
document.addEventListener('focusout',()=>{setTimeout(()=>{const a=document.activeElement;if(needsRender&&!(a&&a.matches&&a.matches('input,textarea,select')))render()},60)});

function lastCod(e){
  const l=visible().filter(o=>o.emp===e).sort((a,b)=>(b.anio-a.anio)||((b.cons||0)-(a.cons||0)))[0];
  return l?l.cod:'';
}
function extraPanel(){
  const acc=authUser?`<div class="sec">Sesión</div><div class="panel"><div class="kv" style="border-bottom:0"><span>${esc(authUser.name)}</span><b>${ROLES[authUser.rol]||authUser.rol}</b></div><div class="pact"><button class="btn sm" data-act="acctopen">Mi cuenta</button><button class="btn sm" data-act="ulogout">Cerrar sesión</button></div></div>`:'';
  return acc+backupPanel()+(isAdmin()?`<div class="sec">Configuración</div><div class="panel"><div class="kv" style="border-bottom:0"><span>Productores registrados</span><b>${LISTA.length}</b></div><p class="note" style="margin-top:6px">Añade, corrige o elimina códigos de productor. Los espacios vacíos se ven para que los asignes. Se guardan en la base de datos al sincronizar.</p><div class="pact"><button class="btn sm" data-act="prodsopen">Editar productores</button>${cfgOK()?'':`<button class="btn sm" data-act="usersopen">Usuarios${pendingUsers()?' ('+pendingUsers()+' por autorizar)':''}</button>`}<button class="btn sm" data-act="regsopen">Vendedores, transportistas, conductores y cajas</button></div></div>`:'');
}
function menuView(){
  const E=EMPS[emp],all=mine().filter(o=>o.variante!=='1.5'),lc=lastCod(emp);
  const proc=all.filter(o=>o.estado!=='completo').length,comp=all.filter(o=>o.estado==='completo');
  const tz=all.filter(o=>o.estado==='completo'||o.productores.length>0),borr=tz.filter(o=>trazCalc(o).borrador).length;
  const seg=['VL','EC'].map(k=>`<button data-act="emp:${k}" aria-pressed="${emp===k}">${k} · ${EMPS[k].name}</button>`).join('');
  const btn=(act,t,s)=>`<button class="mbtn" data-act="${act}"><span><strong>${t}</strong><small>${s}</small></span><span class="mgo" aria-hidden="true">›</span></button>`;
  return topbar(APP_NAME,null)+`<main class="wrap"><section class="hero"><img class="logo" src="${LOGO[emp]}" alt="Logotipo de ${esc(E.name)}"><div class="k">Empresa activa · ${esc(E.rol)}</div><h1>${esc(E.name)}</h1><div class="sub">${esc(E.full)}</div><div class="seg" role="group" aria-label="Empresa que envía los pedidos">${seg}</div><p class="note" style="margin-top:8px">Cambia el logotipo, los colores, los códigos y los pedidos que ves.</p></section>
${btn('orders','Registro de Empaque',`${proc} en proceso · ${comp.length} completos${lc?' · último '+esc(lc):''}`)}
${btn('traz','Código de Trazabilidad',tz.length?`${tz.length} ${tz.length===1?'pedido':'pedidos'}${borr?' · '+borr+' en borrador':''}`:'Aparecen aquí al agregar productores')}
${btn('stats','Estadísticas','Rendimientos, calibres y base de datos')}${ro?'<div class="rolebadge">Acceso de solo lectura: puedes ver y descargar, no modificar.</div>':''}${extraPanel()}</main>`;
}
function estadoChip(o){return o.estado==='completo'?'<span class="chip good">Completo</span>':'<span class="chip warn">En proceso</span>'}
function ordCard(o,sub){
  const M=compute(o);
  return `<button class="ocard${sub?' sub':''}" data-act="open:${o.id}"><div class="orow"><span class="oec">${sub?'Hoja #1.5 · ':''}${esc(o.cod)}${o.ejemplo?'<span class="badge">Ejemplo</span>':''}</span>${estadoChip(o)}</div><div class="note" style="margin-top:6px"><span class="mono">${esc(o.emb)}</span> · PO ${esc(o.po||'—')} · Semana ${esc(o.semana)} · ${fmtDate(o.fecha)} · ${o.productores.length} ${o.productores.length===1?'productor':'productores'} · ${fmt(M.tot.exp)} cajas</div></button>`;
}
function listView(){
  const vis=mine();
  const mains=vis.filter(o=>o.variante!=='1.5').sort((a,b)=>b.createdAt-a.createdAt);
  const orphans=vis.filter(o=>o.variante==='1.5'&&!mains.some(m=>m.cod===o.cod));
  let body;
  if(!vis.length){
    body=`<section class="empty"><h2>Aún no hay pedidos de ${esc(EMPS[emp].name)}</h2><p>Cada pedido junta fruta de varios productores. Aquí capturas el conteo por calibre y ves cuánto falta o sobra contra el manifiesto.</p><button class="btn primary" data-act="new" data-edit>Nuevo pedido</button><button class="btn" data-act="example" data-edit>Cargar pedido de ejemplo</button></section>`;
  }else{
    body=`<div class="pact" style="margin-top:14px"><button class="btn primary" data-act="new" data-edit>Nuevo pedido</button></div><div class="sec">Pedidos de ${esc(EMPS[emp].name)}</div>`+mains.concat(orphans).map(o=>{
      const kids=vis.filter(x=>x.variante==='1.5'&&x.cod===o.cod&&x.id!==o.id);
      return ordCard(o,o.variante==='1.5')+kids.map(k=>ordCard(k,true)).join('');
    }).join('');
  }
  return topbar('Registro de Empaque','menu')+`<main class="wrap">${body}</main>`;
}

function labelCard(o){
  const sibs=sheetsOf(o);
  const has15=sibs.some(x=>x.variante==='1.5');
  const sib=(sibs.length>1||(o.variante==='1'&&!ro))?`<div class="sib">${sibs.map(s=>`<button class="btn sm" data-act="open:${s.id}" aria-pressed="${s.id===o.id}">Hoja ${esc(s.variante)}</button>`).join('')}${o.variante==='1'&&!has15?'<button class="btn sm" data-act="v15" data-edit>+ Hoja 1.5</button>':''}</div>`:'';
  return `<section class="label"><div class="lrow"><div><div class="k">Pedido ${esc(o.emp)}${o.variante==='1.5'?' · hoja #1.5 (pendiente del principal)':''}</div><div class="big" data-out="h.cod">${esc(o.cod)}</div></div><div><div class="k">Código de embarque</div><div class="mono jc" data-out="h.emb">${esc(o.emb)}</div></div></div><hr><div class="meta mono"><span data-out="h.meta"></span>${estadoChip(o)}${o.ejemplo?'<span class="badge">Ejemplo</span>':''}</div>${sib}<button class="link" data-act="hdr" aria-expanded="${showHdr}">${showHdr?'Cerrar encabezado':'Editar encabezado'}</button>${showHdr?hdrForm(o):''}</section>`;
}
function fld(label,bind,val,o2){
  o2=o2||{};const id='f-'+bind.replace(/\./g,'-');
  const type=o2.date?'date':'text';
  const mode=o2.date?'':(o2.dec?' inputmode="decimal"':(o2.num?' inputmode="numeric"':''));
  return `<label class="fld" for="${id}"><span>${esc(label)}</span><input class="in${o2.txt?' txt':''}" id="${id}" type="${type}"${mode} enterkeyhint="next" autocomplete="off" data-bind="${bind}"${o2.num||o2.dec?' data-num="1"':''}${o2.ph!=null?` placeholder="${esc(o2.ph)}" data-ph="${esc(o2.phkey||'')}"`:''} value="${val==null?'':esc(val)}"></label>`;
}
function hdrForm(o){
  return `<hr><div class="grid2">${fld('Pedido (consecutivo)','o.cod',o.cod,{txt:1})}${fld('Código de embarque','o.emb',o.emb,{txt:1})}${fld('PO','o.po',o.po,{txt:1})}${fld('Fecha','o.fecha',o.fecha,{date:1})}${fld('Semana','o.semana',o.semana,{num:1})}${fld('Factura','o.factura',o.factura,{txt:1})}</div>${fld('Cliente','o.customer',o.customer,{txt:1})}${fld('Cliente doméstico','o.domestic',o.domestic,{txt:1})}${fld('Kg por caja de campo','o.kgCaja',o.kgCaja,{dec:1})}<p class="note">Las cajas campo se calculan como kilos ÷ kg por caja.</p>`;
}
function tabsHtml(){
  return `<div class="tabs" role="tablist">${[['captura','Captura'],['resumen','Resumen'],['excel','Excel']].map(t=>`<button class="tab" role="tab" data-act="tab:${t[0]}" aria-selected="${tab===t[0]}">${t[1]}</button>`).join('')}</div>`;
}
function orderView(o){
  const M=compute(o);
  const body=tab==='captura'?capturaTab(o,M):tab==='resumen'?summaryTab(o,M):excelTab(o,M);
  return topbar(o.cod+(o.variante==='1.5'?' · #1.5':''),'orders')+`<main class="wrap">${labelCard(o)}${tabsHtml()}${body}</main>`+(tab==='captura'?dock(o):'');
}
function dock(o){
  if(ro)return '';
  const lo=prevLeftover(o);
  const done=canComplete(o);
  return `<div class="dock"><div class="dockin"><button class="btn" data-act="addp" data-edit>+ Agregar productor</button>${lo?`<button class="btn" data-act="addleft" data-edit>+ Sobrante ${esc(lo.from.cod)}</button>`:''}${done?'<button class="btn primary" data-act="complete" data-edit>Completar registro</button>':''}</div></div>`;
}
function completeBanner(o){
  if(o.estado==='completo'){
    return `<div class="panel okp"><strong>Registro completo</strong><p class="note" style="margin-top:4px">Este empaque ya está en Código de Trazabilidad. El Excel del registro se puede descargar cuando quieras.</p><div class="pact"><button class="btn primary sm" data-act="totraz:${mainOf(o).id}">Ir a Código de Trazabilidad</button><button class="btn sm" data-act="reopen" data-edit>Reabrir registro</button></div></div>`;
  }
  return '';
}
function capturaTab(o,M){
  const lo=prevLeftover(o);
  const ban=completeBanner(o)+(lo?`<div class="panel info"><strong>Sobrante disponible de ${esc(lo.from.cod)}</strong><p class="note" style="margin-top:4px">${esc(lo.text)} · ${fmt(lo.total)} cajas. Puedes sumarlo a este pedido con el botón «+ Sobrante ${esc(lo.from.cod)}».</p></div>`:'');
  if(!M.rows.length)return ban+`<div class="empty"><h2>Sin productores</h2><p>Agrega el primero en el orden en que pasa por la línea. El conteo de cada uno se resta del anterior.</p></div>`;
  return ban+M.rows.map((r,i)=>prodCard(o,r,i,M.rows.length)).join('');
}
function prodCard(o,r,i,n){
  const p=r.p,open=openP===p.id;
  const note=p.nota?`<span class="pnote">${esc(p.nota)}</span>`:'';
  const head=`<button class="prow" data-act="p:${p.id}" aria-expanded="${open}"><span class="idx">${i+1}</span><span class="pn"><span data-out="pn.${p.id}">${esc(p.nombre||'Sin nombre')}</span><small>${p.sob?'Sobrante del pedido anterior':codeLabel(p.codigo,o.emp)}</small>${note}</span><span class="pt" data-out="pt.${p.id}"></span><span class="chip" data-base="chip" data-out="pd.${p.id}"></span></button>`;
  if(!open)return `<article class="pc" id="pc-${p.id}">${head}</article>`;
  const b=k=>`p.${p.id}.${k}`;
  const cal=CAL.map(c=>`<div class="calrow"><span class="cl">${c.l}</span><span class="bef" data-out="b.${p.id}.${c.k}"></span><input class="in" id="f-p-${p.id}-acc-${c.k}" inputmode="numeric" enterkeyhint="next" autocomplete="off" data-bind="${b('acc.'+c.k)}" data-num="1" data-phk="${p.id}.${c.k}" placeholder="${r.before[c.k]}" value="${p.acc&&p.acc[c.k]!=null?esc(p.acc[c.k]):''}" aria-label="Acumulado ${c.l}"><span class="dlt" data-base="dlt" data-out="d.${p.id}.${c.k}"></span></div>`).join('');
  return `<article class="pc" id="pc-${p.id}">${head}<div class="pf">
<div class="sec">Recepción</div>
<div class="grid2">${fld('Nombre en la hoja',b('nombre'),p.nombre,{txt:1})}${fld('Código del productor (número)',b('codigo'),p.codigo,{num:1})}</div>
<div class="grid3">${fld('Cajas 24KL',b('k24'),p.k24,{num:1})}${fld('Cajas 18KL',b('k18'),p.k18,{num:1})}${fld('Kilos del lote',b('kilos'),p.kilos,{dec:1})}</div>
<p class="note" style="margin-top:6px" data-out="pc.${p.id}"></p>
<div class="sec">Conteo al final de la línea (acumulado)</div>
<div class="calhead"><span>Calibre</span><span>Antes</span><span>Acumulado</span><span>Este</span></div>${cal}
<div class="totline"><span class="k">Total exportación</span><b data-out="ptot.${p.id}"></b></div>
<div class="sec">Otras cajas</div>
<div class="grid3">${fld('Segundas',b('seg'),p.seg,{num:1})}${fld('Torreón',b('tor'),p.tor,{num:1})}${fld('Desecho',b('des'),p.des,{num:1})}</div>
<label class="fld" for="f-p-${p.id}-nota" style="margin-top:10px"><span>Notas u observaciones</span><textarea class="in txt ta" id="f-p-${p.id}-nota" rows="2" autocomplete="off" data-bind="${b('nota')}" placeholder="Ej. se llevó sus 2 días, fruta golpeada…">${esc(p.nota||'')}</textarea></label>
<div class="pact"><button class="btn primary sm" data-act="share:${p.id}">Resumen para enviar</button><button class="btn sm" data-act="up:${p.id}" ${i===0?'disabled':''} aria-label="Subir productor">↑ Subir</button><button class="btn sm" data-act="down:${p.id}" ${i===n-1?'disabled':''} aria-label="Bajar productor">↓ Bajar</button><button class="btn sm danger" data-act="delp:${p.id}" data-edit>${confirmKey==='delp:'+p.id?'Toca otra vez':'Eliminar'}</button></div>
</div></article>`;
}
function summaryTab(o,M){
  const rows=CAL.map(c=>`<div class="srow"><span class="cl">${c.l}</span><input class="in" id="f-m-${c.k}" inputmode="numeric" enterkeyhint="next" autocomplete="off" data-bind="m.${c.k}" data-num="1" value="${M.man[c.k]==null?'':M.man[c.k]}" aria-label="Manifiesto ${c.l}"><span class="mono" data-out="sf.${c.k}"></span><span class="chip" data-base="chip" data-out="sd.${c.k}"></span></div>`).join('');
  const lo=leftoverOf(o);
  const comp=o.variante==='1'?(o.estado==='completo'?completeBanner(o):`<div class="panel"><strong>Completar registro</strong><p class="note" style="margin-top:4px">${canComplete(o)?'El manifiesto ya está capturado. Al completar, el pedido pasa a Código de Trazabilidad.':'Captura los productores y el manifiesto para poder completar el registro.'}</p><div class="pact"><button class="btn primary" data-act="complete" data-edit ${canComplete(o)?'':'disabled'}>Completar registro</button></div></div>`):`<div class="panel"><p class="note">La hoja 1.5 depende del pedido principal ${esc(o.cod)}. El registro se completa desde la hoja principal.</p></div>`;
  return comp+`<div class="sec">Manifiesto contra empacado</div><div class="panel sumbox"><div class="shead"><span>Calibre</span><span>Manifiesto</span><span style="text-align:right">Empacado</span><span style="text-align:center">Resultado</span></div>${rows}<div class="totline"><span class="k">Total cajas</span><b><span data-out="sman"></span> / <span data-out="sfin"></span></b></div><div style="margin-top:8px;text-align:right"><span class="chip" data-base="chip" data-out="sdt"></span></div></div>
${lo.total?`<div class="panel info"><strong>Sobrante para el siguiente pedido</strong><p class="note" style="margin-top:4px">${esc(lo.text)} · ${fmt(lo.total)} cajas</p></div>`:''}
<div class="sec">Totales del pedido</div><div class="panel"><div class="kv"><span>Cajas 24KL recibidas</span><b data-out="st.k24"></b></div><div class="kv"><span>Cajas 18KL recibidas</span><b data-out="st.k18"></b></div><div class="kv"><span>Kilos recibidos</span><b data-out="st.kilos"></b></div><div class="kv"><span>Total exportación</span><b data-out="st.exp"></b></div><div class="kv"><span>Segundas (nacional)</span><b data-out="st.seg"></b></div><div class="kv"><span>Torreón</span><b data-out="st.tor"></b></div><div class="kv" style="border-bottom:0"><span>Desecho</span><b data-out="st.des"></b></div></div>`;
}
function blocks(o){
  const M=compute(o),rows=M.rows;
  const cl=s=>String(s==null?'':s).replace(/[\t\r\n]+/g,' ');
  const v=x=>x==null?'':x;
  const gap=fn=>rows.map(fn).join('\n\n');
  return [
    {key:'names',title:'Nombres de productores',hint:'Encabezado de la tabla de arriba, en una fila.',text:rows.map(r=>cl(r.p.nombre)).join('\t')},
    {key:'acc',title:'Acumulados por calibre',hint:'Tabla de arriba: 230 CTN, 250, 230, 200, 175, 150, 110. Un productor por columna.',text:CAL.map(c=>rows.map(r=>r.eff[c.k]).join('\t')).join('\n')},
    {key:'man',title:'Manifiesto',hint:'Columna de manifiesto, los mismos 7 calibres.',text:CAL.map(c=>v(M.man[c.k])).join('\n')},
    {key:'names2',title:'Nombres de la tabla de abajo',hint:'Columna PRODUCTOR, con una fila en blanco entre productores.',text:gap(r=>cl(r.p.nombre))},
    {key:'recv',title:'Código, cajas 24KL y 18KL, kilos',hint:'Cuatro columnas seguidas, una fila en blanco entre productores.',text:gap(r=>[r.p.codigo||0,v(num(r.p.k24)),v(num(r.p.k18)),v(num(r.p.kilos))].join('\t'))},
    {key:'other',title:'Segundas, Torreón y desecho',hint:'Tres columnas seguidas, una fila en blanco entre productores.',text:gap(r=>[v(num(r.p.seg)),v(num(r.p.tor)),v(num(r.p.des))].join('\t'))}
  ];
}
function excelTab(o,M){
  const bl=blocks(o);
  const sibs=sheetsOf(o);
  const has15=sibs.some(x=>x.variante==='1.5');
  const canX=typeof ExcelJS!=='undefined';
  const prods=M.rows.length>0;
  const blk=bl.map(b=>`<article class="blk"><div class="bh"><div><strong>${esc(b.title)}</strong><small>${esc(b.hint)}</small></div><button class="btn sm" data-act="copy:${b.key}" ${prods?'':'disabled'}>Copiar</button></div>${prods?`<pre class="pv">${esc(b.text.split('\n').slice(0,4).join('\n').replace(/\t/g,'  ·  '))}</pre>`:''}</article>`).join('');
  const chip=(k,l,v)=>`<button class="chipbtn" data-act="copyv:${k}"><small>${l}</small>${esc(v||'—')}</button>`;
  return `<div class="sec">Excel del registro</div><div class="panel"><p class="note">Se genera con el avance actual, aunque el empaque siga en proceso. Incluye el logotipo, el acumulado por calibre, el manifiesto, los sobrantes y las fórmulas vivas.${sibs.length>1?' Trae la hoja principal y la hoja 1.5.':''}</p><div class="pact">${canX?`<button class="btn primary" data-act="xlsx" ${prods?'':'disabled'}>Descargar Excel</button><button class="btn" data-act="mailx" ${prods?'':'disabled'}>Enviar por correo</button>`:`<span class="note">La descarga no está disponible en esta vista.</span>`}${o.variante==='1'&&!has15?`<button class="btn" data-act="v15" data-edit>Crear hoja #1.5</button>`:''}</div><p class="note" style="margin-top:8px">«Enviar por correo» abre el menú de compartir del teléfono con el Excel adjunto; elige tu correo. Con la sincronización, el director también ve el avance en su propia cuenta.</p></div>
<details class="more"><summary>Pegar en tu propio Excel (opcional)</summary><p class="note" style="margin-top:8px">Cada bloque cubre solo columnas de captura. Selecciona la primera celda del bloque y pega.</p>${blk}<div class="chips">${chip('cod','Pedido',o.cod)}${chip('emb','Embarque',o.emb)}${chip('po','PO',o.po)}${chip('fecha','Fecha',fmtUS(o.fecha))}${chip('semana','Semana',o.semana)}${chip('factura','Factura',o.factura)}</div></details>
<div class="sec">Pedido</div><button class="btn danger sm" data-act="delorder" data-edit>${confirmKey==='delorder'?'Toca otra vez para eliminar':'Eliminar este pedido'}</button>`;
}

/* ---------- código de trazabilidad: pantallas ---------- */
function trazList(){
  const done=mine().filter(o=>o.variante!=='1.5'&&(o.estado==='completo'||o.productores.length>0)).sort((a,b)=>(b.completadoAt||b.updatedAt||b.createdAt)-(a.completadoAt||a.updatedAt||a.createdAt));
  let body;
  if(!done.length){
    body=`<section class="empty"><h2>Sin pedidos con productores</h2><p>Aquí aparecen los pedidos de ${esc(EMPS[emp].name)} en cuanto agregas el primer productor en Registro de Empaque. Con ellos armas las tarimas, aunque el registro siga en proceso.</p><button class="btn" data-act="orders">Ir a Registro de Empaque</button></section>`;
  }else{
    body=`<div class="sec">Pedidos listos para tarimas</div>`+done.map(o=>{
      const z=trazCalc(o);
      return `<button class="ocard" data-act="topal:${o.id}"><div class="orow"><span class="oec">${esc(o.cod)}</span>${o.estado==='completo'?'':'<span class="chip warn">Registro en proceso</span> '}${z.borrador?'<span class="chip warn">Borrador</span>':'<span class="chip good">Completo</span>'}</div><div class="note" style="margin-top:6px"><span class="mono">${esc(o.emb)}</span> · PO ${esc(o.po||'—')} · ${z.nPal} ${z.nPal===1?'tarima':'tarimas'} · ${fmt(z.cantTot)} cajas${z.nPal?(z.full?' · Full':' · Parcial'):''}</div></button>`;
    }).join('');
  }
  return topbar('Código de Trazabilidad','menu')+`<main class="wrap">${body}</main>`;
}
function palOptions(sel,list,ph){return `<option value="">${ph}</option>`+list.map(v=>`<option value="${esc(v)}"${String(v)===String(sel)?' selected':''}>${esc(v)}</option>`).join('')}
function lineHtml(o,p,l){
  const id=p.id+'-'+l.id;
  return `<div class="pln" id="ln-${id}"><select class="in sel c1" id="f-tl-${id}-cal" data-bind="tl.${p.id}.${l.id}.cal" aria-label="Calibre">${palOptions(l.cal,PCAL,'Calibre')}</select><input class="in c2" id="f-tl-${id}-cant" type="text" inputmode="numeric" pattern="[0-9]*" enterkeyhint="next" autocomplete="off" data-digits="1" data-num="1" data-bind="tl.${p.id}.${l.id}.cant" placeholder="Cajas" value="${l.cant==null?'':esc(l.cant)}" aria-label="Cantidad de cajas"><div class="c3 pcell"><input class="in txt" id="f-tl-${id}-prod" type="text" autocomplete="off" autocapitalize="characters" data-psearch="${p.id}:${l.id}" placeholder="Código o nombre" value="${esc(l.prod||'')}" aria-label="Productor: busca por código o nombre"><div class="pdd" hidden></div></div><button class="icon sm" data-act="dell:${p.id}:${l.id}" data-edit aria-label="Quitar línea">×</button><div class="pavl" data-out="av.${p.id}.${l.id}"></div></div>`;
}
function palHtml(o,p,i){
  const marcas=MARCAS[o.emp]||MARCAS.VL;
  return `<article class="pal" id="pal-${p.id}"><div class="palh"><span class="pn2">Pallet: ${i+1}</span><select class="in sel" id="f-t-${p.id}-marca" data-bind="t.${p.id}.marca" aria-label="Marca del pallet">${marcas.map(m=>`<option value="${esc(m)}"${m===p.marca?' selected':''}>${esc(m)}</option>`).join('')}</select></div>
<div class="plh"><span>Calibre</span><span>Cajas</span><span>Productor</span><span></span></div>${(p.lines||[]).map(l=>lineHtml(o,p,l)).join('')}
<div class="palf"><button class="btn sm" data-act="addl:${p.id}" data-edit>+ Añadir calibre</button><div class="tot"><span class="k">Cantidad Total</span><output class="qt" data-out="tt.${p.id}"></output><span class="chip" data-base="chip" data-out="tc.${p.id}"></span></div></div>
<div class="pact" style="margin-top:8px"><button class="btn sm" data-act="dupt:${p.id}" data-edit>Duplicar tarima</button><button class="btn sm danger" data-act="delt:${p.id}" data-edit>${confirmKey==='delt:'+p.id?'Toca otra vez':'Eliminar tarima'}</button></div></article>`;
}
function trazView(o){
  const m=mainOf(o);const z=trazCalc(m),t=z.t;
  const dls="";
  const cats=HDR_FIELDS.map(f=>`<datalist id="cat-${f[0]}">${catList(f[0],t.hdr.transporte).map(v=>`<option value="${esc(v)}"></option>`).join('')}</datalist>`).join('');
  const hdr=HDR_FIELDS.map(f=>`<label class="fld${['proveedor','vendedor','cliente','transporte','conductor'].indexOf(f[0])>=0?' wide':''}" for="f-z-${f[0]}"><span>${esc(f[1])}</span><input class="in txt" id="f-z-${f[0]}" type="text" list="cat-${f[0]}" autocomplete="off" data-bind="z.${f[0]}" data-learn="${f[0]}" value="${esc(t.hdr[f[0]]||'')}"></label>`).join('');
  const pal=t.tarimas.length?t.tarimas.map((p,i)=>palHtml(m,p,i)).join(''):`<div class="empty"><h2>Sin tarimas</h2><p>Toca «+ Agregar Tarima», elige la marca y captura calibre, cajas y productor en cada línea.</p></div>`;
  return topbar(m.cod+' · Trazabilidad','traz')+`<main class="wrap"><section class="label"><div class="lrow"><div><div class="k">Pedido ${esc(m.emp)} · ${esc(m.emb)}</div><div class="big">${esc(m.cod)}</div></div><div style="text-align:right"><span class="chip" data-base="chip" data-out="zs"></span><div class="note" data-out="zn" style="margin-top:6px"></div></div></div></section>
<div class="sec">Encabezado del embarque</div><button class="link" data-act="hdrz" aria-expanded="${trazHdr}">${trazHdr?'Ocultar encabezado':'Mostrar encabezado'}</button>${trazHdr?`<div class="panel"><div class="grid2 hdrgrid">${hdr}</div></div>`:''}
<div class="sec">Tarimas</div>${pal}
<div id="zval">${trazValidHtml(z)}</div>
<div class="sec">Excel de trazabilidad</div><div class="panel"><p class="note">Genera el Código de Trazabilidad con el logotipo, el encabezado, las tarimas en dos columnas y el diagrama de la caja. Si falta algo sale con la leyenda BORRADOR.</p><div class="pact"><button class="btn primary" data-act="xlsxz">Descargar Excel</button><button class="btn" data-act="mailz">Enviar por correo</button></div></div></main>${ro?'':`<div class="dock"><div class="dockin"><button class="btn primary" data-act="addt" data-edit>+ Agregar Tarima</button></div></div>`}${dls}${cats}`;
}
function trazValidHtml(z){
  const cal=CAL.map(c=>{
    const e1=z.exp['1'][c.k],p1=z.pal['1'][c.k],e2=z.exp['1.5'][c.k],p2=z.pal['1.5'][c.k];
    if(!e1&&!p1&&!e2&&!p2)return '';
    const d=(e1+e2)-(p1+p2);
    const chip=d===0?'<span class="chip good">Completo</span>':d>0?`<span class="chip warn">faltan ${fmt(d)}</span>`:`<span class="chip crit">sobran ${fmt(-d)}</span>`;
    return `<div class="vrow"><span class="cl">${c.l}</span><span class="mono">${fmt(e1+e2)}</span><span class="mono">${fmt(p1+p2)}</span>${chip}</div>`;
  }).join('');
  const over=z.over.length?`<div class="warnbox" role="alert"><strong>Revisa estos productores</strong>${z.over.slice(0,8).map(x=>`<div>${esc(x.msg)}</div>`).join('')}</div>`:'';
  return `<div class="sec">Verificación contra lo empacado</div><div class="panel"><div class="vhead"><span>Calibre</span><span>Por tarimar</span><span>En tarimas</span><span>Estado</span></div>${cal||'<p class="note">Todavía no hay cajas empacadas.</p>'}<p class="note" style="margin-top:8px">«Por tarimar» es lo empacado sin contar el sobrante que pasa al siguiente pedido${z.sobTot?' ('+esc(z.sobText)+'; ya está descontado de los productores)':''}. Las tarimas normales llevan 50 cajas; 54, 55 y 60 se aceptan como excepción.</p></div>${over}`;
}
function updateTraz(){
  const o=cur();if(!o||view!=='trazo')return;
  const z=trazCalc(o);
  $app.querySelectorAll('[data-out]').forEach(el=>{
    const k=el.dataset.out.split('.');let r=null;
    if(k[0]==='tt'){const i=z.info[k[1]];r=i?{text:fmt(i.tot)}:null}
    else if(k[0]==='tc'){const i=z.info[k[1]];if(i)r=!i.tot?{text:'—',cls:''}:i.ok?{text:'50 normal',cls:'good'}:i.exc?{text:'Excepción',cls:'info'}:{text:'Normal: 50',cls:'warn'}}
    else if(k[0]==='av'){const a=lineAvail(z,k[1],k[2]);if(a){el.className='pavl '+a.cls;el.textContent=a.text}return}
    else if(k[0]==='zs')r=z.borrador?{text:'BORRADOR',cls:'warn'}:{text:z.full?'Completo · Full':'Completo',cls:'good'};
    else if(k[0]==='zn')r={text:z.nPal+' '+(z.nPal===1?'tarima':'tarimas')+' · '+fmt(z.cantTot)+' cajas'+(z.nPal?(z.full?' · Full (24+)':' · Parcial (Full = 24+)'):'')};
    if(!r)return;
    el.textContent=r.text;if(el.dataset.base!==undefined)el.className=el.dataset.base+(r.cls?' '+r.cls:'');
  });
  const zv=document.getElementById('zval');if(zv)zv.innerHTML=trazValidHtml(z);
}

/* acciones sobre tarimas */
function trazOrder(){const o=cur();return o?mainOf(o):null}
function addTarima(){
  const o=trazOrder();if(!o||ro)return;const t=ensureTraz(o);
  const last=t.tarimas[t.tarimas.length-1];
  const p={id:uid(),marca:last?last.marca:(MARCAS[o.emp]||MARCAS.VL)[0],lines:[{id:uid(),cal:'',cant:null,prod:''}]};
  t.tarimas.push(p);touch(o);focusId='f-tl-'+p.id+'-'+p.lines[0].id+'-cal';render();
}
function addLine(pid){
  const o=trazOrder();if(!o||ro)return;const p=ensureTraz(o).tarimas.find(x=>x.id===pid);if(!p)return;
  const prev=p.lines[p.lines.length-1];
  const l={id:uid(),cal:'',cant:null,prod:''};p.lines.push(l);touch(o);focusId='f-tl-'+p.id+'-'+l.id+'-cal';render();
}
function delLine(pid,lid){
  const o=trazOrder();if(!o||ro)return;const p=ensureTraz(o).tarimas.find(x=>x.id===pid);if(!p)return;
  if(p.lines.length<=1){p.lines=[{id:uid(),cal:'',cant:null,prod:''}]}else p.lines=p.lines.filter(l=>l.id!==lid);
  touch(o);render();
}
function dupTarima(pid){
  const o=trazOrder();if(!o||ro)return;const t=ensureTraz(o),i=t.tarimas.findIndex(x=>x.id===pid);if(i<0)return;
  const c=clone(t.tarimas[i]);c.id=uid();c.lines.forEach(l=>l.id=uid());t.tarimas.splice(i+1,0,c);touch(o);render();toast('Tarima duplicada');
}
function delTarima(pid){
  const o=trazOrder();if(!o||ro)return;
  if(confirmKey!=='delt:'+pid){armConfirm('delt:'+pid);render();return}
  const t=ensureTraz(o);t.tarimas=t.tarimas.filter(x=>x.id!==pid);confirmKey=null;touch(o);render();
}

/* ---------- buscador de productor en cada línea ---------- */
function lineAvail(z,pid,lid){
  const p=z.t.tarimas.find(x=>x.id===pid),l=p&&p.lines.find(x=>x.id===lid);if(!l)return null;
  if(!String(l.prod||'').trim())return{cls:'',text:''};
  const q=qualityOfMarca(p.marca),pk=resolveProd(z.sh,l.prod),e=z.empQ[q][pk],ck=PCAL_KEY[l.cal];
  if(!e)return{cls:'bad',text:'No está en este pedido ('+(q==='1.5'?'1.5':'primera')+')'};
  if(!ck)return{cls:'',text:e.nombre+' · elige el calibre'};
  const av=z.avail(q,pk,ck,0);
  return av>=0?{cls:'ok',text:e.nombre+' · disponible '+fmt(av)+' de calibre '+l.cal}:{cls:'bad',text:e.nombre+' · te pasas por '+fmt(-av)+' cajas de calibre '+l.cal};
}
let ddKeys=[];
function openPdd(inp){
  const pr=String(inp.dataset.psearch).split(':'),o=trazOrder();if(!o||ro)return;
  const z=trazCalc(o),p=z.t.tarimas.find(x=>x.id===pr[0]),l=p&&p.lines.find(x=>x.id===pr[1]);if(!l)return;
  const q=qualityOfMarca(p.marca),ck=PCAL_KEY[l.cal],box=inp.parentNode.querySelector('.pdd');
  const own=resolveProd(z.sh,l.prod);
  const txt=norm(inp.value).trim(),same=txt&&norm(l.prod||'').trim()===txt,toks=same?[]:txt.split(/\s+/).filter(Boolean);
  let list=Object.keys(z.empQ[q]).map(k=>{
    const e=z.empQ[q][k];
    const av=ck?z.avail(q,k,ck,(own===k?n0(l.cant):0)):CAL.reduce((a,c)=>a+z.avail(q,k,c.k,0),0);
    return{k:k,nombre:e.nombre,av:av};
  }).filter(x=>{
    if(x.av<=0&&x.k!==own)return false;
    if(!toks.length)return true;
    const h=norm(x.k+' '+x.nombre+' '+x.k.replace(/\D+/g,'').replace(/^0+/,''));
    return toks.every(t=>h.includes(t));
  });
  list.sort((a,b)=>a.k.localeCompare(b.k,'es',{numeric:true}));
  ddKeys=list.map(x=>x.k);
  box.innerHTML=(list.length?list.map((x,i)=>`<button type="button" class="pdi" data-act="ppick:${pr[0]}:${pr[1]}:${i}"><span class="pk">${/^(VL|EC)-\d+$/.test(x.k)?esc(x.k):'—'}</span><span class="pn">${esc(x.nombre)}</span><span class="pav${x.av>0?'':' z'}">${fmt(x.av)}</span></button>`).join(''):`<div class="pdn">${ck?'Ningún productor tiene cajas disponibles de calibre '+esc(l.cal)+(toks.length?' con esa búsqueda':'')+' en este pedido.':'Sin coincidencias.'}</div>`)+(ck?'':'<div class="pdn">Elige primero el calibre para ver cuántas cajas quedan.</div>');
  box.hidden=false;
}
function closePdds(){document.querySelectorAll('.pdd').forEach(b=>{b.hidden=true})}
function pickProd(pid,lid,i){
  const o=trazOrder();if(!o||ro)return;const k=ddKeys[+i];if(!k)return;
  const p=ensureTraz(o).tarimas.find(x=>x.id===pid),l=p&&p.lines.find(x=>x.id===lid);if(!l)return;
  l.prod=k;touch(o);if(!l.cant)focusId='f-tl-'+pid+'-'+lid+'-cant';render();
}
function settleProd(inp){
  if(!inp.isConnected||inp.dataset.dirty!=='1')return;
  inp.dataset.dirty='';
  const pr=String(inp.dataset.psearch).split(':'),o=trazOrder();if(!o||ro)return;
  const t=ensureTraz(o),p=t.tarimas.find(x=>x.id===pr[0]),l=p&&p.lines.find(x=>x.id===pr[1]);if(!l)return;
  const v=inp.value.trim();
  if(!v){if(l.prod){l.prod='';touch(o);updateTraz()}return}
  const z=trazCalc(o),q=qualityOfMarca(p.marca),k=resolveProd(z.sh,v);
  if(z.empQ[q][k]&&k!==l.prod){l.prod=k;touch(o);inp.value=k;updateTraz();return}
  if(inp.value!==(l.prod||''))inp.value=l.prod||'';
}

/* encabezado: al elegir vendedor o conductor se completan teléfono y placas */
function onHdrChange(el){
  const f=el.dataset.learn,v=String(el.value||'').trim();learnCat(f,v);
  const o=trazOrder();if(!o||ro)return;const h=ensureTraz(o).hdr,n=norm(v).trim();let re=false;
  if(f==='vendedor'){const x=REG.vendedores.find(y=>norm(y.n).trim()===n);if(x&&x.tel){h.tel=x.tel;re=true}}
  if(f==='conductor'){const x=REG.conductores.find(y=>norm(y.n).trim()===n);if(x&&x.placas){h.placas=x.placas;re=true}}
  if(f==='transporte'){const x=REG.transportistas.find(y=>norm(y.n).trim()===n);if(x&&x.tel)h.telTransporte=x.tel;re=true}
  if(re){touch(o);render()}
}
/* ---------- salidas calculadas ---------- */
function difChip(r){
  if(r.err)return{text:'Revisa conteo',cls:'crit'};
  if(r.dif==null)return{text:'Sin kilos',cls:''};
  const tol=Math.max(3,(r.campo||0)*0.03);
  return{text:'Dif '+(r.dif>0?'+':'')+fmt(r.dif,1),cls:Math.abs(r.dif)<=tol?'good':'warn'};
}
function manChip(d,man){
  if(man==null)return{text:'–',cls:''};
  if(d===0)return{text:'Completo',cls:'good'};
  return d>0?{text:'+'+fmt(d)+' sobran',cls:'info'}:{text:fmt(-d)+' faltan',cls:'warn'};
}
function outFor(key,M,by,o){
  const p=key.split('.');
  switch(p[0]){
    case 'b':{const r=by[p[1]];return r?{text:fmt(r.before[p[2]])}:null}
    case 'd':{const r=by[p[1]];if(!r)return null;const d=r.delta[p[2]];return{text:d===0?'–':(d>0?'+':'')+fmt(d),cls:d<0?'neg':d===0?'zero':''}}
    case 'pt':{const r=by[p[1]];return r?{text:fmt(r.t)+' cajas'}:null}
    case 'ptot':{const r=by[p[1]];return r?{text:fmt(r.t)}:null}
    case 'pn':{const r=by[p[1]];return r?{text:r.p.nombre||'Sin nombre'}:null}
    case 'pc':{const r=by[p[1]];return r?{text:r.campo==null?'Captura los kilos para ver las cajas campo.':'Cajas campo ≈ '+fmt(r.campo,1)+' (kilos ÷ '+M.kg+')'}:null}
    case 'pd':{const r=by[p[1]];return r?difChip(r):null}
    case 'sf':return{text:fmt(M.final[p[1]])}
    case 'sd':return manChip(M.final[p[1]]-(M.man[p[1]]||0),M.man[p[1]]);
    case 'sman':return{text:fmt(M.manT)}
    case 'sfin':return{text:fmt(M.finT)}
    case 'sdt':{const any=CAL.some(c=>M.man[c.k]!=null);return any?manChip(M.finT-M.manT,0):{text:'Captura el manifiesto',cls:''}}
    case 'st':return{text:fmt(M.tot[p[1]])}
    case 'h':
      if(p[1]==='cod')return{text:o.cod||'—'};
      if(p[1]==='emb')return{text:o.emb||'—'};
      return{text:'PO '+(o.po||'—')+' · Semana '+(o.semana||'—')+' · '+fmtDate(o.fecha)};
  }
  return null;
}
function updateDerived(){
  const o=cur();if(!o)return;
  const M=compute(o);const by={};M.rows.forEach(r=>by[r.p.id]=r);
  $app.querySelectorAll('[data-out]').forEach(el=>{
    const r=outFor(el.dataset.out,M,by,o);
    if(!r)return;
    el.textContent=r.text;
    if(el.dataset.base!==undefined)el.className=el.dataset.base+(r.cls?' '+r.cls:'');
  });
  $app.querySelectorAll('[data-phk]').forEach(el=>{const q=el.dataset.phk.split('.');const r=by[q[0]];if(r)el.placeholder=String(r.before[q[1]])});
}

/* ---------- lista de productores ---------- */
function searchLista(q){
  q=norm(q).trim();const toks=q.split(/\s+/);
  const res=LISTA.filter(x=>{const h=norm('vl-'+pad(x.c,3)+' ec-'+pad(x.c,3)+' '+x.c+' '+x.n);return toks.every(t=>h.includes(t))});
  res.sort((a,b)=>{const an=norm(a.n).startsWith(toks[0])?0:1,bn=norm(b.n).startsWith(toks[0])?0:1;return an-bn||a.n.localeCompare(b.n)});
  return res.slice(0,10);
}
function recents(){
  const seen=new Set(),out=[];
  visible().sort((a,b)=>b.createdAt-a.createdAt).slice(0,4).forEach(o=>o.productores.forEach(p=>{
    const k=norm(p.nombre);if(!k||seen.has(k)||/^(ec|vl)-?\d+$/.test(k))return;seen.add(k);out.push({c:p.codigo||null,n:p.nombre});
  }));
  return out.slice(0,8);
}
function resultsHtml(q){
  const has=q.trim().length>0;
  const items=has?searchLista(q):recents();
  sheet.items=items;
  let h='';
  if(!has)h+=items.length?'<div class="sec" style="margin-top:6px">Recientes</div>':'<p class="note">Escribe el nombre o el número del productor.</p>';
  h+=items.map((x,i)=>`<button class="res" data-act="pick:${i}"><span>${esc(x.n)}</span><span class="mono">${x.c?codeLabel(x.c,(cur()||{emp:emp}).emp):'sin código'}</span></button>`).join('');
  if(has)h+=`<button class="res" data-act="pickfree"><span>Agregar «${esc(q.trim())}» sin buscar en la lista</span><span class="mono">nuevo</span></button>`;
  return h;
}
/* ---------- pedidos nuevos ---------- */
/* Consecutivo interno: VL-189. Cada empresa lleva el suyo y vuelve a 1 cada año. */
function nextCons(e,y){let mx=0;visible().forEach(o=>{if(o.emp===e&&+o.anio===+y&&(o.cons||0)>mx)mx=o.cons});return mx+1}
/* Código de embarque: VL264101 = empresa + año + semana + número de empaque de esa semana. */
function nextPed(e,y,w){const s=new Set();visible().forEach(o=>{if(o.emp===e&&+o.anio===+y&&String(o.semana)===String(w))s.add(o.emb)});return s.size+1}
function newDefaults(){
  const fecha=todayISO(),y=fecha.slice(0,4),w=isoWeek(fecha);
  const last=mine().sort((a,b)=>b.createdAt-a.createdAt)[0]||visible().sort((a,b)=>b.createdAt-a.createdAt)[0];
  return{emp:emp,fecha,semana:w,nEC:nextCons(emp,y),nPed:nextPed(emp,y,w),po:'',factura:'',customer:last?last.customer:(emp==='VL'?'VERALIMES USA':''),domestic:last?last.domestic:''};
}
function codesFrom(d){
  const e=d.emp||emp,y=String(d.fecha||'').slice(0,4);
  return{emp:e,anio:+y||null,cons:num(d.nEC),cod:e+'-'+(d.nEC||''),emb:e+y.slice(2)+pad(d.semana||0,2)+pad(d.nPed||0,2)};
}
function datalist(id,key){
  const vals=[...new Set(visible().map(o=>o[key]).filter(Boolean))];
  return `<datalist id="${id}">${vals.map(v=>`<option value="${esc(v)}">`).join('')}</datalist>`;
}
function newSheetHtml(){
  const d=sheet.d,c=codesFrom(d),E=EMPS[d.emp||emp];
  const f=(l,k,t,list)=>`<label class="fld" for="n-${k}"><span>${l}</span><input class="in${t==='text'?' txt':''}" id="n-${k}" type="${t==='date'?'date':'text'}" ${t==='num'?'inputmode="numeric"':''}${list?` list="${list}"`:''} autocomplete="off" data-sf="${k}" value="${esc(d[k])}"></label>`;
  return `<h3>Nuevo pedido · ${esc(E.name)}</h3><div class="grid2">${f('Fecha','fecha','date')}${f('Semana','semana','num')}${f('Consecutivo del año ('+E.id+')','nEC','num')}${f('Empaque de la semana','nPed','num')}${f('PO (si el cliente lo da)','po','text')}${f('Factura','factura','text')}</div>${f('Cliente','customer','text','dl-cust')}${f('Cliente doméstico','domestic','text','dl-dom')}${datalist('dl-cust','customer')}${datalist('dl-dom','domestic')}<div class="panel"><div class="k">Códigos que se generan</div><div class="mono" id="newprev" style="margin-top:6px;font-weight:600">${esc(c.cod)} · ${esc(c.emb)}</div><p class="note" style="margin-top:6px">Puedes corregir los números si el empaque ya traía otro consecutivo.</p></div><div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="create">Crear pedido</button></div>`;
}

/* ---------- ejemplo ---------- */
function loadExample(){
  const o=newOrder({emp:emp,anio:2026,cons:163,cod:emp+'-163',emb:emp+'263802',po:'3872',fecha:'2026-09-17',semana:38,customer:'CITRICOS J&C LLC',domestic:'VILLAMEX FARMS LLC',factura:'VM-26161',ejemplo:true});
  o.manifiesto={ctn:240,c250:85,c230:150,c200:375,c175:225,c150:115,c110:50};
  const D=[
    [emp+'-162',null,null,214,3852,[0,17,61,69,35,20,12],null,null,null,'Sobrante del pedido anterior'],
    ['LUCIANO CALLES',6,19,null,471,[0,20,69,73,37,20,13],8,null,null,''],
    ['MELISA SANCHEZ',null,null,102,1777,[0,24,81,90,57,35,22],20,null,2,''],
    ['JOSE ANTONIO S',57,71,null,1310,[0,38,89,116,65,38,23],12,null,1,''],
    ['SALATIEL',156,474,null,11820,[240,68,95,291,164,81,43],69,null,5,''],
    ['RIGOBERTO MORENO',209,null,200,3200,[240,74,130,349,210,106,53],null,null,null,'se llevo sus 2 das 29.5'],
    ['EMILIO NAVARRO',4,43,null,1044,[240,82,145,359,216,110,54],13,null,1,''],
    ['PRIMITIVO TOLENTINO',null,null,31,590,[240,83,152,369,223,113,55],4,null,null,''],
    ['ROBERTO REBOLLAR',null,null,25,480,[240,85,160,375,225,115,56],5,null,1,'']
  ];
  D.forEach(d=>{const p=newProd(d[0],d[1],d[9]);p.k24=d[2];p.k18=d[3];p.kilos=d[4];CAL.forEach((c,i)=>{p.acc[c.k]=d[5][i]||null});p.seg=d[6];p.tor=d[7];p.des=d[8];o.productores.push(p)});
  orders.push(o);touch(o);curId=o.id;view='order';tab='captura';openP=null;render();
}

/* ---------- estadísticas ---------- */
const MESES=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const isSob=p=>!p.codigo&&/^(ec|vl)-?\d+$/.test(norm(p.nombre).trim());
function periodOf(f){const c=!!(f.desde||f.hasta);return{custom:c,year:c?'ALL':f.year,month:c?'ALL':f.month,desde:f.desde||'',hasta:f.hasta||''}}
/* Filtro combinado exacto del requerimiento; el periodo personalizado manda sobre año y mes. */
function statsList(f,over){
  const g=Object.assign({},f,periodOf(f),over||{});
  return orders.filter(o=>!o.deleted&&(g.emp==='ALL'||o.emp===g.emp)&&(g.cal==='ALL'||o.variante===g.cal)&&(g.year==='ALL'||String(o.anio)===String(g.year))&&(g.month==='ALL'||String(o.fecha||'').slice(5,7)===g.month)&&(!g.desde||(o.fecha||'')>=g.desde)&&(!g.hasta||(o.fecha||'')<=g.hasta));
}
function aggregate(list){
  const prods=new Map(),T={hojas:list.length,pedidos:new Set(list.map(o=>o.emp+'|'+o.cod)).size,kilos:0,exp:0,seg:0,tor:0,des:0,eqv:0,campoR:0,cal:{}};
  CAL.forEach(c=>T.cal[c.k]=0);
  list.forEach(o=>{
    const M=compute(o);
    M.rows.forEach(r=>{
      const p=r.p;
      if(!p.codigo&&/^(ec|vl)-?\d+$/.test(norm(p.nombre).trim()))return; /* sobrante heredado: ya cuenta en el pedido que lo empacó */
      const key=p.codigo?'c'+p.codigo:'n'+norm(p.nombre||'sin nombre');
      let a=prods.get(key);
      if(!a){const li=p.codigo?LISTA.find(x=>x.c===p.codigo):null;a={key:key,codigo:p.codigo||null,nombre:(li&&li.n)||p.nombre||'Sin nombre',ped:new Set(),kilos:0,exp:0,seg:0,tor:0,des:0,eqv:0,campoR:0,cal:{}};CAL.forEach(c=>a.cal[c.k]=0);prods.set(key,a)}
      a.ped.add(o.emp+'|'+o.cod);a.kilos+=n0(p.kilos);a.exp+=r.t;a.seg+=n0(p.seg);a.tor+=n0(p.tor);a.des+=n0(p.des);
      CAL.forEach(c=>{const d=Math.max(0,r.delta[c.k]);a.cal[c.k]+=d;T.cal[c.k]+=d});
      if(r.rend!=null){a.eqv+=r.eqv;a.campoR+=r.campo;T.eqv+=r.eqv;T.campoR+=r.campo}
      T.kilos+=n0(p.kilos);T.exp+=r.t;T.seg+=n0(p.seg);T.tor+=n0(p.tor);T.des+=n0(p.des);
    });
  });
  const rows=[...prods.values()];
  rows.forEach(a=>{a.rend=a.campoR>0?a.eqv/a.campoR:null});
  T.rend=T.campoR>0?T.eqv/T.campoR:null;
  return{rows:rows,T:T,map:prods,list:list};
}
const dayAdd=(s,n)=>{const d=new Date(s+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)};
const dayDiff=(a,b)=>Math.round((new Date(b+'T12:00:00Z')-new Date(a+'T12:00:00Z'))/86400000);
/* Periodo de comparación automático */
function refPeriod(f){
  if(f.desde||f.hasta){
    if(!(f.desde&&f.hasta))return null;
    const days=dayDiff(f.desde,f.hasta)+1,h=dayAdd(f.desde,-1),d=dayAdd(f.desde,-days);
    return{over:{year:'ALL',month:'ALL',desde:d,hasta:h},label:'el periodo anterior de '+days+' días ('+fmtDate(d)+' al '+fmtDate(h)+')'};
  }
  if(f.year!=='ALL'){
    const y=String(+f.year-1);
    return f.month!=='ALL'?{over:{year:y,month:f.month,desde:'',hasta:''},label:MESES[+f.month-1]+' de '+y}:{over:{year:y,month:'ALL',desde:'',hasta:''},label:'el año '+y};
  }
  return null;
}
function statsData(){
  const f=statsF;if(!f.emp)f.emp=emp;
  const key=[f.emp,f.cal,f.year,f.month,f.desde,f.hasta].join('|');
  if(f._cache&&f._cache.key===key)return f._cache.data;
  const cur=aggregate(statsList(f)),rp=refPeriod(f);
  let ref=null;
  if(rp){const r=aggregate(statsList(f,rp.over));if(r.T.hojas>0)ref={agg:r,label:rp.label}}
  const data={cur:cur,ref:ref,hasRef:!!rp};
  f._cache={key:key,data:data};
  return data;
}
const ppV=(a,b)=>(a==null||b==null)?null:(a-b)*100;
const relV=(a,b)=>(b>0)?(a-b)/b*100:null;
function varChip(v,unit,good){ /* good: 'up' favorable al subir, 'down' favorable al bajar, null neutro */
  if(v==null)return '<span class="chip">Sin datos comparables</span>';
  const z=Math.abs(v)<(unit==='pp'?0.05:0.5);
  const cls=z||!good?'info':((v>0)===(good==='up')?'good':'warn');
  return `<span class="chip ${z?'':cls}">${z?'=':(v>0?'▲ +':'▼ ')}${z?'':fmt(Math.abs(v),1).replace(/^/,v<0?'−':'')}${z?' sin cambio':(unit==='pp'?' pp':' %')}</span>`;
}
function filtersHtml(D){
  const f=statsF;
  const years=[...new Set(visible().map(o=>o.anio).filter(Boolean))].sort((a,b)=>b-a);
  const custom=!!(f.desde||f.hasta);
  const sel=(id,label,val,opts,dis)=>`<label class="fld" for="${id}"><span>${label}</span><select id="${id}" data-sf2="${id.replace('st-','')}"${dis?' disabled':''}>${opts.map(o=>`<option value="${o[0]}"${String(o[0])===String(val)?' selected':''}>${esc(o[1])}</option>`).join('')}</select></label>`;
  const chips=(f.desde?`<button class="rchip" data-act="clrd" aria-label="Quitar fecha desde">Desde ${fmtDate(f.desde)} ✕</button>`:'')+(f.hasta?`<button class="rchip" data-act="clrh" aria-label="Quitar fecha hasta">Hasta ${fmtDate(f.hasta)} ✕</button>`:'');
  return `<div class="filters">${sel('st-emp','Empresa',f.emp,[['VL','Vera Limes'],['EC','Citrilar'],['ALL','Ambas']])}${sel('st-cal','Calidad del empaque',f.cal,[['ALL','Todas'],['1','Primera (1)'],['1.5','Segunda (1.5)']])}${sel('st-year','Año',f.year,[['ALL','Todos']].concat(years.map(y=>[y,y])),custom)}${sel('st-month','Mes',f.month,[['ALL','— (todo el año)']].concat(MESES.map((m,i)=>[pad(i+1,2),m.charAt(0).toUpperCase()+m.slice(1)])),f.year==='ALL'||custom)}</div>
<div class="perrow"><button class="btn sm" data-act="per" aria-expanded="${!!f._per}">Establecer periodo</button>${chips}</div>${f._per?`<div class="grid2 perbox"><label class="fld" for="st-desde"><span>Desde</span><input class="in txt" id="st-desde" type="date" data-sf2="desde" value="${esc(f.desde)}"></label><label class="fld" for="st-hasta"><span>Hasta</span><input class="in txt" id="st-hasta" type="date" data-sf2="hasta" value="${esc(f.hasta)}"></label></div>`:''}`;
}
function infoLine(D){
  const l=D.cur.list,f=statsF;
  const ds=l.map(o=>o.fecha).filter(Boolean).sort();
  const per=ds.length?'del '+fmtDate(ds[0])+' al '+fmtDate(ds[ds.length-1]):'sin fechas';
  const e=f.emp==='ALL'?'Ambas empresas':EMPS[f.emp].name;
  const c=f.cal==='ALL'?'Todas las calidades':f.cal==='1'?'Primera':'Segunda 1.5';
  return `Mostrando ${fmt(l.length)} ${l.length===1?'hoja':'hojas'} · ${fmt(D.cur.T.pedidos)} ${D.cur.T.pedidos===1?'pedido':'pedidos'} · ${per} · ${e} · ${c}`;
}
function tileHtml(label,val,sub,chip,tone){return `<div class="tile ${tone||''}"><span class="k">${label}</span><b>${val}</b>${sub?`<small>${sub}</small>`:''}${chip?`<div class="tv">${chip}</div>`:''}</div>`}
function statsView(){
  const f=statsF;if(!f.emp)f.emp=emp;
  const D=statsData(),T=D.cur.T,R=D.ref?D.ref.agg.T:null;
  const nocmp='<span class="chip">Sin datos comparables</span>';
  const tiles=tileHtml('Hojas',fmt(T.hojas),fmt(T.pedidos)+(T.pedidos===1?' pedido':' pedidos'),R?varChip(relV(T.hojas,R.hojas),'%',null):nocmp)
   +tileHtml('Rendimiento ponderado',T.rend==null?'–':fmt(T.rend*100,1)+'%','primeras sobre cajas campo',R?varChip(ppV(T.rend,R.rend),'pp','up'):nocmp,T.rend==null?'':'')
   +tileHtml('Kilos recibidos',fmt(T.kilos),T.hojas?fmt(T.kilos/T.hojas)+' kg por hoja':'',R?varChip(relV(T.kilos,R.kilos),'%',null):nocmp)
   +tileHtml('Cajas exportación',fmt(T.exp),'segundas '+fmt(T.seg)+' · torreón '+fmt(T.tor)+' · desecho '+fmt(T.des),R?varChip(relV(T.exp,R.exp),'%','up'):nocmp);
  const cmpTxt=D.ref?`Comparado con ${esc(D.ref.label)}.`:(D.hasRef?'Sin datos comparables en el periodo anterior.':'Sin datos comparables: elige un año, un mes o un periodo para comparar.');
  const vbtn=(k,t)=>`<button class="btn sm" data-act="vw:${k}" aria-pressed="${f.view===k}">${t}</button>`;
  const dirBtn=`<button class="btn sm" data-act="dir" aria-label="Invertir orden" title="Invertir orden">↑↓ ${f.dir==='desc'?'Mayor primero':'Menor primero'}</button>`;
  let body;
  if(!T.hojas)body=`<section class="empty"><h2>Sin datos con estos filtros</h2><p>Las estadísticas se llenan solas con cada empaque que registres.</p></section>`;
  else body=f.view==='cal'?calView(D):prodView(D);
  return topbar('Estadísticas','menu')+`<main class="wrap"><section class="dbpanel"><div><strong>Base de datos completa</strong><small>Todo el histórico de ambas empresas, listo para Excel.</small></div><button class="btn primary dbbtn" data-act="dbopen">Descargar Base de Datos</button></section>
${filtersHtml(D)}<p class="statline" role="status">${infoLine(D)}</p><div class="tiles">${tiles}</div><p class="note" style="margin-top:8px">${cmpTxt}</p>
<div class="srt">${vbtn('rend','Por rendimiento')}${vbtn('kilos','Por kilos')}${vbtn('cal','Por calibres')}${dirBtn}</div>${body}<p class="note" style="margin-top:12px">Rendimiento de primeras = (cajas de calibre + 230 CTN × 16 ÷ ${KG_DEF}) ÷ cajas campo, sumando primero todo el periodo y dividiendo una sola vez. Solo cuenta productores con kilos capturados.</p></main>`;
}
function prodView(D){
  const f=statsF,T=D.cur.T,dir=f.dir==='asc'?1:-1;
  const val=a=>f.view==='kilos'?a.kilos:(a.rend==null?-1:a.rend);
  const rows=D.cur.rows.slice().sort((a,b)=>((val(a)-val(b))*dir)||a.nombre.localeCompare(b.nombre));
  return `<div class="sec">${f.view==='kilos'?'Por kilos aportados':'Por rendimiento'} · ${rows.length} ${rows.length===1?'productor':'productores'}</div>`+rows.map(a=>{
    const r=D.ref?D.ref.agg.map.get(a.key):null;
    let big,vch;
    if(f.view==='kilos'){big=T.kilos>0?fmt(a.kilos/T.kilos*100,1)+'%':'–';vch=r&&r.kilos>0?varChip(relV(a.kilos,r.kilos),'%',null):nocmpChip();}
    else{big=a.rend==null?'–':fmt(a.rend*100,1)+'%';vch=r&&r.rend!=null&&a.rend!=null?varChip(ppV(a.rend,r.rend),'pp','up'):nocmpChip();}
    const share=T.exp>0?fmt(a.exp/T.exp*100,1)+'%':'–';
    return `<div class="prd"><div class="r1"><div class="pnm">${esc(a.nombre)}<small>${a.codigo?'#'+pad(a.codigo,3):'sin código'} · ${a.ped.size} ${a.ped.size===1?'pedido':'pedidos'}</small></div><div class="rend" title="${f.view==='kilos'?'Parte de los kilos del periodo':'Rendimiento ponderado'}">${big}<small>${f.view==='kilos'?'de los kilos':'rendimiento'}</small></div></div><div class="r2">${fmt(a.kilos)} kg · exportación ${fmt(a.exp)} cajas · segundas ${fmt(a.seg)} · Torreón ${fmt(a.tor)} · desecho ${fmt(a.des)}</div><div class="r3"><span>Aporta ${fmt(a.exp)} cajas de ${fmt(T.exp)} totales, ${share}</span>${vch}</div></div>`;
  }).join('');
}
function nocmpChip(){return '<span class="chip">Sin datos comparables</span>'}
function calView(D){
  const f=statsF,T=D.cur.T,dir=f.dir==='asc'?1:-1;
  const list=CAL.map(c=>({c:c,n:T.cal[c.k]})).sort((a,b)=>((a.n-b.n)*dir)||a.c.l.localeCompare(b.c.l));
  return `<div class="sec">Distribución por calibre</div>`+list.map(x=>{
    const k=x.c.k,pct=T.exp>0?x.n/T.exp*100:0,open=openCal===k;
    let inner='';
    if(open){
      const ps=D.cur.rows.filter(a=>a.cal[k]>0).sort((a,b)=>((b.cal[k]-a.cal[k])*(f.dir==='asc'?-1:1))||a.nombre.localeCompare(b.nombre));
      inner=`<div class="calbody">${ps.length?ps.map(a=>{
        const r=D.ref?D.ref.agg.map.get(a.key):null;
        const inCal=x.n>0?a.cal[k]/x.n*100:0,calIn=a.exp>0?a.cal[k]/a.exp*100:0;
        return `<div class="crow"><div class="cn">${esc(a.nombre)}<small>${a.codigo?'#'+pad(a.codigo,3):'sin código'}</small></div><div class="cv">${fmt(a.cal[k])} cajas</div><div class="cp"><span>Aporte al calibre ${x.c.l}: <b>${fmt(inCal,1)}%</b></span><span>Peso del ${x.c.l} en el productor: <b>${fmt(calIn,1)}%</b></span></div><div class="cd">${r&&r.cal[k]>0?varChip(relV(a.cal[k],r.cal[k]),'%',null):nocmpChip()}</div></div>`}).join(''):'<p class="note">Ningún productor aportó este calibre.</p>'}</div>`;
    }
    return `<div class="cacc"><button class="chead" data-act="calo:${k}" aria-expanded="${open}"><span class="cl">${x.c.l}</span><span class="cbar" role="img" aria-label="${fmt(pct,1)}% de la exportación"><i style="width:${pct.toFixed(2)}%"></i></span><span class="cn2"><b>${fmt(x.n)}</b> cajas<small>${fmt(pct,1)}% de la exportación</small></span></button>${inner}</div>`;
  }).join('')+`<p class="note" style="margin-top:8px">Porcentajes: el del encabezado es la participación del calibre en la exportación del periodo; al abrirlo ves cuánto aporta cada productor a ese calibre y cuánto pesa el calibre dentro de cada productor.</p>`;
}
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset||!t.dataset.sf2)return;
  const k=t.dataset.sf2,v=t.value;
  if(k==='desde'||k==='hasta'){
    statsF[k]=/^\d{4}-\d{2}-\d{2}$/.test(v)?v:'';
    if(statsF.desde&&statsF.hasta&&statsF.desde>statsF.hasta){const x=statsF.desde;statsF.desde=statsF.hasta;statsF.hasta=x}
  }else{
    statsF[k]=v;
    if(k==='year'&&v==='ALL')statsF.month='ALL';
  }
  invalidateStats();saveStatsF();render();
});

/* ---------- Excel (ExcelJS + xl.js) ---------- */
const XLSX_MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const assetCache={};
async function asset(path){
  if(assetCache[path])return assetCache[path];
  let b64;const emb=String(path).indexOf('data:')===0?path:(window.EMP_ASSETS&&window.EMP_ASSETS[path]);
  if(emb)b64=String(emb).split(',')[1];
  else{
    const r=await fetch(path);if(!r.ok)throw new Error('asset '+path);
    const buf=new Uint8Array(await r.arrayBuffer());let s='';
    for(let i=0;i<buf.length;i+=0x8000)s+=String.fromCharCode.apply(null,buf.subarray(i,i+0x8000));
    b64=btoa(s);
  }
  const im=new Image();
  await new Promise(res=>{im.onload=res;im.onerror=res;im.src='data:image/jpeg;base64,'+b64});
  return assetCache[path]={b64:b64,w:im.naturalWidth||560,h:im.naturalHeight||350};
}
async function wbBlob(wb){const buf=await wb.xlsx.writeBuffer();return new Blob([buf],{type:XLSX_MIME})}
function newWb(){const wb=new ExcelJS.Workbook();wb.creator=APP_NAME;wb.created=new Date();return wb}
async function buildRegistroWb(o){
  const wb=newWb(),logo=await asset(LOGO[o.emp]);
  sheetsOf(o).forEach(x=>{
    XL.addRegistro(wb,{o:x,M:compute(x),logo:logo,sheetName:x.variante==='1.5'?x.cod+' 1.5':x.cod,estado:x.estado,titulo:x.cod,sobrante:leftoverOf(x)});
  });
  return wb;
}
const fileSafe=s=>String(s||'').replace(/[^\w.-]+/g,'_');
async function exportRegistro(share){
  const o=cur();if(!o)return;
  if(typeof ExcelJS==='undefined'){toast('La descarga no está disponible aquí');return}
  try{
    const wb=await buildRegistroWb(o);
    await saveFile('Registro_'+fileSafe(o.cod)+'.xlsx',await wbBlob(wb),share?'Registro '+o.cod+' · '+o.emb:null);
  }catch(e){toast('No se pudo generar el Excel')}
}
function drawTrailer(count,used){
  const cv=document.createElement('canvas'),rows=Math.ceil(count/2),W=190,top=84,rh=36,H=top+rows*rh+24;cv.width=W;cv.height=H;
  const x=cv.getContext('2d');x.fillStyle='#ffffff';x.fillRect(0,0,W,H);
  x.fillStyle='#4f7fb8';x.beginPath();x.roundRect?x.roundRect(30,4,130,64,14):x.rect(30,4,130,64);x.fill();
  x.fillStyle='#cfe3f7';x.fillRect(44,14,102,20);x.fillStyle='#2b4f7e';x.fillRect(14,20,12,28);x.fillRect(164,20,12,28);
  x.fillStyle='#e8eef5';x.strokeStyle='#4f7fb8';x.lineWidth=3;x.fillRect(12,top-8,W-24,rows*rh+20);x.strokeRect(12,top-8,W-24,rows*rh+20);
  x.font='bold 14px Arial';x.textAlign='center';x.textBaseline='middle';
  for(let i=0;i<count;i++){
    const r=Math.floor(i/2),c=i%2,bx=22+c*76,by=top+r*rh;const on=i<used;
    x.fillStyle=on?'#2f6fb0':'#d3dce6';x.fillRect(bx,by,70,rh-6);
    x.fillStyle=on?'#ffffff':'#7d8b99';x.fillText(String(i+1),bx+35,by+(rh-6)/2+1);
  }
  return{b64:cv.toDataURL('image/png').split(',')[1],w:W,h:H};
}
async function buildTrazWb(o){
  const m=mainOf(o),z=trazCalc(m),wb=newWb(),logo=await asset(LOGO_F2[m.emp]);
  const trailer=drawTrailer(Math.max(24,z.nPal),z.nPal);
  const pallets=z.t.tarimas.map((p,i)=>({n:i+1,marca:p.marca,lines:(p.lines||[]).map(l=>({cal:l.cal,cant:l.cant,prod:resolveProd(z.sh,l.prod)}))}));
  const ws=XL.addTraz(wb,{o:m,hdr:z.t.hdr,pallets:pallets,borrador:z.borrador,motivos:z.motivos,logo:logo,trailer:trailer,sheetName:m.emb||m.cod,full:z.nPal?z.full:undefined});
  const keys=new Map();
  Object.keys(z.empP).forEach(k=>keys.set(k,z.empP[k].nombre));
  Object.keys(z.palP).forEach(k=>{if(!keys.has(k))keys.set(k,k)});
  const productores=[...keys.entries()].map(([k,nombre])=>({key:k,nombre:nombre,pal:(z.palP[k]&&z.palP[k].by)||{},palTot:(z.palP[k]&&z.palP[k].t)||0,emp:(z.empP[k]&&z.empP[k].t)||0}));
  const calibres=CAL.map(c=>({l:c.l,e1:z.exp['1'][c.k],p1:z.pal['1'][c.k],e15:z.exp['1.5'][c.k],p15:z.pal['1.5'][c.k]}));
  XL.addResumen(wb,{o:m,borrador:z.borrador,trazSheet:ws.name,productores:productores,calibres:calibres});
  return wb;
}
async function exportTraz(share){
  const o=cur();if(!o)return;
  if(typeof ExcelJS==='undefined'){toast('La descarga no está disponible aquí');return}
  try{
    const m=mainOf(o),wb=await buildTrazWb(m);
    await saveFile('Trazabilidad_'+fileSafe(m.emb||m.cod)+(trazCalc(m).borrador?'_BORRADOR':'')+'.xlsx',await wbBlob(wb),share?'Código de Trazabilidad '+m.cod+' · '+m.emb:null);
  }catch(e){toast('No se pudo generar el Excel')}
}

/* ---------- base de datos completa ---------- */
const DBCOLS=[
  {k:'empresa',h:'Empresa',w:12},{k:'pedido',h:'Pedido',w:11},{k:'embarque',h:'Embarque',w:12},{k:'anio',h:'Año',w:7,al:'center'},{k:'semana',h:'Semana',w:8,al:'center'},{k:'fecha',h:'Fecha',w:12,al:'center'},
  {k:'calidad',h:'Calidad',w:13},{k:'estado',h:'Estado',w:11},{k:'po',h:'PO',w:10},{k:'cliente',h:'Cliente',w:22},{k:'domestico',h:'Cliente doméstico',w:22},{k:'factura',h:'Factura',w:12},
  {k:'tipo',h:'Tipo',w:11},{k:'productor',h:'Productor',w:30},{k:'codigo',h:'Código productor',w:12,al:'center'},
  {k:'k24',h:'Cajas 24KL',w:10,fmt:'#,##0'},{k:'k18',h:'Cajas 18KL',w:10,fmt:'#,##0'},{k:'kilos',h:'Kilos',w:11,fmt:'#,##0.0'},{k:'campo',h:'Cajas campo',w:11,fmt:'#,##0.0'}
].concat(CAL.map(c=>({k:'c_'+c.k,h:c.l,w:9,fmt:'#,##0',grp:'cal'})),[
  {k:'exp',h:'Total exportación',w:12,fmt:'#,##0',grp:'cal'},{k:'seg',h:'Segundas',w:10,fmt:'#,##0',grp:'out'},{k:'tor',h:'Torreón',w:10,fmt:'#,##0',grp:'out'},{k:'des',h:'Desecho',w:10,fmt:'#,##0',grp:'out'},
  {k:'rend',h:'Rendimiento 1ras',w:12,fmt:'0.0%',grp:'out'},{k:'dif',h:'Diferencia',w:11,fmt:'#,##0.0',grp:'out'},{k:'nota',h:'Notas',w:34}
]);
function dbRows(){
  const out=[];
  visible().slice().sort((a,b)=>(a.emp<b.emp?-1:a.emp>b.emp?1:0)||(+a.anio-+b.anio)||((a.cons||0)-(b.cons||0))||(a.variante>b.variante?1:-1)).forEach(o=>{
    const M=compute(o);
    M.rows.forEach(r=>{
      const p=r.p,row={empresa:EMPS[o.emp].name,pedido:o.cod,embarque:o.emb,anio:o.anio,semana:num(o.semana),fecha:o.fecha||'',calidad:o.variante==='1.5'?'Segunda 1.5':'Primera',estado:o.estado==='completo'?'Completo':'En proceso',po:o.po||'',cliente:o.customer||'',domestico:o.domestic||'',factura:o.factura||'',tipo:(p.sob||isSob(p))?'Sobrante':'Productor',productor:p.nombre||'',codigo:p.codigo?o.emp+'-'+pad(p.codigo,3):'',k24:num(p.k24),k18:num(p.k18),kilos:num(p.kilos),campo:r.campo==null?null:Math.round(r.campo*100)/100,exp:r.t,seg:num(p.seg),tor:num(p.tor),des:num(p.des),rend:r.rend,dif:r.dif==null?null:Math.round(r.dif*100)/100,nota:p.nota||''};
      CAL.forEach(c=>row['c_'+c.k]=r.delta[c.k]);
      out.push(row);
    });
  });
  return out;
}
function dbTarimas(){
  const out=[];
  visible().filter(o=>o.variante==='1'&&o.traz&&o.traz.tarimas).forEach(o=>{
    o.traz.tarimas.forEach((p,i)=>(p.lines||[]).forEach(l=>out.push({empresa:EMPS[o.emp].name,pedido:o.cod,embarque:o.emb,pallet:i+1,marca:p.marca,calibre:l.cal,cajas:num(l.cant),productor:resolveProd(sheetsOf(o),l.prod)})));
  });
  return out;
}
const csvCell=v=>{if(v==null)return '';const s=String(v);return /[",\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s};
function dbCsv(rows){
  const cols=DBCOLS.map(c=>c.k==='rend'?{k:'rend',h:'Rendimiento 1ras (%)'}:c);
  const lines=[cols.map(c=>csvCell(c.h)).join(',')];
  rows.forEach(r=>lines.push(cols.map(c=>c.k==='rend'?csvCell(r.rend==null?'':Math.round(r.rend*10000)/100):csvCell(r[c.k])).join(',')));
  return '﻿'+lines.join('\r\n');
}
async function exportDb(kind){
  const rows=dbRows(),stamp=todayISO();
  try{
    if(kind==='csv')await saveFile('Base_de_datos_empaque_'+stamp+'.csv',new Blob([dbCsv(rows)],{type:'text/csv;charset=utf-8'}));
    else if(kind==='json')await saveFile('Base_de_datos_empaque_'+stamp+'.json',new Blob([JSON.stringify({app:APP_NAME,exportado:new Date().toISOString(),pedidos:visible(),filas:rows,tarimas:dbTarimas()},null,1)],{type:'application/json'}));
    else{
      if(typeof ExcelJS==='undefined'){toast('La descarga en Excel no está disponible aquí');return}
      const wb=newWb(),A=aggregate(visible()),pr=A.rows.slice().sort((a,b)=>(b.rend==null?-1:b.rend)-(a.rend==null?-1:a.rend)).map(a=>({nombre:a.nombre,codigo:a.codigo?pad(a.codigo,3):'',pedidos:a.ped.size,kilos:a.kilos,exp:a.exp,seg:a.seg,tor:a.tor,des:a.des,rend:a.rend}));
      const tot=CAL.reduce((s,c)=>s+A.T.cal[c.k],0);
      XL.addBase(wb,{titulo:APP_NAME+' · Base de datos',sub:'Exportado el '+fmtDate(stamp)+' · '+rows.length+' filas · '+visible().length+' hojas',cols:DBCOLS,rows:rows,pr:pr,cal:CAL.map(c=>({l:c.l,n:A.T.cal[c.k],pct:tot>0?A.T.cal[c.k]/tot:0})),extra:[{name:'Tarimas',cols:[{k:'empresa',h:'Empresa',w:12},{k:'pedido',h:'Pedido',w:11},{k:'embarque',h:'Embarque',w:12},{k:'pallet',h:'Pallet',w:8,al:'center'},{k:'marca',h:'Marca',w:24},{k:'calibre',h:'Calibre',w:10,al:'center'},{k:'cajas',h:'Cajas',w:9,fmt:'#,##0'},{k:'productor',h:'Productor / código',w:26}],rows:dbTarimas()}]});
      await saveFile('Base_de_datos_empaque_'+stamp+'.xlsx',await wbBlob(wb));
    }
  }catch(e){toast('No se pudo generar el archivo')}
}
function mailSummary(){
  const o=cur();if(!o)return;const M=compute(o),lo=leftoverOf(o);
  const body=[o.cod+' · '+o.emb+' · PO '+(o.po||'—')+' · Semana '+(o.semana||'—'),'Estado: '+(o.estado==='completo'?'completo':'en proceso'),'Productores: '+M.rows.length,'Exportación: '+fmt(M.tot.exp)+' cajas (manifiesto '+fmt(M.manT)+')','Segundas: '+fmt(M.tot.seg)+' · Torreón: '+fmt(M.tot.tor)+' · Desecho: '+fmt(M.tot.des)].concat(lo.total?['Sobrante: '+lo.text]:[]).join('\n');
  location.href='mailto:?subject='+encodeURIComponent('Registro de empaque '+o.cod)+'&body='+encodeURIComponent(body);
}
function blobToB64(blob){
  return new Promise(function(res,rej){const r=new FileReader();r.onload=function(){res(String(r.result).split(',')[1]||'')};r.onerror=function(){rej(r.error)};r.readAsDataURL(blob)});
}
async function saveFile(name,blob,title){
  try{
    const C=window.Capacitor;
    if(C&&C.isNativePlatform&&C.isNativePlatform()){
      const P=C.Plugins||{};
      const w=await P.Filesystem.writeFile({path:name,data:await blobToB64(blob),directory:'CACHE'});
      await P.Share.share({title:title||name,url:w.uri,dialogTitle:'Guardar o enviar (por ejemplo a OneDrive)'});
      return;
    }
    if(window.claude&&typeof window.claude.use==='function'){
      let dl=null;try{dl=await window.claude.use('downloads')}catch(x){}
      if(dl){try{await dl.save({filename:name,data:blob});return}catch(x){if(x&&x.code==='declined')return;throw x}}
    }
    const f=new File([blob],name,{type:blob.type||'application/octet-stream'});
    if(/Android|iPhone|iPad/i.test(navigator.userAgent)&&navigator.canShare&&navigator.canShare({files:[f]})){
      try{await navigator.share({files:[f],title:title||name});return}catch(e){if(e&&e.name==='AbortError')return}
    }
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},4000);
  }catch(e){toast('No se pudo guardar el archivo')}
}

/* ---------- resumen por productor ---------- */
function prodText(o,r){
  const p=r.p;
  return '*'+o.cod+' · '+o.emb+'*'+(o.variante==='1.5'?' (hoja #1.5)':'')+'\nPO '+(o.po||'—')+' · Semana '+(o.semana||'—')+' · '+fmtUS(o.fecha)+'\nProductor: '+(p.nombre||'Sin nombre')+' ('+codeLabel(p.codigo,o.emp)+')\nRecibido: '+fmt(n0(p.k24))+' cajas 24KL · '+fmt(n0(p.k18))+' cajas 18KL · '+fmt(n0(p.kilos))+' kg\nCalibres: '+CAL.map(c=>c.l.replace(' ','')+' '+fmt(r.delta[c.k])).join(' | ')+'\nTotal exportación: '+fmt(r.t)+'\nSegundas: '+fmt(n0(p.seg))+' · Torreón: '+fmt(n0(p.tor))+' · Desecho: '+fmt(n0(p.des))+(p.nota?'\nNota: '+p.nota:'');
}
function drawCard(o,r){
  const W=1080,H=1190,cv=document.createElement('canvas');cv.width=W;cv.height=H;const x=cv.getContext('2d');
  const D="'Barlow Condensed','Arial Narrow',Arial,sans-serif",B="Barlow,Arial,sans-serif",Mo="'IBM Plex Mono',Menlo,monospace";
  const INK='#14221b',MUT='#566a5d',LINE='#cdd8cf';
  const fit=(t,max,w,s,f)=>{do{x.font=w+' '+s+'px '+f;}while(x.measureText(t).width>max&&--s>28)};
  const E=EMPS[o.emp]||EMPS[emp];
  x.fillStyle='#fbfcf8';x.fillRect(0,0,W,H);
  x.fillStyle=E.card;x.fillRect(0,0,W,176);
  x.fillStyle=E.cardInk;x.textBaseline='alphabetic';x.textAlign='left';
  const tl=o.cod+(o.variante==='1.5'?'  #1.5':'');
  fit(tl,W-96-230-190,700,68,D);x.fillText(tl,48,80);
  x.font='500 30px '+Mo;x.fillText(o.emb,48,124);
  x.font='500 26px '+Mo;x.fillText('PO '+(o.po||'—')+'  ·  Sem '+(o.semana||'—')+'  ·  '+fmtUS(o.fecha),48,160);
  /* Rendimiento 1ras (%) en la esquina superior derecha; el logotipo pasa a su izquierda */
  const LX=W-48-230-170-10;
  x.fillStyle='#ffffff';x.beginPath();x.roundRect?x.roundRect(LX,18,170,140,14):x.rect(LX,18,170,140);x.fill();
  const lg=logoImg(o.emp);
  if(lg&&lg.complete&&lg.naturalWidth){const k=Math.min(154/lg.naturalWidth,124/lg.naturalHeight);const lw=lg.naturalWidth*k,lh=lg.naturalHeight*k;x.drawImage(lg,LX+(170-lw)/2,18+(140-lh)/2,lw,lh)}
  x.textAlign='right';x.fillStyle=E.cardInk;
  x.font='500 22px '+Mo;x.fillText('RENDIMIENTO',W-48,46);
  const rtxt=r.rend==null?'–':fmt(r.rend*100,1)+'%';
  fit(rtxt,230,700,104,D);x.fillText(rtxt,W-48,146);
  x.textAlign='left';
  const p=r.p;
  x.fillStyle=INK;fit(p.nombre||'Sin nombre',W-96,700,92,D);x.fillText(p.nombre||'Sin nombre',48,290);
  x.fillStyle=MUT;x.font='500 34px '+Mo;x.fillText(codeLabel(p.codigo,o.emp).toUpperCase(),48,340);
  const box=(bx,by,bw,bh,lab,val,vs)=>{x.strokeStyle=LINE;x.lineWidth=2;x.strokeRect(bx,by,bw,bh);x.fillStyle=MUT;x.font='500 22px '+Mo;x.fillText(lab,bx+14,by+34);x.fillStyle=INK;fit(val,bw-28,700,vs,D);x.fillText(val,bx+14,by+bh-20)};
  const w3=(W-96-40)/3;
  box(48,380,w3,130,'CAJAS 24KL',fmt(n0(p.k24)),72);box(48+w3+20,380,w3,130,'CAJAS 18KL',fmt(n0(p.k18)),72);box(48+2*(w3+20),380,w3,130,'KILOS',fmt(n0(p.kilos)),72);
  x.fillStyle=MUT;x.font='500 24px '+Mo;x.fillText('CAJAS POR CALIBRE',48,574);
  const w7=(W-96-6*10)/7;
  CAL.forEach((c,i)=>{const bx=48+i*(w7+10),by=594;x.strokeStyle=LINE;x.lineWidth=2;x.strokeRect(bx,by,w7,170);x.fillStyle=MUT;x.font='700 36px '+D;x.fillText(c.l,bx+12,by+48);x.fillStyle=INK;fit(fmt(r.delta[c.k]),w7-20,700,84,D);x.fillText(fmt(r.delta[c.k]),bx+12,by+146)});
  x.fillStyle=INK;x.fillRect(48,806,W-96,4);
  x.fillStyle=MUT;x.font='500 24px '+Mo;x.fillText('TOTAL EXPORTACIÓN',48,860);
  x.fillStyle=INK;x.font='700 150px '+D;x.fillText(fmt(r.t),48,990);
  box(W-48-3*190-2*14,880,190,130,'SEGUNDAS',fmt(n0(p.seg)),64);box(W-48-2*190-14,880,190,130,'TORREÓN',fmt(n0(p.tor)),64);box(W-48-190,880,190,130,'DESECHO',fmt(n0(p.des)),64);
  x.fillStyle=MUT;x.font='500 26px '+Mo;
  x.fillText(r.campo==null?'Sin kilos capturados':'Cajas campo ≈ '+fmt(r.campo,1)+'  ·  Dif '+(r.dif>0?'+':'')+fmt(r.dif,1),48,1090);
  if(p.nota){fit('Nota: '+p.nota,W-96,500,28,B);x.fillStyle=INK;x.fillText('Nota: '+p.nota,48,1136)}
  return cv;
}
const logoCache={};
function logoImg(e){
  if(!LOGO[e])return null;
  if(!logoCache[e]){const i=new Image();i.src=LOGO[e];logoCache[e]=i}
  return logoCache[e];
}
async function openShare(pid){
  const o=cur();if(!o)return;const M=compute(o);const r=M.rows.find(x=>x.p.id===pid);if(!r)return;
  try{if(document.fonts&&document.fonts.ready)await document.fonts.ready}catch(e){}
  try{const li=logoImg(o.emp);if(li&&li.decode)await li.decode()}catch(e){}
  const cv=drawCard(o,r);
  sheet={kind:'prod',pid:pid,cv:cv,url:cv.toDataURL('image/png'),text:prodText(o,r),name:(r.p.nombre||'productor')};
  renderSheet();
}

/* ---------- modales ---------- */
function confirmHtml(){
  return `<h3>${esc(sheet.title)}</h3><p style="margin-bottom:6px">${esc(sheet.msg)}</p>${sheet.extra?`<p class="note">${esc(sheet.extra)}</p>`:''}<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn ${sheet.danger?'danger':'primary'}" data-act="${sheet.act}">${esc(sheet.ok)}</button></div>`;
}
function doneHtml(){
  const lo=sheet.lo;
  return `<h3>Listo, empaque para Distribución</h3><p style="margin-bottom:8px">El pedido ${esc(sheet.cod)} ya aparece en Código de Trazabilidad para armar las tarimas.</p>${lo&&lo.total?`<div class="panel info" role="status"><strong>Sobrante disponible para el siguiente pedido</strong><p class="note" style="margin-top:4px">${esc(lo.text)} · ${fmt(lo.total)} cajas</p></div>`:''}<div class="srow2"><button class="btn" data-act="closesheet">Seguir aquí</button><button class="btn primary" data-act="totraz:${esc(sheet.id||'')}">Ir a Código de Trazabilidad</button></div>`;
}
function dbHtml(){
  const n=dbRows().length;
  return `<h3>Descargar Base de Datos</h3><p class="note" style="margin-bottom:10px">Todo el histórico de las dos empresas (${fmt(n)} filas, una por productor y hoja). La columna de calidad indica Primera o Segunda 1.5; los calibres llevan solo el número.</p><div class="dbopts"><button class="btn primary" data-act="dbx">Excel decorado (.xlsx)</button><button class="btn" data-act="dbc">CSV</button><button class="btn" data-act="dbj">JSON (con tarimas)</button></div><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
/* ---------- editor de productores (solo administrador) ---------- */
const LS_LOPS='empaque-lista-ops';
function isAdmin(){if(ro)return false;if(!authUser||authUser.rol!=='admin')return false;if(!cfgOK())return true;return !!session&&roleOf(session.access_token)==='admin'}
function listaOps(){try{return JSON.parse(localStorage.getItem(LS_LOPS)||'[]')||[]}catch(e){return []}}
function listaOpsSave(a){try{localStorage.setItem(LS_LOPS,JSON.stringify(a))}catch(e){}}
function listaPersist(){try{localStorage.setItem(LS_LISTA,JSON.stringify(LISTA))}catch(e){}invalidateStats();setSync()}
function prodSet(c,n){
  c=Math.floor(+c);n=String(n||'').trim().replace(/\s+/g,' ').toUpperCase();
  if(!(c>0&&c<10000))return 'Escribe un código de 1 a 9999.';
  if(n.length<2)return 'Escribe el nombre del productor.';
  const i=LISTA.findIndex(x=>x.c===c);if(i<0)LISTA.push({c:c,n:n});else LISTA[i].n=n;
  LISTA.sort((a,b)=>a.c-b.c);listaPersist();
  listaOpsSave(listaOps().filter(x=>x.c!==c).concat([{t:'set',c:c,n:n}]));setSync();return '';
}
function prodDel(c){
  LISTA=LISTA.filter(x=>x.c!==c);listaPersist();
  listaOpsSave(listaOps().filter(x=>x.c!==c).concat([{t:'del',c:c}]));setSync();
}
async function flushLista(){
  const ops=listaOps();if(!ops.length||ro)return;
  for(const op of ops){
    if(op.t==='set')await sb('/rest/v1/productores?on_conflict=codigo',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{codigo:op.c,nombre:op.n}]});
    else await sb('/rest/v1/productores?codigo=eq.'+op.c,{method:'DELETE'});
  }
  listaOpsSave([]);
}
function prodRowsHtml(){
  const max=LISTA.reduce((m,x)=>Math.max(m,x.c),0),q=norm(sheet.q||'').trim().split(/\s+/).filter(Boolean);
  let h='',shown=0;
  for(let c=1;c<=max;c++){
    const x=LISTA.find(y=>y.c===c),n=x?x.n:'';
    if(sheet.only==='vac'&&n)continue;
    if(q.length){const t=norm(codeLabel(c,emp)+' '+c+' '+n);if(!q.every(w=>t.includes(w)))continue}
    shown++;
    if(sheet.edit===c){h+=`<div class="cprow edit"><span class="mono">${codeLabel(c,emp)}</span><input class="in txt" id="pe-n" type="text" autocomplete="off" autocapitalize="characters" value="${esc(n)}" placeholder="Nombre del productor"><button class="btn sm primary" data-act="psave:${c}">Guardar</button><button class="btn sm" data-act="pcancel">Cancelar</button></div>`;continue}
    h+=`<div class="cprow${n?'':' vac'}"><span class="mono">${codeLabel(c,emp)}</span><span class="pnm">${n?esc(n):'Espacio vacío'}</span><button class="btn sm" data-act="pedit:${c}">${n?'Editar':'Asignar'}</button>${n?`<button class="btn sm danger" data-act="pdel:${c}">${confirmKey==='pdel:'+c?'Toca otra vez':'Eliminar'}</button>`:''}</div>`;
  }
  return h||'<p class="note">Sin resultados.</p>';
}
function prodsHtml(){
  const max=LISTA.reduce((m,x)=>Math.max(m,x.c),0),vac=[];for(let c=1;c<=max;c++)if(!LISTA.some(x=>x.c===c))vac.push(c);
  const pend=listaOps().length;
  return `<h3>Productores</h3><p class="note" style="margin-bottom:8px">${LISTA.length} con código · ${vac.length} ${vac.length===1?'espacio vacío':'espacios vacíos'}${pend?' · '+pend+' cambios por enviar (se envían al sincronizar)':''}.</p>
<div class="padd"><input class="in" id="pn-c" type="text" inputmode="numeric" pattern="[0-9]*" data-digits="1" placeholder="Código" value="${vac[0]||max+1}" aria-label="Código nuevo"><input class="in txt" id="pn-n" type="text" autocomplete="off" autocapitalize="characters" placeholder="Nombre del productor" aria-label="Nombre del productor nuevo"><button class="btn primary sm" data-act="padd">Agregar</button></div>${sheet.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.err)}</p>`:''}
<label class="fld" for="pq" style="margin-top:8px"><span>Buscar por nombre o código</span><input class="in txt" id="pq" type="text" autocomplete="off" data-psq="1" value="${esc(sheet.q||'')}"></label>
<div class="seg" role="group" aria-label="Filtro" style="margin:8px 0"><button data-act="pfil:all" aria-pressed="${sheet.only!=='vac'}">Todos</button><button data-act="pfil:vac" aria-pressed="${sheet.only==='vac'}">Vacíos</button></div>
<div id="plist" class="plist">${prodRowsHtml()}</div><div class="srow2"><button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
const REGSPEC={
  transportistas:{t:'Transportistas',f:[['n','Nombre','Nombre del transportista'],['tel','Teléfono','Teléfono']],vac:'Aún no hay transportistas.'},
  vendedores:{t:'Vendedores',f:[['n','Nombre','Nombre del vendedor'],['tel','Teléfono','Teléfono']],vac:'Aún no hay vendedores.'},
  conductores:{t:'Conductores',f:[['n','Nombre','Nombre del conductor'],['placas','Placas','Placas']],vac:'Aún no hay conductores.'},
  cajas:{t:'Cajas thermo',f:[['n','Caja','Número o nombre de la caja'],['transporte','Transportista','Transportista dueño']],vac:'Aún no hay cajas.'}
};
function regsRowsHtml(){
  const sp=REGSPEC[sheet.rt],L=REG[sheet.rt],q=norm(sheet.q||'').trim().split(/\s+/).filter(Boolean);
  const rows=L.filter(x=>!q.length||q.every(w=>norm(sp.f.map(f=>x[f[0]]||'').join(' ')).includes(w)));
  if(!rows.length)return `<p class="note">${L.length?'Sin resultados.':sp.vac}</p>`;
  return rows.map(x=>{
    if(sheet.edit===x.id)return `<div class="rrow edit">${sp.f.map((f,i)=>`<input class="in txt" id="re-${i}" type="${f[0]==='tel'?'tel':'text'}" autocomplete="off" autocapitalize="characters" value="${esc(x[f[0]]||'')}" placeholder="${esc(f[2])}" aria-label="${esc(f[1])}">`).join('')}<div class="rbt"><button class="btn sm primary" data-act="rsave:${x.id}">Guardar</button><button class="btn sm" data-act="rcancel">Cancelar</button></div></div>`;
    return `<div class="rrow"><div class="rtx"><strong>${esc(x[sp.f[0][0]]||'—')}</strong><small>${esc(x[sp.f[1][0]]||'sin '+sp.f[1][1].toLowerCase())}</small></div><div class="rbt"><button class="btn sm" data-act="redit:${x.id}">Editar</button><button class="btn sm danger" data-act="rdel:${x.id}">${confirmKey==='rdel:'+x.id?'Toca otra vez':'Eliminar'}</button></div></div>`;
  }).join('');
}
function regsHtml(){
  const sp=REGSPEC[sheet.rt];
  const tabs=Object.keys(REGSPEC).map(k=>`<button data-act="rtab:${k}" aria-pressed="${sheet.rt===k}">${REGSPEC[k].t}</button>`).join('');
  const tr=sheet.rt==='cajas'?`<datalist id="rdl-t">${catList('transporte').map(v=>`<option value="${esc(v)}"></option>`).join('')}</datalist>`:'';
  return `<h3>Vendedores, transportistas, conductores y cajas</h3><div class="seg seg4" role="group" aria-label="Lista">${tabs}</div>
<p class="note" style="margin:8px 0">${REG[sheet.rt].length} registrados. Se usan en el encabezado de Código de Trazabilidad: al elegir vendedor, transportista o conductor se completan solos el teléfono o las placas; si no tiene, lo escribes ahí mismo.</p>
<div class="radd">${sp.f.map((f,i)=>`<input class="in txt" id="rn-${i}" type="${f[0]==='tel'?'tel':'text'}" autocomplete="off" autocapitalize="characters" placeholder="${esc(f[2])}" aria-label="${esc(f[1])}"${sheet.rt==='cajas'&&i===1?' list="rdl-t"':''}>`).join('')}<button class="btn primary sm" data-act="radd">Agregar</button></div>${tr}${sheet.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.err)}</p>`:''}
<label class="fld" for="rq" style="margin-top:8px"><span>Buscar</span><input class="in txt" id="rq" type="text" autocomplete="off" data-rsq="1" value="${esc(sheet.q||'')}"></label>
<div id="rlist" class="plist">${regsRowsHtml()}</div><div class="srow2"><button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
function regVals(prefix){const sp=REGSPEC[sheet.rt];return sp.f.map((f,i)=>{let v=String((document.getElementById(prefix+i)||{}).value||'').trim().replace(/\s+/g,' ');return f[0]==='tel'?v:v.toUpperCase()})}
function regSave(id){
  const sp=REGSPEC[sheet.rt],v=regVals(id?'re-':'rn-');
  if(v[0].length<1)return 'Escribe '+(sheet.rt==='cajas'?'el número de la caja.':'el nombre.');
  const L=REG[sheet.rt];
  if(id){const x=L.find(y=>y.id===id);if(!x)return '';sp.f.forEach((f,i)=>{x[f[0]]=v[i]})}
  else{
    if(L.some(y=>norm(y.n).trim()===norm(v[0]).trim()&&(sheet.rt!=='cajas'||norm(y.transporte||'')===norm(v[1]))))return 'Ya existe «'+v[0]+'». Usa Editar para cambiarlo.';
    const x={id:uid()};sp.f.forEach((f,i)=>{x[f[0]]=v[i]});L.push(x);L.sort((a,b)=>String(a.n).localeCompare(String(b.n),'es',{numeric:true}));
  }
  saveReg(true);return '';
}
async function syncReg(){
  try{
    if(REG.dirty&&!ro&&isAdmin()){
      await sb('/rest/v1/catalogos?on_conflict=clave',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{clave:'registros',updated_at:REG.ts,data:{vendedores:REG.vendedores,conductores:REG.conductores,cajas:REG.cajas,transportistas:REG.transportistas}}]});
      REG.dirty=false;saveReg(false);
    }
    const r=await sb('/rest/v1/catalogos?select=updated_at,data&clave=eq.registros');
    if(r&&r[0]&&r[0].data&&Number(r[0].updated_at)>(REG.ts||0)&&!REG.dirty){
      const d=r[0].data;REG.vendedores=d.vendedores||[];REG.conductores=d.conductores||[];REG.cajas=d.cajas||[];if(Array.isArray(d.transportistas))REG.transportistas=d.transportistas;REG.ts=Number(r[0].updated_at);saveReg(false);
    }
  }catch(e){}
}
function renderSheet(){
  if(!sheet){$sh.innerHTML='';return}
  let inner='';
  if(sheet.kind==='new')inner=newSheetHtml();
  else if(sheet.kind==='add'){inner=`<h3>Agregar productor</h3><label class="fld" for="s-q"><span>Nombre o número</span><input class="in txt" id="s-q" type="text" autocomplete="off" data-search="1" value="${esc(sheet.q||'')}"></label><div id="results">${resultsHtml(sheet.q||'')}</div><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`}
  else if(sheet.kind==='prod'){inner=`<h3>Resumen del productor</h3><img src="${sheet.url}" alt="Resumen de ${esc(sheet.name)}"><p class="note" style="margin-top:8px">También puedes mantener presionada la imagen para guardarla.</p><div class="srow2"><button class="btn primary" data-act="savepng">Guardar imagen</button><button class="btn" data-act="copysum">Copiar texto</button><button class="btn" data-act="closesheet">Cerrar</button></div>`}
  else if(sheet.kind==='login'){inner=loginHtml()}
  else if(sheet.kind==='syncinfo'){inner=syncInfoHtml()}
  else if(sheet.kind==='confirm'){inner=confirmHtml()}
  else if(sheet.kind==='done'){inner=doneHtml()}
  else if(sheet.kind==='db'){inner=dbHtml()}
  else if(sheet.kind==='prods'){inner=prodsHtml()}
  else if(sheet.kind==='regs'){inner=regsHtml()}
  else if(sheet.kind==='users'){inner=usersHtml()}
  else if(sheet.kind==='acct'){inner=acctHtml()}
  else if(sheet.kind==='copy'){inner=`<h3>Copiar ${esc(sheet.label||'texto')}</h3><p class="note" style="margin-bottom:8px">Tu navegador no dejó copiar solo. Selecciona el texto, cópialo y pégalo.</p><textarea id="copyta" readonly>${esc(sheet.text)}</textarea><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`}
  $sh.innerHTML=`<div class="scrim"><div class="sheet" role="dialog" aria-modal="true">${inner}</div></div>`;
  if(sheet.kind==='add'){const q=document.getElementById('s-q');if(q)q.focus()}
  if(sheet.kind==='copy'){const t=document.getElementById('copyta');if(t){t.focus();t.select()}}
  if(sheet.kind==='login'){const q=document.getElementById('lf-email');if(q&&!q.value)q.focus()}
}
function closeSheet(){sheet=null;renderSheet()}
async function copyText(text,label){
  try{await navigator.clipboard.writeText(text);toast((label||'Texto')+' copiado')}
  catch(e){sheet={kind:'copy',text:text,label:label};renderSheet()}
}

/* ---------- acciones ---------- */
function addProd(nombre,codigo,nota){
  const o=cur();if(!o||ro)return;const p=newProd(nombre,codigo,nota);o.productores.push(p);touch(o);
  openP=p.id;tab='captura';scrollToP=p.id;sheet=null;renderSheet();render();
  setTimeout(()=>{const el=document.getElementById('f-p-'+p.id+'-k24');if(el)el.focus({preventScroll:true})},350);
}
function swap(pid,dir){
  const o=cur();if(!o)return;const i=o.productores.findIndex(p=>p.id===pid),j=i+dir;
  if(i<0||j<0||j>=o.productores.length)return;
  const t=o.productores[i];o.productores[i]=o.productores[j];o.productores[j]=t;touch(o);scrollToP=pid;render();
}
function armConfirm(key){confirmKey=key;setTimeout(()=>{if(confirmKey===key){confirmKey=null;if(!sheet)softRender()}},4000)}
function goto(v){view=v;curId=null;showHdr=false;sheet=null;renderSheet();render();window.scrollTo(0,0)}
function onClick(e){
  const t=e.target;
  if(t.classList&&t.classList.contains('scrim')){closeSheet();return}
  const el=t.closest('[data-act]');if(!el||el.disabled)return;
  const parts=el.dataset.act.split(':'),act=parts[0],arg=parts[1];
  const o=cur();
  switch(act){
    case 'menu':goto('menu');break;
    case 'orders':case 'home':goto('orders');break;
    case 'traz':goto('traz');break;
    case 'stats':if(!statsF.emp)statsF.emp=emp;goto('stats');break;
    case 'emp':setEmp(arg);render();break;
    case 'new':if(ro)break;sheet={kind:'new',d:newDefaults()};renderSheet();break;
    case 'example':loadExample();break;
    case 'open':curId=arg;view='order';tab='captura';openP=null;showHdr=false;sheet=null;renderSheet();render();window.scrollTo(0,0);break;
    case 'topal':case 'totraz':curId=arg;view='trazo';sheet=null;renderSheet();render();window.scrollTo(0,0);break;
    case 'tab':tab=arg;render();break;
    case 'hdr':showHdr=!showHdr;render();break;
    case 'hdrz':trazHdr=!trazHdr;render();break;
    case 'p':openP=openP===arg?null:arg;scrollToP=openP;render();break;
    case 'addp':sheet={kind:'add',q:'',items:[]};renderSheet();break;
    case 'addleft':addLeftover();break;
    case 'pick':{const x=sheet&&sheet.items&&sheet.items[+arg];if(x)addProd(x.n,x.c||null)}break;
    case 'pickfree':{const q=(document.getElementById('s-q')||{}).value||'';if(q.trim())addProd(q.trim().toUpperCase(),null)}break;
    case 'up':swap(arg,-1);break;
    case 'down':swap(arg,1);break;
    case 'delp':
      if(confirmKey==='delp:'+arg){const oo=cur();if(oo){oo.productores=oo.productores.filter(p=>p.id!==arg);touch(oo);if(openP===arg)openP=null}confirmKey=null;render()}
      else{armConfirm('delp:'+arg);render()}
      break;
    case 'delorder':
      if(!o||ro)break;
      sheet={kind:'confirm',title:'Eliminar este pedido',msg:'¿Eliminar el pedido '+o.cod+'?'+(sheetsOf(o).length>1?' Se elimina también su hoja 1.5.':''),extra:'Esta acción no se puede deshacer desde la app.',ok:'Eliminar',act:'dodel',danger:true};renderSheet();break;
    case 'dodel':
      if(o&&!ro){const gone=o.variante==='1'?sheetsOf(o):[o];gone.forEach(x=>{x.deleted=true;touch(x)});invalidateStats();sheet=null;renderSheet();curId=null;view='orders';render();toast('Pedido eliminado')}
      break;
    case 'complete':
      if(o&&canComplete(o)){sheet={kind:'confirm',title:'Completar registro',msg:'¿Completar el registro de '+o.cod+'? Pasará a Código de Trazabilidad para armar las tarimas.',extra:'Puedes reabrirlo si necesitas corregir algo.',ok:'Completar registro',act:'docomplete'};renderSheet()}
      break;
    case 'docomplete':completeOrder();break;
    case 'reopen':reopenOrder();break;
    case 'share':openShare(arg);break;
    case 'savepng':if(sheet&&sheet.cv)sheet.cv.toBlob(b=>{if(b)saveFile('Empaque_'+(sheet.name||'productor').replace(/[^\w.-]+/g,'_')+'.png',b)},'image/png');break;
    case 'copysum':if(sheet)copyText(sheet.text,'Resumen');break;
    case 'copy':{if(!o)break;const b=blocks(o).find(x=>x.key===arg);if(b)copyText(b.text,b.title)}break;
    case 'copyv':{if(!o)break;const m={cod:o.cod,emb:o.emb,po:o.po,fecha:fmtUS(o.fecha),semana:String(o.semana),factura:o.factura};copyText(m[arg]||'',arg.toUpperCase())}break;
    case 'xlsx':exportRegistro(false);break;
    case 'mailx':exportRegistro(true);break;
    case 'xlsxz':exportTraz(false);break;
    case 'mailz':exportTraz(true);break;
    case 'addt':addTarima();break;
    case 'addl':addLine(arg);break;
    case 'dell':addDelLine(arg,parts[2]);break;
    case 'dupt':dupTarima(arg);break;
    case 'delt':delTarima(arg);break;
    case 'dbopen':sheet={kind:'db'};renderSheet();break;
    case 'dbx':exportDb('xlsx');break;
    case 'dbc':exportDb('csv');break;
    case 'dbj':exportDb('json');break;
    case 'vw':statsF.view=arg;saveStatsF();render();break;
    case 'dir':statsF.dir=statsF.dir==='desc'?'asc':'desc';saveStatsF();render();break;
    case 'per':statsF._per=!statsF._per;render();break;
    case 'clrd':statsF.desde='';invalidateStats();saveStatsF();render();break;
    case 'clrh':statsF.hasta='';invalidateStats();saveStatsF();render();break;
    case 'calo':openCal=openCal===arg?null:arg;render();break;
    case 'v15':{
      if(!o)break;
      const n=newOrder({emp:o.emp,anio:o.anio,cons:o.cons,cod:o.cod,emb:o.emb,po:o.po,fecha:o.fecha,semana:o.semana,customer:o.customer,domestic:o.domestic,factura:o.factura,variante:'1.5'});
      n.kgCaja=o.kgCaja;n.estado=o.estado;orders.push(n);touch(n);curId=n.id;view='order';tab='captura';openP=null;render();window.scrollTo(0,0);toast('Hoja #1.5 creada');
    }break;
    case 'create':{
      const d=sheet&&sheet.d;if(!d)break;const c=codesFrom(d);
      const n=newOrder({emp:c.emp,anio:c.anio,cons:c.cons,cod:c.cod,emb:c.emb,po:d.po,fecha:d.fecha,semana:num(d.semana)==null?d.semana:num(d.semana),customer:d.customer,domestic:d.domestic,factura:d.factura});
      orders.push(n);touch(n);curId=n.id;view='order';tab='captura';openP=null;sheet=null;renderSheet();render();window.scrollTo(0,0);
      const lo=prevLeftover(n);if(lo)toast('Hay sobrante de '+lo.from.cod+' para este pedido');
    }break;
    case 'sync':
      if(!cfgOK()){sheet={kind:'syncinfo'};renderSheet()}
      else if(!session){sheet={kind:'login',lf:{email:'',pw:''},err:''};renderSheet()}
      else doSync();
      break;
    case 'dologin':doLogin();break;
    case 'logout':session=null;ro=false;try{localStorage.removeItem(LS_SESSION)}catch(x){}setSync();render();toast('Sesión cerrada');break;
    case 'exportjson':exportBackup();break;
    case 'importjson':{const f=document.getElementById('impfile');if(f)f.click()}break;
    case 'closesheet':closeSheet();break;
    case 'regsopen':if(isAdmin()){sheet={kind:'regs',rt:'vendedores',q:'',edit:null,err:''};renderSheet()}break;
    case 'rtab':if(sheet&&REGSPEC[arg]){sheet.rt=arg;sheet.q='';sheet.edit=null;sheet.err='';renderSheet()}break;
    case 'radd':if(sheet&&isAdmin()){sheet.err=regSave(null);if(!sheet.err)toast('Guardado');renderSheet();const f=document.getElementById('rn-0');if(f&&!sheet.err)f.focus()}break;
    case 'redit':if(sheet&&isAdmin()){sheet.edit=arg;sheet.err='';renderSheet()}break;
    case 'rcancel':if(sheet){sheet.edit=null;renderSheet()}break;
    case 'rsave':if(sheet&&isAdmin()){sheet.err=regSave(arg);if(!sheet.err){sheet.edit=null;toast('Guardado')}renderSheet()}break;
    case 'rdel':if(sheet&&isAdmin()){if(confirmKey==='rdel:'+arg){confirmKey=null;REG[sheet.rt]=REG[sheet.rt].filter(x=>x.id!==arg);saveReg(true);toast('Eliminado')}else armConfirm('rdel:'+arg);renderSheet()}break;
    case 'lgtab':lg.tab=arg;lg.err='';lg.msg='';render();break;
    case 'lgin':doLogin();break;
    case 'lgreg':doRegister();break;
    case 'ulogout':case 'usersopen':case 'acctopen':case 'acsave':case 'uok':case 'urej':case 'ublk':case 'udel':userAct(act,arg,parts[2]);break;
    case 'ppick':pickProd(parts[1],parts[2],parts[3]);break;
    case 'prodsopen':if(isAdmin()){sheet={kind:'prods',q:'',only:'all',edit:null,err:''};renderSheet()}break;
    case 'pfil':if(sheet){sheet.only=arg;renderSheet()}break;
    case 'pedit':if(sheet&&isAdmin()){sheet.edit=+arg;sheet.err='';renderSheet();const i=document.getElementById('pe-n');if(i){i.focus();i.select()}}break;
    case 'pcancel':if(sheet){sheet.edit=null;renderSheet()}break;
    case 'psave':if(sheet&&isAdmin()){const v=(document.getElementById('pe-n')||{}).value;const m=prodSet(+arg,v);sheet.err=m;if(!m){sheet.edit=null;toast('Productor guardado')}renderSheet()}break;
    case 'padd':if(sheet&&isAdmin()){const c=(document.getElementById('pn-c')||{}).value,n=(document.getElementById('pn-n')||{}).value;const ex=LISTA.find(x=>x.c===+c);const m=ex?'El código '+c+' ya tiene a '+ex.n+'. Usa Editar para cambiarlo.':prodSet(c,n);sheet.err=m;if(!m){sheet.q='';toast('Productor agregado')}renderSheet()}break;
    case 'pdel':if(sheet&&isAdmin()){if(confirmKey==='pdel:'+arg){confirmKey=null;prodDel(+arg);toast('Código '+arg+' liberado')}else armConfirm('pdel:'+arg);renderSheet()}break;
  }
}
function addDelLine(pid,lid){delLine(pid,lid)}
function setBind(b,val,isNum){
  const o=cur();if(!o||ro)return;const p=b.split('.');const v=isNum?num(val):val;
  if(p[0]==='o'){o[p[1]]=v;if(p[1]==='cod'){const m=String(val).match(/(\d+)\s*$/);if(m)o.cons=+m[1]}if(p[1]==='fecha'&&val){o.semana=isoWeek(val);const s=document.getElementById('f-o-semana');if(s)s.value=o.semana}}
  else if(p[0]==='m'){o.manifiesto=o.manifiesto||{};o.manifiesto[p[1]]=v}
  else if(p[0]==='p'){const pr=o.productores.find(x=>x.id===p[1]);if(!pr)return;if(p[2]==='acc'){pr.acc=pr.acc||{};pr.acc[p[3]]=v}else pr[p[2]]=v}
  else if(p[0]==='z'){ensureTraz(mainOf(o)).hdr[p[1]]=val}
  else if(p[0]==='t'){const pl=ensureTraz(mainOf(o)).tarimas.find(x=>x.id===p[1]);if(pl)pl[p[2]]=val}
  else if(p[0]==='tl'){const pl=ensureTraz(mainOf(o)).tarimas.find(x=>x.id===p[1]);const l=pl&&pl.lines.find(x=>x.id===p[2]);if(l)l[p[3]]=p[3]==='cant'?v:val}
}
$app.addEventListener('click',onClick);
$sh.addEventListener('click',onClick);
$app.addEventListener('input',e=>{
  const el=e.target;const b=el.dataset&&el.dataset.bind;if(!b)return;
  if(el.dataset.digits){const d=el.value.replace(/\D+/g,'');if(d!==el.value)el.value=d}
  setBind(b,el.value,!!el.dataset.num);const o=cur();if(o)touch(o);
  if(view==='trazo')updateTraz();else updateDerived();
});
$app.addEventListener('change',e=>{const el=e.target;if(el&&el.dataset&&el.dataset.learn)onHdrChange(el)});
$sh.addEventListener('input',e=>{
  const el=e.target;if(!sheet)return;
  if(el.dataset.lf&&sheet.lf){sheet.lf[el.dataset.lf]=el.value;return}
  if(el.dataset.search){sheet.q=el.value;const r=document.getElementById('results');if(r)r.innerHTML=resultsHtml(el.value);return}
  const k=el.dataset.sf;if(!k||!sheet.d)return;
  sheet.d[k]=el.value;
  if(k==='fecha'&&el.value){const w=isoWeek(el.value),y=el.value.slice(0,4);sheet.d.semana=w;sheet.d.nEC=nextCons(sheet.d.emp,y);sheet.d.nPed=nextPed(sheet.d.emp,y,w);['semana','nEC','nPed'].forEach(f=>{const i=document.getElementById('n-'+f);if(i)i.value=sheet.d[f]})}
  if(k==='semana'){sheet.d.nPed=nextPed(sheet.d.emp,String(sheet.d.fecha).slice(0,4),el.value);const i=document.getElementById('n-nPed');if(i)i.value=sheet.d.nPed}
  const c=codesFrom(sheet.d),pv=document.getElementById('newprev');if(pv)pv.textContent=c.cod+' · '+c.emb;
});
$app.addEventListener('focusin',e=>{const t=e.target;if(t.dataset&&t.dataset.num)setTimeout(()=>{try{t.select()}catch(x){}},0)});
$app.addEventListener('keydown',e=>{
  if(e.key!=='Enter'||!e.target.matches||!e.target.matches('input.in')||e.target.dataset.psearch||e.target.dataset.lg)return;
  e.preventDefault();const scope=e.target.closest('.pf,.sumbox,.pal')||$app;
  const ins=[...scope.querySelectorAll('input.in')];const i=ins.indexOf(e.target);
  if(ins[i+1])ins[i+1].focus();else e.target.blur();
});

$sh.addEventListener('keydown',e=>{if(e.key==='Enter'&&sheet&&sheet.kind==='login'&&e.target.matches&&e.target.matches('input')){e.preventDefault();doLogin()}});
document.addEventListener('change',e=>{if(e.target&&e.target.id==='impfile')importBackup(e.target)});

/* buscador de productor dentro de las tarimas */
$app.addEventListener('focusin',e=>{const t=e.target;if(t.dataset&&t.dataset.psearch){closePdds();openPdd(t);setTimeout(()=>{try{t.select()}catch(x){}},0)}});
$app.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.psearch){t.dataset.dirty='1';openPdd(t)}});
$app.addEventListener('focusout',e=>{const t=e.target;if(t.dataset&&t.dataset.psearch)setTimeout(()=>{closePdds();settleProd(t)},220)});
$app.addEventListener('mousedown',e=>{if(e.target.closest&&e.target.closest('.pdd'))e.preventDefault()});
$app.addEventListener('keydown',e=>{
  const t=e.target;if(!(t.dataset&&t.dataset.psearch))return;
  if(e.key==='Escape'){closePdds();t.blur()}
  else if(e.key==='Enter'){e.preventDefault();const b=t.parentNode.querySelector('.pdi');if(b)b.click();else t.blur()}
});
$sh.addEventListener('input',e=>{
  const el=e.target;if(!sheet||(sheet.kind!=='prods'&&sheet.kind!=='regs'))return;
  if(el.dataset.digits){const d=el.value.replace(/\D+/g,'');if(d!==el.value)el.value=d}
  if(el.dataset.rsq){sheet.q=el.value;const r=document.getElementById('rlist');if(r)r.innerHTML=regsRowsHtml()}
  if(el.dataset.psq){sheet.q=el.value;const r=document.getElementById('plist');if(r)r.innerHTML=prodRowsHtml()}
});

$app.addEventListener('keydown',e=>{const t=e.target;if(t.dataset&&t.dataset.lg&&e.key==='Enter'){e.preventDefault();if(lg.tab==='reg')doRegister();else doLogin()}});
$sh.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.urol&&adminOnly()){const x=USERS.find(y=>y.id===t.dataset.urol);if(x){x.rol=t.value;if(!USERS.some(y=>y.rol==='admin'&&y.estado==='activo')){x.rol='admin';toast('Debe quedar al menos un administrador')}saveUsers();renderSheet()}}});

/* ---------- acceso de usuarios (candado local; con la base de datos se cambia por cuentas de Supabase) ---------- */
const LS_USERS='empaque-usuarios',LS_AUTH='empaque-auth';
const ROLES={admin:'Administrador',jefe:'Jefe de empaque',lector:'Solo lectura'};
let USERS=[],authUser=null,lg={tab:'in',err:'',msg:''},lgFails=0,lgLock=0;
const unorm=s=>norm(String(s||'')).replace(/\s+/g,' ').trim();
function loadUsers(){try{USERS=JSON.parse(localStorage.getItem(LS_USERS)||'[]')||[]}catch(e){USERS=[]}}
function saveUsers(){try{localStorage.setItem(LS_USERS,JSON.stringify(USERS))}catch(e){}}
async function hashPw(pw,salt){
  const s=salt+'|'+pw;
  try{if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return 'a'+Array.prototype.map.call(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}
  let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return 'b'+(h>>>0).toString(16);
}
const newSalt=()=>Math.random().toString(36).slice(2)+Date.now().toString(36);
async function ensureUsers(){
  if(USERS.length)return;
  const salt=newSalt();
  USERS=[{id:'u-1',user:'USUARIO 1',name:'USUARIO 1',salt:salt,hash:await hashPw('12345',salt),rol:'admin',estado:'activo',defPw:true,createdAt:Date.now()}];
  saveUsers();
}
function loadAuth(){
  if(cfgOK()){authUser=null;return}
  loadUsers();
  try{const a=JSON.parse(localStorage.getItem(LS_AUTH)||'null');authUser=(a&&USERS.find(x=>x.id===a.uid&&x.estado==='activo'))||null}catch(e){authUser=null}
}
loadAuth();
if(!cfgOK())ensureUsers().then(()=>{if(!authUser&&!document.getElementById('lg-u'))render()});
function authFromSession(){
  if(!cfgOK()||!session){return}
  const r=roleOf(session.access_token),em=session.email||'';
  authUser={id:'sb:'+em,user:em,name:em,rol:(r==='admin'||r==='jefe')?r:'lector',sinRol:!(r==='admin'||r==='jefe'||r==='lector'),estado:'activo',remote:true};
  applyRole();
}
function setAuth(u){authUser=u;try{if(u)localStorage.setItem(LS_AUTH,JSON.stringify({uid:u.id}));else localStorage.removeItem(LS_AUTH)}catch(e){}applyRole()}
const gv=id=>String((document.getElementById(id)||{}).value||'');
function loginView(){
  if(cfgOK())return `<main class="wrap lgw"><section class="hero"><img class="logo" src="${LOGO[emp]}" alt="Logotipo"><h1>${esc(APP_NAME)}</h1><div class="sub">Acceso para el personal autorizado</div></section>
<div class="panel" style="margin-top:12px"><label class="fld" for="lg-u"><span>Correo</span><input class="in txt" id="lg-u" data-lg="1" type="email" inputmode="email" autocomplete="username" autocapitalize="none" value="${esc(lg.u||'')}"></label>
<label class="fld" for="lg-p"><span>Contraseña</span><input class="in txt" id="lg-p" data-lg="1" type="password" autocomplete="current-password"></label>
${lg.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(lg.err)}</p>`:''}${lg.busy?'<p class="note">Entrando…</p>':''}
<button class="btn primary" style="width:100%;margin-top:8px" data-act="lgin"${lg.busy?' disabled':''}>Entrar</button><p class="note" style="margin-top:8px">Las cuentas las crea el administrador. Si no tienes una, pídesela.</p></div></main>`;
  const reg=lg.tab==='reg';
  return `<main class="wrap lgw"><section class="hero"><img class="logo" src="${LOGO[emp]}" alt="Logotipo"><h1>${esc(APP_NAME)}</h1><div class="sub">Acceso para el personal autorizado</div></section>
<div class="seg" role="group" aria-label="Acceso" style="margin:12px 0"><button data-act="lgtab:in" aria-pressed="${!reg}">Entrar</button><button data-act="lgtab:reg" aria-pressed="${reg}">Solicitar acceso</button></div>
<div class="panel">${reg?`<label class="fld" for="lg-n"><span>Nombre completo</span><input class="in txt" id="lg-n" data-lg="1" type="text" autocomplete="name" value="${esc(lg.n||'')}"></label>`:''}
<label class="fld" for="lg-u"><span>Usuario</span><input class="in txt" id="lg-u" data-lg="1" type="text" autocomplete="username" autocapitalize="characters" value="${esc(lg.u||'')}"></label>
<label class="fld" for="lg-p"><span>Contraseña</span><input class="in txt" id="lg-p" data-lg="1" type="password" autocomplete="${reg?'new-password':'current-password'}"></label>
${reg?`<label class="fld" for="lg-p2"><span>Repite la contraseña</span><input class="in txt" id="lg-p2" data-lg="1" type="password" autocomplete="new-password"></label><p class="note">Mínimo 6 caracteres. Tu solicitud queda pendiente hasta que el administrador la autorice.</p>`:''}
${lg.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(lg.err)}</p>`:''}${lg.msg?`<div class="panel info" role="status">${esc(lg.msg)}</div>`:''}
<button class="btn primary" style="width:100%;margin-top:8px" data-act="${reg?'lgreg':'lgin'}">${reg?'Enviar solicitud':'Entrar'}</button></div></main>`;
}
async function doLogin(){
  if(cfgOK()){
    const em=gv('lg-u').trim().toLowerCase(),pw=gv('lg-p');lg.u=em;
    if(!em||!pw){lg.err='Escribe tu correo y tu contraseña.';render();return}
    lg.busy=true;lg.err='';render();
    try{await login(em,pw);lg={tab:'in',err:'',msg:'',busy:false};authFromSession();view='menu';curId=null;render();window.scrollTo(0,0);doSync()}
    catch(e){lg.busy=false;lg.err=(e&&e.status>=400&&e.status<500)?'Correo o contraseña incorrectos.':'No se pudo conectar. Revisa tu internet e inténtalo otra vez.';render()}
    return;
  }
  if(Date.now()<lgLock){lg.err='Demasiados intentos. Espera unos segundos.';lg.msg='';render();return}
  const u=unorm(gv('lg-u')),p=gv('lg-p');lg.u=gv('lg-u');
  await ensureUsers();
  const x=USERS.find(y=>unorm(y.user)===u);
  if(!x||x.hash!==await hashPw(p,x.salt)){if(++lgFails>=5){lgLock=Date.now()+30000;lgFails=0}lg.err='Usuario o contraseña incorrectos.';lg.msg='';render();return}
  lgFails=0;
  if(x.estado==='pendiente'){lg.err='Tu solicitud sigue pendiente. El administrador debe autorizarla.';lg.msg='';render();return}
  if(x.estado!=='activo'){lg.err='Tu acceso no está autorizado. Habla con el administrador.';lg.msg='';render();return}
  lg={tab:'in',err:'',msg:''};setAuth(x);view='menu';curId=null;render();window.scrollTo(0,0);
}
async function doRegister(){
  const n=gv('lg-n').trim().replace(/\s+/g,' '),u=gv('lg-u').trim().replace(/\s+/g,' '),p=gv('lg-p'),p2=gv('lg-p2');
  lg.n=n;lg.u=u;lg.msg='';
  if(n.length<3)lg.err='Escribe tu nombre completo.';
  else if(u.length<3)lg.err='El usuario necesita al menos 3 caracteres.';
  else if(p.length<6)lg.err='La contraseña necesita al menos 6 caracteres.';
  else if(p!==p2)lg.err='Las contraseñas no coinciden.';
  else if(USERS.some(y=>unorm(y.user)===unorm(u)))lg.err='Ese usuario ya existe. Elige otro.';
  else{
    const salt=newSalt();USERS.push({id:uid(),user:u.toUpperCase(),name:n.toUpperCase(),salt:salt,hash:await hashPw(p,salt),rol:'lector',estado:'pendiente',createdAt:Date.now()});saveUsers();
    lg={tab:'in',err:'',msg:'Solicitud enviada. Cuando el administrador la autorice podrás entrar con tu usuario y contraseña.',u:u};
  }
  if(lg.err&&lg.msg==='')lg.msg='';
  render();
}
function pendingUsers(){return USERS.filter(x=>x.estado==='pendiente').length}
function usersHtml(){
  const me=authUser,pend=USERS.filter(x=>x.estado==='pendiente'),rest=USERS.filter(x=>x.estado!=='pendiente');
  const roleBtns=(id)=>['jefe','lector','admin'].map(r=>`<button class="btn sm" data-act="uok:${id}:${r}">${ROLES[r]}</button>`).join('');
  const p=pend.length?`<div class="sec">Pendientes de autorizar</div>`+pend.map(x=>`<div class="urow"><div class="rtx"><strong>${esc(x.name)}</strong><small>Usuario: ${esc(x.user)}</small></div><div class="ubt"><small>Autorizar como:</small><div class="rbt">${roleBtns(x.id)}</div><button class="btn sm danger" data-act="urej:${x.id}">Rechazar</button></div></div>`).join(''):'<p class="note">No hay solicitudes pendientes.</p>';
  const r=rest.map(x=>{
    const self=me&&x.id===me.id;
    return `<div class="urow"><div class="rtx"><strong>${esc(x.name)}${self?' (tú)':''}</strong><small>${esc(x.user)} · ${ROLES[x.rol]||x.rol} · ${x.estado==='activo'?'activo':x.estado}</small></div>${self?'':`<div class="ubt"><select class="in sel" data-urol="${x.id}" aria-label="Rol">${['admin','jefe','lector'].map(k=>`<option value="${k}"${x.rol===k?' selected':''}>${ROLES[k]}</option>`).join('')}</select><div class="rbt"><button class="btn sm" data-act="ublk:${x.id}">${x.estado==='activo'?'Bloquear':'Activar'}</button><button class="btn sm danger" data-act="udel:${x.id}">${confirmKey==='udel:'+x.id?'Toca otra vez':'Eliminar'}</button></div></div>`}</div>`;
  }).join('');
  return `<h3>Usuarios</h3><p class="note" style="margin-bottom:8px">Aquí autorizas a quien pide acceso y eliges su rol. Jefe de empaque captura y edita; Solo lectura únicamente consulta y descarga; Administrador además configura.</p>${p}<div class="sec">Usuarios</div>${r}<div class="srow2"><button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
function acctHtml(){
  const u=authUser;if(!u)return '';
  if(u.remote)return `<h3>Mi cuenta</h3><p class="note" style="margin-bottom:8px">${esc(u.user)} · ${u.sinRol?'Sin rol asignado (solo lectura)':ROLES[u.rol]}</p><p class="note">La contraseña y las cuentas se administran en Supabase (Authentication → Users).</p><div class="srow2"><button class="btn primary" data-act="closesheet">Cerrar</button></div>`;
  return `<h3>Mi cuenta</h3><p class="note" style="margin-bottom:8px">${esc(u.name)} · ${esc(u.user)} · ${ROLES[u.rol]||u.rol}</p>${u.defPw?'<div class="warnbox" role="alert"><strong>Cambia la contraseña inicial</strong><div>Esta cuenta todavía usa la contraseña de prueba.</div></div>':''}
<label class="fld" for="ac-c"><span>Contraseña actual</span><input class="in txt" id="ac-c" type="password" autocomplete="current-password"></label><label class="fld" for="ac-n"><span>Contraseña nueva</span><input class="in txt" id="ac-n" type="password" autocomplete="new-password"></label><label class="fld" for="ac-n2"><span>Repite la nueva</span><input class="in txt" id="ac-n2" type="password" autocomplete="new-password"></label>${sheet.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.err)}</p>`:''}
<div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button><button class="btn primary" data-act="acsave">Cambiar contraseña</button></div>`;
}
async function changePw(){
  const u=authUser;if(!u)return;
  const c=gv('ac-c'),n=gv('ac-n'),n2=gv('ac-n2');
  if(u.hash!==await hashPw(c,u.salt))sheet.err='La contraseña actual no es correcta.';
  else if(n.length<6)sheet.err='La nueva necesita al menos 6 caracteres.';
  else if(n!==n2)sheet.err='Las contraseñas nuevas no coinciden.';
  else{u.salt=newSalt();u.hash=await hashPw(n,u.salt);u.defPw=false;saveUsers();sheet=null;renderSheet();render();toast('Contraseña actualizada');return}
  renderSheet();
}
function adminOnly(){return authUser&&authUser.rol==='admin'}
function userAct(act,arg,rol){
  if(act==='ulogout'){if(cfgOK()){session=null;try{localStorage.removeItem(LS_SESSION)}catch(x){}}setAuth(null);view='menu';curId=null;sheet=null;renderSheet();lg={tab:'in',err:'',msg:''};render();return}
  if(act==='usersopen'){if(adminOnly()){sheet={kind:'users'};renderSheet()}return}
  if(act==='acctopen'){sheet={kind:'acct',err:''};renderSheet();return}
  if(act==='acsave'){changePw();return}
  if(!adminOnly())return;
  const x=USERS.find(y=>y.id===arg);if(!x)return;
  if(act==='uok'){x.estado='activo';x.rol=rol;toast(x.name+' autorizado')}
  else if(act==='urej'){USERS=USERS.filter(y=>y.id!==arg);toast('Solicitud rechazada')}
  else if(act==='ublk'){x.estado=x.estado==='activo'?'bloqueado':'activo'}
  else if(act==='udel'){if(confirmKey==='udel:'+arg){confirmKey=null;USERS=USERS.filter(y=>y.id!==arg)}else armConfirm('udel:'+arg)}
  if(!USERS.some(y=>y.rol==='admin'&&y.estado==='activo')){x.rol='admin';x.estado='activo';toast('Debe quedar al menos un administrador')}
  saveUsers();renderSheet();render();
}
if(typeof module!=='undefined'&&module.exports){module.exports={compute,blocks,prodText,isoWeek,codesFrom,searchLista,migrate,nextCons,nextPed,CAL,LISTA,setOrders:v=>{orders=v}}}
else{window.EMP_TEST={compute,leftoverOf,prevLeftover,trazCalc,aggregate,statsList,statsData,refPeriod,dbRows,dbCsv,buildRegistroWb,buildTrazWb,wbBlob,sheetsOf,mainOf,ensureTraz,orders:()=>orders,setOrders:v=>{orders=v;render()},statsF:()=>statsF,resolveProd,setEmp,go:v=>{view=v;render()}};loadLocal();loadSession();authFromSession();applyTheme();render();registerSW()}
})();
