
(function(){
'use strict';
let LISTA=[{"c":1,"n":"ESC. JESUS LAGUNES RGUEZ"},{"c":2,"n":"EMP.JESUS LAGUNES RGUEZ"},{"c":3,"n":"EL CIELO JESUS LAGUNES RGUEZ"},{"c":4,"n":"EMILIO NAVARRO SANTARROSAS"},{"c":5,"n":"NARCIZO BRAVO"},{"c":6,"n":"LUCIANO CALLES TELLO"},{"c":7,"n":"EZEQUIEL MELQUIADEZ"},{"c":8,"n":"BENIGNO LEON CARMONA"},{"c":9,"n":"FERNANDO GARCIA"},{"c":10,"n":"ERUBEY SALAZAR"},{"c":11,"n":"ELIU CORDOBA"},{"c":12,"n":"JOSE RODILES"},{"c":13,"n":"SAUL QUIÑONES"},{"c":14,"n":"ANTONIO LAGUNES"},{"c":15,"n":"VICTOR HUGO"},{"c":16,"n":"MIRANDA"},{"c":17,"n":"BELTRAN"},{"c":18,"n":"JORGE MARIN"},{"c":19,"n":"HECTOR SANCHEZ"},{"c":20,"n":"NOE BIELMA"},{"c":22,"n":"MANUEL MARTINEZ"},{"c":23,"n":"CITILAR"},{"c":27,"n":"ROBERTO ESPINOZA"},{"c":28,"n":"CANDIDO OLIVOS LARA"},{"c":29,"n":"LUIS VELAZQUEZ"},{"c":31,"n":"MACARIO SANCHEZ"},{"c":32,"n":"ROGELIO LOPEZ"},{"c":34,"n":"LUCIANO JUAREZ HERRERA"},{"c":36,"n":"ALEJANDRO VELA"},{"c":39,"n":"ANGEL SANTIAGO"},{"c":41,"n":"OSCAR BAUTISTA / PASTORA/EDITH BAUTISTA"},{"c":44,"n":"LORENZO CEJA"},{"c":46,"n":"ISAIAS NERY"},{"c":48,"n":"ANTONIO CERVANTES"},{"c":50,"n":"KARINA MARIN"},{"c":54,"n":"ANTONIO MOTA"},{"c":57,"n":"JOSE ANTONIO SANCHEZ M."},{"c":64,"n":"GABINO MORENO"},{"c":65,"n":"BENITO GARCIA"},{"c":66,"n":"BENITO MARTINEZ"},{"c":68,"n":"AMADO HERNANEZ"},{"c":70,"n":"MIGUEL ALCANTARA"},{"c":71,"n":"MARICELA VELA"},{"c":72,"n":"IGNACIO ACEVEDO/ EDGAR ACEVEDO"},{"c":73,"n":"ADALBERTO ROSALES"},{"c":74,"n":"VICTOR GUTIERREZ RODRIGUEZ"},{"c":75,"n":"ANICETO MINA SALAZAR"},{"c":80,"n":"FELIPE VAZQUEZ"},{"c":84,"n":"MISADEL VARGAS"},{"c":86,"n":"CIRO VALDIVIA ZAMORA"},{"c":89,"n":"JOSE FERNANDO RODRIGUEZ"},{"c":90,"n":"PEDRO FLORES HERNANDEZ"},{"c":91,"n":"VICTOR MANUEL PAVON"},{"c":105,"n":"ISMAEL SIVERIO DOMINGUEZ"},{"c":110,"n":"DORIS MENDOZA GARCIA"},{"c":114,"n":"EZEQUIEL USCANGA CANO"},{"c":115,"n":"HORACIO RODRIGUEZ"},{"c":118,"n":"PEDRO GALLARDO/ELIZETH GALLARDO"},{"c":129,"n":"SARA FLORES"},{"c":133,"n":"FIDEL CALLES TRUJILLO"},{"c":144,"n":"ROBERTO REBOLLAR BENITES"},{"c":147,"n":"OMAR JAVIER MORENO GARCIA"},{"c":148,"n":"GERARDO GARCIA"},{"c":152,"n":"MIRIAM JANET MENDEZ MUÑOZ"},{"c":153,"n":"ANAI PAVON CALLES"},{"c":154,"n":"MARGARITO JUAN"},{"c":155,"n":"EDGAR ACEVEDO"},{"c":156,"n":"SALATIEL"},{"c":159,"n":"REYES GARCIA"},{"c":162,"n":"ANDRES ALEJANDRO BRAVO BRAVO"},{"c":163,"n":"JOSE MARTIN PAVON RODRIGUEZ"},{"c":174,"n":"SERGIO VELA"},{"c":177,"n":"LAMBERTO MALPICA"},{"c":180,"n":"RIGOBERTO DEL VALLE"},{"c":186,"n":"JULIO FRANCO/MOISES FRANCO/EZEQUIEL LARA"},{"c":188,"n":"JULIAN REYES"},{"c":190,"n":"EDMUNDO LAGUNES"},{"c":191,"n":"AVIEL HERNANDEZ"},{"c":197,"n":"AYREL MINA VARGAS"},{"c":202,"n":"HUGO FLORES"},{"c":206,"n":"YOLANDA LAGUNES"},{"c":209,"n":"RIGOBERTO MORENO VALDIVIA"},{"c":212,"n":"PRIMITIVO TOLENTINO GONZALEZ"},{"c":213,"n":"ALEJANDRO MARTINEZ"},{"c":231,"n":"ALEJANDRO CARDENAS"},{"c":239,"n":"EVA M"},{"c":241,"n":"JULIAN MAPLICA"},{"c":242,"n":"MANUEL MEDINA"},{"c":252,"n":"TOÑO FLORES"}];
const CAL_STD=[{k:'ctn',l:'230 CTN'},{k:'c250',l:'250'},{k:'c230',l:'230'},{k:'c200',l:'200'},{k:'c175',l:'175'},{k:'c150',l:'150'},{k:'c110',l:'110'}];
/* el cartón de 10 lb se clasifica por su propia medida (63…28), no por tamaño */
const CAL_MM=[63,60,54,48,42,36,28].map(n=>({k:'m'+n,l:String(n)}));
const CAL=CAL_STD.concat(CAL_MM);
const isMM=k=>/^m\d/.test(String(k));
const LS='registro-empaque-v1';
/* v8.16: estos pesos salen del catálogo «Pesos y equivalencias» (engrane de Registro de empaque); aquí van sus valores de inicio */
let KG_DEF=17.8,SEG_KG=18,SOB_KG=17.8,TARA_KG=1.64;
const LS_EMP='registro-empaque-emp',LS_STATS='statsF-v1',LS_CAT='empaque-catalogos';
const APP_NAME='Empaque Vera Limes';
const LOGO={VL:'img/logo-vl.jpg',EC:'img/logo-ec.jpg'};
const ICO={VL:'img/ico-vl.png',EC:'img/ico-ec.png'};
const LOGO_F2={VL:'img/logo-vlusa.jpg',EC:'img/logo-jc.jpg'};
const EMPS={VL:{id:'VL',name:'Vera Limes',full:'Exportadora de Cítricos Vera Limes S.A. de C.V.',prov:'EXPORTADORA DE CITRICOS VERA LIMES S.A. DE C.V.',rol:'Principal',card:'#98c858',cardInk:'#10203a'},EC:{id:'EC',name:'Citrilar',full:'Exportadora Citrilar',prov:'EXPORTADORA CITRILAR SA DE CV',rol:'Secundaria',card:'#f08030',cardInk:'#2a1304'}};
const MARCAS={VL:['VERALIMES PRIMERA','VERALIMES UNO Y MEDIO'],EC:['CITRILAR PRIMERA','CITRILAR UNO Y MEDIO']};
/* Tipo de empaque del productor (se elige en Registro de empaque). RPC es el predeterminado. */
const TIPOS=[['RPC','RPC'],['CTN','CTN'],['CTN10','CTN 10 lb'],['PLT','PLT']];
const TIPO_L={RPC:'RPC',CTN:'CTN',CTN10:'CTN 10 lb',PLT:'PLT'};
function tipoOf(p){const t=p&&p.tipo;return TIPO_L[t]?t:'RPC'}
/* v5: un productor puede llevar varios tipos de empaque; cada tipo tiene su propio conteo acumulado en la línea.
   El primer tipo usa p.acc (como antes) y los demás p.accX[tipo]. */
function tiposOf(p){const a=[];(Array.isArray(p&&p.tipos)?p.tipos:[]).forEach(t=>{if(TIPO_L[t]&&a.indexOf(t)<0)a.push(t)});if(!a.length)a.push(tipoOf(p));return a}
function accOf(p,t,mk){
  if(t===tiposOf(p)[0]){if(mk&&!p.acc)p.acc={};return p.acc||{}}
  if(mk){p.accX=p.accX||{};p.accX[t]=p.accX[t]||{}}
  return (p.accX&&p.accX[t])||{};
}
function tiposTxt(p){return tiposOf(p).map(t=>TIPO_L[t]).join(' y ')}
/* v6: cada calidad (hoja 1 = primera, hoja 1.5 = uno y medio) lleva un manifiesto propio por tipo de empaque.
   Línea = calidad + tipo: de 1 (solo RPC de primera) hasta 2 x 4 = 8. */
const TIPO_K=TIPOS.map(x=>x[0]);
const TIPO_CH={RPC:'RPC',CTN:'CTN (cartón)',CTN10:'CTN (10 lb)',PLT:'PLT'};
const CALIDAD_L={'1':'Primera','1.5':'Uno y medio'},CALIDAD_S={'1':'1ª','1.5':'1½'};
const lineKey=(q,t)=>q+'|'+t;
function lineLabel(L,short){const a=String(L).split('|');return short?(CALIDAD_S[a[0]]||a[0])+' '+(TIPO_L[a[1]]||a[1]):(CALIDAD_L[a[0]]||a[0])+' · '+(TIPO_CH[a[1]]||a[1])}
/* la antigua fila 230 CTN siempre cuenta como cartón */
const lineType=(t0,k)=>k==='ctn'?'CTN':t0;
function lineOrd(a,b){const x=a.split('|'),y=b.split('|');return (x[0]===y[0]?0:(x[0]==='1'?-1:1))||(TIPO_K.indexOf(x[1])-TIPO_K.indexOf(y[1]))}
/* o.manifiesto queda como la suma de los manifiestos por tipo (lo usan pedidos viejos, el Excel y la sincronización) */
function syncManSum(o){const s={};Object.keys(o.manT||{}).forEach(t=>{const m=o.manT[t]||{};CAL.forEach(c=>{const v=num(m[c.k]);if(v!=null)s[c.k]=(s[c.k]||0)+v})});o.manifiesto=s}
/* "RPC", "RPC y CTN", "CTN 10 lb"… según los tipos que usan los productores del pedido */
function tipoText(o){
  const ks=[];(o.productores||[]).forEach(p=>tiposOf(p).forEach(t=>{if(ks.indexOf(t)<0)ks.push(t)}));
  if(!ks.length)ks.push('RPC');
  ks.sort((a,b)=>TIPOS.findIndex(x=>x[0]===a)-TIPOS.findIndex(x=>x[0]===b));
  return ks.map(k=>TIPO_L[k]).join(' y ');
}
/* la fila "230 CTN" ya no se usa; solo se muestra en pedidos viejos que la tienen capturada, para no esconder datos */
function legacyCtn(o){return !!(o&&((o.productores||[]).some(p=>p.acc&&p.acc.ctn!=null)||(o.manifiesto&&o.manifiesto.ctn!=null)))}
function usesMM(o){return !!o&&((o.productores||[]).some(p=>tiposOf(p).indexOf('CTN10')>=0)||!!(o.manT&&o.manT.CTN10))}
function calUI(o){const s=legacyCtn(o)?CAL_STD:CAL_STD.filter(c=>c.k!=='ctn');return usesMM(o)?s.concat(CAL_MM):s}
/* calibres que se capturan por tipo: CTN 10 lb con su propia medida (más los de tamaño que un pedido viejo ya tenga capturados) */
function calsFor(t,o,first){
  if(t==='CTN10'){
    const old=CAL_STD.filter(c=>c.k!=='ctn'&&((o.productores||[]).some(p=>tiposOf(p).indexOf('CTN10')>=0&&accOf(p,'CTN10')[c.k]!=null)||!!(o.manT&&o.manT.CTN10&&o.manT.CTN10[c.k]!=null)));
    return CAL_MM.concat(old);
  }
  return CAL_STD.filter(c=>c.k!=='ctn'||(first&&legacyCtn(o)));
}
const PCAL=['110','150','175','200','230','250','230 CTN'];
const PCAL_MM=CAL_MM.map(c=>c.l).reverse();
const PCAL_KEY={'230 CTN':'ctn','250':'c250','230':'c230','200':'c200','175':'c175','150':'c150','110':'c110'};
CAL_MM.forEach(c=>{PCAL_KEY[c.l]=c.k;PCAL_KEY[c.l+' mm']=c.k});
const HDR_FIELDS=[['factura','Factura#','factura'],['proveedor','Proveedor','proveedor'],['vendedor','Vendedor','vendedor'],['tel','Teléfono del vendedor','tel'],['poCliente','PO# cliente','poCliente'],['cliente','Cliente','cliente'],['pOrder','P. Order','pOrder'],['sello','Sello','sello'],['transporte','Transportista','transporte'],['telTransporte','Teléfono del transportista','telTransporte'],['conductor','Conductor','conductor'],['trailer','Trailer (núm. económico)','trailer'],['placas','Placas del tractor','placas'],['caja','Termo (# caja)','caja'],['placasCaja','Placas del termo','placasCaja']];
const HDR_REQ=['factura','poCliente','cliente','sello','transporte','conductor','placas','caja'];
const CAT_SEED={proveedor:['EXPORTADORA DE CITRICOS VERA LIMES S.A. DE C.V.','EXPORTADORA CITRILAR SA DE CV'],vendedor:['CLAUDIA MORALES OROZCO'],cliente:['VERALIMES USA','VILLAMEX','CITRICOS J&C LLC'],transporte:['JESUS LAGUNES RODRIGUEZ'],conductor:['JOSE FRANCISCO ROSAS DEL RIO']};
const $app=document.getElementById('app');
const $sh=document.getElementById('sheetRoot');

let orders=[],dirty=new Set(),curId=null,tab='captura',openP=null;
let listAll=false,showHdr=false,sheet=null,confirmKey=null,needsRender=false,scrollToP=null,flushT=null,flushing=false,focusId=null,trazHdr=true,openCal=null;
let emp='VL',view='menu',ro=false;
let statsF=loadStatsF();
try{const e=localStorage.getItem(LS_EMP);if(e==='VL'||e==='EC')emp=e}catch(x){}
function loadStatsF(){
  const d={emp:null,cal:'ALL',year:'ALL',month:'ALL',week:'ALL',desde:'',hasta:'',view:'rend',dir:'desc',_cache:null,_per:false};
  try{
    const j=JSON.parse(localStorage.getItem(LS_STATS)||'null');
    if(j&&typeof j==='object'){
      if(j.emp==='VL'||j.emp==='EC'||j.emp==='ALL')d.emp=j.emp;
      if(['ALL','1','1.5'].indexOf(String(j.cal))>=0)d.cal=String(j.cal);
      if(/^\d{4}$/.test(String(j.year)))d.year=String(j.year);
      if(/^(0[1-9]|1[0-2])$/.test(String(j.month)))d.month=String(j.month);
      if(/^\d{4}-\d{2}-\d{2}$/.test(String(j.desde||'')))d.desde=j.desde;
      if(/^\d{4}-\d{2}-\d{2}$/.test(String(j.hasta||'')))d.hasta=j.hasta;
      if(['rend','kilos','cal'].indexOf(j.view)>=0)d.view=j.view;
      if(j.dir==='asc')d.dir='asc';
      if(j.tab==='fin'||j.tab==='bi')d.tab=j.tab;if(['res','cxc','cxp','fin','emb','pre','ctb','bi'].indexOf(j.ftab)>=0)d.ftab=j.ftab;if(j.cxG==='grp')d.cxG='grp';if(j.pmode==='M')d.pmode='M';if(typeof j.csub==='string')d.csub=j.csub;if(['fecha','neto','margen'].indexOf(j.esort)>=0)d.esort=j.esort;if(/^\d{4}-S\d{2}$/.test(String(j.week||'')))d.week=j.week;if(typeof j.kpi==='string')d.kpi=j.kpi;if(['util','margen','pago'].indexOf(j.fsort)>=0)d.fsort=j.fsort;
    }
  }catch(e){}
  if(d.year==='ALL')d.month='ALL';
  if(d.desde&&d.hasta&&d.desde>d.hasta){const t=d.desde;d.desde=d.hasta;d.hasta=t}
  return d;
}
function saveStatsF(){try{const s=statsF;localStorage.setItem(LS_STATS,JSON.stringify({emp:s.emp,cal:s.cal,year:s.year,month:s.month,week:s.week,desde:s.desde,hasta:s.hasta,view:s.view,dir:s.dir,tab:s.tab,ftab:s.ftab,kpi:s.kpi,fsort:s.fsort,cxG:s.cxG,pmode:s.pmode,esort:s.esort,csub:s.csub}))}catch(e){}}
const parCache=new Map();
let dataVer=0;
function invalidateStats(){dataVer++;statsF._cache=null;statsF._acc=null;statsF._jug=null;parCache.clear()}
const LS_SKIN='empaque-apariencia';
let skin=(()=>{try{return localStorage.getItem(LS_SKIN)||(window.EMPAQUE_CONFIG&&window.EMPAQUE_CONFIG.APARIENCIA)||'clasico'}catch(e){return 'clasico'}})();
function applyTheme(){const r=document.documentElement;r.dataset.emp=emp;r.dataset.skin=skin;const m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute('content',skin==='marco'?'#15263f':EMPS[emp].card)}
function setEmp(e){emp=e;try{localStorage.setItem(LS_EMP,e)}catch(x){}applyTheme()}

/* ---------- utilidades ---------- */
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=v=>{if(v===null||v===undefined||v==='')return null;const n=typeof v==='number'?v:parseFloat(String(v).replace(/,/g,''));return isFinite(n)?n:null};
const n0=v=>num(v)||0;
const fmt=(v,d)=>v==null?'–':v.toLocaleString('es-MX',{minimumFractionDigits:d||0,maximumFractionDigits:d||0});
const clone=o=>JSON.parse(JSON.stringify(o));
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
const pad=(n,l)=>String(n).padStart(l,'0');
function todayISO(){const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1,2)+'-'+pad(d.getDate(),2)}
function isoWeek(s){const d=new Date(s+'T12:00:00');if(isNaN(d))return '';const t=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));const day=t.getUTCDay()||7;t.setUTCDate(t.getUTCDate()+4-day);const y0=new Date(Date.UTC(t.getUTCFullYear(),0,1));return Math.ceil(((t-y0)/86400000+1)/7)}
function fmtDate(s){if(!s)return '';const p=s.split('-');return p.length===3?p[2]+'/'+p[1]+'/'+p[0]:s}
function fmtUS(s){if(!s)return '';const p=s.split('-');return p.length===3?p[1]+'/'+p[2]+'/'+p[0]:s}

/* ---------- v8.4.1 · ver contraseña (ojo) ---------- */
const EYE_ON='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const EYE_OFF='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 5.2A10.6 10.6 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.5 6.6A17 17 0 0 0 2 12s3.6 7 10 7a10 10 0 0 0 4.4-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';
function PWI(inp){return '<span class="pwbox">'+inp+'<button type="button" class="eye" data-eye="1" aria-label="Mostrar contraseña" aria-pressed="false">'+EYE_ON+'</button></span>'}
document.addEventListener('mousedown',e=>{if(e.target.closest&&e.target.closest('[data-eye]'))e.preventDefault()});
document.addEventListener('click',e=>{
  const b=e.target.closest&&e.target.closest('[data-eye]');if(!b)return;
  const inp=b.parentNode.querySelector('input');if(!inp)return;
  const show=inp.type==='password';
  inp.type=show?'text':'password';
  b.setAttribute('aria-pressed',show?'true':'false');
  b.setAttribute('aria-label',show?'Ocultar contraseña':'Mostrar contraseña');
  b.innerHTML=show?EYE_OFF:EYE_ON;
  try{inp.focus({preventScroll:true});const l=inp.value.length;inp.setSelectionRange(l,l)}catch(x){}
},true);

let tt;function toast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),2400)}
const cur=()=>orders.find(o=>o.id===curId&&!o.deleted);
const visible=()=>orders.filter(o=>!o.deleted);
const mine=()=>visible().filter(o=>o.emp===emp);

/* ---------- datos ---------- */
function newOrder(f){return{id:uid(),v:5,emp:f.emp,anio:f.anio,cons:f.cons,cod:f.cod,emb:f.emb,po:f.po||'',fecha:f.fecha,semana:f.semana,customer:f.customer||'',domestic:f.domestic||'',factura:f.factura||'',variante:f.variante||'1',kgCaja:KG_DEF,manifiesto:{},manT:{},productores:[],estado:'proceso',traz:null,ejemplo:!!f.ejemplo,createdAt:Date.now(),updatedAt:Date.now(),deleted:false}}
/* Los pedidos de versiones anteriores se convierten al formato nuevo al abrirse. */
function migrate(o){
  if(o.v==null||o.v<2){
    const m=String(o.ec||'').match(/^(EC|VL)-(\d{4})-(\d+)$/);
    o.emp=o.emp||(m?m[1]:'EC');
    o.anio=o.anio||(m?+m[2]:(+String(o.fecha||'').slice(0,4)||new Date().getFullYear()));
    o.cons=o.cons!=null?o.cons:(m?+m[3]:null);
    o.cod=o.cod||(o.cons!=null?o.emp+'-'+o.cons:String(o.ec||''));
    o.emb=o.emb||o.jc||'';
    delete o.ec;delete o.jc;
  }
  if(!o.estado)o.estado='proceso';
  if(o.traz===undefined)o.traz=null;
  if((o.v||0)<4){
    /* antes todos los productores compartían un solo contador aunque tuvieran distinto tipo.
       Si el pedido mezcla tipos, se rehace el acumulado por tipo conservando exactamente las cajas de cada productor. */
    const ps=o.productores||[],zero=()=>{const z={};CAL.forEach(c=>z[c.k]=0);return z};
    if(new Set(ps.map(p=>tipoOf(p))).size>1){
      let prev=zero();const run={};
      ps.forEach(p=>{
        const tp=tipoOf(p),r=run[tp]=run[tp]||zero(),acc=p.acc||{},na={};
        CAL.forEach(c=>{const v=num(acc[c.k]),eff=v==null?prev[c.k]:v,d=eff-prev[c.k];prev[c.k]=eff;r[c.k]+=d;if(v!=null||d!==0)na[c.k]=r[c.k]});
        p.acc=na;delete p.accx;
      });
    }
    ps.forEach(p=>{
      p.tipos=[tipoOf(p)];
      if(p.accx){const nx={};Object.keys(p.accx).forEach(k=>{nx[k.indexOf(':')<0?tipoOf(p)+':'+k:k]=p.accx[k]});p.accx=nx}
    });
  }
  if((o.v||0)<5&&!o.manT){
    /* v6: el manifiesto único pasa al tipo de empaque que usa el pedido (RPC si mezcla tipos); la fila 230 CTN va a cartón */
    const m=o.manifiesto||{},ts=[];(o.productores||[]).forEach(p=>tiposOf(p).forEach(t=>{if(ts.indexOf(t)<0)ts.push(t)}));
    const t0=ts.length===1?ts[0]:'RPC',mt={};
    CAL.forEach(c=>{const v=num(m[c.k]);if(v==null)return;const t=lineType(t0,c.k);(mt[t]=mt[t]||{})[c.k]=v});
    o.manT=mt;
  }
  o.v=5;
}
/* v8.25.2 · el REEMPAQUE guardaba acumulados dentro del contador de la línea (renglón 1) y a los renglones ya capturados se les sumaba.
   Ahora guarda solo sus cajas. Si los renglones de abajo ya traían sumado el reempaque, se les resta; si se capturaron sin él, se dejan igual. */
function rmpOwnMig(o){
  if(!o||o.rmpOwn||!Array.isArray(o.productores))return;o.rmpOwn=1;
  const P=o.productores;P.forEach((row,ri)=>{if(!row||!row.rmp)return;
    const amt={};
    tiposOf(row).forEach(tp=>{const pv={};for(let j=0;j<ri;j++){const q=P[j];if(q.rmp||tiposOf(q).indexOf(tp)<0)continue;const a=accOf(q,tp);CAL.forEach(c=>{const v=num(a[c.k]);if(v!=null)pv[c.k]=v})}
      const a=accOf(row,tp),m=amt[tp]={};CAL.forEach(c=>{const v=num(a[c.k]);if(v==null)return;const own=Math.max(0,v-(pv[c.k]||0));m[c.k]={own:own,pv:pv[c.k]||0};a[c.k]=own||null})});
    let incl=true,any=false;
    Object.keys(amt).forEach(tp=>CAL.forEach(c=>{const x=amt[tp][c.k];if(!x||!x.own)return;for(let j=ri+1;j<P.length;j++){const q=P[j];if(q.rmp||tiposOf(q).indexOf(tp)<0)continue;const v=num(accOf(q,tp)[c.k]);if(v==null)continue;any=true;if(v<x.pv+x.own)incl=false;break}}));
    if(any&&incl)Object.keys(amt).forEach(tp=>CAL.forEach(c=>{const x=amt[tp][c.k];if(!x||!x.own)return;for(let j=ri+1;j<P.length;j++){const q=P[j];if(q.rmp||tiposOf(q).indexOf(tp)<0)continue;const b=accOf(q,tp);const v=num(b[c.k]);if(v!=null)b[c.k]=v-x.own}}));
  });
}
function normOrders(){orders.forEach(o=>{if(o&&o.v!==5)migrate(o);rmpOwnMig(o);/* v8.21.3: REEMPAQUE sin cajas ni kilos */if(o&&Array.isArray(o.productores))o.productores.forEach(p=>{if(p&&p.rmp)rmpFill(p,false)});/* tarimas viejas guardaban «54 mm» */if(o&&o.traz&&o.traz.tarimas)o.traz.tarimas.forEach(p=>(p.lines||[]).forEach(l=>{if(/^\d+\s*mm$/i.test(String(l.cal||'')))l.cal=String(l.cal).replace(/\s*mm$/i,'')}))})}
function newProd(nombre,codigo,nota){return{id:uid(),nombre:nombre||'',codigo:codigo==null?null:codigo,tipo:'RPC',tipos:['RPC'],k24:null,k18:null,kilos:null,acc:{},seg:null,tor:null,des:null,jug:null,nota:nota||''}}

function compute(o){
  const W=pesosOf(o),kg=W.campo,zero=()=>{const z={};CAL.forEach(c=>z[c.k]=0);return z};
  /* prev: acumulado combinado de todos los tipos (lo usan manifiesto, Excel y trazabilidad); prevT: contador de cada tipo */
  let prev=zero();const prevT={};
  const rows=[];const tot={k24:0,k18:0,kilos:0,seg:0,cera:0,tor:0,des:0,jug:0,exp:0,kgE:0};
  (o.productores||[]).forEach(p=>{
    const ts=tiposOf(p),byT={},byW={},delta=zero(),before=Object.assign({},prev),eff={};let t=0,err=false,kgE=0;
    ts.forEach(tp=>{
      /* v8.25.2: el REEMPAQUE no pasa por el contador de la línea; sus casillas son sus propias cajas y no mueven el acumulado de los demás */
      const own=!!p.rmp,pv=own?zero():(prevT[tp]||zero()),a=accOf(p,tp),e={},d={};let tt=0,tk=0;
      /* v8.14: cada caja pesa lo de su tipo de empaque (la vieja fila 230 CTN pesa como CTN) */
      CAL.forEach(c=>{const v=num(a[c.k]);e[c.k]=v==null?pv[c.k]:v;d[c.k]=e[c.k]-pv[c.k];if(d[c.k]<0)err=true;tt+=d[c.k];delta[c.k]+=d[c.k];if(d[c.k]){const wt=lineType(tp,c.k);byW[wt]=(byW[wt]||0)+d[c.k];tk+=d[c.k]*W[wt]}});
      byT[tp]={before:Object.assign({},pv),eff:e,delta:d,t:tt,kg:tk};if(!own)prevT[tp]=e;t+=tt;kgE+=tk;
    });
    CAL.forEach(c=>{eff[c.k]=prev[c.k]+delta[c.k]});
    prev=Object.assign({},eff);
    const kilos=num(p.kilos);const campo=kilos==null?null:kilos/kg;
    /* v8.14 · Rendimiento de primeras: kilos empacados (cajas × peso de su tipo de empaque) entre kilos recibidos.
       eqv = cajas empacadas convertidas a cajas campo; la diferencia también resta las cajas ya convertidas (igual que en el Excel). */
    const eqv=kgE/kg;
    const dif=campo==null?null:campo-eqv-n0(p.seg)-n0(p.cera)-n0(p.tor)-n0(p.des)-n0(p.jug);
    const rend=(campo&&campo>0)?eqv/campo:null;
    rows.push({p,before,eff,delta,t,err,campo,dif,eqv,kgE,byW,rend,byT,tipos:ts,tipo:ts.length===1?ts[0]:tiposTxt(p)});
    tot.kgE+=kgE;tot.k24+=n0(p.k24);tot.k18+=n0(p.k18);tot.kilos+=n0(p.kilos);tot.seg+=n0(p.seg);tot.cera+=n0(p.cera);tot.tor+=n0(p.tor);tot.des+=n0(p.des);tot.jug+=n0(p.jug);tot.exp+=t;
  });
  /* cajas empacadas por tipo de empaque (la antigua fila 230 CTN cuenta como CTN) */
  const byTipo={};
  rows.forEach(r=>r.tipos.forEach(t0=>{const d=r.byT[t0].delta;CAL.forEach(c=>{const tp=lineType(t0,c.k),b=byTipo[tp]=byTipo[tp]||{};b[c.k]=(b[c.k]||0)+d[c.k];b.t=(b.t||0)+d[c.k]})}));
  /* manifiesto propio de cada tipo de empaque; el manifiesto por calibre es la suma de los tipos */
  const mt=o.manT||(o.manifiesto?{RPC:o.manifiesto}:{}),manBy={};
  TIPO_K.forEach(t=>{const m=mt[t]||{},x={};let any=false,tt=0;CAL.forEach(c=>{const v=num(m[c.k]);x[c.k]=v;if(v!=null){any=true;tt+=v}});if(any){x.t=tt;manBy[t]=x}});
  const man={};let manT=0,finT=0;
  CAL.forEach(c=>{let v=null;Object.keys(manBy).forEach(t=>{if(manBy[t][c.k]!=null)v=(v||0)+manBy[t][c.k]});man[c.k]=v;manT+=v||0;finT+=prev[c.k]});
  /* v8.21.6: lo que salió de esta hoja por reempaque ya no se embarca aquí (manifiesto, empacado y tarimas esperadas) */
  if(o&&o.id&&typeof rmpOutsOf==='function'&&Array.isArray(orders))rmpOutsOf(o.id).forEach(x=>{const b=byTipo[x.tipo0];if(!b)return;const v=Math.min(n0(x.n0),b[x.ck0]||0);if(v>0){b[x.ck0]-=v;b.t-=v}});
  const tipos=TIPO_K.filter(k=>byTipo[k]&&byTipo[k].t>0);
  const lines=TIPO_K.filter(k=>tipos.indexOf(k)>=0||manBy[k]);
  if(!lines.length)lines.push('RPC');
  return{rows,tot,final:prev,man,manT,finT,kg,W,byTipo,tipos,manBy,lines};
}

function codeLabel(c,e){return c?((e||emp)+'-'+pad(c,3)):'sin código'}

/* ---------- v8.9.1 · tarimas que pasan al próximo viaje ----------
   El jefe de empaque manda una tarima de primera (completa o no) al siguiente pedido de la misma empresa.
   La tarima se mueve tal cual; sus líneas guardan de qué pedido vienen (l.de) y siguen con el código de su productor.
   En el pedido nuevo entran juntas en el renglón SOBRANTES (sob2) con el detalle por productor y tarima (sobAp), sin kilos ni pago:
   esas cajas ya se pagaron en el viaje donde se recibieron. */
let _SENT=null;
function sentIdx(){
  if(_SENT&&_SENT.v===dataVer&&_SENT.n===orders.length)return _SENT.m;
  const m=new Map();
  /* v8.25.5: una tarima reenviada lleva cajas de varios viajes (cada línea guarda el suyo en l.de) */
  visible().forEach(o=>{const t=o.traz;if(t&&Array.isArray(t.tarimas))t.tarimas.forEach(p=>{if(!p.from||!p.from.oid)return;(p.lines||[]).forEach(l=>{if(!l.de)return;const n=n0(l.cant),ck=PCAL_KEY[l.cal];if(!(n>0)||!ck)return;let a=m.get(l.de);if(!a)m.set(l.de,a=[]);a.push({to:o,p:p,l:l,tipo:palTipo(p),ck:ck,n:n,key:l.prod})})});
    /* v8.25.5: sobrantes en piso que pasaron a otro viaje sin tarima */
    const r=sobRow(o);if(r&&r.sobAp)r.sobAp.forEach(a=>{if(!a.piso||!(n0(a.n)>0)||!a.de)return;let x=m.get(a.de);if(!x)m.set(a.de,x=[]);x.push({to:o,p:null,l:null,a:a,piso:true,tipo:a.tipo,ck:a.ck,n:n0(a.n),key:a.key})});
    /* v8.26.4: cajas de una tarima recibida que se reempacaron en otro viaje: ya no están en el viaje de origen (están en el REEMPAQUE que las recibió) */
    (o.productores||[]).forEach(p=>{if(!p.rmp)return;(p.sobAp||[]).forEach(a=>(a.palTk||[]).forEach(t=>{const n=n0(t.cant),ck=PCAL_KEY[t.cal];if(!t.de||!(n>0)||!ck)return;let x=m.get(t.de);if(!x)m.set(t.de,x=[]);x.push({to:mainOf(o),p:null,l:null,a:a,rmp:true,tipo:a.palTipo||a.tipo0,ck:ck,n:n,key:t.prod})}))})});
  _SENT={v:dataVer,n:orders.length,m:m};return m;
}
function sentOf(o){return (o&&sentIdx().get(o.id))||[]}
/* regla nueva: todo lo empacado de primera va en tarima; lo que sobra se manda en tarima al próximo viaje.
   Los pedidos que se completaron con versiones anteriores (sin la marca sobPal) siguen con el sobrante suelto de antes */
function sobPalMode(o){return !!o&&o.variante==='1'&&(!!o.sobPal||o.estado!=='completo'||sentOf(o).length>0)}
function sentLeft(o,S){
  const L={},LT={},to=[],pals=[];let total=0,fl=0,rm=0;
  S.forEach(s=>{const tp=lineType(s.tipo,s.ck);(LT[tp]=LT[tp]||{})[s.ck]=(LT[tp][s.ck]||0)+s.n;L[s.ck]=(L[s.ck]||0)+s.n;total+=s.n;if(to.indexOf(s.to.cod)<0)to.push(s.to.cod);if(s.p&&pals.indexOf(s.p)<0)pals.push(s.p);if(s.piso)fl+=s.n;if(s.rmp)rm+=s.n});
  const ks=Object.keys(LT),tag=ks.length>1||(ks[0]&&ks[0]!=='RPC');
  const cal=ks.map(t=>(tag?TIPO_L[t]+' ':'')+CAL.filter(c=>LT[t][c.k]).map(c=>c.l+': '+fmt(LT[t][c.k])).join(' · ')).join(' | ');
  return{L:L,LT:LT,total:total,pal:true,to:to,nPal:pals.length,text:cal+' · '+[pals.length?pals.length+(pals.length===1?' tarima':' tarimas'):'',fl?fmt(fl)+' en piso':'',rm?fmt(rm)+' reempacadas':''].filter(Boolean).join(' y ')+' a '+to.join(', ')};
}
/* siguiente pedido de la misma empresa para las tarimas de o: el que ya recibe sus tarimas, o el consecutivo que sigue (en proceso) */
function nextTripOf(o){
  const S=sentOf(o).filter(x=>!x.rmp);if(S.length)return mainOf(S[0].to);
  return visible().find(x=>x.emp===o.emp&&x.variante==='1'&&+x.anio===+o.anio&&(x.cons||0)===(o.cons||0)+1&&x.estado!=='completo')||null;
}
/* tarimas recibidas en este pedido que todavía no se importan al renglón SOBRANTES */
/* v8.25.5: viaje de origen de cada línea de una tarima recibida (una tarima reenviada lleva líneas de varios viajes) */
function lineFrom(p,l){const f=(p&&p.from)||{},same=l.de===f.oid;return {oid:l.de,cod:l.deCod||(same?f.cod:'')||'otro viaje',n:l.dePn||(same?f.n:null)}}
function sobRow(o){return (o.productores||[]).find(p=>p.sob2&&!p.rmp)}
function sobPend(o){
  const m=mainOf(o),t=m.traz;if(!t||!Array.isArray(t.tarimas))return [];
  const r=sobRow(m),got=new Set(((r&&r.sobAp)||[]).map(a=>a.lid));
  const out=[];t.tarimas.forEach((p,i)=>{if(!p.from)return;const ls=(p.lines||[]).filter(l=>l.de&&n0(l.cant)>0&&PCAL_KEY[l.cal]&&!got.has(l.id));if(ls.length)out.push({p:p,i:i,ls:ls,n:ls.reduce((a,l)=>a+n0(l.cant),0)})});
  return out;
}
/* tarima elegible para el próximo viaje: tiene cajas, todas de primera (la segunda 1.5 se va a Juguera al cerrar la semana) y no viene de otro viaje */
function palNextOk(p){const ls=(p.lines||[]).filter(l=>n0(l.cant)>0);return ls.length>0&&!p.from&&ls.every(l=>lineQ(p,l)==='1'&&PCAL_KEY[l.cal]&&!l.de)}
function palCarried(p){return !!(p&&p.from&&(p.lines||[]).some(l=>l.de))}
function palOwnLines(p){return (p.lines||[]).filter(l=>!l.de&&n0(l.cant)>0)}
/* cómo queda el viaje contra su manifiesto si sale la tarima p (solo avisa) */
function palNextShort(o,p){
  const m=mainOf(o),z=trazCalc(m),out=[];
  const man={};sheetsOf(m).filter(x=>x.variante==='1').forEach(x=>{const M=compute(x);Object.keys(M.manBy).forEach(tp=>CAL.forEach(c=>{const v=M.manBy[tp][c.k];if(v!=null){const k=tp+'|'+c.k;man[k]=(man[k]||0)+v}}))});
  if(!Object.keys(man).length)return {sin:true,list:[]};
  const rm={};(p.lines||[]).forEach(l=>{const ck=PCAL_KEY[l.cal],n=n0(l.cant);if(ck&&n>0){const k=lineType(palTipo(p),ck)+'|'+ck;rm[k]=(rm[k]||0)+n}});
  Object.keys(rm).forEach(k=>{const tp=k.split('|')[0],ck=k.split('|')[1],L=lineKey('1',tp),have=((z.palL[L]||{})[ck]||0)-rm[k],mv=man[k];if(mv!=null&&have<mv)out.push((tp!=='RPC'?TIPO_L[tp]+' ':'')+calLab(ck)+': faltarían '+fmt(mv-have)+' de '+fmt(mv))});
  return {sin:false,list:out};
}
function palLinesTxt(sh,p,onlyDe){
  return (p.lines||[]).filter(l=>n0(l.cant)>0&&(!onlyDe||l.de)).map(l=>{const k=resolveProd(sh,l.prod)||l.prod||'sin productor',nm=l.dn||prodNameOf(sh,k);return {k:k,nm:nm,cal:calLab(PCAL_KEY[l.cal]||l.cal),n:n0(l.cant)}});
}
function prodNameOf(sh,k){for(const o of sh)for(const p of (o.productores||[]))if(prodKey(o,p)===k)return p.nombre||'';return ''}
/* v8.10: pedidos que pueden recibir las tarimas: los siguientes de la misma empresa y año, en proceso y con su semana abierta */
/* v8.25.5: también los viajes en proceso de la otra empresa (Vera Limes ↔ Citrilar); ex: viajes que no se ofrecen (el de origen de la tarima) */
function palNextCands(m,ex){ex=ex||[];
  const ok=x=>x.variante==='1'&&x.id!==m.id&&ex.indexOf(x.id)<0&&+x.anio===+m.anio&&x.estado!=='completo'&&!orderLocked(x)&&!manClosed(x),by=(a,b)=>(a.cons||0)-(b.cons||0);
  return visible().filter(x=>ok(x)&&x.emp===m.emp&&(x.cons||0)>(m.cons||0)).sort(by).concat(visible().filter(x=>ok(x)&&x.emp!==m.emp).sort(by));
}
function palFwdOk(p){const ls=(p.lines||[]).filter(l=>n0(l.cant)>0);return !!p.from&&ls.length>0&&ls.every(l=>lineQ(p,l)==='1'&&PCAL_KEY[l.cal])}
function palOrigins(p){return [...new Set((p.lines||[]).map(l=>l.de).filter(Boolean).concat(p.from&&p.from.oid?[p.from.oid]:[]))]}
/* lo reempacado desde SOBRANTES tiene que seguir cubierto después de quitar los renglones rm de sobAp */
/* igual, con lo que se quita por productor|tipo|calibre */
function sobRmpOkD(m,D){
  const r=sobRow(m);if(!r||!Object.keys(D).length)return true;const out={};rmpOutRow(m.id,r.id).forEach(a=>{const k=a.key+'|'+a.tipo0+'|'+a.ck0;out[k]=(out[k]||0)+n0(a.n0)});
  const be={};(r.sobAp||[]).forEach(a=>{const k=a.key+'|'+a.tipo+'|'+a.ck;be[k]=(be[k]||0)+n0(a.n)});
  return Object.keys(out).every(k=>{const af=Math.max(0,(be[k]||0)-(D[k]||0));return !(af<out[k]&&(be[k]||0)>af)});
}
function sobRmpOk(m,rm){
  const r=sobRow(m);if(!r||!rm.length)return true;const out={};rmpOutRow(m.id,r.id).forEach(a=>{const k=a.key+'|'+a.tipo0+'|'+a.ck0;out[k]=(out[k]||0)+n0(a.n0)});
  const be={},af={};(r.sobAp||[]).forEach(a=>{const k=a.key+'|'+a.tipo+'|'+a.ck;be[k]=(be[k]||0)+n0(a.n);if(rm.indexOf(a)<0)af[k]=(af[k]||0)+n0(a.n)});
  return Object.keys(out).every(k=>!((af[k]||0)<out[k]&&(be[k]||0)>(af[k]||0)));
}
const empNm=e=>(EMPS[e]&&EMPS[e].name)||e;
function palNextSheet(pid){
  const o=trazOrder();if(!o||ro)return;if(orderLocked(o)){toast(wkLab(wkOf(o))+' está cerrada');return}
  const p=ensureTraz(o).tarimas.find(x=>x.id===pid);if(!p)return;const fwd=!!p.from;
  if(fwd?!palFwdOk(p):!palNextOk(p)){toast('Solo pasan tarimas de primera con cajas');return}
  const m=mainOf(o),ex=fwd?palOrigins(p):[],C=palNextCands(m,ex),B=nextTripOf(m),q={};
  (fwd?(p.lines||[]).filter(l=>n0(l.cant)>0):palOwnLines(p)).forEach(l=>q[l.id]=n0(l.cant));
  sheet={kind:'pnext',pid:pid,oid:o.id,fwd:fwd,ex:ex,dest:B&&C.some(x=>x.id===B.id)?B.id:(C[0]?C[0].id:'new'),q:q};renderSheet();
}
/* cajas que se mandan de cada línea (lo capturado en la ventana, sin pasar de lo que tiene la línea) */
/* v8.26.2: de una tarima recibida también se puede mandar solo una parte (cada línea, la de origen y las de este viaje) */
function pnextQ(p){const q=(sheet&&sheet.q)||{};return (sheet&&sheet.fwd?(p.lines||[]).filter(l=>n0(l.cant)>0):palOwnLines(p)).map(l=>{const v=q[l.id];const k=Math.max(0,Math.min(n0(l.cant),v==null||v===''?n0(l.cant):Math.floor(n0(v))));return {l:l,k:k}})}
function pnextWarn(m,p,Q){const S=palNextShort(m,Object.assign({},p,{lines:Q.map(x=>Object.assign({},x.l,{cant:x.k}))}));
  return S.list.length?`<div class="warnbox" role="alert"><strong>El viaje quedaría corto del manifiesto</strong>${S.list.map(x=>`<div>${esc(x)}</div>`).join('')}</div>`:S.sin?'<p class="note">Este viaje todavía no tiene manifiesto capturado.</p>':''}
function pnextHtml(){
  const o=orders.find(x=>x.id===sheet.oid);if(!o)return '';const m=mainOf(o),t=ensureTraz(m),i=t.tarimas.findIndex(x=>x.id===sheet.pid),p=t.tarimas[i];if(!p)return '';
  const fwd=!!sheet.fwd,C=palNextCands(m,sheet.ex),nc=codOf(m.emp,m.anio,nextCons(m.emp,m.anio)),sh=sheetsOf(m),Q=pnextQ(p),tot=Q.reduce((a,x)=>a+x.k,0),all=Q.every(x=>x.k===n0(x.l.cant));
  const dest=sheet.dest==='new'?null:C.find(x=>x.id===sheet.dest)||null,cod=dest?dest.cod:nc;
  const warn=`<div id="pnwarn">${pnextWarn(m,p,Q)}</div>`;
  const ntar=x=>{const tt=x.traz&&Array.isArray(x.traz.tarimas)?x.traz.tarimas.length:0;return tt+(tt===1?' tarima':' tarimas')};
  const opts=C.length?`<div class="sec">¿A qué viaje va?</div><div class="pnopts" role="radiogroup" aria-label="Viaje que recibe la tarima">${C.map(x=>`<label class="pnopt"><input type="radio" name="pndest" value="${x.id}" data-pndest="1"${sheet.dest===x.id?' checked':''}><span><b class="mono">${esc(x.cod)}</b>${x.emp!==m.emp?` <span class="chip info">${esc(empNm(x.emp))}</span>`:''}<small>${esc(x.emb||'sin embarque')} · Semana ${esc(x.semana||'—')} · ${fmtDate(x.fecha)} · ${ntar(x)} · en proceso</small></span></label>`).join('')}<label class="pnopt"><input type="radio" name="pndest" value="new" data-pndest="1"${sheet.dest==='new'?' checked':''}><span><b class="mono">${esc(nc)}</b><small>Pedido nuevo con el encabezado vacío</small></span></label></div>`:'';
  const rows=Q.map(x=>{const nm=x.l.dn||prodNameOf(sh,resolveProd(sh,x.l.prod)||x.l.prod),k=resolveProd(sh,x.l.prod)||x.l.prod||'sin productor';
    return `<div class="kv pnq"><span>${sobLab(k,nm)}<br><small class="note">${esc(TIPO_L[palTipo(p)]||'')} · calibre ${esc(calLab(PCAL_KEY[x.l.cal]||x.l.cal))} · ${x.l.de?'de '+esc(lineFrom(p,x.l).cod):'tiene '+fmt(n0(x.l.cant))}</small></span><input class="in" type="text" inputmode="numeric" pattern="[0-9]*" data-pnq="${x.l.id}" value="${x.k}" aria-label="Cajas que se envían de ${esc(nm||k)}, calibre ${esc(x.l.cal)}"></div>`}).join('');
  return `<h3>¿Seguro que quieres enviar la Tarima ${i+1} a otro viaje?</h3>${opts}<p style="margin:8px 0 6px">Van <b id="pnqtot">${fmt(tot)}</b> cajas al pedido <b class="mono">${esc(cod)}</b>${dest?'':' (se crea con el encabezado vacío)'}. Ahí quedan en una tarima empezada en Código de Trazabilidad y en Registro de empaque entran solas al renglón <b>SOBRANTES</b> (cajas chicas y kilos = cajas × ${String(SOB_KG)}).</p>
<div class="sec">Cajas de cada productor</div><div class="panel">${rows}<p class="note" id="pnqnote">${(all?'Va la tarima completa.':'Va una parte: lo demás se queda en esta tarima.')+(fwd?' Es un sobrante que llegó de '+esc(p.from.cod)+': lo que va sale de los SOBRANTES de este pedido y cada caja sigue siendo de su viaje de origen.':'')}</p></div>${warn}
<p class="note">Las cajas ya se pagaron en su viaje; en el que las recibe no se pagan otra vez. Si te equivocas, en el pedido que las recibe está «Regresar a su viaje».</p>
<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="pnextok">Sí, enviar a ${esc(cod)}</button></div>`;
}
$sh.addEventListener('input',e=>{const t=e.target;if(!sheet||sheet.kind!=='pnext'||!t.dataset||!t.dataset.pnq)return;
  t.value=t.value.replace(/\D+/g,'');sheet.q[t.dataset.pnq]=t.value;
  const o=orders.find(x=>x.id===sheet.oid),p=o&&ensureTraz(mainOf(o)).tarimas.find(x=>x.id===sheet.pid);if(!p)return;const Q=pnextQ(p);
  const a=document.getElementById('pnqtot');if(a)a.textContent=fmt(Q.reduce((s,x)=>s+x.k,0));
  const n=document.getElementById('pnqnote');if(n)n.textContent=Q.every(x=>x.k===n0(x.l.cant))?'Va la tarima completa.':'Va una parte: lo demás se queda en esta tarima.';
  const w=document.getElementById('pnwarn');if(w)w.innerHTML=pnextWarn(mainOf(o),p,Q)});
$sh.addEventListener('change',e=>{const t=e.target;if(sheet&&sheet.kind==='grandes'&&t.dataset&&t.dataset.grsel!=null){grSel=t.value;renderSheet();return}if(sheet&&sheet.kind==='recsem'&&t.dataset){if(t.dataset.rswk){sheet.wk=t.value;renderSheet()}else if(t.dataset.rsall)sheet.all=t.checked}})
$sh.addEventListener('change',e=>{const t=e.target;if(!sheet||sheet.kind!=='pnext'||!t.dataset)return;
  if(t.dataset.pndest){sheet.dest=t.value;renderSheet()}else if(t.dataset.pnq){const L=document.querySelector('[data-pnq="'+t.dataset.pnq+'"]');if(L){const o=orders.find(x=>x.id===sheet.oid),p=o&&ensureTraz(mainOf(o)).tarimas.find(x=>x.id===sheet.pid),q=p&&pnextQ(p).find(x=>x.l.id===t.dataset.pnq);if(q)L.value=q.k}}});
function palNextDo(){
  const o=orders.find(x=>x.id===(sheet&&sheet.oid));if(!o||ro)return;const m=mainOf(o),t=ensureTraz(m),i=t.tarimas.findIndex(x=>x.id===sheet.pid),p=t.tarimas[i];
  const fwd=!!sheet.fwd;if(!p||(fwd?!palFwdOk(p):!palNextOk(p))){sheet=null;renderSheet();return}
  const Q=pnextQ(p),tot=Q.reduce((a,x)=>a+x.k,0);if(!(tot>0)){toast('Escribe cuántas cajas se envían');return}
  if(fwd){const D={};Q.forEach(x=>{if(!x.l.de||!(x.k>0))return;const k=x.l.prod+'|'+palTipo(p)+'|'+PCAL_KEY[x.l.cal];D[k]=(D[k]||0)+x.k});if(!sobRmpOkD(m,D)){toast('De SOBRANTES ya se reempacaron esas cajas. Manda menos o primero regresa ese reempaque');return}}
  const C=palNextCands(m,sheet.ex);let B=sheet.dest==='new'?null:C.find(x=>x.id===sheet.dest)||null,nuevo=false;
  if(!B&&sheet.dest!=='new')B=nextTripOf(m);
  if(!B){const cons=nextCons(m.emp,m.anio);const hoy=todayISO();B=newOrder({emp:m.emp,anio:m.anio,cons:cons,cod:codOf(m.emp,m.anio,cons),emb:'',po:'',fecha:hoy,semana:isoWeek(hoy),customer:'',domestic:'',factura:'',variante:'1'});B.sobDe=m.id;orders.push(B);nuevo=true}
  const sh=sheetsOf(m),all=Q.every(x=>x.k===n0(x.l.cant));
  if(fwd){palFwdDo(m,t,i,p,B,nuevo,Q,all);return}
  let mv;
  if(all){t.tarimas.splice(i,1);mv=p}
  else{
    /* v8.10: va solo una parte: sale una tarima nueva con esas cajas y lo demás se queda en la original */
    mv={id:uid(),marca:p.marca,empaque:p.empaque,lines:Q.filter(x=>x.k>0).map(x=>({id:uid(),q:'1',cal:x.l.cal,cant:x.k,prod:x.l.prod}))};
    Q.forEach(x=>{x.l.cant=n0(x.l.cant)-x.k});p.lines=(p.lines||[]).filter(l=>!(l.cal&&!(n0(l.cant)>0)&&Q.some(x=>x.l===l)));
  }
  mv.from={oid:m.id,cod:m.cod,n:i+1,at:Date.now(),pid:p.id};
  (mv.lines||[]).forEach(l=>{if(!(n0(l.cant)>0))return;const k=resolveProd(sh,l.prod);l.prod=k;l.dn=prodNameOf(sh,k)||'';l.de=m.id});
  mv.lines=(mv.lines||[]).filter(l=>l.de);
  const tb=ensureTraz(B);let at=0;while(at<tb.tarimas.length&&tb.tarimas[at].from)at++;tb.tarimas.splice(at,0,mv);
  m.sobPal=1;if(palOpen===mv.id)palOpen=null;
  touch(m);touch(B);
  /* v8.10: en Registro de empaque del pedido que recibe, las cajas entran solas al renglón SOBRANTES */
  sobImport(B,[mv.id]);
  logAdd({k:'note',ctx:ctxOf(m),lab:'Tarima '+(i+1)+(all?'':' (parte)')+' al próximo viaje',o:'',n:B.cod+' · '+fmt(palTot(mv))+' cajas'});
  sheet=null;renderSheet();render();
  toast(fmt(palTot(mv))+' cajas enviadas a '+B.cod+(nuevo?' (pedido nuevo)':'')+'. Ya están en su renglón SOBRANTES');
}
/* v8.25.5: una tarima que llegó de otro viaje sigue a un tercero. Sus cajas salen de los SOBRANTES de aquí;
   las líneas que ya traía siguen siendo de su viaje de origen y las de este viaje quedan como sobrante de este viaje */
function palFwdDo(m,t,i,p,B,nuevo,Q,all){
  if(Q&&!all)return palFwdPart(m,t,i,p,B,nuevo,Q);
  const sh=sheetsOf(m),pf=p.from,own=palOwnLines(p).length;
  sobUnimport(m,p);t.tarimas.splice(i,1);
  (p.lines||[]).forEach(l=>{if(!(n0(l.cant)>0))return;if(l.de){const f=lineFrom({from:pf},l);l.deCod=f.cod;l.dePn=f.n}else{const k=resolveProd(sh,l.prod);l.prod=k;l.dn=prodNameOf(sh,k)||'';l.de=m.id;l.deCod=m.cod;l.dePn=i+1}});
  p.lines=(p.lines||[]).filter(l=>l.de);
  p.from={oid:m.id,cod:m.cod,n:i+1,at:Date.now(),pid:p.id,prev:pf};
  const tb=ensureTraz(B);let at=0;while(at<tb.tarimas.length&&tb.tarimas[at].from)at++;tb.tarimas.splice(at,0,p);
  if(own)m.sobPal=1;if(palOpen===p.id)palOpen=null;
  touch(m);touch(B);sobImport(B,[p.id]);
  logAdd({k:'note',ctx:ctxOf(m),lab:'Tarima '+(i+1)+' (sobrante de '+pf.cod+') a otro viaje',o:'',n:B.cod+' · '+fmt(palTot(p))+' cajas'});
  sheet=null;renderSheet();render();
  toast(fmt(palTot(p))+' cajas enviadas a '+B.cod+(nuevo?' (pedido nuevo)':'')+'. Ya están en su renglón SOBRANTES');
}
/* v8.26.2: va solo una parte: sale una tarima nueva con esas cajas; lo demás se queda aquí y vuelve a entrar a SOBRANTES con lo que quedó */
function palFwdPart(m,t,i,p,B,nuevo,Q){
  const sh=sheetsOf(m),pf=p.from,mv={id:uid(),marca:p.marca,empaque:p.empaque,lines:[]};let own=0;
  sobUnimport(m,p);
  Q.forEach(x=>{if(!(x.k>0))return;const l=x.l,nl={id:uid(),q:'1',cal:l.cal,cant:x.k,prod:l.prod};
    if(l.de){const f=lineFrom({from:pf},l);nl.de=l.de;nl.dn=l.dn||'';nl.deCod=f.cod;nl.dePn=f.n}
    else{const k=resolveProd(sh,l.prod);nl.prod=k;nl.dn=prodNameOf(sh,k)||'';nl.de=m.id;nl.deCod=m.cod;nl.dePn=i+1;own++}
    mv.lines.push(nl);l.cant=n0(l.cant)-x.k});
  p.lines=(p.lines||[]).filter(l=>!(l.cal&&!(n0(l.cant)>0)&&Q.some(x=>x.l===l)));
  mv.from={oid:m.id,cod:m.cod,n:i+1,at:Date.now(),pid:p.id,prev:pf};
  const tb=ensureTraz(B);let at=0;while(at<tb.tarimas.length&&tb.tarimas[at].from)at++;tb.tarimas.splice(at,0,mv);
  if(own)m.sobPal=1;
  touch(m);touch(B);sobImport(m,[p.id]);sobImport(B,[mv.id]);
  logAdd({k:'note',ctx:ctxOf(m),lab:'Tarima '+(i+1)+' (parte, sobrante de '+pf.cod+') a otro viaje',o:'',n:B.cod+' · '+fmt(palTot(mv))+' cajas'});
  sheet=null;renderSheet();render();
  toast(fmt(palTot(mv))+' cajas enviadas a '+B.cod+(nuevo?' (pedido nuevo)':'')+'. Lo demás sigue en la tarima '+(i+1));
}
function palBackSheet(pid){
  const o=trazOrder();if(!o||ro)return;const p=ensureTraz(o).tarimas.find(x=>x.id===pid);if(!p||!p.from)return;
  if(palOwnLines(p).length){toast('Esta tarima ya lleva cajas de este viaje. Quítalas primero para regresarla');return}
  const A=orders.find(x=>x.id===p.from.oid&&!x.deleted);if(!A){toast('Ya no existe el pedido '+p.from.cod);return}
  if(orderLocked(A)){toast(wkLab(wkOf(A))+' está cerrada');return}
  sheet={kind:'pback',pid:pid,oid:o.id};renderSheet();
}
function pbackHtml(){
  const o=orders.find(x=>x.id===sheet.oid);if(!o)return '';const t=ensureTraz(o),i=t.tarimas.findIndex(x=>x.id===sheet.pid),p=t.tarimas[i];if(!p)return '';
  const tot=palTot(p);
  return `<h3>¿Regresar la tarima a su viaje?</h3><p style="margin-bottom:6px">La Tarima ${i+1} (${fmt(tot)} cajas) vuelve al pedido <b class="mono">${esc(p.from.cod)}</b>, al lugar ${p.from.n}. Sus cajas salen del renglón SOBRANTES de este pedido.</p><div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="pbackok">Sí, regresar a su viaje</button></div>`;
}
function palBackDo(){
  const o=orders.find(x=>x.id===(sheet&&sheet.oid));if(!o||ro)return;const m=mainOf(o),t=ensureTraz(m),i=t.tarimas.findIndex(x=>x.id===sheet.pid),p=t.tarimas[i];
  if(!p||!p.from||palOwnLines(p).length){sheet=null;renderSheet();return}
  {const sr=sobRow(m);if(!sobRmpOk(m,((sr&&sr.sobAp)||[]).filter(a=>a.pid===p.id))){sheet=null;renderSheet();toast('De SOBRANTES ya se reempacaron cajas de esta tarima. Primero regresa ese reempaque');return}}
  const A=orders.find(x=>x.id===p.from.oid&&!x.deleted);if(!A){sheet=null;renderSheet();return}
  const Am=mainOf(A),ta=ensureTraz(Am),cod=p.from.cod,pos=Math.max(0,Math.min(ta.tarimas.length,(p.from.n||ta.tarimas.length+1)-1));
  sobUnimport(m,p);
  t.tarimas.splice(i,1);
  if(p.from.prev){/* v8.25.5: era una tarima reenviada: vuelve al viaje que la mandó, otra vez como sobrante recibido */
    const fo=p.from.oid,n=palTot(p),og=p.from.pid&&p.from.pid!==p.id?ta.tarimas.find(x=>x.id===p.from.pid&&x.from):null;p.lines=(p.lines||[]).filter(l=>l.de);p.lines.forEach(l=>{if(l.de===fo){delete l.de;delete l.dn;delete l.deCod;delete l.dePn}});p.from=p.from.prev;
    if(og){/* v8.26.2: la parte que salió vuelve a su tarima */
      sobUnimport(Am,og);const sa=sheetsOf(Am);
      p.lines.forEach(l=>{const x=og.lines.find(y=>(y.de||'')===(l.de||'')&&y.cal===l.cal&&(l.de?y.prod===l.prod:resolveProd(sa,y.prod)===resolveProd(sa,l.prod)));if(x)x.cant=n0(x.cant)+n0(l.cant);else og.lines.push(Object.assign({},l,{id:uid()}))});
      if(palOpen===p.id)palOpen=null;touch(m);touch(Am);sobImport(Am,[og.id]);
    }else{ta.tarimas.splice(pos,0,p);if(palOpen===p.id)palOpen=null;touch(m);touch(Am);sobImport(Am,[p.id])}
    logAdd({k:'note',ctx:ctxOf(m),lab:'Tarima regresada a su viaje',o:'',n:cod+' · '+fmt(n)+' cajas'});
    sheet=null;renderSheet();render();toast('La tarima regresó a '+cod);return;
  }
  const og=p.from.pid&&p.from.pid!==p.id?ta.tarimas.find(x=>x.id===p.from.pid):null;
  p.lines=(p.lines||[]).filter(l=>l.de);p.lines.forEach(l=>{delete l.de;delete l.dn;delete l.deCod;delete l.dePn});delete p.from;
  if(og){/* v8.10: la parte que salió vuelve a su tarima original */
    p.lines.forEach(l=>{const x=og.lines.find(y=>!y.de&&y.cal===l.cal&&resolveProd(sheetsOf(Am),y.prod)===l.prod);if(x)x.cant=n0(x.cant)+n0(l.cant);else og.lines.push({id:uid(),q:'1',cal:l.cal,cant:l.cant,prod:l.prod})});
  }else ta.tarimas.splice(pos,0,p);
  if(palOpen===p.id)palOpen=null;
  touch(m);touch(Am);
  logAdd({k:'note',ctx:ctxOf(m),lab:'Tarima regresada a su viaje',o:'',n:cod+' · '+fmt(palTot(p))+' cajas'});
  sheet=null;renderSheet();render();toast('La tarima regresó a '+cod);
}
/* el renglón SOBRANTES va primero en la línea: su conteo es la suma de las tarimas importadas; los acumulados de los demás se recorren */
function sobShift(o,row,D){
  const ri=o.productores.indexOf(row);
  Object.keys(D).forEach(tp=>{
    const d=D[tp];if(tiposOf(row).indexOf(tp)<0){row.tipos=tiposOf(row).concat([tp]);row.tipo=row.tipos[0]}
    if(row.rmp){const a=accOf(row,tp,true);CAL.forEach(c=>{if(!d[c.k])return;const v=Math.max(0,(num(a[c.k])||0)+d[c.k]);a[c.k]=v||null});return}
    let base={};for(let j=ri-1;j>=0;j--){const q=o.productores[j];if(q.rmp)continue;if(tiposOf(q).indexOf(tp)>=0){const a=accOf(q,tp);CAL.forEach(c=>{if(base[c.k]==null&&a[c.k]!=null)base[c.k]=num(a[c.k])});}}
    const a=accOf(row,tp,true);
    CAL.forEach(c=>{if(!d[c.k])return;const cur=a[c.k]!=null?num(a[c.k]):(base[c.k]||0);a[c.k]=cur+d[c.k]});
    o.productores.forEach((q,j)=>{if(j<=ri||q.rmp||tiposOf(q).indexOf(tp)<0)return;const b=accOf(q,tp);CAL.forEach(c=>{if(d[c.k]&&b[c.k]!=null)b[c.k]=num(b[c.k])+d[c.k]})});
  });
  /* v8.10: cajas chicas = cajas que llegaron y kilos = cajas × 17.8 (sin pago: esas cajas ya se pagaron en su viaje) */
  const tot=(row.sobAp||[]).reduce((a,x)=>a+n0(x.n),0);if(row.rmp){rmpFill(row,true);return} /* v8.21.3: el REEMPAQUE lleva sus cajas como chicas y sus kilos, sin pago */
  row.k18=tot||null;row.kilos=tot?Math.round(tot*SOB_KG*100)/100:null;
}
/* ---------- v8.21 · Reempaque: fruta ya empacada que pasa a otra presentación (en otro viaje o en el mismo) ----------
   La fruta no es nueva: en el viaje que la recibe entra al renglón REEMPAQUE (como SOBRANTES: sob2, sin kilos ni pago),
   con el detalle de cada productor, su viaje de origen y la presentación y calibre de antes y de ahora (sobAp con rmp).
   En el viaje de origen el productor no cambia (kilos, calibres, rendimiento y pago); esas cajas solo salen de su venta y de lo que llevan sus tarimas.
   La venta cuenta en el destino con el precio de la presentación nueva, y ahí se cargan el empaque y la mano de obra del reempaque. */
/* calibres de 40 lb (RPC, CTN, PLT) contra los de 10 lb: 250↔63, 230↔60, 200↔54 o 48, 175↔42, 150↔36, 110↔28 */
const RMP_TO10={c250:'m63',c230:'m60',ctn:'m60',c200:'m54',c175:'m42',c150:'m36',c110:'m28'};
const RMP_TO40={m63:'c250',m60:'c230',m54:'c200',m48:'c200',m42:'c175',m36:'c150',m28:'c110'};
function rmpCk(ck,tipo,alt){
  if(tipo==='CTN10'){if(isMM(ck))return ck;const m=RMP_TO10[ck]||null;return m==='m54'&&alt==='m48'?'m48':m}
  if(isMM(ck))return RMP_TO40[ck]||null;
  return ck==='ctn'?'c230':ck;
}
/* lo que ya salió de cada hoja por reempaque (se lee de los renglones REEMPAQUE de todos los pedidos) */
let _RMP=null;
function rmpIdx(){
  if(_RMP&&_RMP.v===dataVer&&_RMP.n===orders.length)return _RMP;
  const out=new Map(),sob=new Map(),rows=new Map();orders.forEach(o=>rows.set(o.id,new Set((o.productores||[]).map(p=>p.id))));
  /* v8.26.4: si el renglón de donde salió ya no existe (p. ej. se quitó el SOBRANTES), esas cajas ya no se descuentan de la hoja */
  visible().forEach(o=>(o.productores||[]).forEach(p=>{if(!p.rmp)return;(p.sobAp||[]).forEach(a=>{if(!a.de||!(n0(a.n0)>0))return;const x=Object.assign({to:o,row:p},a),R=rows.get(a.de);let L=out.get(a.de);if(!L)out.set(a.de,L=[]);if(!R||R.has(a.pid))L.push(x);
    /* v8.22: reempaque hecho desde SOBRANTES: la venta sale del viaje donde se empacó (a.sobDe) */
    if(a.sobDe){let S=sob.get(a.sobDe);if(!S)sob.set(a.sobDe,S=[]);S.push(x)}})}));
  _RMP={v:dataVer,n:orders.length,out:out,sob:sob};return _RMP;
}
/* v8.21.6: el productor de un registro de reempaque se identifica por su código con la empresa actual del pedido
   (si el pedido cambia de «Sale por», el código guardado VL-/EC- ya no coincide con el de sus tarimas) */
function rmpKey(s,a){return a&&a.codigo?(s.emp+'-'+pad(a.codigo,3)):((a&&a.key)||'')}
function rmpOutsOf(sid){return rmpIdx().out.get(sid)||[]}
function rmpCodeOf(k){const m=/^(VL|EC)-?(\d+)$/i.exec(String(k||'').trim());return m?+m[2]:null}
/* cajas de venta que ya no se venden en un renglón: lo reempacado desde el renglón y, en el viaje donde se empacaron, lo reempacado desde sus SOBRANTES en otro viaje */
function rmpOutAll(o,p){const m=rmpOutMap(o.id,p.id);if(p.sob2)return m;const k=prodKey(o,p);(rmpIdx().sob.get(o.id)||[]).forEach(a=>{if(rmpKey(o,a)!==k)return;const q=a.tipo0+'|'+a.ck0;m[q]=(m[q]||0)+n0(a.n0)});return m}
function rmpOutRow(sid,pid){return rmpOutsOf(sid).filter(a=>a.pid===pid)}
/* cajas de venta que salen de un renglón: {tipo|calibre: cajas} */
function rmpOutMap(sid,pid){const m={};rmpOutRow(sid,pid).forEach(a=>{const k=a.tipo0+'|'+a.ck0;m[k]=(m[k]||0)+n0(a.n0)});return m}
/* fruta disponible para reempaque en todo el viaje: por hoja, productor, tipo y calibre, menos lo ya reempacado y lo mandado al próximo viaje */
function rmpAvail(o,all){
  const m=mainOf(o),sh=sheetsOf(m),out=[],left={};
  const leftR={};sentOf(m).forEach(x=>{const k=x.key+'|'+lineType(x.tipo,x.ck)+'|'+x.ck,L=x.rmp?leftR:left;L[k]=(L[k]||0)+x.n});
  sh.forEach(s=>{
    const M=compute(s),pes=pesosOf(s);
    M.rows.forEach(r=>{const p=r.p;if(p.sob2){rmpAvailSob(s,p,pes,out,all,s.variante==='1'?{S:left,R:leftR}:null);return}if(p.sob)return;const key=prodKey(s,p),om=rmpOutMap(s.id,p.id),cd=pCode(p);
      r.tipos.forEach(t0=>{const d=r.byT[t0].delta;CAL.forEach(c=>{let n=Math.max(0,d[c.k]||0);if(!n)return;const tp=lineType(t0,c.k),ok=tp+'|'+c.k,reg=n;let sx=0;
        let u=Math.min(n,om[ok]||0);if(u){n-=u;om[ok]-=u}
        if(s.variante==='1'){const rk=key+'|'+ok,y=Math.min(n,leftR[rk]||0);if(y>0){n-=y;leftR[rk]-=y;u+=y}}
        if(s.variante==='1'){const sk=key+'|'+ok,x=Math.min(n,left[sk]||0);if(x>0){n-=x;left[sk]-=x;sx=x}}
        if(n>0||all)out.push({reg:reg,rmpd:u,sent:sx,id:s.id+'|'+p.id+'|'+ok,sid:s.id,q:s.variante==='1.5'?'1.5':'1',pid:p.id,key:key,nombre:p.nombre||key,codigo:cd||null,cls:cd&&+cd!==SEG_COD&&!p.segLot?clsOf(cd):'',tipo0:tp,ck0:c.k,av:n,kg0:pes[tp]||pes.RPC})})});
    });
  });
  return all?out:rmpSplit(m,out);
}
/* v8.25 · existencia en empaque: cada caja está en un solo lugar. Lo disponible de cada renglón se reparte entre
   piso (registrado, sin tarima) y las tarimas del viaje donde está. Con el manifiesto cerrado, lo de tarimas ya no se ofrece. */
function palCountMap(m){
  const t=ensureTraz(m),sh=sheetsOf(m),M=new Map();
  t.tarimas.forEach((p,i)=>(p.lines||[]).forEach(l=>{const c=n0(l.cant),ck=PCAL_KEY[l.cal];if(!(c>0)||!ck)return;const pk=resolveProd(sh,l.prod);if(!pk)return;
    const k=lineOfCal(p,ck,l)+'|'+pk+'|'+ck;let a=M.get(k);if(!a)M.set(k,a=[]);let x=a.find(y=>y.p===p);if(!x)a.push(x={p:p,i:i,n:0});x.n+=c}));
  return M;
}
function rmpPlace(m,out){
  const M=palCountMap(m);
  return out.map(a=>{const P=M.get(lineKey(a.q==='1.5'?'1.5':'1',a.tipo0)+'|'+a.key+'|'+a.ck0)||[],tot=P.reduce((s,x)=>s+x.n,0),piso=Math.max(0,a.av-tot);let rest=a.av-piso;
    const pals=[];P.forEach(x=>{const v=Math.min(x.n,rest);if(v>0){rest-=v;pals.push({p:x.p,i:x.i,n:v})}});
    return {a:a,piso:piso,pals:pals,palTot:tot}});
}
function rmpSplit(m,out){
  const cl=manClosed(m),res=[];
  rmpPlace(m,out).forEach(x=>{const a=x.a;
    if(x.piso>0)res.push(Object.assign({},a,{id:a.id+'|piso',av:x.piso,src:'piso'}));
    if(!cl)x.pals.forEach(y=>res.push(Object.assign({},a,{id:a.id+'|pal:'+y.p.id,av:y.n,src:'pal',pal:y.p.id,palN:y.i+1})))});
  return res;
}
/* quita n cajas (productor, calidad y calibre) de una tarima del viaje; regresa las líneas quitadas para poder deshacer */
function palTake(m,pid,q,ck,pk,n){
  const p=ensureTraz(m).tarimas.find(x=>x.id===pid);if(!p)return [];const sh=sheetsOf(m),took=[];
  p.lines.slice().reverse().forEach(l=>{if(n<=0||PCAL_KEY[l.cal]!==ck||lineQ(p,l)!==q||resolveProd(sh,l.prod)!==pk)return;const c=n0(l.cant),v=Math.min(c,n);if(!(v>0))return;
    l.cant=c-v;n-=v;took.push({cal:l.cal,q:q,prod:l.prod,cant:v,de:l.de||null})});
  p.lines=p.lines.filter(l=>n0(l.cant)>0||(!l.cal&&!String(l.prod||'').trim()));if(!p.lines.length)p.lines=[{id:uid(),q:q,cal:'',cant:null,prod:''}];syncMarca(m,p);
  return took;
}
/* deshacer: las cajas vuelven a su tarima (o a una nueva de la misma presentación si ya no existe) */
function palGive(m,a){
  const t=ensureTraz(m);let p=t.tarimas.find(x=>x.id===a.pal);
  if(!p){p={id:uid(),marca:marcaOfQ(m.emp,a.q==='1.5'?'1.5':'1'),empaque:a.palTipo||lineType(a.tipo0,a.ck0)||'RPC',lines:[]};t.tarimas.push(p)}
  p.lines=(p.lines||[]).filter(l=>l.cal||n0(l.cant)>0||String(l.prod||'').trim());
  (a.palTk||[]).forEach(x=>{const l=p.lines.find(y=>(y.de||null)===(x.de||null)&&lineQ(p,y)===x.q&&y.cal===x.cal&&y.prod===x.prod);if(l)l.cant=n0(l.cant)+n0(x.cant);else p.lines.push({id:uid(),q:x.q,cal:x.cal,cant:n0(x.cant),prod:x.prod,de:x.de||undefined})});
  syncMarca(m,p);
}
/* v8.25 · manifiesto cerrado: congela las tarimas del viaje; lo cierra o reabre (con motivo) el jefe de empaque o la administración */
let exisOpen=false;
document.addEventListener('toggle',e=>{const t=e.target;if(t&&t.classList&&t.classList.contains('exis'))exisOpen=t.open},true);
function manClosed(o){const m=o&&mainOf(o);return !!(m&&m.manCerr&&m.manCerr.at)}
function canManClose(){return !!authUser&&!roRole&&['admin','jefe'].indexOf(authUser.rol)>=0}
function whoName(){return (authUser&&(authUser.name||authUser.user))||'—'}
function manClose(o){
  const m=o&&mainOf(o);if(!m||!canManClose()||manClosed(m))return;
  if(orderLocked(m)){toast(wkLab(wkOf(m))+' está cerrada');return}
  const z=trazCalc(m);if(!z.t.tarimas.length){toast('El viaje todavía no tiene tarimas');return}
  const k='mancl:'+m.id;if(z.borrador&&confirmKey!==k){armConfirm(k);render();toast('El código sigue en borrador ('+z.motivos[0]+'). Toca otra vez para cerrar de todos modos');return}confirmKey=null;
  m.manCerr={at:Date.now(),by:whoName(),cajas:z.cantTot,tarimas:z.nPal};touch(m);
  logAdd({k:'note',ctx:ctxOf(m),lab:'Manifiesto cerrado',o:'',n:fmt(z.cantTot)+' cajas en '+z.nPal+(z.nPal===1?' tarima':' tarimas')});
  render();toast('Manifiesto de '+m.cod+' cerrado. Sus tarimas ya no se pueden cambiar ni reempacar');
}
function manReopen(o,mot){
  const m=o&&mainOf(o);if(!m||!canManClose()||!manClosed(m))return false;mot=String(mot||'').trim();if(mot.length<4){toast('Escribe el motivo para reabrir');return false}
  m.manHist=(m.manHist||[]).concat([Object.assign({},m.manCerr,{reAt:Date.now(),reBy:whoName(),mot:mot})]);m.manCerr=null;touch(m);
  logAdd({k:'note',ctx:ctxOf(m),lab:'Manifiesto reabierto',o:'',n:mot});toast('Manifiesto de '+m.cod+' reabierto');return true;
}
function manBanHtml(m){
  const c=m.manCerr,can=canManClose()&&!orderLocked(m),h=(m.manHist||[]).slice(-1)[0];
  if(c&&c.at)return `<div class="panel manban closed" role="note"><strong>${LOCK_SVG} Manifiesto cerrado</strong><p class="note">Cerrado por ${esc(c.by||'—')} el ${esc(fmtTs(c.at))}${c.cajas!=null?' · '+fmt(c.cajas)+' cajas en '+fmt(c.tarimas)+(c.tarimas===1?' tarima':' tarimas'):''}. Sus tarimas no se pueden cambiar y sus cajas no se ofrecen para reempaque.</p>${can?`<div class="pact"><button class="btn sm" data-act="manre:${m.id}">Reabrir con motivo</button></div>`:''}</div>`;
  return `<div class="panel manban"><strong>Manifiesto abierto</strong><p class="note">Las tarimas se pueden armar y corregir. Al cerrarlo se congelan y sus cajas ya no se pueden reempacar.${h?' Última reapertura: '+esc(h.reBy||'—')+', '+esc(fmtTs(h.reAt))+' · «'+esc(h.mot||'')+'».':''}</p>${can&&!ro?`<div class="pact"><button class="btn sm" data-act="mancl:${m.id}">${confirmKey==='mancl:'+m.id?'Toca otra vez para cerrar':'Cerrar manifiesto'}</button></div>`:''}</div>`;
}
/* existencia por productor, presentación y calibre: lo que sigue en el empaque (en piso o en tarima) */
function exisData(o){
  const m=mainOf(o),cl=manClosed(m),P=rmpPlace(m,rmpAvail(m,true));const G=new Map();
  P.forEach(x=>{const a=x.a,k=a.key;let g=G.get(k);if(!g)G.set(k,g={key:k,nombre:a.nombre,codigo:a.codigo,L:[],t:{reg:0,rmp:0,sent:0,pal:0,man:0,piso:0}});
    const pal=x.pals.reduce((s,y)=>s+y.n,0),r={q:a.q,tipo:a.tipo0,ck:a.ck0,via:a.via||null,reg:a.reg!=null?a.reg:a.av,rmp:a.rmpd||0,sent:a.sent||0,pal:cl?0:pal,man:cl?pal:0,piso:x.piso,sobra:Math.max(0,x.palTot-a.av)};
    g.L.push(r);['reg','rmp','sent','pal','man','piso'].forEach(f=>g.t[f]+=r[f])});
  return {m:m,cl:cl,G:[...G.values()].sort((a,b)=>String(a.key).localeCompare(String(b.key),'es',{numeric:true}))};
}
function exisHtml(o){
  const X=exisData(o);if(!X.G.length)return '';
  const T={reg:0,rmp:0,sent:0,pal:0,man:0,piso:0};X.G.forEach(g=>Object.keys(T).forEach(f=>T[f]+=g.t[f]));
  const sob=X.G.reduce((s,g)=>s+g.L.reduce((a,r)=>a+r.sobra,0),0);
  const row=(g)=>`<tr><td><b>${esc(g.nombre||g.key)}</b><small>${esc(/^(VL|EC)-\d+$/.test(g.key)?g.key:'sin código')}</small></td><td class="num">${fmt(g.t.reg)}</td><td class="num">${g.t.rmp?fmt(g.t.rmp):'–'}</td><td class="num">${g.t.sent?fmt(g.t.sent):'–'}</td><td class="num">${fmt(X.cl?g.t.man:g.t.pal)}</td><td class="num"><b>${fmt(g.t.piso)}</b></td></tr>`+g.L.filter(r=>r.reg>0).map(r=>`<tr class="exl"><td>${r.q==='1.5'?'1.5 · ':''}${esc(TIPO_L[r.tipo]||r.tipo)} ${esc(calLab(r.ck))}${r.via?' · '+(r.via==='rmp'?'reempaque':'sobrante'):''}</td><td class="num">${fmt(r.reg)}</td><td class="num">${r.rmp?fmt(r.rmp):'–'}</td><td class="num">${r.sent?fmt(r.sent):'–'}</td><td class="num">${fmt(X.cl?r.man:r.pal)}</td><td class="num">${fmt(r.piso)}</td></tr>`).join('');
  return `<details class="panel exis"${exisOpen?' open':''}><summary><strong>Existencia en empaque</strong><small>${fmt(T.piso)} en piso · ${fmt(X.cl?T.man:T.pal)} ${X.cl?'manifestadas':'en tarimas'} · ${fmt(T.rmp)} reempacadas · ${fmt(T.sent)} al próximo viaje</small></summary>
<div class="ltw"><table class="ltab extab"><thead><tr><th>Productor</th><th class="num">Registradas</th><th class="num">Reempacadas</th><th class="num">Próximo viaje</th><th class="num">${X.cl?'Manifestadas':'En tarima'}</th><th class="num">En piso</th></tr></thead><tbody>${X.G.map(row).join('')}</tbody><tfoot><tr><td><b>Total</b></td><td class="num"><b>${fmt(T.reg)}</b></td><td class="num">${fmt(T.rmp)}</td><td class="num">${fmt(T.sent)}</td><td class="num">${fmt(X.cl?T.man:T.pal)}</td><td class="num"><b>${fmt(T.piso)}</b></td></tr></tfoot></table></div>
<p class="note">Cada caja está en un solo lugar: registradas = reempacadas + próximo viaje + ${X.cl?'manifestadas':'en tarima'} + en piso. Solo lo que está en piso${X.cl?'':' o en una tarima abierta'} se puede reempacar.${sob?` <b>Hay ${fmt(sob)} cajas de más en tarimas</b> (más que las registradas); revisa la verificación.`:''}</p></details>${!ro&&!orderLocked(X.m)&&pisoItems(X.m).length?`<div class="pact pisomvb"><button class="btn sm nextb" data-act="pisomv" data-edit>Mover sobrantes en piso a otro viaje →</button></div>`:''}`;
}
/* v8.22: cajas de los renglones SOBRANTES y REEMPAQUE, por productor, presentación y calibre, menos lo que ya se volvió a reempacar.
   Así se reempaca un reempaque (sin límite) y se convierten los sobrantes que llegan en tarima a otra presentación. */
function rmpAvailSob(s,p,pes,out,all,LF){
  /* v8.26.4: en SOBRANTES cada caja sigue con la clave de su productor (VL-/EC-) tal como está en la tarima, aunque el viaje sea de la otra empresa */
  const sh=sheetsOf(mainOf(s)),G=new Map(),idk=p.rmp?(a=>{const c=a.codigo||rmpCodeOf(a.key);return c?s.emp+'-'+pad(c,3):resolveProd(sh,a.key)}):(a=>resolveProd(sh,a.key));
  (p.sobAp||[]).forEach(a=>{const n=n0(a.n);if(!(n>0)||!a.ck||!a.tipo)return;const k=idk(a),g=k+'|'+a.tipo+'|'+a.ck;let x=G.get(g);if(!x)G.set(g,x={k:k,a:a,n:0});x.n+=n;x.reg=(x.reg||0)+n});
  rmpOutRow(s.id,p.id).forEach(x=>{const y=G.get(idk(x)+'|'+x.tipo0+'|'+x.ck0);if(y){y.n-=n0(x.n0);y.r=(y.r||0)+n0(x.n0)}});
  /* v8.26.4: lo que pasó a otro viaje (o se reempacó allá desde su tarima) ya no está aquí */
  if(LF)G.forEach(x=>{const k=x.k+'|'+lineType(x.a.tipo,x.a.ck)+'|'+x.a.ck,y=Math.min(Math.max(0,x.n),LF.R[k]||0);if(y>0){x.n-=y;LF.R[k]-=y;x.r=(x.r||0)+y}const z=Math.min(Math.max(0,x.n),LF.S[k]||0);if(z>0){x.n-=z;LF.S[k]-=z;x.s=z}});
  G.forEach(x=>{if(!(x.n>0)&&!all)return;const a=x.a,cd=a.codigo||rmpCodeOf(a.key),tp=a.tipo;
    out.push({reg:x.reg,rmpd:x.r||0,sent:x.s||0,id:s.id+'|'+p.id+'|'+tp+'|'+a.ck+'|'+x.k,sid:s.id,q:s.variante==='1.5'?'1.5':'1',pid:p.id,key:x.k,nombre:a.nombre||x.k,codigo:p.rmp?(cd||null):(a.codigo||null),cls:a.cls||(cd&&+cd!==SEG_COD?clsOf(cd):''),tipo0:tp,ck0:a.ck,av:Math.max(0,x.n),kg0:pes[tp]||pes.RPC,
      via:p.rmp?'rmp':'sob',ori:a.ori||a.deCod||'',sobDe:p.rmp?(a.sobDe||null):(a.de||null)})});
}
/* viajes que pueden recibir: el mismo, los que siguen en proceso de las dos empresas o uno nuevo */
function rmpDests(m){return visible().filter(x=>mainOf(x)===x&&x.id!==m.id&&x.estado!=='completo'&&!orderLocked(x)).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).slice(0,12)}
function rmpKg(B,tipo){const P=pesosOf(B||{});return P[tipo]||P.RPC}
function rmpLineCalc(a){
  const s=sheet||{},q=s.q||{},v=q[a.id],n0_=Math.max(0,Math.min(a.av,v==null||v===''?a.av:Math.floor(n0(v))));
  const ck=rmpCk(a.ck0,s.tipo,(s.mm||{})[a.id]),kg1=rmpKg(s._dest,s.tipo),prop=kg1>0?Math.floor(n0_*a.kg0/kg1+1e-9):0;
  const nq=s.nq||{},gv=(k,d)=>{const e=nq[k];return e==null||e===''?d:Math.max(0,Math.floor(n0(e)))};
  /* v8.21.5: el 200 que pasa a 10 lb sale en 54 y 48 a la vez, mitad y mitad; cada uno se corrige ahí mismo */
  if(s.tipo==='CTN10'&&a.ck0==='c200'){const h=Math.ceil(prop/2),n54=gv(a.id,h),n48=gv(a.id+'#48',prop-h),n=n54+n48;
    return {a:a,n0:n0_,ck:'m54',kg1:kg1,prop:prop,n:n,split:[{ck:'m54',n:n54},{ck:'m48',n:n48}],merma:Math.round((n0_*a.kg0-n*kg1)*100)/100}}
  const n=gv(a.id,prop);
  return {a:a,n0:n0_,ck:ck,kg1:kg1,prop:prop,n:n,merma:Math.round((n0_*a.kg0-n*kg1)*100)/100};
}
function openRmp(o){
  if(!o||ro)return;const m=mainOf(o);
  if(orderLocked(m)){toast(wkLab(wkOf(m))+' está cerrada. Un administrador puede reabrirla en Periodos');return}
  if(!rmpAvail(o).length){toast('Este viaje no tiene cajas empacadas disponibles para reempaque');return}
  const D=rmpDests(m);
  sheet={kind:'rmp',oid:o.id,sel:{},q:{},nq:{},mm:{},tipo:'CTN10',dest:m.estado!=='completo'?'self':(D[0]?D[0].id:'new:'+m.emp)};renderSheet();
}
function rmpDestOf(m){const d=sheet.dest;if(d==='self')return m;if(String(d).indexOf('new:')===0)return null;return orders.find(x=>x.id===d)||null}
function rmpHtml(){
  const o=orders.find(x=>x.id===sheet.oid);if(!o)return '';const m=mainOf(o),A=rmpAvail(o),sel=sheet.sel||{},q=sheet.q||{},tipo=sheet.tipo;
  const B=rmpDestOf(m);sheet._dest=B||{emp:String(sheet.dest).slice(4)};
  const G=new Map();A.forEach(a=>{const k=a.q+'|'+a.key;let g=G.get(k);if(!g)G.set(k,g={q:a.q,key:a.key,nombre:a.nombre,cls:a.cls,L:[]});g.L.push(a)});
  const grp=[...G.values()].sort((x,y)=>x.q.localeCompare(y.q)||String(x.nombre).localeCompare(String(y.nombre)));
  let lastQ='';
  const list=grp.map(g=>{const hd=g.q!==lastQ?`<div class="wkhd">${g.q==='1.5'?'Calidad 1.5':'Primera'}</div>`:'';lastQ=g.q;
    return hd+`<div class="s2g"><div class="s2h"><div><strong>${esc(g.nombre)}</strong><small>${esc(/^(VL|EC)-\d+$/.test(g.key)?g.key:'sin código')}${g.cls?' · '+esc(PCLS_L[g.cls]||g.cls):''}</small></div></div>${g.L.map(a=>`<label class="s2r rmr" for="rm-${esc(a.id)}"><input type="checkbox" id="rm-${esc(a.id)}" data-rmsel="${esc(a.id)}"${sel[a.id]?' checked':''}><span class="s2d"><b>${esc(TIPO_L[a.tipo0]||a.tipo0)} · ${esc(calLab(a.ck0))}</b><small>${a.src==='pal'?'<span class="chip info">Tarima '+a.palN+'</span> ':a.src==='piso'?'<span class="chip">En piso</span> ':''}disponible ${fmt(a.av)} · ${fmt(a.av*a.kg0,0)} kg${a.via?' · '+(a.via==='rmp'?'reempaque':'sobrante')+(a.ori?' de '+esc(a.ori):''):''}</small></span><input class="in" inputmode="numeric" autocomplete="off" data-rmq="${esc(a.id)}" value="${q[a.id]!=null?esc(q[a.id]):fmt(a.av).replace(/,/g,'')}" aria-label="Cajas de ${esc(g.nombre)} ${esc(calLab(a.ck0))} que se reempacan"${sel[a.id]?'':' disabled'}></label>`).join('')}</div>`}).join('');
  const C=A.filter(a=>sel[a.id]).map(rmpLineCalc);
  const conv=C.length?C.map(x=>{const a=x.a;
    const ins=x.split?x.split.map((y,i)=>`<label class="rmsp"><span>${esc(calLab(y.ck))}</span><input class="in" inputmode="numeric" autocomplete="off" data-rmn="${esc(a.id+(i?'#48':''))}" value="${y.n}" aria-label="Cajas de ${esc(TIPO_L[tipo])} ${esc(calLab(y.ck))} que salieron de ${esc(a.nombre)}"></label>`).join(''):`<input class="in" inputmode="numeric" autocomplete="off" data-rmn="${esc(a.id)}" value="${x.n}" aria-label="Cajas de ${esc(TIPO_L[tipo])} que salieron de ${esc(a.nombre)}">`;
    return `<div class="rmc"><div><b>${esc(a.nombre)}</b><small>${fmt(x.n0)} ${esc(TIPO_L[a.tipo0])} ${esc(calLab(a.ck0))} (${fmt(x.n0*a.kg0,0)} kg) → ${x.split?esc(TIPO_L[tipo])+' 54 y 48':x.ck?esc(TIPO_L[tipo])+' '+esc(calLab(x.ck)):'<b class="neg">sin calibre equivalente</b>'}</small></div><div class="rmci${x.split?' rmci2':''}">${ins}<small data-rmm="${esc(a.id)}">${x.merma>0.005?'merma '+fmt(x.merma,1)+' kg':x.merma<-0.005?'+'+fmt(-x.merma,1)+' kg':'sin merma'}</small></div></div>`}).join(''):'<p class="note">Marca la fruta que se reempaca.</p>';
  const D=rmpDests(m),nv=e=>codOf(e,m.anio,nextCons(e,m.anio));
  const opt=(v,t,s)=>`<label class="pnopt"><input type="radio" name="rmdest" value="${esc(v)}" data-rmdest="1"${sheet.dest===v?' checked':''}><span><b class="mono">${esc(t)}</b><small>${esc(s)}</small></span></label>`;
  const dests=(m.estado!=='completo'?opt('self',m.cod,'El mismo viaje, en otra tarima'):'')+D.map(x=>opt(x.id,x.cod,(EMPS[x.emp]||{}).name+' · Semana '+(x.semana||'—')+' · '+fmtDate(x.fecha)+' · en proceso')).join('')+Object.keys(EMPS).map(e=>opt('new:'+e,nv(e),'Pedido nuevo de '+EMPS[e].name+' con el encabezado vacío')).join('');
  return `<h3>Reempaque · ${esc(m.cod)}</h3><p class="note">La fruta ya empacada de este viaje pasa a otra presentación. No es fruta nueva: al productor se le paga como en este empaque (kilos, calibres y rendimiento). La venta cuenta en el viaje que la recibe, con el precio de la presentación nueva.</p>
<p class="note">Solo aparece la fruta en existencia: en piso o en una tarima${manClosed(m)?'. <b>El manifiesto está cerrado</b>: lo que está en sus tarimas ya no se ofrece':' abierta. Al reempacar desde una tarima, la app la descuenta sola'}.</p>
<div class="srow2"><button class="btn sm" data-act="rmpall">Seleccionar todo</button><button class="btn sm" data-act="rmpnone">Limpiar</button></div>
<div class="s2list rmlist">${list}</div>
<div class="sec">Presentación nueva</div><div class="seg rmt" role="group" aria-label="Presentación nueva">${TIPO_K.map(t=>`<button data-act="rmt:${t}" aria-pressed="${tipo===t}">${esc(TIPO_L[t])}</button>`).join('')}</div>
<div class="sec">¿A qué viaje va?</div><div class="pnopts rmdests" role="radiogroup" aria-label="Viaje que recibe">${dests}</div>
<div class="sec">Conversión · cajas que salieron</div><p class="note">La app propone por peso (${esc(TIPO_L[tipo])} de ${fmt(rmpKg(sheet._dest,tipo),2)} kg); corrige con las cajas reales y la diferencia queda como merma.</p><div class="panel rmconv">${conv}</div>
<p class="s2tot" id="rmtot">${esc(rmpTot(C))}</p>
<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="rmpok">Reempacar</button></div>`;
}
function rmpTot(C){let a=0,b=0,k0=0,k1=0;C.forEach(x=>{a+=x.n0;b+=x.n;k0+=x.n0*x.a.kg0;k1+=x.n*x.kg1});return C.length?'Salen '+fmt(a)+' cajas ('+fmt(k0,0)+' kg) → '+fmt(b)+' cajas de '+(TIPO_L[sheet.tipo]||'')+' ('+fmt(k1,0)+' kg)'+(k0-k1>0.5?' · merma '+fmt(k0-k1,0)+' kg':''):'Nada seleccionado'}
/* hoja del viaje B que recibe la calidad qq (la 1.5 se crea si no existe) */
function rmpSheet(B,qq){
  const sh=sheetsOf(B);if(qq!=='1.5')return sh.find(x=>x.variante==='1')||B;
  let s=sh.find(x=>x.variante==='1.5');if(s)return s;
  s=newOrder({emp:B.emp,anio:B.anio,cons:B.cons,cod:B.cod,emb:B.emb,po:B.po,fecha:B.fecha,semana:B.semana,customer:B.customer,domestic:B.domestic,factura:B.factura,variante:'1.5'});s.kgCaja=B.kgCaja;orders.push(s);return s;
}
function rmpDo(){
  const o=orders.find(x=>x.id===(sheet&&sheet.oid));if(!o||ro)return;const m=mainOf(o),tipo=sheet.tipo;
  if(orderLocked(m)){toast(wkLab(wkOf(m))+' está cerrada');return}
  const A=rmpAvail(o),C=A.filter(a=>sheet.sel[a.id]).map(rmpLineCalc).filter(x=>x.n0>0);
  if(!C.length){toast('Marca la fruta que se reempaca');return}
  if(C.some(x=>!x.ck)){toast('Algún calibre no tiene equivalente en '+TIPO_L[tipo]);return}
  if(C.some(x=>!(x.n>0))){toast('Escribe cuántas cajas de '+TIPO_L[tipo]+' salieron');return}
  if(C.some(x=>x.a.src==='pal')&&manClosed(m)){toast('El manifiesto de '+m.cod+' está cerrado: sus tarimas no se reempacan');return}
  let B=rmpDestOf(m),nuevo=false;
  if(B===m&&C.some(x=>x.a.tipo0===tipo&&x.ck===x.a.ck0)){toast('En el mismo viaje elige otra presentación');return}
  if(B&&orderLocked(B)){toast(wkLab(wkOf(B))+' está cerrada');return}
  if(!B){const e=String(sheet.dest).slice(4)||m.emp,y=m.anio||String(todayISO()).slice(0,4),cons=nextCons(e,y),hoy=todayISO();
    B=newOrder({emp:e,anio:y,cons:cons,cod:codOf(e,y,cons),emb:'',po:'',fecha:hoy,semana:isoWeek(hoy),customer:'',domestic:'',factura:'',variante:'1'});orders.push(B);nuevo=true}
  const rid=uid(),at=Date.now(),by=(authUser&&(authUser.name||authUser.user))||'—',byQ={};
  C.forEach(x=>(byQ[x.a.q]=byQ[x.a.q]||[]).push(x));
  let n0t=0,nt=0;
  Object.keys(byQ).forEach(qq=>{
    const S=rmpSheet(B,qq);let row=(S.productores||[]).find(p=>p.rmp);
    if(!row){rmpOwnMig(S);row=newProd('REEMPAQUE',null,'');row.sob2=true;row.rmp=true;row.sobAp=[];row.tipos=[];S.productores.unshift(row)}
    const D={};
    byQ[qq].forEach(x=>{const a=x.a;
      /* el 200 repartido en 54 y 48 se guarda como dos registros; las cajas de origen se reparten en la misma proporción */
      const parts=(x.split||[{ck:x.ck,n:x.n}]).filter(y=>y.n>0);let r0=x.n0;
      /* v8.25: si sale de una tarima, se descuenta de ella y queda el rastro para deshacer */
      const tk=a.src==='pal'?palTake(m,a.pal,a.q==='1.5'?'1.5':'1',a.ck0,a.key,x.n0):null,pt=a.src==='pal'?((ensureTraz(m).tarimas.find(p=>p.id===a.pal))||{}):null;
      parts.forEach((y,i)=>{const c0=i===parts.length-1?r0:Math.round(x.n0*y.n/x.n);r0-=c0;
        row.sobAp.push({src:a.src||null,pal:a.pal||null,palN:a.palN||null,palTipo:pt&&pt.id?palTipo(pt):null,palTk:i===0&&tk?tk:undefined,id:uid(),rid:rid,de:a.sid,deCod:m.cod,deEmp:m.emp,pid:a.pid,key:a.key,nombre:a.nombre,codigo:a.codigo,cls:a.cls,q:qq,via:a.via||null,ori:a.via?(a.ori||null):null,sobDe:a.sobDe||null,tipo0:a.tipo0,ck0:a.ck0,n0:c0,kg0:a.kg0,tipo:tipo,ck:y.ck,n:y.n,kg:x.kg1,at:at,by:by});
        (D[tipo]=D[tipo]||{})[y.ck]=((D[tipo]||{})[y.ck]||0)+y.n});
      n0t+=x.n0;nt+=x.n});
    if(!row.tipos.length){row.tipos=Object.keys(D);row.tipo=row.tipos[0]}
    sobShift(S,row,D);touch(S);
  });
  touch(m);
  const nPal=C.filter(x=>x.a.src==='pal').reduce((s,x)=>s+x.n0,0);
  logAdd({k:'note',ctx:ctxOf(m),lab:'Reempaque a '+TIPO_L[tipo],o:fmt(n0t)+' cajas'+(nPal?' ('+fmt(nPal)+' de tarimas)':''),n:B.cod+' · '+fmt(nt)+' cajas de '+TIPO_L[tipo]});
  if(B!==m)logAdd({k:'note',ctx:ctxOf(B),lab:'Reempaque recibido de '+m.cod,o:'',n:fmt(nt)+' cajas de '+TIPO_L[tipo]});
  sheet=null;renderSheet();render();
  toast(fmt(nt)+' cajas de '+TIPO_L[tipo]+' en el renglón REEMPAQUE de '+B.cod+(nuevo?' (pedido nuevo)':'')+'. Arma su tarima en Código de Trazabilidad');
}
/* deshacer un reempaque: las cajas regresan a su viaje de origen */
function rmpBack(sid,rid){
  const S=orders.find(x=>x.id===sid);if(!S||ro)return;const row=(S.productores||[]).find(p=>p.rmp);if(!row)return;
  if(S.estado==='completo'||orderLocked(S)){toast('Este registro ya está completo o su semana cerrada');return}
  if(rmpOutRow(S.id,row.id).length){toast('De este renglón ya se volvió a reempacar. Primero regresa ese reempaque');return}
  const k='rmback:'+sid+':'+rid;if(confirmKey!==k){armConfirm(k);render();return}confirmKey=null;
  const out=row.sobAp.filter(a=>a.rid===rid);if(!out.length)return;
  const srcM=(()=>{const x=orders.find(y=>y.id===out[0].de);return x?mainOf(x):null})();
  if(srcM&&out.some(a=>a.palTk&&a.palTk.length)&&manClosed(srcM)){toast('El manifiesto de '+srcM.cod+' está cerrado. Reábrelo para regresar las cajas a su tarima');return}
  if(srcM)out.forEach(a=>{if(a.palTk&&a.palTk.length)palGive(srcM,a)});if(srcM)touch(srcM);
  const D={};out.forEach(a=>{(D[a.tipo]=D[a.tipo]||{})[a.ck]=((D[a.tipo]||{})[a.ck]||0)-n0(a.n)});
  row.sobAp=row.sobAp.filter(a=>a.rid!==rid);sobShift(S,row,D);
  if(!row.sobAp.length){const ri=S.productores.indexOf(row),r=compute(S).rows[ri];if(r&&!(r.t>0))S.productores.splice(ri,1)}
  touch(S);const src=orders.find(x=>x.id===out[0].de);if(src)touch(src);
  logAdd({k:'note',ctx:ctxOf(S),lab:'Reempaque regresado a '+(out[0].deCod||'su viaje'),o:fmt(out.reduce((s,a)=>s+n0(a.n),0))+' cajas',n:''});
  render();toast('Las cajas regresaron a '+(out[0].deCod||'su viaje'));
}
/* v8.21.3 · cajas chicas = cajas que salieron de su primer empaque; kilos = esas cajas × su peso (la fruta que entró a reempacar).
   Solo informativo: sin pago ni kilos nuevos en Finanzas y Estadísticas. Con force=false solo llena casillas vacías (pedidos de la 8.21.0 a 8.21.2). */
function rmpFill(row,force){
  if(!row||!row.rmp)return;const L=row.sobAp||[];if(!force&&(row.k18!=null||row.kilos!=null||!L.length))return;
  const c=L.reduce((s,a)=>s+n0(a.n0),0),k=L.reduce((s,a)=>s+n0(a.n0)*n0(a.kg0),0);
  row.k18=c||null;row.kilos=c?Math.round(k*100)/100:null;
}
function rmpTxt(a){return fmt(n0(a.n0))+' '+(TIPO_L[a.tipo0]||a.tipo0)+' '+calLab(a.ck0)+(a.src==='pal'&&a.palN?' de la tarima '+a.palN:a.src==='piso'?' en piso':'')+' → '+fmt(n0(a.n))+' '+(TIPO_L[a.tipo]||a.tipo)+' '+calLab(a.ck)+(a.via==='rmp'?' · reempaque de '+(a.ori||'otro viaje'):a.via==='sob'?' · sobrante de '+(a.ori||'otro viaje'):'')}
/* resumen dentro del renglón REEMPAQUE (viaje que recibe) */
function rmpRowHtml(o,p){
  const ops=new Map();(p.sobAp||[]).forEach(a=>{let g=ops.get(a.rid);if(!g)ops.set(a.rid,g={rid:a.rid,deCod:a.deCod,at:a.at,by:a.by,L:[]});g.L.push(a)});
  const can=!ro&&o.estado!=='completo'&&!orderLocked(o),t=(p.sobAp||[]).reduce((s,a)=>s+n0(a.n),0);
  return `<div class="apbox"><div class="sec">Resumen · fruta reempacada (ya se pagó en su primer empaque)</div>${[...ops.values()].map(g=>{const k='rmback:'+o.id+':'+g.rid,mk=g.L.reduce((s,a)=>s+n0(a.n0)*n0(a.kg0)-n0(a.n)*n0(a.kg),0);
    return `<div class="rmop"><div class="rmoh"><b>De ${esc(g.deCod||'otro viaje')}</b><small>${esc(fmtTs(g.at))} · ${esc(g.by||'—')}${mk>0.5?' · merma '+fmt(mk,0)+' kg':''}</small></div>${g.L.map(a=>`<div class="apr sobr"><span class="apn"><b>${esc(a.nombre||a.key)}</b><small>${esc(sobCod(rmpKey(o,a)))}${a.cls?' · '+esc(PCLS_L[a.cls]||a.cls):''} · ${esc(rmpTxt(a))}</small></span><b class="mono">${fmt(n0(a.n))}</b></div>`).join('')}${can?`<div class="pact"><button class="btn sm" data-act="${k}">${confirmKey===k?'Toca otra vez':'↩ Regresar a '+esc(g.deCod||'su viaje')}</button></div>`:''}</div>`}).join('')||'<p class="note">Sin fruta reempacada.</p>'}<div class="kv" style="border-bottom:0"><span>Total reempacado</span><b>${fmt(t)} cajas</b></div><p class="note">Las cajas pequeñas y los kilos son los de su primer empaque y no se pagan otra vez. Con estas cajas se arma la tarima en Código de Trazabilidad; cada caja sigue con su productor.</p></div>`;
}
/* aviso en el productor del viaje de origen */
function rmpSrcHtml(o,p){
  const L=rmpOutRow(o.id,p.id);if(!L.length)return '';
  return `<div class="panel info rmsrc"><strong>Reempacado: ${fmt(L.reduce((s,a)=>s+n0(a.n0),0))} cajas</strong>${L.map(a=>`<div class="kv"><span>${esc(rmpTxt(a))}</span><b class="mono">${esc(a.to.cod)}</b></div>`).join('')}<p class="note">Su pago, kilos y rendimiento siguen siendo los de este empaque. Estas cajas ya no van en las tarimas de este viaje.</p></div>`;
}
function rmpNoteLines(row){return (row.sobAp||[]).map(a=>sobCod(a.key)+' · '+(a.nombre||a.key||'')+' · '+rmpTxt(a)+' · de '+(a.deCod||''))}
function rmpOutNotes(o,p){return rmpOutRow(o.id,p.id).map(a=>'Reempaque: '+rmpTxt(a)+' · a '+a.to.cod)}

function sobImport(o,pids){
  const m=mainOf(o),P=sobPend(m).filter(x=>!pids||pids.indexOf(x.p.id)>=0);if(!P.length)return 0;
  let row=sobRow(m),c=0;
  if(!row){row=newProd('SOBRANTES',null,'');row.sob2=true;row.sobAp=[];row.tipos=[];m.productores.unshift(row)}
  const D={};
  P.forEach(x=>{const tp=palTipo(x.p);x.ls.forEach(l=>{const ck=PCAL_KEY[l.cal],n=n0(l.cant),lt=tp,lf=lineFrom(x.p,l);row.sobAp.push({id:uid(),lid:l.id,pid:x.p.id,de:lf.oid,deCod:lf.cod,pn:lf.n,key:l.prod,nombre:l.dn||'',tipo:tp,ck:ck,n:n});(D[lt]=D[lt]||{})[ck]=((D[lt]||{})[ck]||0)+n;c+=n})});
  if(!row.tipos.length){row.tipos=Object.keys(D);row.tipo=row.tipos[0]}
  sobShift(m,row,D);touch(m);
  logAdd({k:'add',ctx:ctxOf(m),lab:'Sobrantes importados',o:'',n:fmt(c)+' cajas de '+P.length+(P.length===1?' tarima':' tarimas')});
  return c;
}
function sobUnimport(m,p){
  const row=sobRow(m);if(!row||!row.sobAp)return;
  const out=row.sobAp.filter(a=>a.pid===p.id);if(!out.length)return;
  const D={};out.forEach(a=>{const lt=a.tipo;(D[lt]=D[lt]||{})[a.ck]=((D[lt]||{})[a.ck]||0)-n0(a.n)});
  row.sobAp=row.sobAp.filter(a=>a.pid!==p.id);
  sobShift(m,row,D);
  if(!row.sobAp.length){const ri=m.productores.indexOf(row);const tot=compute(m).rows[ri];if(tot&&!(tot.t>0))m.productores.splice(ri,1)}
}
/* v8.26.4: se corrige una línea de una tarima que viene de otro viaje (calibre o cajas): el renglón SOBRANTES cambia lo mismo.
   Se mueve solo la diferencia, para no tocar lo que ya se reempacó de esa línea */
function sobLineSync(m,p,l,ock,on){
  const row=sobRow(m);if(!row||!row.sobAp)return;
  const E=row.sobAp.filter(a=>a.pid===p.id&&a.lid===l.id&&!a.piso);if(!E.length)return;
  const ck=PCAL_KEY[l.cal]||null,n=n0(l.cant),tp=E[0].tipo,D={},add=(c,v)=>{if(!c||!v)return;(D[tp]=D[tp]||{})[c]=((D[tp]||{})[c]||0)+v};
  if(ck&&ck===ock){const a=E.find(x=>x.ck===ck)||E[0],d=Math.max(-n0(a.n),n-on);a.n=n0(a.n)+d;add(ck,d)}
  else{let r=on;E.filter(x=>x.ck===ock).forEach(a=>{const v=Math.min(n0(a.n),r);if(!(v>0))return;a.n=n0(a.n)-v;r-=v;add(ock,-v)});
    if(ck&&n>0){const a=E.find(x=>x.ck===ck);if(a)a.n=n0(a.n)+n;else row.sobAp.push(Object.assign({},E[0],{id:uid(),ck:ck,n:n}));add(ck,n)}}
  row.sobAp=row.sobAp.filter(a=>!(a.pid===p.id&&a.lid===l.id)||n0(a.n)>0);
  sobShift(m,row,D);touch(m);
}
function openSobIm(o){if(!o||ro)return false;const m=mainOf(o),P=sobPend(m);if(!P.length)return false;const sel={};P.forEach(x=>sel[x.p.id]=true);sheet={kind:'sobim',oid:m.id,sel:sel};renderSheet();return true}
function sobimHtml(){
  const o=orders.find(x=>x.id===sheet.oid);if(!o)return '';const P=sobPend(o),sel=sheet.sel||{};
  let tot=0;P.forEach(x=>{if(sel[x.p.id])tot+=x.n});
  return `<h3>Sobrantes del viaje anterior</h3><p class="note">Tarimas que el jefe de empaque mandó a este pedido. Ya están en Código de Trazabilidad; al importarlas entran juntas en el renglón SOBRANTES, con el detalle de cada productor (sin kilos ni pago: ya se pagaron en su viaje).</p>
<div class="s2list">${P.map(x=>{const g=new Map();x.ls.forEach(l=>{const k=l.prod;let a=g.get(k);if(!a)g.set(k,a={k:k,nm:l.dn||'',by:[],n:0});a.by.push(calLab(PCAL_KEY[l.cal])+': '+fmt(n0(l.cant)));a.n+=n0(l.cant)});
  return `<label class="s2g sobg" for="sb-${x.p.id}"><div class="s2h"><div><strong>Tarima ${x.p.from.n} de ${esc(x.p.from.cod)}</strong><small>${esc(TIPO_L[palTipo(x.p)]||'')} · ${fmt(x.n)} cajas · aquí es la tarima ${x.i+1}</small></div><input type="checkbox" id="sb-${x.p.id}" data-sobsel="${x.p.id}"${sel[x.p.id]?' checked':''}></div>${[...g.values()].map(a=>`<div class="kv"><span>${sobLab(a.k,a.nm)}<br><small class="note">${esc(a.by.join(' · '))}</small></span><b>${fmt(a.n)}</b></div>`).join('')}</label>`}).join('')}</div>
<p class="s2tot">Seleccionadas: ${fmt(tot)} cajas</p>
<div class="srow2"><button class="btn" data-act="closesheet">Después</button><button class="btn primary" data-act="sobimok">Importar a SOBRANTES</button></div>`;
}
/* texto por productor (código, nombre, cajas, calibres y tarima de origen): resumen en pantalla y notas del Excel */
function sobGroups(row){
  const g=new Map();
  (row.sobAp||[]).forEach(a=>{if(!(n0(a.n)>0))return;const k=a.key+'|'+(a.piso?'piso:'+a.mv:a.pid);let x=g.get(k);if(!x)g.set(k,x={key:a.key,nombre:a.nombre,deCod:a.deCod,pn:a.pn,piso:!!a.piso,mv:a.mv,tipo:a.tipo,by:{},n:0});x.by[a.ck]=(x.by[a.ck]||0)+n0(a.n);x.n+=n0(a.n)});
  return [...g.values()].sort((a,b)=>String(a.deCod).localeCompare(String(b.deCod))||((a.pn||0)-(b.pn||0))||String(a.key).localeCompare(String(b.key)));
}
function sobCalTxt(by){return CAL.filter(c=>by[c.k]).map(c=>c.l+': '+fmt(by[c.k])).join(', ')}
/* código y nombre de un productor de sobrante; si no tiene código, su clave es el nombre */
function sobLab(k,nm){const c=/^[A-Z]{2}-\d{3}$/.test(String(k||''));return c?`<b class="mono">${esc(k)}</b> ${esc(nm||'')}`:`<b>${esc(nm||k||'')}</b> <small class="note">sin código</small>`}
const sobCod=k=>/^[A-Z]{2}-\d{3}$/.test(String(k||''))?k:'sin código';
function sobNoteLines(row){return sobGroups(row).map(x=>sobCod(x.key)+' · '+(x.nombre||x.key||'')+' · '+fmt(x.n)+' cajas · '+sobCalTxt(x.by)+' · '+(TIPO_L[x.tipo]||x.tipo)+' · '+(x.piso?'En piso de ':'Tarima '+x.pn+' de ')+x.deCod)}
function sob2Html(o,p){
  const G=sobGroups(p),t=G.reduce((a,x)=>a+x.n,0),pend=ro?[]:sobPend(o);
  /* v8.25.4: lo que ya salió a reempaque se marca en cada línea; el conteo del renglón sigue siendo lo que llegó */
  const out={};rmpOutRow(o.id,p.id).forEach(a=>{const k=a.key+'|'+a.tipo0+'|'+a.ck0;out[k]=(out[k]||0)+n0(a.n0)});
  let rt=0;const ln=x=>{const r={};CAL.forEach(c=>{const v=x.by[c.k];if(!v)return;const k=x.key+'|'+x.tipo+'|'+c.k,u=Math.min(v,out[k]||0);if(u>0){r[c.k]=u;out[k]-=u;rt+=u}});return r};
  const rows=G.map(x=>{const r=ln(x),u=Object.keys(r).reduce((s,k)=>s+r[k],0),left=x.n-u;
    return `<div class="apr sobr${left<=0?' rmpdone':''}"><span class="apn"><b>${esc(x.nombre||x.key)}</b><small>${esc(sobCod(x.key))} · ${esc(TIPO_L[x.tipo]||x.tipo)} · ${esc(sobCalTxt(x.by))} · ${x.piso?'En piso (sin tarima) de':'Tarima '+x.pn+' de'} ${esc(x.deCod)}</small>${u?`<small class="rmpmk">${left<=0?'Reempacadas todas':'Reempacadas '+esc(sobCalTxt(r))+' · quedan '+fmt(left)}</small>`:''}</span><b class="mono">${u?`<s>${fmt(x.n)}</s> ${fmt(left)}`:fmt(x.n)}</b></div>`}).join('');
  return `<div class="apbox"><div class="sec">Resumen · sobrantes del viaje anterior</div>${G.length?rows:'<p class="note">Todavía no hay tarimas importadas.</p>'}<div class="kv"${rt?'':' style="border-bottom:0"'}><span>Total de sobrantes que llegaron</span><b>${fmt(t)} cajas</b></div>${rt?`<div class="kv"><span>Ya reempacadas</span><b>${fmt(rt)} cajas</b></div><div class="kv" style="border-bottom:0"><span>Quedan como sobrantes</span><b>${fmt(t-rt)} cajas</b></div><p class="note">El conteo por calibre de este renglón sigue siendo lo que llegó. Lo reempacado ya no se espera en las tarimas de este viaje: va en el renglón REEMPAQUE.</p>`:''}${pisoBackHtml(o,p)}<p class="note">El conteo por calibre de este renglón es la suma de todas las tarimas${(p.sobAp||[]).some(a=>a.piso)?' y de lo que llegó en piso':''}. Para corregir una tarima, usa «Regresar a su viaje» en la tarima, en Código de Trazabilidad.</p>${pend.length?`<div class="pact"><button class="btn sm" data-act="sobim" data-edit>+ Importar sobrantes (${fmt(pend.reduce((a,x)=>a+x.n,0))})</button></div>`:''}</div>`;
}

/* ---------- v8.25.5 · sobrantes en piso a otro viaje, sin tarima ----------
   Cajas de primera registradas que no están en ninguna tarima. Pasan al renglón SOBRANTES del viaje que se elija
   (de la misma empresa o de la otra) como sobAp con piso:1 y mv (la clave del movimiento). Ahí se entariman con la fruta de ese viaje.
   En el viaje de origen cuentan en «Próximo viaje» (sentOf) y ya no se esperan en sus tarimas. */
function pisoItems(o){
  /* no más de lo que el viaje espera de más en piso por línea (expL − tarimas): así nunca quedan cajas de más en sus tarimas */
  const X=exisData(o),z=trazCalc(o),left={},out=[];
  X.G.forEach(g=>g.L.forEach(r=>{if(r.q!=='1'||r.via||!(r.piso>0))return;const L=lineKey('1',lineType(r.tipo,r.ck)),k=L+'|'+r.ck;
    if(left[k]==null)left[k]=Math.max(0,((z.expL[L]||{})[r.ck]||0)-((z.palL[L]||{})[r.ck]||0));const n=Math.min(r.piso,left[k]);left[k]-=n;
    out.push({id:g.key+'|'+r.tipo+'|'+r.ck,key:g.key,nombre:g.nombre,tipo:r.tipo,ck:r.ck,n:n,piso:r.piso})}));
  return out;
}
function pisoMvSheet(o){
  const m=o&&mainOf(o);if(!m||ro)return;if(orderLocked(m)){toast(wkLab(wkOf(m))+' está cerrada');return}
  if(!pisoItems(m).length){toast('No hay cajas de primera en piso');return}
  /* v8.26.3: la ventana abre aunque nada se pueda mover, para decir por qué */
  const C=palNextCands(m),B=nextTripOf(m);
  sheet={kind:'pisomv',oid:m.id,dest:B&&C.some(x=>x.id===B.id)?B.id:(C[0]?C[0].id:'new'),q:{}};renderSheet();
}
function pisoQ(m){const q=(sheet&&sheet.q)||{};return pisoItems(m).filter(x=>x.n>0).map(x=>{const v=q[x.id];return {x:x,k:Math.max(0,Math.min(x.n,v==null||v===''?x.n:Math.floor(n0(v))))}})}
function pisoMvHtml(){
  const m=orders.find(x=>x.id===sheet.oid);if(!m)return '';const C=palNextCands(m),nc=codOf(m.emp,m.anio,nextCons(m.emp,m.anio)),Q=pisoQ(m),tot=Q.reduce((a,y)=>a+y.k,0);
  const dest=sheet.dest==='new'?null:C.find(x=>x.id===sheet.dest)||null,cod=dest?dest.cod:nc;
  const opts=`<div class="sec">¿A qué viaje van?</div><div class="pnopts" role="radiogroup" aria-label="Viaje que recibe las cajas">${C.map(x=>`<label class="pnopt"><input type="radio" name="pmdest" value="${x.id}" data-pmdest="1"${sheet.dest===x.id?' checked':''}><span><b class="mono">${esc(x.cod)}</b>${x.emp!==m.emp?` <span class="chip info">${esc(empNm(x.emp))}</span>`:''}<small>${esc(x.emb||'sin embarque')} · Semana ${esc(x.semana||'—')} · ${fmtDate(x.fecha)} · en proceso</small></span></label>`).join('')}<label class="pnopt"><input type="radio" name="pmdest" value="new" data-pmdest="1"${sheet.dest==='new'?' checked':''}><span><b class="mono">${esc(nc)}</b><small>Pedido nuevo con el encabezado vacío</small></span></label></div>`;
  const blk=pisoItems(m).filter(x=>!(x.n>0));
  const rows=Q.map(y=>`<div class="kv pnq"><span>${sobLab(y.x.key,y.x.nombre)}<br><small class="note">${esc(TIPO_L[y.x.tipo]||y.x.tipo)} · calibre ${esc(calLab(y.x.ck))} · ${y.x.n<y.x.piso?'se pueden mover '+fmt(y.x.n)+' de '+fmt(y.x.piso)+' en piso':'en piso '+fmt(y.x.n)}</small></span><input class="in" type="text" inputmode="numeric" pattern="[0-9]*" data-pmq="${esc(y.x.id)}" value="${y.k}" aria-label="Cajas que se mueven de ${esc(y.x.nombre||y.x.key)}, calibre ${esc(calLab(y.x.ck))}"></div>`).join('');
  return `<h3>Mover sobrantes en piso a otro viaje</h3><p class="note">Cajas de primera registradas en ${esc(m.cod)} que no están en ninguna tarima. Pasan sin tarima al renglón SOBRANTES del viaje que elijas, con su productor (sin kilos ni pago: ya se pagaron aquí). Allá se entariman con la fruta de ese viaje.</p>${opts}
<div class="sec">Cajas de cada productor</div><div class="panel">${rows||'<p class="note">No hay cajas en piso que se puedan mover.</p>'}${blk.length?`<div class="warnbox" role="note"><strong>No se pueden mover</strong>${blk.map(x=>`<div>${esc((x.nombre||x.key)+' · '+(TIPO_L[x.tipo]||x.tipo)+' '+calLab(x.ck)+': '+fmt(x.piso)+' en piso')}</div>`).join('')}<p class="note">En el renglón del productor están en piso, pero en el conteo de todo el viaje (${esc(blk.map(x=>TIPO_L[x.tipo]||x.tipo).filter((v,i,a)=>a.indexOf(v)===i).join(', '))}) ya no sobran: lo registrado de esa presentación y calibre ya está en tarimas o salió por reempaque, muchas veces de un renglón que se borró. Revisa los reempaques de este viaje y lo registrado en esa presentación; si las cajas sí están en piso, falta registrarlas bien.</p></div>`:''}<p class="note">Pon 0 en lo que se queda aquí.${Q.some(y=>y.x.n<y.x.piso)?' Donde dice «se pueden mover», el resto de lo que se ve en piso ya cuenta como reempacado (o en tarimas de otro productor) en la revisión del viaje; moverlo dejaría cajas de más en sus tarimas.':''}</p></div>
<p style="margin:8px 0 6px">Van <b id="pmtot">${fmt(tot)}</b> cajas a <b class="mono">${esc(cod)}</b>${dest?'':' (se crea con el encabezado vacío)'}. Si te equivocas, en el renglón SOBRANTES del pedido que las recibe está «Regresar a ${esc(m.cod)}».</p>
<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="pisomvok"${Q.length?'':' disabled'}>Mover a ${esc(cod)}</button></div>`;
}
$sh.addEventListener('input',e=>{const t=e.target;if(!sheet||sheet.kind!=='pisomv'||!t.dataset||!t.dataset.pmq)return;
  t.value=t.value.replace(/\D+/g,'');sheet.q[t.dataset.pmq]=t.value;const m=orders.find(x=>x.id===sheet.oid);if(!m)return;
  const a=document.getElementById('pmtot');if(a)a.textContent=fmt(pisoQ(m).reduce((s,y)=>s+y.k,0))});
$sh.addEventListener('change',e=>{const t=e.target;if(!sheet||sheet.kind!=='pisomv'||!t.dataset)return;
  if(t.dataset.pmdest){sheet.dest=t.value;renderSheet()}else if(t.dataset.pmq){const m=orders.find(x=>x.id===sheet.oid),y=m&&pisoQ(m).find(z=>z.x.id===t.dataset.pmq);if(y)t.value=y.k}});
function pisoMvDo(){
  const m0=orders.find(x=>x.id===(sheet&&sheet.oid));if(!m0||ro)return;const m=mainOf(m0);
  const Q=pisoQ(m).filter(y=>y.k>0),tot=Q.reduce((a,y)=>a+y.k,0);if(!(tot>0)){toast('Escribe cuántas cajas se mueven');return}
  const C=palNextCands(m);let B=sheet.dest==='new'?null:C.find(x=>x.id===sheet.dest)||null,nuevo=false;
  if(!B&&sheet.dest!=='new'){toast('Elige el viaje que las recibe');return}
  if(!B){const cons=nextCons(m.emp,m.anio);const hoy=todayISO();B=newOrder({emp:m.emp,anio:m.anio,cons:cons,cod:codOf(m.emp,m.anio,cons),emb:'',po:'',fecha:hoy,semana:isoWeek(hoy),customer:'',domestic:'',factura:'',variante:'1'});B.sobDe=m.id;orders.push(B);nuevo=true}
  const Bm=mainOf(B);let row=sobRow(Bm);
  if(!row){row=newProd('SOBRANTES',null,'');row.sob2=true;row.sobAp=[];row.tipos=[];Bm.productores.unshift(row)}
  const mv=uid(),at=Date.now(),by=whoName(),D={};
  Q.forEach(y=>{const x=y.x;row.sobAp.push({id:uid(),lid:uid(),pid:null,piso:1,mv:mv,at:at,by:by,de:m.id,deCod:m.cod,pn:null,key:x.key,nombre:x.nombre||'',tipo:x.tipo,ck:x.ck,n:y.k});(D[x.tipo]=D[x.tipo]||{})[x.ck]=((D[x.tipo]||{})[x.ck]||0)+y.k});
  if(!row.tipos.length){row.tipos=Object.keys(D);row.tipo=row.tipos[0]}
  sobShift(Bm,row,D);m.sobPal=1;touch(m);touch(Bm);
  logAdd({k:'note',ctx:ctxOf(m),lab:'Sobrantes en piso a otro viaje',o:'',n:Bm.cod+' · '+fmt(tot)+' cajas sin tarima'});
  sheet=null;renderSheet();render();
  toast(fmt(tot)+' cajas en piso pasaron a '+Bm.cod+(nuevo?' (pedido nuevo)':'')+'. Ya están en su renglón SOBRANTES');
}
/* en el renglón SOBRANTES del viaje que recibe: deshacer cada movimiento en piso */
function pisoBackHtml(o,p){
  const g=new Map();(p.sobAp||[]).forEach(a=>{if(!a.piso)return;let x=g.get(a.mv);if(!x)g.set(a.mv,x={mv:a.mv,deCod:a.deCod,n:0});x.n+=n0(a.n)});
  if(!g.size||ro||o.estado==='completo'||orderLocked(o))return '';
  return `<div class="pact">${[...g.values()].map(x=>{const k='pisoback:'+o.id+':'+x.mv;return `<button class="btn sm" data-act="${k}" data-edit>${confirmKey===k?'Toca otra vez':'↩ Regresar a '+esc(x.deCod||'su viaje')+' ('+fmt(x.n)+' en piso)'}</button>`}).join('')}</div>`;
}
function pisoBack(oid,mv){
  const o=orders.find(x=>x.id===oid);if(!o||ro)return;const m=mainOf(o),row=sobRow(m);if(!row||!row.sobAp)return;
  if(orderLocked(m)){toast(wkLab(wkOf(m))+' está cerrada');return}
  const out=row.sobAp.filter(a=>a.piso&&a.mv===mv);if(!out.length)return;
  if(!sobRmpOk(m,out)){toast('De SOBRANTES ya se reempacaron estas cajas. Primero regresa ese reempaque');return}
  const k='pisoback:'+oid+':'+mv;if(confirmKey!==k){armConfirm(k);render();return}confirmKey=null;
  const D={};let n=0;out.forEach(a=>{(D[a.tipo]=D[a.tipo]||{})[a.ck]=((D[a.tipo]||{})[a.ck]||0)-n0(a.n);n+=n0(a.n)});
  row.sobAp=row.sobAp.filter(a=>out.indexOf(a)<0);sobShift(m,row,D);
  if(!row.sobAp.length){const ri=m.productores.indexOf(row);const tt=compute(m).rows[ri];if(tt&&!(tt.t>0))m.productores.splice(ri,1)}
  const A=orders.find(x=>x.id===out[0].de);touch(m);if(A)touch(mainOf(A));
  logAdd({k:'note',ctx:ctxOf(m),lab:'Sobrantes en piso regresados',o:'',n:(out[0].deCod||'')+' · '+fmt(n)+' cajas'});
  render();toast(fmt(n)+' cajas regresaron a '+(out[0].deCod||'su viaje'));
}

/* ---------- sobrantes entre pedidos ---------- */
/* Lo que se empacó por encima del manifiesto queda guardado y se ofrece en el siguiente pedido de la misma empresa.
   v8.9.1: con la regla nueva (sobPalMode) el sobrante son las tarimas mandadas al próximo viaje */
function leftoverOf(o){
  if(sobPalMode(o)){const S=sentOf(o);if(S.length)return sentLeft(o,S);return{L:{},LT:{},total:0,text:''}}
  /* cada tipo de empaque se compara contra su propio manifiesto */
  const M=compute(o),L={},LT={};let total=0;
  Object.keys(M.manBy).forEach(t=>{const m=M.manBy[t],b=M.byTipo[t]||{};CAL.forEach(c=>{if(m[c.k]==null)return;const v=Math.max(0,(b[c.k]||0)-m[c.k]);if(v>0){(LT[t]=LT[t]||{})[c.k]=v;L[c.k]=(L[c.k]||0)+v;total+=v}})});
  const ks=Object.keys(LT),tag=ks.length>1||(ks[0]&&ks[0]!=='RPC');
  return{L:L,LT:LT,total:total,text:ks.map(t=>(tag?TIPO_L[t]+' ':'')+CAL.filter(c=>LT[t][c.k]).map(c=>c.l+': '+fmt(LT[t][c.k])).join(' · ')).join(' | ')};
}
function prevLeftover(o){
  if(!o||o.variante!=='1')return null;
  const prev=visible().filter(x=>x.emp===o.emp&&x.variante==='1'&&x.id!==o.id&&x.estado==='completo'&&(+x.anio<+o.anio||(+x.anio===+o.anio&&(x.cons||0)<(o.cons||0))))
    .sort((a,b)=>(+b.anio-+a.anio)||((b.cons||0)-(a.cons||0)))[0];
  if(!prev)return null;
  if(sobPalMode(prev))return null;
  if(visible().some(x=>x.productores.some(q=>q.sobDe===prev.id)))return null;
  const lo=leftoverOf(prev);
  return lo.total>0?Object.assign({from:prev},lo):null;
}
function addLeftover(){
  const o=cur();if(!o||ro)return;const lo=prevLeftover(o);if(!lo)return;
  /* el sobrante entra primero a la línea: los acumulados que ya estaban capturados se recorren para incluirlo */
  const ts=Object.keys(lo.LT);
  ts.forEach(t=>{const L=lo.LT[t];o.productores.forEach(p=>{if(p.rmp||tiposOf(p).indexOf(t)<0)return;const a=accOf(p,t);CAL.forEach(c=>{if(L[c.k]&&a[c.k]!=null)a[c.k]=num(a[c.k])+L[c.k]})})});
  const p=newProd(lo.from.cod,null,'Sobrante del pedido anterior');p.sob=true;p.sobDe=lo.from.id;
  p.tipos=ts.length?ts:['RPC'];p.tipo=p.tipos[0];
  ts.forEach(t=>{const a=accOf(p,t,true);CAL.forEach(c=>{if(lo.LT[t][c.k])a[c.k]=lo.LT[t][c.k]})});
  /* inventario inicial: las cajas del sobrante van como cajas pequeñas y los kilos del lote = cajas × 17.8 */
  p.k18=lo.total;p.kilos=Math.round(lo.total*KG_DEF*10)/10;
  o.productores.unshift(p);touch(o);openP=null;render();
  toast('Sobrante de '+lo.from.cod+' agregado: '+fmt(lo.total)+' cajas');
}
/* una hoja 1.5 puede ser el pedido completo (todo segunda): se completa sola si no hay hoja 1 */
function hasMain(o){return sheetsOf(o).some(x=>x.variante==='1')}
function isLeader(o){return !!o&&(o.variante==='1'||!hasMain(o))}
function canComplete(o){return !!o&&!ro&&isLeader(o)&&o.estado!=='completo'&&o.productores.length>0&&compute(o).manT>0}
/* la trazabilidad vive en la hoja principal; si esa hoja cambia, las tarimas se pasan a la nueva principal */
function moveTraz(from,to){
  if(!from||!to||from===to||!from.traz)return;
  if(!to.traz||!(to.traz.tarimas||[]).length){to.traz=from.traz;from.traz=null;touch(to);touch(from)}
}
function removeSheet(o){
  const sibs=sheetsOf(o).filter(x=>x.id!==o.id);
  if(o.traz&&sibs.length)moveTraz(o,sibs.find(x=>x.variante==='1')||sibs[0]);
  o.deleted=true;touch(o);
}
function sheetsOf(o){return visible().filter(x=>x.emp===o.emp&&x.cod===o.cod).sort((a,b)=>a.variante>b.variante?1:-1)}
function mainOf(o){return sheetsOf(o).find(x=>x.variante==='1')||o}
function completeOrder(){
  const o=cur();if(!o||!canComplete(o))return;
  /* v8.14: el pedido completo se queda con los pesos por caja con los que se completó */
  sheetsOf(o).forEach(x=>{x.estado='completo';x.completadoAt=Date.now();x.kgT=Object.assign({},pesosClean(PESOS.kg));if(x.variante==='1')x.sobPal=1;touch(x)});
  logAdd({k:'add',ctx:ctxOf(o),lab:'Completó el registro'});
  invalidateStats();
  sheet={kind:'done',cod:o.cod,id:mainOf(o).id,lo:leftoverOf(o)};renderSheet();render();
}
function reopenOrder(){
  const o=cur();if(!o||ro)return;
  sheetsOf(o).forEach(x=>{x.estado='proceso';delete x.kgT;touch(x)});render();toast('Registro reabierto');
}

/* ---------- código de trazabilidad: datos ---------- */
function ensureTraz(o){
  if(!o.traz){
    o.traz={hdr:{factura:o.factura||'',proveedor:EMPS[o.emp].prov,vendedor:'',tel:'',poCliente:o.po||'',cliente:o.customer||'',pOrder:'',sello:'',transporte:(REG.transportistas.length===1?REG.transportistas[0].n:''),telTransporte:(REG.transportistas.length===1?(REG.transportistas[0].tel||''):''),conductor:'',trailer:'',placas:'',caja:'',placasCaja:''},tarimas:[]};
  }
  if(!o.traz.hdr)o.traz.hdr={};if(!o.traz.tarimas)o.traz.tarimas=[];
  return o.traz;
}
/* tipo de empaque de cada tarima: RPC, 1-1/2 (segunda en RPC), CTN (cartón) y CTN 10 lb. Las tarimas viejas lo deducen de la marca. */
const EMPAQUES=[['RPC','RPC'],['1.5','1-1/2 (segunda)'],['CTN','CTN (cartón)'],['CTN10','CTN 10 lb'],['PLT','PLT']];
const EMP_PL={'RPC':'RPC','1.5':'RPC','CTN':'CARTON','CTN10':'CARTON 10 LBS','PLT':'PLT'};
const EMP_TAG={'CTN':'CTN','CTN10':'CTN 10 LB','PLT':'PLT'};
/* TM: tipo de empaque de cada productor (por su código), tomado de Registro de empaque */
let TM={};
function tipoMapFor(o){
  const m={};
  /* solo se deduce el empaque de productores con un solo tipo; con varios, la tarima debe decirlo */
  try{(sheetsOf(o)||[o]).forEach(x=>(x.productores||[]).forEach(p=>{const k=prodKey(x,p),ts=tiposOf(p);if(k&&!m[k]&&ts.length===1)m[k]=ts[0]}))}catch(e){}
  return m;
}
function palEmp(p){
  if(p&&p.empaque)return p.empaque;
  const ls=(p&&p.lines)||[];
  if(ls.some(l=>/CTN/i.test(String(l.cal||''))))return 'CTN';
  const ts=[];ls.forEach(l=>{const t=TM[l.prod];if(t&&ts.indexOf(t)<0)ts.push(t)});
  const t=ts.find(x=>x!=='RPC')||ts[0];
  if(t==='CTN'||t==='CTN10'||t==='PLT')return t;
  return /UNO\s+Y\s+MEDIO/i.test(String((p&&p.marca)||''))?'1.5':'RPC';
}
/* al cambiar la marca (calidad) o el empaque de una tarima, los dos se mantienen de acuerdo */
/* la calidad la da la marca (primera o uno y medio); la presentación es una de las cuatro. Las tarimas viejas con «1-1/2» pasan a RPC */
const PRES=[['RPC','RPC'],['CTN','CTN (cartón)'],['CTN10','CTN 10 lb'],['PLT','PLT']];
function palCouple(b){
  const m=/^t\.([^.]+)\.(marca|empaque)$/.exec(b||'');if(!m)return;
  const o=trazOrder();if(!o)return;const p=ensureTraz(o).tarimas.find(x=>x.id===m[1]);if(!p)return;
  if(p.empaque==='1.5')p.empaque='RPC';
}
const PL_PROV={EC:'CITRICOS J&C LLC',VL:'VERA LIMES USA LLC'};
const PL_FIELDS=[['salida','Fecha de salida','date'],['hora','Hora de salida','time'],['llegada','Fecha de llegada','date'],['plProv','Proveedor del Packing List','text']];
/* filas del Packing List: una por tarima, con el tamaño (o los tamaños con su cantidad), el empaque y la calidad */
function plRows(z){
  return z.t.tarimas.map((p,i)=>{
    const by={};let tot=0;
    (p.lines||[]).forEach(l=>{const c=n0(l.cant);if(!(c>0))return;const k=String(l.cal||'').replace(/\s*[^\d\s].*$/,'').trim()||String(l.cal||'').trim()||'S/C';by[k]=(by[k]||0)+c;tot+=c});
    const ks=Object.keys(by).sort((a,b)=>(parseFloat(a)||0)-(parseFloat(b)||0));
    let tam='';
    if(ks.length===1)tam=ks[0];
    else if(ks.length>1){const parts=ks.map(k=>k+'-'+by[k]);tam=parts.length>1?parts.slice(0,-1).join(', ')+' Y '+parts[parts.length-1]:parts[0]}
        return{n:i+1,tam:isFinite(+tam)&&tam!==''?+tam:tam,tipo:EMP_PL[palEmp(p)]||'RPC',cal:palCalTxt(p),cajas:tot};
  });
}
function loadCat(){try{return JSON.parse(localStorage.getItem(LS_CAT)||'{}')||{}}catch(e){return {}}}
const LS_REG='empaque-registros';
let REG={vendedores:[],conductores:[],cajas:[],transportistas:null,trailers:[],clientes:null,ts:0,dirty:false};
(function(){try{const r=JSON.parse(localStorage.getItem(LS_REG)||'null');if(r&&typeof r==='object')REG=Object.assign(REG,r)}catch(e){}if(!Array.isArray(REG.transportistas))REG.transportistas=[{id:'t-jlr',n:'JESUS LAGUNES RODRIGUEZ',tel:'271 177 0112'}];if(!Array.isArray(REG.trailers))REG.trailers=[];if(!Array.isArray(REG.clientes))REG.clientes=CAT_SEED.cliente.map((n,i)=>({id:'c-seed'+i,n:n}))})();
function saveReg(stamp){if(stamp){REG.ts=Date.now();REG.dirty=true}try{localStorage.setItem(LS_REG,JSON.stringify(REG))}catch(e){}setSync()}
function catList(field,transp){
  const s=new Set(CAT_SEED[field]||[]);(loadCat()[field]||[]).forEach(v=>s.add(v));
  if(field==='vendedor')REG.vendedores.forEach(x=>s.add(x.n));
  if(field==='conductor'){const t=norm(transp||'').trim();const mine=REG.conductores.filter(x=>t&&norm(x.transporte||'').trim()===t),use=mine.length?mine:REG.conductores;use.forEach(x=>s.add(x.n))}
  if(field==='trailer'){const t=norm(transp||'').trim();const mine=REG.trailers.filter(x=>t&&norm(x.transporte||'').trim()===t),use=mine.length?mine:REG.trailers;use.forEach(x=>s.add(x.n))}
  if(field==='cliente')REG.clientes.forEach(x=>s.add(x.n));
  if(field==='transporte'){REG.transportistas.forEach(x=>s.add(x.n));REG.cajas.forEach(x=>{if(x.transporte)s.add(x.transporte)})}
  if(field==='caja'){const t=norm(transp||'').trim();const mine=REG.cajas.filter(x=>t&&norm(x.transporte||'').trim()===t),use=mine.length?mine:REG.cajas;use.forEach(x=>s.add(x.n))}
  visible().forEach(o=>{const h=o.traz&&o.traz.hdr;if(h&&h[field])s.add(h[field])});
  return [...s].filter(Boolean).sort((a,b)=>a.localeCompare(b));
}
function learnCat(field,val){
  val=String(val||'').trim();if(val.length<2)return;
  try{const c=loadCat();const l=c[field]||[];if(l.indexOf(val)<0){l.push(val);c[field]=l.slice(-60);localStorage.setItem(LS_CAT,JSON.stringify(c))}}catch(e){}
}
const qualityOfMarca=m=>/UNO\s+Y\s+MEDIO/i.test(String(m||''))?'1.5':'1';
function prodKey(o,p){return p.codigo?o.emp+'-'+pad(p.codigo,3):(p.nombre||'')}
function resolveProd(sheetsList,s){
  s=String(s||'').trim();if(!s)return '';
  const n=norm(s).replace(/\s+/g,' ');
  const digits=/^\d+$/.test(s)?+s:null;
  for(const o of sheetsList){for(const p of o.productores){
    const k=prodKey(o,p);
    if(norm(k)===n||norm(p.nombre)===n||(digits!=null&&p.codigo===digits)||(/^(vl|ec)-?\d+$/.test(n)&&p.codigo&&norm(o.emp+'-'+pad(p.codigo,3))===n.replace(/^(vl|ec)-?/,m=>m.slice(0,2)+'-').replace(/-(\d+)$/,(x,d)=>'-'+pad(+d,3))))return k;
  }}
  return s.toUpperCase();
}
/* tipo de empaque de la tarima (1-1/2 es RPC de segunda) y línea calidad|tipo de una línea de tarima */
function palTipo(p){const e=palEmp(p);return e==='1.5'?'RPC':e}
/* v7.9: la calidad va por línea (en una tarima puede ir primera y 1-1/2); la presentación es una sola por tarima. Las tarimas viejas toman la calidad de la marca */
function lineQ(p,l){return l&&(l.q==='1'||l.q==='1.5')?l.q:qualityOfMarca(p.marca)}
function lineOfCal(p,ck,l,q){return lineKey(q||lineQ(p,l),lineType(palTipo(p),ck||''))}
/* calidades de la tarima y su marca para documentos: «CITRILAR PRIMERA», o las dos si va mezclada */
function palQs(p){const s=[];(p.lines||[]).forEach(l=>{if(!(n0(l.cant)>0)&&!l.cal)return;const q=lineQ(p,l);if(s.indexOf(q)<0)s.push(q)});if(!s.length)s.push(qualityOfMarca(p.marca));return s.sort()}
function marcaOfQ(e,q){const m=MARCAS[e]||MARCAS.VL;return q==='1.5'?m[1]:m[0]}
function palMarcaTxt(p,e){return palQs(p).map(q=>marcaOfQ(e,q)).join(' / ')}
function palCalTxt(p){return palQs(p).map(q=>q==='1.5'?'UNO Y MEDIO':'PRIMERA').join(' / ')}
/* la marca guardada sigue a las líneas: si todas son 1-1/2 es la de uno y medio, si no la de primera */
function syncMarca(o,p){const qs=palQs(p);p.marca=marcaOfQ(o.emp,qs.length===1?qs[0]:'1')}
/* Todo lo que la pantalla, el Excel y los documentos necesitan saber de las tarimas de un pedido, por línea calidad|tipo */
function trazCalc(o){
  o=mainOf(o);const t=ensureTraz(o),sh=sheetsOf(o);TM=tipoMapFor(o);
  const zero=()=>{const z={};CAL.forEach(c=>z[c.k]=0);return z};
  const exp={'1':zero(),'1.5':zero()},pal={'1':zero(),'1.5':zero()},empP={},palP={},empQ={},palQ={},expL={},palL={},lines=[];
  const addLine=L=>{if(!expL[L]){expL[L]=zero();palL[L]=zero();empQ[L]={};palQ[L]={};lines.push(L)}return L};
  /* v8.9.1: en la regla nueva la primera no se recorta por manifiesto; se descuentan las tarimas mandadas al próximo viaje */
  const SENT=sentOf(o),newRule=sobPalMode(o);
  sh.forEach(s=>{
    const M=compute(s),q=s.variante,noCut=q==='1'&&newRule;
    /* el sobrante (lo que pasó del manifiesto de cada tipo) no se tarima: se descuenta de los últimos productores de ese tipo */
    const cut=M.rows.map(()=>({}));
    TIPO_K.forEach(tp=>{
      const b=M.byTipo[tp],m=M.manBy[tp];if(!(b&&b.t)&&!m)return;
      const L=addLine(lineKey(q,tp));
      CAL.forEach(c=>{
        const pk=(b&&b[c.k])||0,mv=m&&!noCut?m[c.k]:null;
        expL[L][c.k]+=mv==null?pk:Math.max(0,Math.min(pk,mv));
        let ex=mv==null?0:Math.max(0,pk-mv);
        for(let i=M.rows.length-1;i>=0&&ex>0;i--){const r=M.rows[i];if(r.p.sob2)continue;r.tipos.forEach(t0=>{if(ex<=0||lineType(t0,c.k)!==tp)return;const cu=cut[i][t0]=cut[i][t0]||{},x=Math.min(ex,Math.max(0,r.byT[t0].delta[c.k]-(cu[c.k]||0)));if(x>0){cu[c.k]=(cu[c.k]||0)+x;ex-=x}})}
      });
    });
    M.rows.forEach((r,ri)=>{
      /* renglón SOBRANTES: cuenta por el productor dueño de cada caja, no como un productor */
      if(r.p.sob2){(r.p.sobAp||[]).forEach(a=>{const v=n0(a.n),ck=a.ck;if(!(v>0)||!ck)return;const k=resolveProd(sh,r.p.rmp?rmpKey(s,a):a.key),L=addLine(lineKey(q,lineType(a.tipo,ck)));empP[k]=empP[k]||{nombre:a.nombre||k,t:0,by:{}};const e=empQ[L][k]=empQ[L][k]||{k:k,nombre:a.nombre||k,t:0,by:{}};e.by[ck]=(e.by[ck]||0)+v;e.t+=v;empP[k].by[ck]=(empP[k].by[ck]||0)+v;empP[k].t+=v});return}
      const k=prodKey(s,r.p);empP[k]=empP[k]||{nombre:r.p.nombre||k,t:0,by:{}};
      r.tipos.forEach(t0=>{const d=r.byT[t0].delta,cu=cut[ri][t0]||{};CAL.forEach(c=>{const v=d[c.k]-(cu[c.k]||0);if(!v)return;const L=addLine(lineKey(q,lineType(t0,c.k)));const e=empQ[L][k]=empQ[L][k]||{k:k,nombre:r.p.nombre||k,t:0,by:{}};e.by[c.k]=(e.by[c.k]||0)+v;e.t+=v;empP[k].by[c.k]=(empP[k].by[c.k]||0)+v;empP[k].t+=v})});
    });
  });
  SENT.forEach(x=>{const L=addLine(lineKey('1',lineType(x.tipo,x.ck)));expL[L][x.ck]-=x.n;const e=empQ[L][x.key];if(e){e.by[x.ck]=(e.by[x.ck]||0)-x.n;e.t-=x.n}const P=empP[x.key];if(P){P.by[x.ck]=(P.by[x.ck]||0)-x.n;P.t-=x.n}});
  /* v8.21: las cajas reempacadas ya no van en las tarimas de este viaje (van en las del viaje que las recibe) */
  /* (lo esperado por línea ya viene sin ellas: compute descuenta el reempaque de byTipo) */
  sh.forEach(s=>rmpOutsOf(s.id).forEach(x=>{const v=n0(x.n0),L=addLine(lineKey(s.variante==='1.5'?'1.5':'1',x.tipo0)),k=resolveProd(sh,x.via==='sob'&&!x.codigo?x.key:rmpKey(s,x));const e=empQ[L][k];if(e){e.by[x.ck0]=(e.by[x.ck0]||0)-v;e.t-=v}const P=empP[k];if(P){P.by[x.ck0]=(P.by[x.ck0]||0)-v;P.t-=v}}));
  let sinProd=0,incompletas=0,cantTot=0;const info={};
  t.tarimas.forEach((p,i)=>{
    let tot=0;
    (p.lines||[]).forEach(l=>{
      const c=n0(l.cant),key=PCAL_KEY[l.cal],q=lineQ(p,l);
      tot+=c;cantTot+=c;
      const L=key?addLine(lineOfCal(p,key,l)):null;
      if(key){pal[q][key]+=c;palL[L][key]+=c}
      const pk=resolveProd(sh,l.prod);
      if(c>0&&!pk)sinProd++;
      if(!l.cal||!c||!pk)incompletas++;
      if(pk&&c>0&&key){const pq=palQ[L][pk]=palQ[L][pk]||{by:{},t:0};pq.by[key]=(pq.by[key]||0)+c;pq.t+=c;palP[pk]=palP[pk]||{by:{},t:0};palP[pk].by[key]=(palP[pk].by[key]||0)+c;palP[pk].t+=c}
    });
    const cap=palCap(palTipo(p));info[p.id]={n:i+1,tot:tot,cap:cap,ok:tot===cap,exc:cap===50&&(tot===54||tot===55||tot===60)};
  });
  lines.sort(lineOrd);
  lines.forEach(L=>{const q=L.split('|')[0];CAL.forEach(c=>{exp[q][c.k]+=expL[L][c.k]})});
  const falta={};let faltaTot=0,sobra=0;
  lines.forEach(L=>CAL.forEach(c=>{const d=expL[L][c.k]-palL[L][c.k];if(d!==0)falta[L+'|'+c.k]=d;if(d>0)faltaTot+=d;else sobra+=-d}));
  const over=[];
  lines.forEach(L=>Object.keys(palQ[L]).forEach(k=>{
    const e=empQ[L][k],qn=' ('+lineLabel(L,true)+')';
    if(!e){over.push({k:k,msg:k+qn+': no tiene cajas de '+lineLabel(L)+' en este pedido'});return}
    CAL.forEach(c=>{const a=palQ[L][k].by[c.k]||0,b=e.by[c.k]||0;if(a>b)over.push({k:k,msg:e.nombre+qn+' · '+c.l+': '+fmt(a)+' en tarimas, solo '+fmt(b)+' empacadas'})});
  }));
  const hdrMiss=HDR_REQ.filter(f=>!String(t.hdr[f]||'').trim());
  const motivos=[];
  if(!t.tarimas.length)motivos.push('no hay tarimas');
  if(hdrMiss.length)motivos.push('falta en el encabezado: '+hdrMiss.map(f=>(HDR_FIELDS.find(x=>x[0]===f)||[0,f])[1]).join(', '));
  if(incompletas)motivos.push(incompletas+' '+(incompletas===1?'línea sin calibre, cajas o productor':'líneas sin calibre, cajas o productor'));
  if(faltaTot>0)motivos.push('faltan '+fmt(faltaTot)+' cajas por tarimar');
  if(sobra>0)motivos.push('hay '+fmt(sobra)+' cajas de más en tarimas (o en otra calidad o tipo de empaque)');
  const pendSob=sobPend(o);
  if(pendSob.length)motivos.push('hay '+pendSob.length+(pendSob.length===1?' tarima':' tarimas')+' del viaje anterior sin importar a SOBRANTES en Registro de empaque');
  else if(over.length)motivos.push('hay cajas en tarimas que todavía no están registradas en Registro de Empaque');
  const avail=(L,k,ck,ex)=>{const e=empQ[L]&&empQ[L][k],u=palQ[L]&&palQ[L][k];return((e&&e.by[ck])||0)-((u&&u.by[ck])||0)+(ex||0)};
  const lo=sh.map(x=>leftoverOf(x)),sobTot=lo.reduce((a,x)=>a+x.total,0),sobText=lo.map(x=>x.text).filter(Boolean).join(' · ');
  /* aviso (no es borrador): primera en tarimas contra el manifiesto, por tipo y calibre */
  const manDiff=[];if(newRule){const man={};sh.filter(x=>x.variante==='1').forEach(x=>{const M=compute(x);Object.keys(M.manBy).forEach(tp=>CAL.forEach(c=>{const v=M.manBy[tp][c.k];if(v!=null){const k=tp+'|'+c.k;man[k]=(man[k]||0)+v}}))});
    Object.keys(man).forEach(k=>{const tp=k.split('|')[0],ck=k.split('|')[1],L=lineKey('1',tp),h=(palL[L]||{})[ck]||0,d=h-man[k];if(d)manDiff.push({tp:tp,ck:ck,d:d,man:man[k],h:h})})}
  return{manDiff:manDiff,sent:SENT,pendSob:pendSob,sobTot:sobTot,sobText:sobText,o:o,t:t,sh:sh,exp:exp,pal:pal,expL:expL,palL:palL,lines:lines,empP:empP,palP:palP,empQ:empQ,palQ:palQ,avail:avail,info:info,falta:falta,faltaTot:faltaTot,sobra:sobra,over:over,hdrMiss:hdrMiss,motivos:motivos,borrador:motivos.length>0,nPal:t.tarimas.length,full:t.tarimas.length>=24,cantTot:cantTot,sinProd:sinProd};
}

/* ---------- guardado local y sincronización ---------- */
const CFG=window.EMPAQUE_CONFIG||{};
const LS_SESSION='registro-empaque-sesion',LS_META='registro-empaque-meta',LS_LISTA='registro-empaque-lista';
let session=null,meta={lastSync:0},syncing=false,autoT=null,autoFail=0;
try{const l=JSON.parse(localStorage.getItem(LS_LISTA)||'null');if(l&&l.length)LISTA=l}catch(e){}
/* v8.9 · clasificación del productor: Chicos, Grandes o Internos (con impacto financiero y contable).
   El orden de la lista desplegable es el de la mayoría: Chicos, Grandes, Internos. Un productor sin clasificación guardada
   cuenta como Chico, salvo los de Jesús Lagunes, que son Internos. */
const PCLS=[['chico','Chicos'],['grande','Grandes'],['interno','Internos']];
const PCLS_L={chico:'Chicos',grande:'Grandes',interno:'Internos'};
let PCLS_SRV='?';/* '?' aún no se sabe · 'ok' la tabla productores tiene la columna clasificacion · 'no' todavía no se corrió el SQL v8.9 */
function clsExp(c){const x=c?LISTA.find(y=>y.c===c):null;return x&&PCLS_L[x.k]?x.k:null}
function clsOf(c){const k=clsExp(c);if(k)return k;const x=c?LISTA.find(y=>y.c===c):null;return x&&/JESUS\s+LAGUNES/i.test(x.n||'')?'interno':'chico'}
/* un productor escrito solo con nombre, igual al de la lista, es ese mismo productor (misma clave en todos los reportes) */
let _LN=null;
function lisNameMap(){if(!_LN||_LN.src!==LISTA||_LN.n!==LISTA.length){const m=new Map();LISTA.forEach(x=>{const k=norm(x.n||'').replace(/\s+/g,' ').trim();if(k&&!m.has(k))m.set(k,x.c)});_LN={src:LISTA,n:LISTA.length,m:m}}return _LN.m}
function pCode(p){if(p.codigo)return p.codigo;return lisNameMap().get(norm(p.nombre||'').replace(/\s+/g,' ').trim())||null}
function pKey(p){const c=pCode(p);return c?'c'+c:'n'+norm(p.nombre||'sin nombre')}
function saveLocal(){try{localStorage.setItem(LS,JSON.stringify({orders,dirty:[...dirty]}))}catch(e){}}
function loadLocal(){try{const j=JSON.parse(localStorage.getItem(LS)||'null');if(j){orders=j.orders||[];(j.dirty||[]).forEach(i=>dirty.add(i))}}catch(e){}}
function saveMeta(){try{localStorage.setItem(LS_META,JSON.stringify(meta))}catch(e){}}
function loadSession(){
  try{session=JSON.parse(localStorage.getItem(LS_SESSION)||'null')}catch(e){session=null}
  try{meta=Object.assign(meta,JSON.parse(localStorage.getItem(LS_META)||'{}'))}catch(e){}
  applyRole();
}
function cfgOK(){return !!(CFG.SUPABASE_URL&&CFG.SUPABASE_KEY)}
function syncState(){if(syncing)return 'syncing';if(dirty.size||listaOps().length||REG.dirty||FIN.dirty||PESOS.dirty||DEC.dirty||PER.dirty||(INV.dirty.length&&!INV.noTable)||(LOG.dirty.length&&!LOG.noTable)||(typeof CONT!=='undefined'&&CONT.dirty.length&&!CONT.noTable))return 'pending';return(cfgOK()&&session)?'synced':'local'}
function syncLabel(){const st=syncState();const b=st==='syncing'?'Sincronizando…':st==='pending'?'Pendiente de sincronizar':st==='synced'?'Sincronizado':(cfgOK()&&!session?'Toca para entrar y sincronizar':'Sin sincronización');if(!(cfgOK()&&session))return b;const o=typeof RT!=='undefined'&&RT.st==='on'?rtNames():[];return b+(typeof RT!=='undefined'&&RT.st==='on'?' · en vivo'+(o.length?' · también conectados: '+o.join(', '):''):'')}
function rtCount(){return typeof RT!=='undefined'&&RT.st==='on'?rtNames().length:0}
function setSync(){const el=document.getElementById('syncpill');if(el){el.dataset.s=syncState();el.dataset.rt=typeof RT!=='undefined'?RT.st:'off';const l=syncLabel();el.setAttribute('aria-label',l);el.title=l;el.disabled=syncing;const n=rtCount(),c=el.querySelector('.scnt');if(c){c.textContent=n?String(n):'';c.hidden=!n}}autoKick()}
/* sincronización automática: al cambiar datos (con una pausa corta), al volver la conexión, al abrir la app y cada minuto */
function canAuto(){return cfgOK()&&!!session&&!syncing&&navigator.onLine!==false}
function autoKick(ms){
  try{
    if(autoT||!canAuto())return;
    if(ms==null&&syncState()!=='pending')return;
    const d=ms!=null?ms:Math.min((typeof RT!=='undefined'&&RT.st==='on'?900:4000)*Math.pow(2,autoFail),300000);
    autoT=setTimeout(()=>{autoT=null;if(canAuto())doSync(true)},d);
  }catch(e){}
}
function autoInit(){
  setInterval(()=>{if(!document.hidden&&canAuto()&&!(RT.st==='on'&&Date.now()-(meta.lastSync||0)<55000))doSync(true)},20000);
  window.addEventListener('online',()=>{autoKick(1500);rtStart()});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){autoKick(1500);rtStart()}});
  autoKick(2500);rtStart();
}
/* ---------- v8.4 · tiempo real ----------
   Un canal de Supabase Realtime avisa al instante cuando otro usuario guarda algo. Cobros, pagos y bitácora llegan
   con el mensaje; lo demás dispara una sincronización en seguida (con la misma unión campo por campo).
   Si el canal no está disponible (sin internet o sin la publicación de v8.4) sigue la sincronización cada 20 segundos.
   El mismo canal dice quién está conectado. */
const RT={ws:null,st:'off',ref:0,jref:'',hb:null,retry:0,rt:null,who:{},pend:false,deb:null,tok:'',dev:''};
try{RT.dev=localStorage.getItem('empaque-dev')||'';if(!RT.dev){RT.dev='d'+Math.random().toString(36).slice(2,10);localStorage.setItem('empaque-dev',RT.dev)}}catch(e){RT.dev='d'+Math.random().toString(36).slice(2,10)}
let remoteN=0;
const RT_TOPIC='realtime:empaque';
function rtUrl(){return String(CFG.SUPABASE_URL).replace(/\/$/,'').replace(/^http/,'ws')+'/realtime/v1/websocket?apikey='+encodeURIComponent(CFG.SUPABASE_KEY)+'&vsn=1.0.0'}
function rtSend(topic,event,payload){if(!RT.ws||RT.ws.readyState!==1)return;const m={topic:topic,event:event,payload:payload||{},ref:String(++RT.ref)};if(topic!=='phoenix')m.join_ref=RT.jref;RT.ws.send(JSON.stringify(m))}
function rtMe(){return {u:(authUser&&(authUser.name||authUser.user))||(session&&session.email)||'—',rol:(authUser&&authUser.rol)||'',dev:RT.dev,at:Date.now()}}
function rtStart(){
  if(typeof WebSocket==='undefined'||RT.ws||RT.rt||!cfgOK()||!session||navigator.onLine===false)return;
  let ws;try{ws=new WebSocket(rtUrl())}catch(e){rtRetry();return}
  RT.ws=ws;RT.st='conn';
  ws.onopen=()=>{
    RT.jref=String(++RT.ref);RT.tok=session?session.access_token:'';
    ws.send(JSON.stringify({topic:RT_TOPIC,event:'phx_join',ref:RT.jref,join_ref:RT.jref,payload:{config:{broadcast:{self:false,ack:false},presence:{key:RT.dev},postgres_changes:[{event:'*',schema:'public'}]},access_token:RT.tok}}));
    clearInterval(RT.hb);
    RT.hb=setInterval(()=>{rtSend('phoenix','heartbeat',{});if(session&&session.access_token!==RT.tok){RT.tok=session.access_token;rtSend(RT_TOPIC,'access_token',{access_token:RT.tok})}},25000);
  };
  ws.onmessage=ev=>{let m;try{m=JSON.parse(ev.data)}catch(e){return}try{rtMsg(m)}catch(e){}};
  ws.onclose=()=>{clearInterval(RT.hb);RT.ws=null;RT.st='off';RT.who={};setSync();rtRetry()};
  ws.onerror=()=>{try{ws.close()}catch(e){}};
}
function rtRetry(){if(RT.rt||!cfgOK()||!session)return;const d=Math.min(2000*Math.pow(2,RT.retry++),60000);RT.rt=setTimeout(()=>{RT.rt=null;rtStart()},d)}
function rtStop(){clearTimeout(RT.rt);RT.rt=null;clearInterval(RT.hb);if(RT.ws){RT.ws.onclose=null;try{RT.ws.close()}catch(e){}}RT.ws=null;RT.st='off';RT.who={};RT.retry=0}
function rtMsg(m){
  if(m.topic!==RT_TOPIC)return;
  const P=m.payload||{};
  if(m.event==='phx_reply'&&m.ref===RT.jref){
    if(P.status==='ok'){RT.st='on';RT.retry=0;rtSend(RT_TOPIC,'presence',{type:'presence',event:'track',payload:rtMe()});setSync();rtPull()}
    else{RT.st='err';try{RT.ws.close()}catch(e){}}
    return;
  }
  if(m.event==='postgres_changes'){rtChange(P.data||{});return}
  if(m.event==='presence_state'){RT.who={};Object.keys(P).forEach(k=>{const a=(P[k].metas||[])[0];if(a)RT.who[k]=a});setSync();return}
  if(m.event==='presence_diff'){Object.keys(P.leaves||{}).forEach(k=>delete RT.who[k]);Object.keys(P.joins||{}).forEach(k=>{const a=(P.joins[k].metas||[])[0];if(a)RT.who[k]=a});setSync();return}
  if(m.event==='phx_error'||m.event==='phx_close'){try{RT.ws.close()}catch(e){}}
}
/* un cambio de otro usuario: se aplica o se sincroniza; los ecos de lo que subió este dispositivo se ignoran */
function rtChange(d){
  const tb=d.table,r=d.record||{};if(!tb)return;
  if((tb==='cobros'||tb==='pagos')&&r.data){const S=tb==='cobros'?COB:PAG,i=S.list.findIndex(x=>x.id===r.id);
    if(i<0){S.list.push(r.data)}else if((+r.data.ts||0)>(+S.list[i].ts||0)&&S.dirty.indexOf(r.id)<0){S.list[i]=r.data}else return;
    saveMov();invalidateStats();remoteN++;softRender();return}
  if(tb==='bitacora'&&r.data){const k=LOG.list.findIndex(x=>x.id===r.id);if(k<0){LOG.list.unshift(r.data);LOG.list.sort((a,b)=>b.ts-a.ts);saveLog()}return}
  if(tb==='orders'&&r.id&&SYNCB.so[r.id]!=null&&Number(r.updated_at)===SYNCB.so[r.id])return;
  if(tb==='entradas'&&r.id&&SYNCB.se[r.id]!=null&&Number(r.updated_at)===SYNCB.se[r.id])return;
  rtPull();
}
function rtPull(){clearTimeout(RT.deb);RT.deb=setTimeout(()=>{RT.deb=null;if(syncing){RT.pend=true;return}if(canAuto())doSync(true)},600)}
function rtNames(){const me=RT.dev,L=Object.keys(RT.who).filter(k=>k!==me).map(k=>RT.who[k].u||'—');return [...new Set(L)]}
/* ---------- unir cambios de varios dispositivos ----------
   SRV guarda la última versión del servidor que vio este dispositivo (updated_at) y BASE una copia de esa versión.
   Si alguien más cambió el pedido mientras aquí también hubo cambios, se juntan campo por campo contra BASE,
   en vez de que el último en sincronizar borre lo del otro. */
const LS_SYNCB='empaque-sync-base';
let SYNCB={o:{},e:{},so:{},se:{}};
(function(){try{const j=JSON.parse(localStorage.getItem(LS_SYNCB)||'null');if(j&&typeof j==='object')SYNCB=Object.assign(SYNCB,j)}catch(e){}})();
function saveSyncB(){
  /* se guarda la copia solo de lo reciente para no llenar la memoria del teléfono */
  try{
    const lim=Date.now()-60*86400000;
    ['o','e'].forEach(g=>Object.keys(SYNCB[g]).forEach(id=>{const it=g==='o'?orders.find(x=>x.id===id):INV.entradas.find(x=>x.id===id);if(!it||((it.updatedAt||0)<lim&&!(g==='o'?dirty.has(id):INV.dirty.indexOf(id)>=0)))delete SYNCB[g][id]}));
    localStorage.setItem(LS_SYNCB,JSON.stringify(SYNCB));
  }catch(e){SYNCB.o={};SYNCB.e={};try{localStorage.setItem(LS_SYNCB,JSON.stringify(SYNCB))}catch(x){}}
}
function setBase(g,id,data){try{SYNCB[g][id]=JSON.parse(JSON.stringify(data))}catch(e){}}
const isPlain=x=>!!x&&typeof x==='object'&&!Array.isArray(x);
const jeq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const idList=a=>Array.isArray(a)&&a.length>0&&a.every(x=>isPlain(x)&&x.id!=null);
/* unión a tres vías: b = versión común, l = este dispositivo, r = servidor. Si los dos cambiaron lo mismo, gana este dispositivo. */
function merge3(b,l,r){
  if(jeq(l,r))return l;
  if(b!==undefined&&jeq(l,b))return r;
  if(b!==undefined&&jeq(r,b))return l;
  if(isPlain(l)&&isPlain(r)){
    const o={};new Set(Object.keys(r).concat(Object.keys(l))).forEach(k=>{if(k==='updatedAt')return;const v=merge3(isPlain(b)?b[k]:undefined,l[k],r[k]);if(v!==undefined)o[k]=v});
    return o;
  }
  if(Array.isArray(l)&&Array.isArray(r)&&(idList(l)||idList(r))&&l.concat(r).every(x=>isPlain(x)&&x.id!=null)){
    const B=new Map((Array.isArray(b)?b:[]).filter(x=>isPlain(x)&&x.id!=null).map(x=>[x.id,x])),L=new Map(l.map(x=>[x.id,x])),R=new Map(r.map(x=>[x.id,x])),out=[];
    r.forEach(ri=>{const li=L.get(ri.id),bi=B.get(ri.id);
      if(li)out.push(merge3(bi,li,ri));
      else if(!(bi&&jeq(bi,ri)))out.push(ri); /* aquí se borró y allá no cambió: queda borrado */
    });
    l.forEach((li,i)=>{if(R.has(li.id))return;const bi=B.get(li.id);
      if(bi&&jeq(bi,li))return; /* allá se borró y aquí no cambió */
      /* nuevo en este dispositivo: va después del que tenía antes */
      const prev=i>0?out.findIndex(x=>x.id===l[i-1].id):-1;out.splice(prev+1,0,li);
    });
    return out;
  }
  return l!==undefined?l:r;
}
function touch(o){o.updatedAt=Date.now();dirty.add(o.id);invalidateStats();saveLocal();setSync()}

/* subir con control de versión: nuevos con «ignorar si ya existe», conocidos con «solo si updated_at sigue igual».
   Devuelve los id que alguien más cambió en medio (conflictos). */
async function pushOne(tb,a){
  const row={updated_at:a.t,deleted:!!(a.d&&a.d.deleted),data:a.d};
  if(a.base==null){const r=await sb('/rest/v1/'+tb+'?on_conflict=id&select=id',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=representation'},body:[Object.assign({id:a.id},row)]});return !!(r&&r.length)}
  const r=await sb('/rest/v1/'+tb+'?id=eq.'+encodeURIComponent(a.id)+'&updated_at=eq.'+a.base+'&select=id',{method:'PATCH',headers:{Prefer:'return=representation'},body:row});
  return !!(r&&r.length);
}
async function pushCas(tb,items,done){
  const conf=[],fresh=items.filter(a=>a.base==null),known=items.filter(a=>a.base!=null);
  for(let i=0;i<fresh.length;i+=25){
    const part=fresh.slice(i,i+25);
    const r=(await sb('/rest/v1/'+tb+'?on_conflict=id&select=id',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=representation'},body:part.map(a=>({id:a.id,updated_at:a.t,deleted:!!(a.d&&a.d.deleted),data:a.d}))}))||[];
    const ins=new Set(r.map(x=>x.id));part.forEach(a=>{if(ins.has(a.id))done(a.x);else conf.push(a.id)});
  }
  for(const a of known){if(await pushOne(tb,a))done(a.x);else conf.push(a.id)}
  return conf;
}
async function sb(path,opts){
  opts=opts||{};
  const h=Object.assign({apikey:CFG.SUPABASE_KEY,'Content-Type':'application/json'},opts.headers||{});
  if(opts.auth!==false&&session)h.Authorization='Bearer '+session.access_token;
  const r=await fetch(String(CFG.SUPABASE_URL).replace(/\/$/,'')+path,{method:opts.method||'GET',headers:h,body:opts.body?JSON.stringify(opts.body):undefined});
  if(!r.ok){const err=new Error('HTTP '+r.status);err.status=r.status;try{const j=JSON.parse(await r.text());err.code=j.error_code||j.code||'';err.msg=j.msg||j.message||j.error_description||''}catch(e){}throw err}
  if(r.status===204)return null;
  const ct=r.headers.get('content-type')||'';
  if(ct.indexOf('json')<0)return null;
  const tx=await r.text();
  return tx?JSON.parse(tx):null;
}
/* v8.25 · roles: superadmin (administrador que además cambia roles), admin, jefe, inocuidad (jefe que también edita productores y logística),
   tarima (solo conteo), lector y contador. roleOf da el rol que usan los permisos de siempre: superadmin cuenta como admin e inocuidad como jefe;
   roleRaw da el rol tal como está en la cuenta. */
function roleRaw(tok){try{const p=JSON.parse(atob(String(tok).split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));return (p.app_metadata&&p.app_metadata.rol)||''}catch(e){return ''}}
const ROL_EF={superadmin:'admin',inocuidad:'jefe'};
function roleOf(tok){const r=roleRaw(tok);return ROL_EF[r]||r}
let roRole=false;
function applyRole(){const rr=session?roleOf(session.access_token):'';ro=roRole=rr==='lector'||rr==='contador'||rr==='tarima'||(typeof authUser!=='undefined'&&!!authUser&&(authUser.rol==='lector'||authUser.rol==='contador'||authUser.rol==='tarima'))}
function saveSession(s){session=s;applyRole();try{localStorage.setItem(LS_SESSION,JSON.stringify(s))}catch(e){}}
function sessionFrom(j){return{access_token:j.access_token,refresh_token:j.refresh_token,expires_at:Date.now()+(j.expires_in||3600)*1000-30000,email:(j.user&&j.user.email)||(session&&session.email)||''}}
async function login(email,pw){const j=await sb('/auth/v1/token?grant_type=password',{method:'POST',body:{email:email,password:pw},auth:false});saveSession(sessionFrom(j))}
async function ensureSession(){
  if(!session)throw Object.assign(new Error('login'),{code:'login'});
  if(Date.now()<session.expires_at)return;
  try{
    const j=await sb('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:{refresh_token:session.refresh_token},auth:false});
    saveSession(sessionFrom(j));
  }catch(e){
    if(e&&(e.status===400||e.status===401||e.status===403)){session=null;ro=roRole=false;try{localStorage.removeItem(LS_SESSION)}catch(x){}throw Object.assign(new Error('login'),{code:'login'})}
    throw e;
  }
}
async function doSync(auto){
  if(syncing)return;
  syncing=true;setSync();
  let pulled=0,pushed=0,ok=false;const rn0=remoteN;
  try{
    await ensureSession();
    /* 1. bajar lo que esta mas nuevo en la nube */
    const idx=(await sb('/rest/v1/orders?select=id,updated_at&order=updated_at.desc&limit=1000'))||[];
    let merged=0;
    const need=idx.filter(r=>{const l=orders.find(x=>x.id===r.id),t=Number(r.updated_at)||0;return !l||(SYNCB.so[r.id]!=null?t!==SYNCB.so[r.id]:t>(l.updatedAt||0)||dirty.has(r.id))});
    for(let i=0;i<need.length;i+=20){
      const ids=need.slice(i,i+20).map(r=>r.id).join(',');
      const rows=(await sb('/rest/v1/orders?select=id,updated_at,data&id=in.('+ids+')'))||[];
      rows.forEach(r=>{
        if(!r.data||!Array.isArray(r.data.productores))return;
        const t=Number(r.updated_at)||0,k=orders.findIndex(x=>x.id===r.id);
        const d=JSON.parse(JSON.stringify(r.data||{}));d.id=r.id;d.updatedAt=t;
        if(k>=0&&dirty.has(r.id)){
          /* los dos dispositivos cambiaron este pedido: se juntan y se vuelve a subir */
          const m=merge3(SYNCB.o[r.id],orders[k],d);m.id=r.id;m.updatedAt=Math.max(Date.now(),t+1);orders[k]=m;merged++;pulled++;
        }else if(k<0||t!==(orders[k].updatedAt||0)){
          if(k<0)orders.push(d);else orders[k]=d;
          dirty.delete(r.id);pulled++;
        }
        SYNCB.so[r.id]=t;setBase('o',r.id,d);
      });
    }
    if(pulled)normOrders();
    /* 2. subir lo pendiente de este dispositivo */
    /* v8.4: solo se escribe si el servidor sigue en la versión que conoce este dispositivo; si otro usuario guardó
       en medio, se baja la suya, se junta campo por campo y se vuelve a intentar (nadie pisa lo del otro) */
    const sent=ro?[]:[...dirty].map(id=>orders.find(o=>o.id===id)).filter(Boolean).map(o=>({o:o,t:o.updatedAt}));
    const oDone=x=>{SYNCB.so[x.o.id]=x.t;setBase('o',x.o.id,x.o);if(x.o.updatedAt===x.t)dirty.delete(x.o.id);pushed++};
    const oPull=async id=>{const r=((await sb('/rest/v1/orders?select=id,updated_at,data&id=eq.'+encodeURIComponent(id)))||[])[0],k=orders.findIndex(x=>x.id===id);if(!r||!r.data||k<0)return null;
      const t=Number(r.updated_at)||0,d=JSON.parse(JSON.stringify(r.data));d.id=id;d.updatedAt=t;const m=merge3(SYNCB.o[id],orders[k],d);m.id=id;m.updatedAt=Math.max(Date.now(),t+1);orders[k]=m;SYNCB.so[id]=t;setBase('o',id,d);merged++;pulled++;return {o:m,t:m.updatedAt}};
    const conf=await pushCas('orders',sent.map(x=>({x:x,id:x.o.id,t:x.t,d:x.o,base:SYNCB.so[x.o.id]})),oDone);
    for(const id of conf){for(let n=0;n<3;n++){const x=await oPull(id);if(!x)break;if(await pushOne('orders',{id:id,t:x.t,d:x.o,base:SYNCB.so[id]})){oDone(x);break}}}
    /* 3. lista de productores */
    try{
      await flushLista();
      let lp=null;
      /* v8.9: la clasificación viaja en la columna «clasificacion»; si el SQL v8.9 aún no se corrió, todo sigue como antes y la clasificación queda en este dispositivo */
      if(PCLS_SRV!=='no'){try{lp=await sb('/rest/v1/productores?select=codigo,nombre,clasificacion&order=codigo.asc&limit=1000');PCLS_SRV='ok'}catch(e){if(e&&(e.status===400||e.status===404))PCLS_SRV='no';else throw e}}
      if(PCLS_SRV==='no')lp=await sb('/rest/v1/productores?select=codigo,nombre&order=codigo.asc&limit=1000');
      if(lp&&lp.length){
        const loc=new Map(LISTA.map(x=>[x.c,x.k])),up=[];
        const nl=lp.map(x=>{const o={c:x.codigo,n:x.nombre},sk=PCLS_L[x.clasificacion]?x.clasificacion:null,lk=PCLS_L[loc.get(x.codigo)]?loc.get(x.codigo):null,k=PCLS_SRV==='ok'?(sk||lk):lk;if(k)o.k=k;if(PCLS_SRV==='ok'&&!sk&&lk)up.push({t:'set',c:x.codigo,n:x.nombre,k:lk});return o});
        if(up.length)listaOpsSave(listaOps().filter(z=>!up.some(u=>u.c===z.c)).concat(up));
        if(JSON.stringify(nl)!==JSON.stringify(LISTA))remoteN++;LISTA=nl;localStorage.setItem(LS_LISTA,JSON.stringify(LISTA))}
    }catch(e){}
    await syncReg();
    await syncPer();
    await syncPar();
    await syncFin();
    await syncPesos();
    await syncPres();
    await syncCtb();
    await syncMovTab(COB,'cobros');
    await syncMovTab(PAG,'pagos');
    await syncInv();
    await syncLog();
    await syncCont();
    meta.lastSync=Date.now();saveMeta();saveLocal();ok=true;
    saveSyncB();
    if(!auto){const o=RT.st==='on'?rtNames():[];toast('Listo: '+pushed+' enviados, '+pulled+' recibidos'+(merged?' · '+merged+(merged===1?' pedido unido':' pedidos unidos')+' con cambios de otro dispositivo':'')+(RT.st==='on'?' · en vivo'+(o.length?' con '+o.join(', '):''):''))}
    else if(merged)toast(merged===1?'Se juntó un pedido con cambios de otro dispositivo':'Se juntaron '+merged+' pedidos con cambios de otro dispositivo');
  }catch(e){
    if(e&&e.code==='login'){if(!auto){sheet={kind:'login',lf:{email:(session&&session.email)||'',pw:''},err:'Tu sesión venció. Vuelve a entrar.'};renderSheet()}}
    else if(!auto)toast(e&&e.status?'El servidor respondió '+e.status+'. Revisa la configuración.':'Sin conexión. Tus datos siguen guardados aquí.');
  }finally{syncing=false;autoFail=ok?0:Math.min(autoFail+1,6);invalidateStats();saveLocal();setSync();if(!auto||pulled>0||remoteN>rn0)softRender();if(ok)rtStart();if(RT.pend){RT.pend=false;rtPull()}}
}
async function doSheetLogin(){
  if(!sheet||sheet.kind!=='login'||sheet.busy)return;
  const lf=sheet.lf||{};
  if(!lf.email||!lf.pw){sheet.err='Escribe el correo y la contraseña.';renderSheet();return}
  sheet.busy=true;sheet.err='';renderSheet();
  try{await login(String(lf.email).trim(),lf.pw);sheet=null;renderSheet();doSync()}
  catch(e){
    if(!sheet||sheet.kind!=='login')return;
    sheet.busy=false;
    sheet.err=(e&&(e.status===400||e.status===401))?'Correo o contraseña incorrectos.':(e&&e.status?'El servidor respondió '+e.status+'. Revisa la configuración.':'Sin conexión. Intenta cuando tengas red.');
    renderSheet();
  }
}
function loginHtml(){
  const lf=sheet.lf||{email:'',pw:''};
  return '<h3>Entrar para sincronizar</h3><p class="note" style="margin-bottom:10px">Usa el correo y la contraseña que se creó para el equipo. Solo hace falta una vez por teléfono.</p>'
   +'<label class="fld" for="lf-email"><span>Correo</span><input class="in txt" id="lf-email" type="email" autocomplete="username" autocapitalize="none" data-lf="email" value="'+esc(lf.email)+'"></label>'
   +'<label class="fld" for="lf-pw"><span>Contraseña</span>'+PWI('<input class="in txt" id="lf-pw" type="password" autocomplete="current-password" data-lf="pw" value="'+esc(lf.pw)+'">')+'</label>'
   +(sheet.err?'<p class="note" style="color:var(--crit);margin-bottom:8px" role="alert">'+esc(sheet.err)+'</p>':'')
   +'<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="dologin"'+(sheet.busy?' disabled':'')+'>'+(sheet.busy?'Entrando…':'Entrar y sincronizar')+'</button></div>';
}
function syncInfoHtml(){
  return '<h3>Sincronización sin configurar</h3><p class="note">Falta poner la dirección y la clave pública de la base de datos en el archivo config.js. La guía incluida explica cómo. Mientras tanto la app guarda todo en este teléfono y puedes usar el respaldo.</p><div class="srow2"><button class="btn primary" data-act="closesheet">Entendido</button></div>';
}
function backupPanel(){
  const last=meta.lastSync?new Date(meta.lastSync).toLocaleString('es-MX',{dateStyle:'medium',timeStyle:'short'}):'nunca';
  return '<div class="sec">Sincronización y respaldo</div><div class="panel"><div class="kv"><span>Última sincronización</span><b>'+esc(last)+'</b></div><div class="kv" style="border-bottom:0"><span>Pendientes de enviar</span><b>'+dirty.size+'</b></div>'
   +(cfgOK()?'':'<p class="note" style="margin-top:8px">La sincronización aún no está configurada. Mientras tanto, usa el respaldo.</p>')
   +'<p class="note" style="margin-top:8px">'+(canFin()?'El respaldo completo incluye pedidos, entradas, precios, cierres, cobros, pagos, presupuesto y contabilidad.':'El respaldo incluye pedidos, entradas y catálogos.')+' El respaldo diario automático queda pendiente para el plan Pro de Supabase; mientras tanto, descárgalo al cerrar cada semana.</p>'
   +'<div class="pact"><button class="btn sm" data-act="exportjson">'+(canFin()?'Descargar respaldo completo':'Descargar respaldo')+'</button><button class="btn sm" data-act="importjson">Importar respaldo</button>'+(session?'<button class="btn sm" data-act="logout">Cerrar sesión</button>':'')+'</div><input type="file" id="impfile" accept=".json,application/json" hidden></div>';
}
/* v8.16: respaldo completo. Con permisos de Finanzas incluye precios, versiones, cierres, cobros, pagos, presupuesto y contabilidad;
   el jefe de empaque respalda pedidos, entradas y catálogos sin dinero. El respaldo diario automático queda para el plan Pro de Supabase. */
async function exportBackup(){
  const f=canFin(),d={app:'registro-empaque',v:2,exportado:new Date().toISOString(),version:APP_VER,por:(authUser&&(authUser.name||authUser.user))||'',completo:f,
    orders:orders,entradas:INV.entradas,pesos:PESOS.kg,decisiones:DEC.m,periodos:PER.list,registros:REG,productores:LISTA};
  if(f)Object.assign(d,{finanzas:{VL:FIN.VL,EC:FIN.EC},parametros:PAR.list,cierres:CIE.list,cobros:COB.list,pagos:PAG.list,presupuesto:PPTO.d,contable:CTB.d,bitacora:LOG.list});
  await saveFile('Respaldo_Empaque_'+(f?'completo_':'')+todayISO()+'.json',new Blob([JSON.stringify(d)],{type:'application/json'}));
}
function importBackup(inp){
  const f=inp.files&&inp.files[0];if(!f)return;
  const rd=new FileReader();
  rd.onload=function(){
    try{
      const j=JSON.parse(rd.result);const list=Array.isArray(j)?j:(j&&j.orders);
      if(!Array.isArray(list))throw new Error('formato');
      let n=0,ne=0;
      list.forEach(r=>{
        if(!r||!r.id||!Array.isArray(r.productores))return;
        const i=orders.findIndex(x=>x.id===r.id);
        if(i<0||(r.updatedAt||0)>(orders[i].updatedAt||0)){if(i<0)orders.push(r);else orders[i]=r;dirty.add(r.id);n++}
      });
      /* v8.16: el respaldo completo también trae las entradas de fruta; precios, cobros y pagos se guardan en el archivo pero no se reimportan desde aquí */
      if(j&&Array.isArray(j.entradas))j.entradas.forEach(r=>{if(!r||!r.id)return;const i=INV.entradas.findIndex(x=>x.id===r.id);if(i<0||(r.updatedAt||0)>(INV.entradas[i].updatedAt||0)){if(i<0)INV.entradas.push(r);else INV.entradas[i]=r;if(INV.dirty.indexOf(r.id)<0)INV.dirty.push(r.id);ne++}});
      if(ne)saveInv();
      normOrders();invalidateStats();saveLocal();setSync();render();toast(n+' pedidos'+(ne?' y '+ne+' entradas':'')+' importados');
    }catch(e){toast('El archivo no es un respaldo válido')}
    inp.value='';
  };
  rd.readAsText(f);
}
function registerSW(){
  try{
    const C=window.Capacitor;if(C&&C.isNativePlatform&&C.isNativePlatform())return;
    if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{});
    if('serviceWorker' in navigator&&(location.protocol==='https:'||location.hostname==='localhost'))navigator.serviceWorker.register('sw.js').catch(()=>{});
  }catch(e){}
}


/* ---------- v8.4 · menú inferior, Productores y Control Logístico ---------- */
const NAV_ICO={
  inv:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 7h12v9H2z"/><path d="M14 10h4l4 4v2h-8z"/><circle cx="6" cy="18" r="1.8"/><circle cx="18" cy="18" r="1.8"/></svg>',
  dv:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 12h7M9 16h7"/></svg>',
  menu:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/></svg>',
  orders:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h14v16H5z"/><path d="M8 9h8M8 13h8M8 17h5"/></svg>',
  traz:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7l9-4 9 4-9 4z"/><path d="M3 12l9 4 9-4M3 17l9 4 9-4"/></svg>',
  prods:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/></svg>',
  log:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 6h12v9H2z"/><path d="M14 9h4l4 4v2h-8z"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="18" cy="17.5" r="1.8"/></svg>',
  fin:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 20h18"/><path d="M5.5 20v-6M10 20V9M14.5 20v-4M19 20V6"/></svg>'
};
/* v8.25: Inicio, Recepción, Empaque, Trazabilidad, Documentos y Finanzas. Productores y Logística quedan en el menú (Mantenimiento) */
const NAV_ITEMS=[['menu','Inicio'],['inv','Recepción'],['orders','Empaque'],['traz','Trazabilidad'],['dv','Documentos']];
function navOn(){return !!authUser&&!isContador()&&!isTarima()&&['menu','inv','orders','traz','prods','log','stats','fin','dv','dvt'].indexOf(view)>=0}
/* v8.9.2: Finanzas es la sexta opción, solo para quien puede verla (el jefe de empaque no la ve) */
function navItems(){return canFin()?NAV_ITEMS.concat([['fin','Finanzas']]):NAV_ITEMS}
function navHtml(){
  if(!navOn())return '';
  const its=navItems(),vv=view==='dvt'||view==='docs'?'dv':view==='trazo'?'traz':view==='order'?'orders':view,cur2=its.some(i=>i[0]===vv)?vv:'menu';
  const mk=isMarco();
  return `<nav class="bnav" aria-label="Secciones">${mk?`<div class="bnbrand"><img src="${ICO.VL}" alt=""><img src="${ICO.EC}" alt=""><span>Empaque<small>Vera Limes · Citrilar</small></span></div>`:''}<div class="bnavin" style="--nb:${its.length}">${its.map(i=>`<button data-act="${i[0]}" class="bn" aria-current="${cur2===i[0]?'page':'false'}">${NAV_ICO[i[0]]}<span>${i[1]}</span></button>`).join('')}</div>${mk?`<div class="bnfoot"><span>Uso interno</span><button data-act="legal:priv">Aviso de privacidad</button><button data-act="legal:term">Términos</button></div>`:''}</nav>`;
}
function clsChip(c){const k=clsOf(c);return ` <i class="pcls k-${k}">${PCLS_L[k]}</i>`}
function clsSelHtml(id,val){return `<label class="fld" for="${id}"><span>Clasificación</span><select class="in sel" id="${id}">${PCLS.map(x=>`<option value="${x[0]}"${val===x[0]?' selected':''}>${x[1]}</option>`).join('')}</select></label>`}
function prodCardsHtml(){
  const adm=canCat(),max=LISTA.reduce((m,x)=>Math.max(m,x.c),0),q=norm(PV.q||'').trim().split(/\s+/).filter(Boolean);
  let h='',shown=0;
  for(let c=1;c<=max;c++){
    const x=LISTA.find(y=>y.c===c),n=x?x.n:'';
    if(!n&&!adm)continue;
    if(PV.only==='vac'&&n)continue;
    if(PV.only==='acu'&&!(n&&acuTxt(c)))continue;
    if(PV.cls&&PV.cls!=='all'&&(!n||clsOf(c)!==PV.cls))continue;
    if(q.length){const t=norm(codeLabel(c,emp)+' '+c+' '+n);if(!q.every(w=>t.includes(w)))continue}
    shown++;
    const body=`<span class="pcc mono">${codeLabel(c,emp)}</span><span class="pcn">${n?esc(n)+clsChip(c):'Código libre'}</span>${n?(acuTxt(c)||'<small class="acs none">Sin acuerdo de compra</small>'):''}`;
    h+=adm?`<button class="pcard${n?'':' vac'}" data-act="pvopen:${c}" aria-label="${n?'Editar ':'Asignar '}${esc(codeLabel(c,emp)+' '+n)}">${body}<span class="pce">${n?'Editar':'Asignar'}</span></button>`:`<div class="pcard${n?'':' vac'}">${body}</div>`;
  }
  return h||'<p class="note">Sin resultados.</p>';
}
function prodsView(){
  const adm=canCat(),max=LISTA.reduce((m,x)=>Math.max(m,x.c),0),vac=[];for(let c=1;c<=max;c++)if(!LISTA.some(x=>x.c===c))vac.push(c);
  const conAcu=LISTA.filter(x=>acuTxt(x.c)).length,pend=listaOps().length;
  const add=adm?`<div class="panel"><div class="padd"><input class="in" id="pv-c" type="text" inputmode="numeric" pattern="[0-9]*" data-digits="1" placeholder="Código" value="${vac[0]||max+1}" aria-label="Código nuevo"><input class="in txt" id="pv-n" type="text" autocomplete="off" autocapitalize="characters" placeholder="Nombre del productor nuevo" aria-label="Nombre del productor nuevo"><select class="in sel" id="pv-k" aria-label="Clasificación del productor nuevo">${PCLS.map(x=>`<option value="${x[0]}">${x[1]}</option>`).join('')}</select><button class="btn primary sm" data-act="pvadd">Agregar</button></div>${PV.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(PV.err)}</p>`:''}</div>`:'';
  return topbar('Productores','menu')+`<main class="wrap"><div class="panel info"><p class="note"><strong>${LISTA.length}</strong> productores con código · <strong>${conAcu}</strong> con acuerdo de compra · ${vac.length} ${vac.length===1?'código libre':'códigos libres'}${pend?' · '+pend+' cambios por enviar (se envían al sincronizar)':''}.${adm?' Toca una tarjeta para editar el nombre y el acuerdo de compra.':' Solo el administrador puede editar.'}</p></div>${add}
<label class="fld" for="pvq" style="margin-top:10px"><span>Buscar por nombre o código</span><input class="in txt" id="pvq" type="text" autocomplete="off" data-pvq="1" value="${esc(PV.q||'')}"></label>
<div class="seg" role="group" aria-label="Filtro" style="margin:10px 0"><button data-act="pvfil:all" aria-pressed="${PV.only==='all'}">Todos</button><button data-act="pvfil:acu" aria-pressed="${PV.only==='acu'}">Con acuerdo</button>${adm?`<button data-act="pvfil:vac" aria-pressed="${PV.only==='vac'}">Libres</button>`:''}</div>
<div class="seg" role="group" aria-label="Clasificación" style="margin:0 0 10px"><button data-act="pvcls:all" aria-pressed="${PV.cls==='all'}">Todas</button>${PCLS.map(x=>`<button data-act="pvcls:${x[0]}" aria-pressed="${PV.cls===x[0]}">${x[1]}</button>`).join('')}</div>
<div id="pvgrid" class="pgrid">${prodCardsHtml()}</div></main>`+navHtml();
}
function prodOneHtml(){
  const c=sheet.c,x=LISTA.find(y=>y.c===c),n=x?x.n:'';
  return `<h3>${n?'Productor':'Asignar código'} · ${codeLabel(c,emp)}</h3><label class="fld" for="pe-n"><span>Nombre del productor</span><input class="in txt" id="pe-n" type="text" autocomplete="off" autocapitalize="characters" value="${esc(n)}" placeholder="Nombre del productor"></label>${clsSelHtml('pe-k',clsOf(c))}${clsExp(c)?'':'<p class="note">Sin clasificación guardada: cuenta como '+PCLS_L[clsOf(c)]+'. Elígela y guarda.</p>'}${sheet.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.err)}</p>`:''}${isAdmin()?acuFormHtml(c):''}<div class="srow2">${n?`<button class="btn danger" data-act="pvdel:${c}">${confirmKey==='pvdel:'+c?'Toca otra vez':'Eliminar'}</button>`:''}<button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="pvsave:${c}">Guardar</button></div>`;
}
const LOG_ICO={trailers:'M2 6h12v9H2zM14 9h4l4 4v2h-8z',cajas:'M3 5h18v12H3zM3 9h18M8 5v12',conductores:'M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 20c1-4 4-6 8-6s7 2 8 6',transportistas:'M3 20V8l9-5 9 5v12zM9 20v-6h6v6',vendedores:'M5 4h14v16H5zM9 9h6M9 13h6',clientes:'M3 21V9l6-4v16M9 21V3h12v18zM13 8h4M13 12h4M13 16h4'};
function logView(){
  const adm=canCat();
  if(!LG.rt){
    const tiles=Object.keys(REGSPEC).map(k=>{const sp=REGSPEC[k];return `<button class="ltile" data-act="logsec:${k}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${LOG_ICO[k]}"/></svg><span class="ltt">${esc(sp.t)}</span><span class="ltc mono">${REG[k].length}</span><small>${esc(sp.uso)}</small></button>`}).join('');
    return topbar('Control Logístico','menu')+`<main class="wrap"><div class="panel info"><p class="note">Los datos de logística se capturan una sola vez aquí y se eligen en Registro de empaque, Código de Trazabilidad, Manifiesto y Packing List. Al elegir un transportista, conductor, trailer, termo, vendedor o cliente se completan solos sus teléfonos, placas y códigos.${adm?'':' Solo el administrador puede editar.'}</p></div><div class="lgrid">${tiles}</div></main>`+navHtml();
  }
  const sp=REGSPEC[LG.rt];
  const imp=adm&&LG.rt==='clientes'?`<div class="pact"><button class="btn sm" data-act="logimp">Traer clientes de los pedidos</button></div>`:'';
  return topbar(sp.t,'logmenu')+`<main class="wrap"><div class="panel info"><p class="note"><strong>${REG[LG.rt].length}</strong> registrados. Se usan en: ${esc(sp.uso)}</p>${imp}</div>${adm?`<div class="panel">${regsAddHtml(LG)}</div>`:''}
<label class="fld" for="rq" style="margin-top:10px"><span>Buscar</span><input class="in txt" id="rq" type="text" autocomplete="off" data-rsq="1" value="${esc(LG.q||'')}"></label>
<div id="rlist" class="rlist">${regsRowsHtml(LG)}</div></main>`+navHtml();
}
$app.addEventListener('input',e=>{
  const el=e.target;if(!el||!el.dataset)return;
  if(el.dataset.pvq){PV.q=el.value;const g=document.getElementById('pvgrid');if(g)g.innerHTML=prodCardsHtml()}
  if(el.dataset.rsq&&view==='log'){LG.q=el.value;const r=document.getElementById('rlist');if(r)r.innerHTML=regsRowsHtml(LG)}
});

/* ---------- vistas ---------- */
function topbar(title,back){
  return `<header class="top"><div class="topin">${back?`<button class="icon back" data-act="${back}" aria-label="Volver" title="Volver"><svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`:''}<span class="empchip" title="${esc(EMPS[emp].name)}"><img src="${ICO[emp]}" alt=""><span class="ect">${emp}</span></span><div class="ttl">${esc(title)}</div>${authUser?'<button class="icon hist" data-act="logopen" aria-label="Registro de cambios" title="Registro de cambios"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M3 4v4h4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>':''}<button class="sbtn" id="syncpill" data-act="sync" data-s="${syncState()}" aria-label="${esc(syncLabel())}" title="${esc(syncLabel())}"><span class="sring"><b>S</b></span><i class="sdot"></i><i class="scnt"${rtCount()?'':' hidden'}>${rtCount()||''}</i></button></div></header>`;
}
function render(){
  needsRender=false;
  normOrders();applyTheme();
  if(!authUser){$app.className='';document.body.classList.remove('hasnav');$app.innerHTML=loginView();return}
  /* v8.0: el FIN vigente sigue a las versiones; sin base de datos, el administrador migra al abrir */
  if(!render.fp){render.fp=1;try{finFromPar()}catch(e){}}
  if(!cfgOK()&&isAdmin()&&parNeedsMig())try{parMigrate()}catch(e){}
  if((view==='order'||view==='trazo'||view==='docs'||view==='dvt')&&!cur()){curId=null;view=view==='trazo'?'traz':view==='dvt'?'dv':'orders'}
  /* dentro de un pedido, los colores y logotipos son los de la empresa por la que sale */
  if((view==='order'||view==='trazo'||view==='docs'||view==='dvt')&&cur()&&cur().emp!==emp&&EMPS[cur().emp])setEmp(cur().emp);
  /* una semana cerrada deja sus pedidos en solo lectura */
  /* el contador captura cobros y pagos en Finanzas; fuera de ahí sigue en solo lectura */
  if(isTarima()&&view!=='conteo'){view='conteo';curId=null}
  ro=(view==='fin'&&isContador())||(view==='conteo'&&isTarima())?false:roRole||((view==='order'||view==='trazo'||view==='docs'||view==='dvt')&&orderLocked(cur()))||(view==='trazo'&&manClosed(cur()));
  $app.className=ro?'ro':'';
  if(view==='stats'&&!canStats())view='menu';
  if(isContador()&&['order','orders','traz','trazo','docs','inv','prods','log','dv','dvt'].indexOf(view)>=0){view='fin';curId=null}
  if(view==='fin'&&!canFin())view='menu';
  const fp=view==='trazo'&&render.vk&&render.vk.indexOf('trazo|')===0?(flipPrev||flipSnap()):null;flipPrev=null;
  $app.innerHTML=view==='order'?orderView(cur()):view==='orders'?listView():view==='stats'?statsView():view==='fin'?finSecView():view==='traz'?trazList():view==='trazo'?trazView(cur()):view==='docs'?docsView(cur()):view==='inv'?invView():view==='prods'?prodsView():view==='log'?logView():view==='dv'?dvView():view==='dvt'?dvtView(cur()):view==='conteo'?conteoView():menuView();
  if(ro)$app.querySelectorAll('input.in,select.in').forEach(i=>{i.readOnly=true;if(i.tagName==='SELECT')i.disabled=true});
  if(navOn()&&view!=='prods'&&view!=='log')$app.insertAdjacentHTML('beforeend',navHtml());
  document.body.classList.toggle('hasnav',!!$app.querySelector('.bnav'));
  /* v8.11: animación al cambiar de pantalla o pestaña y al abrir una tarima (no en cada redibujo) */
  {const vk=[view,curId,tab,docTab,statsF.ftab,statsF.tab].join('|');if(render.vk!==undefined&&render.vk!==vk){const m=$app.querySelector('main');if(m)m.classList.add('vin')}render.vk=vk;
   if(view==='trazo'&&palOpen&&render.po!==palOpen){const el=document.getElementById('pal-'+palOpen);if(el&&el.classList.contains('pal'))el.classList.add('pin')}render.po=view==='trazo'?palOpen:null}
  updateDerived();if(view==='trazo'){updateTraz();if(fp)flipPlay(fp)}if(view==='docs')liveSched(0);xlvAll();
  $app.querySelectorAll('[data-cs]').forEach(cs=>cardPage(cs,+cs.dataset.pg0||0,false));
  if(scrollToP){const el=document.getElementById('pc-'+scrollToP);if(el)el.scrollIntoView({block:'start',behavior:'smooth'});scrollToP=null}
  if(focusId){const el=document.getElementById(focusId);if(el){el.scrollIntoView({block:'center'});try{el.focus({preventScroll:true})}catch(x){}}focusId=null}
}
function softRender(){const a=document.activeElement;if(a&&a.matches&&a.matches('input,textarea,select')&&$app.contains(a)){needsRender=true}else render()}
document.addEventListener('focusout',()=>{setTimeout(()=>{const a=document.activeElement;if(needsRender&&!(a&&a.matches&&a.matches('input,textarea,select')))render()},60)});

function lastCod(e){
  const l=visible().filter(o=>o.emp===e).sort((a,b)=>(b.anio-a.anio)||((b.cons||0)-(a.cons||0)))[0];
  return l?l.cod:'';
}
/* ---------- v8.23 · apariencia «Marco azul» (tema opcional, solo estilo) ---------- */
function isMarco(){return skin==='marco'}
function setSkin(s){skin=s==='marco'?'marco':'clasico';try{localStorage.setItem(LS_SKIN,skin)}catch(e){}applyTheme()}
/* pictogramas de línea del menú: trazo del color del texto, un detalle con el color de la empresa (clase «a») */
const PIC={
  inv:'<svg viewBox="0 0 48 48"><path d="M4 13h23v19H4z"/><path d="M27 19h8.5l6.5 7.5V32H27z"/><path d="M31 19v7.5h11"/><circle cx="12" cy="35" r="3.6"/><circle cx="34" cy="35" r="3.6"/><path d="M8.5 26.5h4m3 0h4m-11-5.5h4m3 0h4"/><ellipse class="a" cx="15.5" cy="7.5" rx="5" ry="3.6"/></svg>',
  orders:'<svg viewBox="0 0 48 48"><path d="M17 4h14l-4 7h-6z"/><path d="M24 11v5"/><rect class="a" x="7" y="20" width="10" height="9" rx="1.5"/><rect x="19" y="20" width="10" height="9" rx="1.5"/><rect x="31" y="20" width="10" height="9" rx="1.5"/><path d="M4 32h40"/><circle cx="9" cy="37.5" r="3"/><circle cx="24" cy="37.5" r="3"/><circle cx="39" cy="37.5" r="3"/></svg>',
  traz:'<svg viewBox="0 0 48 48"><rect x="6" y="6" width="13" height="13" rx="1.5"/><rect x="29" y="6" width="13" height="13" rx="1.5"/><rect x="6" y="29" width="13" height="13" rx="1.5"/><rect class="a" x="10.5" y="10.5" width="4" height="4"/><rect class="a" x="33.5" y="10.5" width="4" height="4"/><rect class="a" x="10.5" y="33.5" width="4" height="4"/><path d="M29 29h5v5m8-5v13h-5m-8 0v-4m5-4v4h3"/></svg>',
  stats:'<svg viewBox="0 0 48 48"><path d="M4 42h40"/><path d="M8 42V28h6v14m5 0V20h6v22"/><path class="a" d="M36 6a10 10 0 1 1-10 10h10z"/><path d="M33 13A10 10 0 0 0 23 3v10z"/></svg>',
  prods:'<svg viewBox="0 0 48 48"><circle cx="18" cy="15" r="7"/><path d="M5 40c1-8 6-13 13-13s12 5 13 13"/><path class="a" d="M38 12c-6 0-9 4-9 9 5 0 9-3 9-9z"/><path d="M29 21l-3 3"/></svg>',
  dv:'<svg viewBox="0 0 48 48"><path d="M12 5h17l8 8v30H12z"/><path d="M29 5v8h8"/><path d="M18 22h13M18 28h13M18 34h8"/><rect class="a" x="5" y="13" width="9" height="12" rx="1.5"/></svg>',
  log:'<svg viewBox="0 0 48 48"><path d="M4 12h24v18H4z"/><path d="M28 18h8l7 7v5H28z"/><circle cx="11" cy="34" r="3.6"/><circle cx="35" cy="34" r="3.6"/><path class="a" d="M10 18h12v6H10z"/></svg>',
  peropen:'<svg viewBox="0 0 48 48"><rect x="5" y="9" width="38" height="33" rx="2"/><path d="M5 18h38M15 5v8M33 5v8"/><rect class="a" x="12" y="24" width="8" height="7"/><path d="M27 27h9M27 34h9M12 36h8"/></svg>',
  pendopen:'<svg viewBox="0 0 48 48"><path d="M24 5l20 36H4z"/><path d="M24 18v11"/><circle class="a" cx="24" cy="35" r="2.5"/></svg>',
  logopen:'<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="18"/><path d="M24 13v12l8 5"/><circle class="a" cx="24" cy="25" r="3"/></svg>',
  usersadm:'<svg viewBox="0 0 48 48"><circle cx="17" cy="15" r="6"/><path d="M5 38c1-7 5-11 12-11s11 4 12 11"/><path class="a" d="M36 18l7 3v6c0 5-3 8-7 10-4-2-7-5-7-10v-6z"/></svg>',
  conteo:'<svg viewBox="0 0 48 48"><path d="M5 38h38"/><rect x="8" y="26" width="14" height="12"/><rect x="26" y="26" width="14" height="12"/><rect class="a" x="17" y="12" width="14" height="14"/><path d="M5 43h38"/></svg>',
  fin:'<svg viewBox="0 0 48 48"><path d="M4 30l9-9 7 6 12-13"/><path d="M26 14h6v6"/><circle class="a" cx="34" cy="34" r="9"/><path d="M37 30.5h-4.2a2.1 2.1 0 0 0 0 4.2h2.4a2.1 2.1 0 0 1 0 4.2H31M34 28.5v2m0 8.4v2"/></svg>'
};
const PEND_LVL={crit:['Urgente',0],warn:['Revisar',1],info:['Aviso',2]};
function pendTable(){
  if(!authUser)return '';
  const I=pendItems().slice().sort((a,b)=>(PEND_LVL[a.lvl]||[0,3])[1]-(PEND_LVL[b.lvl]||[0,3])[1]);
  const bell='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>';
  if(!I.length)return `<section class="ptab ok"><header class="ptabh"><span class="ptico">${bell}</span><strong>Pendientes</strong><span class="chip good">Todo al día</span></header><p class="note">No falta capturar, configurar ni aprobar nada.</p></section>`;
  const cnt={crit:0,warn:0,info:0};I.forEach(x=>{cnt[x.lvl]=(cnt[x.lvl]||0)+(x.rows.length||1)});
  const sum=['crit','warn','info'].filter(k=>cnt[k]).map(k=>`<span class="pcnt ${k}" title="${PEND_LVL[k][0]}">${fmt(cnt[k])}<span class="vh"> ${PEND_LVL[k][0]}</span></span>`).join('');
  const rows=I.slice(0,6).map(x=>`<button class="ptr ${x.lvl}" data-act="pendopen"><span class="ptl">${(PEND_LVL[x.lvl]||['Aviso'])[0]}</span><span class="ptt">${esc(x.t)}</span><span class="ptw">${esc(x.who)}</span><span class="ptg" aria-hidden="true">›</span></button>`).join('');
  return `<section class="ptab"><header class="ptabh"><span class="ptico">${bell}</span><strong>Pendientes</strong><span class="pcnts">${sum}</span></header><div class="ptrh" aria-hidden="true"><span>Prioridad</span><span>Pendiente</span><span>Responsable</span><span></span></div><div class="ptrs">${rows}</div><button class="ptfoot" data-act="pendopen">${I.length>6?`Ver los ${I.length} pendientes`:'Ver detalle y corregir'}<span aria-hidden="true">›</span></button></section>`;
}
function aparPanel(){
  return `<div class="sec">Apariencia</div><div class="panel"><div class="seg" role="group" aria-label="Apariencia de la app" style="margin-top:0"><button data-act="skin:clasico" aria-pressed="${!isMarco()}">Clásica</button><button data-act="skin:marco" aria-pressed="${isMarco()}">Marco azul</button></div><p class="note" style="margin-top:8px">Solo cambia colores, letras y acomodo. Los datos y las funciones son los mismos. Se guarda en este dispositivo.</p></div>`;
}

/* ---------- v8.23 · información legal de uso interno (datos de la empresa agregados en v8.24) ----------
   Borradores tomados de «Documentos legales – App Empaque Vera Limes» (LFPDPPP vigente desde el 21-mar-2025),
   ajustados para las dos empresas. Los campos marcados con LF() faltan por llenar y todo lo debe revisar un abogado. */
const LEGAL_VER='1.1',LS_LEGAL='empaque-legal';
const LF=t=>`<mark class="lfill">[${t}]</mark>`;
const VLX='Exportadora de Cítricos Vera Limes, S.A. de C.V.',ECX='Exportadora Citrilar, S.A. de C.V.';
const LEGAL_DAT={
  rfcVL:'ECV170817C71',rfcEC:'ECI061103G4A',
  dom:'Carretera Federal Córdoba–Veracruz km 56.6, Rancho Copalillo, C.P. 94910, Cuitláhuac, Veracruz de Ignacio de la Llave, México',
  rep:'Danilo Naranjo Hernández',
  datos:'Danilo Naranjo Hernández, Director de Operaciones',tel:'+52 271 206 7611',
  sw:'Brayand Axel Achautla Hernández',swRol:'soporte técnico',swTel:'+52 271 177 5970',
  nube:'Supabase, región ca-central-1 (Canadá)',conserva:'5 años'
};
const LDOM=()=>LEGAL_DAT.dom;
const LCONT=()=>`${LEGAL_DAT.datos}, teléfono y WhatsApp ${LEGAL_DAT.tel}, o por escrito en el domicilio de las empresas`;
const LEGAL={
  priv:{t:'Aviso de privacidad integral',b:()=>`
<h4>Responsables</h4><p>${VLX} («Vera Limes», RFC ${LEGAL_DAT.rfcVL}) y ${ECX} («Citrilar», RFC ${LEGAL_DAT.rfcEC}), ambas con domicilio en ${LDOM()}, son responsables, cada una, de los datos personales que se registran en la app «Empaque Vera Limes» sobre sus propias operaciones. Representante legal de ambas: ${LEGAL_DAT.rep}.</p>
<p><b>Relación entre las empresas.</b> Citrilar presta a Vera Limes el servicio de maquila (empaque) y las dos exportan por su cuenta. Cuando Citrilar empaca fruta de Vera Limes, trata esos datos por encargo de Vera Limes y solo para ese servicio. Para sus propias exportaciones, cada empresa es responsable de sus datos.</p>
<p><b>Persona responsable de datos personales:</b> ${LCONT()}.</p>
<h4>Datos personales que tratamos</h4><ul>
<li><b>Personas usuarias:</b> nombre, usuario, correo o teléfono, rol y registro de actividad dentro de la app.</li>
<li><b>Productores</b> (en su mayoría personas físicas y algunas personas morales): nombre o razón social, código de productor (VL- o EC-), clasificación, fruta entregada (cajas, kilos de báscula, calibres y rendimiento), precios acordados y montos por pagar y pagados.</li>
<li><b>Transportistas y conductores:</b> nombre, teléfono y placas de tractocamión y termo.</li>
<li><b>Fotografías y chat</b>, cuando se activen: fotos de tickets y del empaque, que pueden mostrar nombres, placas, firmas u otras personas, y los mensajes del chat interno.</li></ul>
<p>No recabamos a propósito datos personales sensibles. Si una foto o un mensaje los contiene sin haberlos pedido, se usan solo para la finalidad de este aviso.</p>
<h4>Finalidades necesarias</h4><ol>
<li>Crear y administrar cuentas y controlar el acceso.</li>
<li>Registrar la recepción y el empaque de limón y mantener la trazabilidad de cada lote.</li>
<li>Generar manifiestos, listas de empaque, códigos de trazabilidad y reportes de rendimiento.</li>
<li>Calcular y realizar los pagos a productores conforme a la relación comercial con cada uno, y llevar cuentas por cobrar y por pagar.</li>
<li>Documentar con fotos la evidencia de tickets y de empaque, y permitir la comunicación de trabajo por chat, cuando se activen.</li>
<li>Cumplir obligaciones legales, fiscales, aduaneras y de inocuidad alimentaria.</li>
<li>Seguridad de la información y respaldo de datos.</li></ol>
<p><b>Finalidades que requieren su consentimiento:</b> ninguna. Todas las finalidades anteriores derivan de la relación laboral, comercial o de servicio con las empresas.</p>
<h4>Comunicación de datos</h4><p>Vera Limes y Citrilar comparten entre sí la información necesaria para operar el empaque y la logística comunes. A terceros (clientes, agentes aduanales, transportistas y autoridades) solo se entregan los datos que corresponden al empaque y a la trazabilidad aduanera de cada embarque, como manifiestos, listas de empaque y códigos de trazabilidad. Los datos se alojan con proveedores que actúan por cuenta de las empresas: ${LEGAL_DAT.nube}, para la base de datos, y Microsoft OneDrive, para copias en Excel. Por eso la información puede guardarse fuera de México. Cuando usted comparte un archivo por WhatsApp, esa app se rige por sus propios términos.</p>
<h4>Derechos ARCO</h4><p>Puede acceder a sus datos, rectificarlos, cancelarlos u oponerse a su tratamiento, y revocar su consentimiento cuando aplique. Diríjase a ${LCONT()}, con su nombre, un medio para responderle, la descripción clara de lo que pide y una identificación oficial. Respondemos en los plazos que marca la ley. Si considera que su derecho fue vulnerado, puede acudir a la Secretaría Anticorrupción y Buen Gobierno.</p>
<h4>Conservación y seguridad</h4><p>Conservamos los datos mientras dure la relación y, como mínimo, ${LEGAL_DAT.conserva} después, o más si alguna obligación legal, fiscal o aduanera lo exige. Pasado ese plazo se eliminan o anonimizan. Aplicamos medidas administrativas, técnicas y físicas: acceso con usuario, control por roles, registro de cambios, conexión cifrada y teléfonos de la empresa autorizados solo para uso interno.</p>
<h4>Cambios a este aviso</h4><p>Publicaremos cualquier cambio dentro de la app y lo tendremos disponible en el domicilio de las empresas. Si cambian las finalidades, pediremos de nuevo su consentimiento.</p>
<p class="lmeta">Entrada en vigor: ${LF('fecha de entrada en vigor, en desarrollo')} · Versión ${LEGAL_VER}</p>`},
  emp:{t:'Aviso para personal y usuarios internos',b:()=>`
<h4>Responsables</h4><p>${VLX} y ${ECX}, según la empresa para la que usted trabaje. Domicilio: ${LDOM()}. Contacto: ${LCONT()}.</p>
<h4>Datos que tratamos de usted</h4><p>Nombre, puesto, usuario y contraseña (guardada cifrada), registro de actividad en la app (qué capturó, cuándo y desde qué dispositivo), y las fotos y mensajes de trabajo cuando esas funciones se activen. Los datos de nómina y expediente laboral se rigen por el aviso laboral general de la empresa: ${LF('aviso laboral, pendiente')}.</p>
<h4>Finalidades</h4><ol><li>Asignar y controlar su acceso.</li><li>Atribuir cada registro a quien lo capturó.</li><li>Auditar la trazabilidad y corregir errores.</li><li>Mantener la comunicación de trabajo.</li><li>Seguridad de la información y cumplimiento legal.</li></ol>
<h4>Equipos y monitoreo</h4><p>Los teléfonos donde se usa la app son equipos de la empresa, autorizados exclusivamente para uso interno en las actividades del empaque. La app y su registro de cambios son herramientas de trabajo. La empresa puede revisarlos para auditoría, seguridad o investigación de incidentes, sin acceder a cuentas ni dispositivos personales.</p>
<h4>Derechos ARCO y cambios</h4><p>Igual que en el aviso de privacidad integral. Este aviso se entrega al crear su cuenta y se registra su recepción.</p>
<p class="lmeta">Versión ${LEGAL_VER} · Conviene que un abogado laboral confirme la redacción del monitoreo y que el reglamento interior o el contrato mencionen el uso de la app.</p>`},
  term:{t:'Términos y condiciones de uso interno',b:()=>`<ol class="lterms">
<li><b>Qué es la app.</b> «Empaque Vera Limes» es una herramienta de uso interno de ${VLX} y de ${ECX} para registrar la recepción y el empaque de limón, la trazabilidad, la logística y las finanzas de la operación. No es una app pública: se entrega solo a personas autorizadas por las empresas.</li>
<li><b>Cuenta.</b> Cada cuenta es personal e intransferible. Usted cuida su contraseña y avisa de inmediato si sospecha de un acceso no autorizado.</li>
<li><b>Equipos.</b> La app se usa en teléfonos y equipos de la empresa, autorizados exclusivamente para uso interno en las actividades del empaque. No instale la app ni copie su información en equipos personales sin autorización.</li>
<li><b>Uso permitido.</b> Capture información veraz y completa. Está prohibido modificar o eliminar registros para alterar la trazabilidad, compartir datos con terceros no autorizados o intentar vulnerar la seguridad del sistema.</li>
<li><b>Confidencialidad.</b> Precios, rendimientos, pagos, datos de productores, clientes y embarques son información confidencial de las empresas. No los comparta, ni en capturas de pantalla, fuera de los canales que su responsable autorice. Esta obligación sigue vigente después de terminar su relación con la empresa.</li>
<li><b>Fotografías</b> (cuando se active la cámara). Tome solo fotos de tickets, fruta, cajas y tarimas necesarias para el trabajo. Evite captar personas, rostros o documentos personales; si ocurre, avise a su responsable para eliminarlas.</li>
<li><b>Chat interno</b> (cuando se active). Es un medio de trabajo. No se permiten mensajes ofensivos, discriminatorios, de acoso ni ajenos a la operación. La empresa puede conservar y revisar los mensajes conforme al aviso de privacidad.</li>
<li><b>Compartir por WhatsApp u otros medios.</b> Cuando usted envía un manifiesto, una lista de empaque o una foto por otra app, esa app se rige por sus propios términos y aviso de privacidad.</li>
<li><b>Incidentes.</b> Si detecta un acceso indebido, la pérdida de un equipo o un error que afecte la información, avise de inmediato. El aviso va del área donde ocurrió (Empaque o Inocuidad) al representante legal, ${LEGAL_DAT.rep}, y de ahí a soporte técnico, o directamente a soporte técnico al ${LEGAL_DAT.swTel}.</li>
<li><b>Propiedad de la información.</b> Los datos, reportes y registros pertenecen a la empresa por la que sale cada operación, Vera Limes o Citrilar. Los logotipos y marcas son de cada empresa. El software y su diseño pertenecen a ${LEGAL_DAT.sw}, titular del software y responsable de ${LEGAL_DAT.swRol}.</li>
<li><b>Disponibilidad.</b> La app puede tener interrupciones por mantenimiento o fallas de terceros. Las empresas procuran respaldar la información, pero no garantizan disponibilidad continua.</li>
<li><b>Suspensión.</b> No cumplir estos términos puede llevar a suspender la cuenta y a las medidas laborales o legales que correspondan.</li>
<li><b>Cambios y ley aplicable.</b> Estos términos pueden actualizarse y se avisará en la app. Se rigen por las leyes de los Estados Unidos Mexicanos y los tribunales de ${LF('ciudad, pendiente')}, Veracruz.</li></ol>
<p class="lmeta">Entrada en vigor: ${LF('fecha de entrada en vigor, en desarrollo')} · Versión ${LEGAL_VER}</p>`},
  perm:{t:'Permisos de cámara y chat',b:()=>`<p>Estos textos aparecerán la primera vez que se pida cada permiso, cuando las funciones de cámara y chat se activen.</p>
<h4>Antes de pedir la cámara</h4><blockquote>Usaremos la cámara solo para fotografiar tickets y el proceso de empaque como evidencia de trabajo. Las fotos se guardan en los servidores de la empresa y no se comparten sin su acción. Evite captar personas.</blockquote>
<h4>Antes de abrir el chat</h4><blockquote>El chat es una herramienta de trabajo. Los mensajes pueden ser revisados por la empresa conforme al aviso de privacidad.</blockquote>`},
  about:{t:'Acerca de la app',b:()=>`<p><b>${esc(APP_NAME)}</b> · versión ${APP_VER}</p><p>Sistema de uso interno de ${VLX} y ${ECX} Acceso solo para personal autorizado. Se distribuye como APK interno y como versión web con acceso por usuario; no se publica en tiendas de aplicaciones.</p>
<div class="ltw"><table class="ltab"><tbody>
<tr><td>Vera Limes</td><td>${VLX} · RFC ${LEGAL_DAT.rfcVL}</td></tr>
<tr><td>Citrilar</td><td>${ECX} · RFC ${LEGAL_DAT.rfcEC}</td></tr>
<tr><td>Domicilio fiscal (ambas)</td><td>${LDOM()}</td></tr>
<tr><td>Representante legal (ambas)</td><td>${LEGAL_DAT.rep}</td></tr>
<tr><td>Datos personales</td><td>${LEGAL_DAT.datos} · ${LEGAL_DAT.tel}</td></tr>
<tr><td>Titular del software</td><td>${LEGAL_DAT.sw} (${LEGAL_DAT.swRol})</td></tr>
<tr><td>Soporte</td><td>${LEGAL_DAT.swTel}</td></tr>
<tr><td>Servidores</td><td>${LEGAL_DAT.nube}</td></tr>
<tr><td>Conservación</td><td>Mínimo ${LEGAL_DAT.conserva}</td></tr>
<tr><td>Certificaciones</td><td>${LF('certificados vigentes, pendientes de agregar')}</td></tr></tbody></table></div>
<h4>Datos por completar antes de publicar</h4><div class="ltw"><table class="ltab"><thead><tr><th>Dato</th><th>Dónde se usa</th><th>Estado</th></tr></thead><tbody>
<tr><td>Razones sociales, RFC y domicilio</td><td>Avisos y Acerca de</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Responsable de datos personales y contacto ARCO</td><td>Todos los avisos</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Relación entre las empresas (maquila)</td><td>Aviso integral</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Terceros que reciben datos</td><td>Comunicación de datos</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Región de servidores</td><td>Comunicación de datos</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Pagos a productores por relación comercial</td><td>Finalidades</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Titular del software y soporte</td><td>Términos y Acerca de</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Uso de teléfonos de la empresa</td><td>Términos y aviso al personal</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Plazo de conservación</td><td>Aviso integral</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Ruta de incidentes</td><td>Términos</td><td><span class="chip good">Listo</span></td></tr>
<tr><td>Ciudad de los tribunales</td><td>Términos, cláusula 13</td><td><span class="chip warn">Falta</span></td></tr>
<tr><td>Aviso laboral general</td><td>Aviso al personal</td><td><span class="chip warn">Falta</span></td></tr>
<tr><td>Certificados</td><td>Acerca de</td><td><span class="chip warn">Falta</span></td></tr>
<tr><td>Fecha de entrada en vigor</td><td>Avisos y términos</td><td><span class="chip info">En desarrollo</span></td></tr>
<tr><td>Revisión por abogado (datos y laboral)</td><td>Todo el paquete</td><td><span class="chip warn">Falta</span></td></tr></tbody></table></div>`}
};
const LEGAL_ORD=['priv','term','emp','perm','about'];
function legalAcc(){try{const j=JSON.parse(localStorage.getItem(LS_LEGAL)||'null');return j&&j.ver===LEGAL_VER?j:null}catch(e){return null}}
function legalRecord(user){if(legalAcc()&&!lg.acc)return;try{localStorage.setItem(LS_LEGAL,JSON.stringify({ver:LEGAL_VER,user:String(user||''),ts:Date.now()}))}catch(e){}lg.acc=false}
function legalOK(){return !!(legalAcc()||lg.acc)}
function legalBox(){
  const a=legalAcc();
  if(a)return `<p class="note lacc">Aceptaste el aviso de privacidad y los términos (versión ${esc(a.ver)}). <button class="link" data-act="legal:priv">Volver a leer</button></p>`;
  return `<div class="lbox"><p><b>Aviso de privacidad.</b> ${VLX} y ${ECX}, con domicilio en Cuitláhuac, Veracruz, son responsables del tratamiento de sus datos personales. Usamos sus datos de cuenta y de actividad, y las fotos y mensajes que usted registre, para administrar su acceso, llevar la trazabilidad del empaque de limón, generar manifiestos y reportes, y comunicarnos con usted dentro de la app. La base de datos se aloja con Supabase en Canadá, fuera de México. Puede ejercer sus derechos ARCO con ${LEGAL_DAT.datos}, al ${LEGAL_DAT.tel}.</p>
<p class="llinks"><button class="link" data-act="legal:priv">Aviso integral</button><button class="link" data-act="legal:term">Términos y condiciones</button></p>
<label class="lchk" for="lg-acc"><input type="checkbox" id="lg-acc" data-act="lgacc"${lg.acc?' checked':''}><span>He leído el aviso de privacidad y los términos y condiciones de uso.</span></label></div>`;
}
function legalFoot(){return `<footer class="lfoot"><p>Sistema de uso interno de ${VLX} y ${ECX} Acceso solo para personal autorizado.</p><p class="llinks"><button class="link" data-act="legal:priv">Aviso de privacidad</button><button class="link" data-act="legal:term">Términos</button><button class="link" data-act="legal:about">Acerca de</button></p></footer>`}
function legalPanel(){
  const a=legalAcc(),d=a?new Date(a.ts).toLocaleDateString('es-MX',{dateStyle:'medium'}):'';
  return `<div class="sec">Información legal</div><div class="panel lpanel">${LEGAL_ORD.map(k=>`<button class="lrow" data-act="legal:${k}"><span>${LEGAL[k].t}</span><span aria-hidden="true">›</span></button>`).join('')}<p class="note" style="margin-top:8px">${a?`Aceptaste la versión ${esc(a.ver)} el ${esc(d)} en este dispositivo.`:'Aún no hay aceptación registrada en este dispositivo.'} Uso interno de Vera Limes y Citrilar.</p></div>`;
}
function legalHtml(){
  const k=LEGAL[sheet.doc]?sheet.doc:'priv',D=LEGAL[k];
  return `<h3>${D.t}</h3><div class="ltabs" role="tablist">${LEGAL_ORD.map(x=>`<button class="chipbtn ltb" role="tab" aria-selected="${x===k}" data-act="legal:${x}">${LEGAL[x].t.replace('Aviso de privacidad integral','Privacidad').replace('Términos y condiciones de uso interno','Términos').replace('Aviso para personal y usuarios internos','Personal').replace('Permisos de cámara y chat','Permisos').replace('Acerca de la app','Acerca de')}</button>`).join('')}</div><p class="lwarn">Borrador. Los campos <mark class="lfill">[así]</mark> faltan por llenar y todo el texto debe revisarlo un abogado antes de usarse.</p><div class="ldoc">${D.b()}</div><div class="srow2"><button class="btn primary" data-act="closesheet">Cerrar</button></div>`;
}

function extraPanel(){
  const acc=authUser?`<div class="sec">Sesión</div><div class="panel"><div class="kv" style="border-bottom:0"><span>${esc(authUser.name)}</span><b>${ROLES[authUser.rol]||authUser.rol}</b></div><div class="pact"><button class="btn sm" data-act="acctopen">Mi cuenta</button><button class="btn sm" data-act="ulogout">Cerrar sesión</button></div></div>`:'';
  return acc+aparPanel()+backupPanel()+(isAdmin()?`<div class="sec">Configuración</div><div class="panel"><div class="kv" style="border-bottom:0"><span>Productores registrados</span><b>${LISTA.length}</b></div><p class="note" style="margin-top:6px">Añade, corrige o elimina códigos de productor. Los espacios vacíos se ven para que los asignes. Se guardan en la base de datos al sincronizar.</p><div class="pact"><button class="btn sm" data-act="prods">Productores</button>${cfgOK()?'':`<button class="btn sm" data-act="usersopen">Usuarios${pendingUsers()?' ('+pendingUsers()+' por autorizar)':''}</button>`}<button class="btn sm" data-act="log">Control Logístico</button><button class="btn sm" data-act="peropen">Periodos (abrir y cerrar semanas)</button></div></div>`:'')+legalPanel();
}
function menuView(){
  const E=EMPS[emp],all=visible().filter(o=>o.variante!=='1.5'),lc=visible().filter(o=>o.variante!=='1.5').sort((a,b)=>b.createdAt-a.createdAt).map(o=>o.cod)[0]||'';
  const proc=all.filter(o=>o.estado!=='completo').length,comp=all.filter(o=>o.estado==='completo');
  const lead=visible().filter(isLeader),borr=lead.filter(o=>o.estado==='completo'&&trazCalc(o).borrador).length;
  const seg=['VL','EC'].map(k=>`<button data-act="emp:${k}" aria-pressed="${emp===k}"><img class="segico" src="${ICO[k]}" alt="">${k} · ${EMPS[k].name}</button>`).join('');
  const btn=(act,t,s)=>isMarco()?`<button class="mtile" data-act="${act}"><span class="mpic" aria-hidden="true">${PIC[act]||''}</span><span class="mtx"><strong>${t}</strong><small>${s}</small></span></button>`:`<button class="mbtn" data-act="${act}"><span><strong>${t}</strong><small>${s}</small></span><span class="mgo" aria-hidden="true">›</span></button>`;
  if(isMarco())return topbar(APP_NAME,null)+`<main class="wrap"><div class="mk"><section class="mk-t" aria-label="Operaciones"><div class="mtiles">
${modsHtml(btn,proc,comp,lc,lead,borr)}</div></section><section class="mk-p">${pendTable()}</section><aside class="mk-s"><section class="mlogos" aria-label="Empresas">${['VL','EC'].map(k=>`<figure><img src="${LOGO[k]}" alt="Logotipo de ${esc(EMPS[k].name)}"><figcaption>${esc(EMPS[k].full)}</figcaption></figure>`).join('')}</section>${extraPanel()}</aside></div></main>`;
  return topbar(APP_NAME,null)+`<main class="wrap"><div class="dsk dmenu"><div class="g-a"><section class="hero hero2"><div class="logos2">${['VL','EC'].map(k=>`<figure><img src="${LOGO[k]}" alt="Logotipo de ${esc(EMPS[k].name)}"><figcaption>${esc(EMPS[k].full)}</figcaption></figure>`).join('')}</div></section></div><div class="g-b">
${modsHtml(btn,proc,comp,lc,lead,borr)}</div><div class="g-c">${pendPanel()}${extraPanel()}</div></div></main>`;
}
/* v8.25 · menú por módulos, como iSolve: cada módulo separa Operaciones (captura), Reportes (consulta) y Mantenimiento (catálogos) */
function modsHtml(btn,proc,comp,lc,lead,borr){
  const C=isContador(),T=isTarima(),adm=isAdmin()||perAdmin();
  if(T)return btn('conteo','Conteo de tarimas','Cuenta las cajas por productor y calibre que se agregan a las tarimas');
  const M=[
    ['Recepción',[!C&&['op','inv','Entrada de Fruta',invMenuSub()]],[],[!C&&['mt','prods','Productores',LISTA.length+' con código · acuerdos de compra y clasificación']]],
    ['Empaque',[!C&&['op','orders','Registro de Empaque',`${proc} en proceso · ${comp.length} completos${lc?' · último '+esc(lc):''}`]],[canStats()&&['rp','stats','Estadísticas','Rendimientos de empaque y base de datos']],[]],
    ['Trazabilidad y embarque',[!C&&['op','traz','Código de Trazabilidad',lead.length?`${lead.length} ${lead.length===1?'pedido':'pedidos'}${proc?' · '+proc+' aún en empaque':''}${borr?' · '+borr+' en borrador':''}`:'Aparecen aquí al crear un pedido']],[!C&&['rp','dv','Documentos de viaje','Manifiestos, packing list, códigos y etiquetas por viaje']],[!C&&['mt','log','Control Logístico','Transportistas, conductores, trailers, vendedores y clientes']]],
    ['Finanzas',[canFin()&&['op','fin','Finanzas','Por cobrar, por pagar, precios y contabilidad']],[],[perAdmin()&&['mt','peropen','Periodos','Abrir y cerrar semanas']]],
    ['Administración',[['op','pendopen','Pendientes',pendItems().length+' por revisar']],[!C&&['rp','logopen','Registro de cambios','Quién cambió qué y cuándo']],[adm&&['mt','usersadm','Usuarios y roles',cfgOK()?'Cuentas, roles y acceso':'Cuentas de este dispositivo']]]
  ];
  const TAG={op:'Operaciones',rp:'Reportes',mt:'Mantenimiento'};
  const html=M.map(([t,...g])=>{const it=g.flat().filter(Boolean);if(!it.length)return '';
    return `<section class="mod" aria-label="${esc(t)}"><div class="modh">${esc(t)}</div>${['op','rp','mt'].map(k=>{const L=it.filter(x=>x[0]===k);return L.length?`<div class="modg"><span class="modk">${TAG[k]}</span>${L.map(x=>btn(x[1],x[2],x[3])).join('')}</div>`:''}).join('')}</section>`}).join('');
  return html+(C?'<div class="rolebadge">Acceso de contador: consultas finanzas, BI, precios y periodos. La captura de empaque no se muestra.</div>':ro?'<div class="rolebadge">Acceso de solo lectura: puedes ver y descargar, no modificar.</div>':'');
}
function estadoChip(o){return o.estado==='completo'?'<span class="chip good">Completo</span>':'<span class="chip warn">En proceso</span>'}
function ordCard(o,sub){
  const M=compute(o);
  return `<div class="ocw${sub?' sub':''}"><button class="ocard${sub?' sub':''}" data-act="open:${o.id}"><div class="orow"><span class="oec"><img class="oico" src="${ICO[o.emp]||ICO.VL}" alt="${esc((EMPS[o.emp]||EMPS.VL).name)}">${sub?'Hoja #1.5 · ':''}${esc(o.cod)}${o.ejemplo?'<span class="badge">Ejemplo</span>':''}</span>${estadoChip(o)}</div><div class="note" style="margin-top:6px"><span class="mono">${esc(o.emb)}</span> · PO ${esc(o.po||'—')} · Semana ${esc(o.semana)} · ${fmtDate(o.fecha)} · ${o.productores.length} ${o.productores.length===1?'productor':'productores'} · ${fmt(M.tot.exp)} cajas</div></button>${ro||orderLocked(o)?'':`<button class="ocdel" data-act="delsheet:${o.id}" aria-label="Eliminar la hoja ${esc(o.variante)} de ${esc(o.cod)}">Eliminar hoja ${esc(o.variante)}</button>`}</div>`;
}
/* interruptor de empresa: Vera Limes ⟷ Citrilar */
function empToggle(cur,act,lab){
  return `<div class="esw"><span class="k">${lab||'Sale por'}</span><button type="button" class="eswb${cur==='EC'?' ec':''}" role="switch" aria-checked="${cur==='EC'}" data-act="${act}"${ro?' disabled':''} aria-label="Empresa: ${esc(EMPS[cur].name)}. Toca para cambiar a ${esc(EMPS[cur==='VL'?'EC':'VL'].name)}"><i class="eswk" aria-hidden="true"></i>${['VL','EC'].map(k=>`<span class="eswo${cur===k?' on':''}"><img src="${ICO[k]}" alt="">${esc(EMPS[k].name)}</span>`).join('')}</button></div>`;
}
/* cambia la empresa de un pedido (todas sus hojas): códigos, marcas de las tarimas y membretes que seguían el valor de la empresa anterior */
function changeEmp(o,ne){
  if(!o||ro||!EMPS[ne]||o.emp===ne)return;
  const old=o.emp,sh=sheetsOf(o),ids=sh.map(x=>x.id),y=o.anio,oldCod=o.cod;
  const others=visible().filter(x=>x.emp===ne&&ids.indexOf(x.id)<0);
  const cons=others.some(x=>+x.anio===+y&&x.cons===o.cons)?nextCons(ne,y):o.cons;
  const po=EMB_PRE[old]||old,pn=EMB_PRE[ne]||ne,eo=String(o.emb||'');
  let cod=codOf(ne,y,cons),emb=eo.indexOf(po)===0?pn+eo.slice(po.length):eo.indexOf(old)===0?pn+eo.slice(old.length):pn+eo;
  /* si ese embarque ya existe en la otra empresa se toma el siguiente número de empaque de la semana */
  if(others.some(x=>x.emb===emb))emb=embOf(ne,y,o.semana,nextPed(ne,y,o.semana));
  const mOld=MARCAS[old]||[],mNew=MARCAS[ne]||[],dOld=docDef(mainOf(o));
  sh.forEach(x=>{
    x.emp=ne;x.cod=cod;x.emb=emb;x.cons=cons;
    const pre=v=>{const s=String(v||'');return new RegExp('^'+old+'-?\\d').test(s)?ne+s.slice(old.length):s};
    if(x.traz&&Array.isArray(x.traz.tarimas))x.traz.tarimas.forEach(t=>{const i=mOld.indexOf(t.marca);if(i>=0&&mNew[i])t.marca=mNew[i];(t.lines||[]).forEach(l=>{if(l.prod)l.prod=pre(l.prod)})});
    /* proveedor del embarque y sobrantes que seguían a la empresa anterior */
    if(x.traz&&x.traz.hdr&&norm(x.traz.hdr.proveedor).trim()===norm(EMPS[old].prov).trim())x.traz.hdr.proveedor=EMPS[ne].prov;
    (x.productores||[]).forEach(p=>{if(isSob(p))p.nombre=pre(p.nombre)});
    if(x.docs)['h1','h2','h3','prov'].forEach(k=>{if(x.docs[k]!=null&&x.docs[k]===dOld[k])delete x.docs[k]});
    touch(x);
  });
  logAdd({k:'note',ctx:ctxOf(o),lab:'Empresa del pedido',o:EMPS[old].name+' ('+oldCod+')',n:EMPS[ne].name+' ('+cod+')'});
  setEmp(ne);invalidateStats();render();toast('Ahora sale por '+EMPS[ne].name+': '+cod);
}
function empSwitch(){return `<div class="seg segtop" role="group" aria-label="Empresa">${['VL','EC'].map(k=>`<button data-act="emp:${k}" aria-pressed="${emp===k}"><img class="segico" src="${ICO[k]}" alt="">${k} · ${EMPS[k].name}</button>`).join('')}</div>`}
const LIST_MAX=10;
function listView(){
  const vis=visible();
  const mains=vis.filter(o=>o.variante!=='1.5').sort((a,b)=>b.createdAt-a.createdAt);
  const orphans=vis.filter(o=>o.variante==='1.5'&&!mains.some(m=>m.emp===o.emp&&m.cod===o.cod));
  let body;
  if(!vis.length){
    body=`<section class="empty"><h2>Aún no hay pedidos</h2><p>Cada pedido junta fruta de varios productores. Aquí capturas el conteo por calibre y ves cuánto falta o sobra contra el manifiesto.</p><button class="btn primary" data-act="new" data-edit>Nuevo pedido</button>${cfgOK()?'':'<button class="btn" data-act="example" data-edit>Cargar pedido de ejemplo</button>'}</section>`;
  }else{
    /* se ven los 10 pedidos más recientes; «Ver más» muestra los anteriores */
    /* clasificado por semana: se ve una semana a la vez y el histórico queda en el desplegable */
    const ks=[...new Set(mains.concat(orphans).map(wkOf).filter(Boolean))].sort().reverse(),sw=listWk==='ALL'?'ALL':(ks.indexOf(listWk)>=0?listWk:ks[0]);
    const all=mains.concat(orphans).filter(o=>sw==='ALL'||wkOf(o)===sw).sort((a,b)=>sw==='ALL'?(wkOf(b).localeCompare(wkOf(a))||b.createdAt-a.createdAt):b.createdAt-a.createdAt),lim=sw==='ALL'&&!listAll?LIST_MAX:1e9,shown=all.slice(0,lim),rest=sw==='ALL'?all.length-LIST_MAX:0;
    const cnt=k=>new Set(vis.filter(o=>wkOf(o)===k).map(o=>o.emp+'|'+o.cod)).size;
    const wsel=`<div class="wkbar"><label class="fld wksel" for="lwk"><span>Semana</span><select class="in sel" id="lwk" data-lwk="1">${ks.map(k=>`<option value="${k}"${k===sw?' selected':''}>${esc(wkLab(k))} · ${esc(wkSpan(k))} · ${cnt(k)} ${cnt(k)===1?'pedido':'pedidos'}${wkClosed(k)?' · cerrada':''}</option>`).join('')}<option value="ALL"${sw==='ALL'?' selected':''}>Todas las semanas (histórico)</option></select></label>${sw!=='ALL'?`<span class="chip ${wkClosed(sw)?'crit':'good'}">${wkClosed(sw)?LOCK_SVG+' Cerrada':'Abierta'}</span>`:''}${perAdmin()?'<button class="btn sm" data-act="peropen">Periodos</button>':''}</div>`;
    let lastW='';
    const xw=sw!=='ALL'?`<button class="btn" data-act="wktrips">Descargar Excel de viajes de la semana</button>`:'';
    body=`<div class="pact" style="margin-top:14px"><button class="btn primary" data-act="new" data-edit>Nuevo pedido</button>${xw}</div>${wsel}<div class="sec">${sw==='ALL'?'Todas las semanas':esc(wkLab(sw))}${rest>0?` · ${listAll?all.length:LIST_MAX} de ${all.length}`:` · ${all.length} ${all.length===1?'hoja principal':'hojas principales'}`}</div><div class="ogrid">`+shown.map(o=>{
      const kids=vis.filter(x=>x.variante==='1.5'&&x.emp===o.emp&&x.cod===o.cod&&x.id!==o.id),w=wkOf(o),hd=sw==='ALL'&&w!==lastW?`<div class="wkhd">${esc(wkLab(w))}${wkClosed(w)?' · cerrada':''}</div>`:'';lastW=w;
      const vj=viajeOf(o);
      return hd+'<div class="ogrp">'+(vj?`<span class="vjn" title="Viaje ${vj} de la semana"><small>Viaje</small><b>${vj}</b></span>`:'')+ordCard(o,o.variante==='1.5')+kids.map(k=>ordCard(k,true)).join('')+'</div>';
    }).join('')+'</div>'+(rest>0?`<div class="more"><button class="btn" data-act="listmore" aria-expanded="${listAll}">${listAll?'Ver menos':'Ver más · '+rest+(rest===1?' pedido anterior':' pedidos anteriores')}</button></div>`:'');
  }
  return topbar('Registro de Empaque','menu')+`<main class="wrap">${body}</main>`;
}

/* número de viaje de la semana: el que lleva el código de embarque (VL264201 → 1); si no se puede leer, el orden en que se creó en su semana */
function viajeOf(o){
  const m=String(o.emb||'').match(/(\d{2})$/),yw=String(o.anio||'').slice(2)+pad(o.semana||0,2);
  if(m&&String(o.emb).slice(-6,-2)===yw)return +m[1];
  const w=wkOf(o),L=visible().filter(x=>x.emp===o.emp&&wkOf(x)===w&&(x.variante!=='1.5'||!hasMain(x))).sort((a,b)=>(a.createdAt||0)-(b.createdAt||0));
  const i=L.findIndex(x=>x.cod===o.cod);return i>=0?i+1:null;
}
function labelCard(o){
  const sibs=sheetsOf(o);
  const has15=sibs.some(x=>x.variante==='1.5');
  const sib=(sibs.length>1||!ro)?`<div class="sib">${sibs.map(s=>`<button class="btn sm" data-act="open:${s.id}" aria-pressed="${s.id===o.id}">Hoja ${esc(s.variante)}</button>`).join('')}${!ro&&!has15?'<button class="btn sm" data-act="v15" data-edit>+ Hoja 1.5</button>':''}${!ro&&!hasMain(o)?'<button class="btn sm" data-act="v1" data-edit>+ Hoja 1</button>':''}</div>`:'';
  const gear=`<button class="icon kgset" data-act="kgemp" aria-label="Pesos y equivalencias" title="Pesos y equivalencias"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></g></svg></button>`;
  /* v8.21: fruta ya empacada que pasa a otra presentación */
  const rmpB=!ro&&sibs.some(s=>compute(s).tot.exp>0)?`<button class="btn sm rmpb" data-act="rmp" title="Reempacar fruta ya empacada en otra presentación">+ Reempaque</button>`:'';
  return `<section class="label hasgear${rmpB?' hasrmp':''}">${gear}${rmpB}${empToggle(o.emp,'oemp')}<div class="lrow"><div><div class="k">Pedido ${esc(o.emp)}${o.variante==='1.5'?(hasMain(o)?' · hoja #1.5':' · solo hoja #1.5'):''}</div><div class="big" data-out="h.cod">${esc(o.cod)}</div></div><div><div class="k">Código de embarque</div><div class="mono jc" data-out="h.emb">${esc(o.emb)}</div></div></div><hr><div class="meta mono"><span data-out="h.meta"></span>${estadoChip(o)}${o.ejemplo?'<span class="badge">Ejemplo</span>':''}</div>${o.fecha?'':`<div class="panel warn" style="margin-top:10px"><strong>Este pedido no tiene fecha</strong><p class="note">Captúrala en «Editar encabezado». Mientras tanto, el Excel del registro usa ${(()=>{const r=regFecha(o);return r.src==='salida'?'la fecha de salida de Código de Trazabilidad':r.src==='pedido'?'la fecha de la otra hoja del pedido':'el día en que se creó el pedido'})()} (${esc(fmtDate(regFecha(o).f))}).</p></div>`}${sib}<div class="xnav"><button class="btn sm" data-act="totraz:${mainOf(o).id}">Ir a Trazabilidad ›</button></div><button class="link" data-act="hdr" aria-expanded="${showHdr}">${showHdr?'Cerrar encabezado':'Editar encabezado'}</button>${showHdr?hdrForm(o):''}</section>`;
}
/* el productor se lleva sus segundas: esas cajas no quedan disponibles para la hoja 1.5 */
function segLlevoTxt(p){const q=Math.max(0,n0(p.seg)-Math.min(n0(p.seg),n0(p.segLlevo)));return q?fmt(q)+(q===1?' queda disponible':' quedan disponibles')+' para la hoja 1.5.':'No queda ninguna para la hoja 1.5.'}
function segLlevoHtml(p,b){
  if(+p.codigo===SEG_COD||p.segLot)return '';
  if(p.segLlevo==null)return ro?'':`<div class="segll"><button class="btn sm" data-act="segll:${p.id}" data-edit>Se llevó sus segundas</button><small>Si no, quedan disponibles para la hoja 1.5 a nombre de este productor.</small></div>`;
  return `<div class="segll on">${fld('Se llevó (cajas de segunda)',b('segLlevo'),p.segLlevo,{num:1})}<small data-out="psll.${p.id}">${esc(segLlevoTxt(p))}</small>${ro?'':`<button class="btn sm" data-act="segllx:${p.id}" data-edit>Quitar</button>`}</div>`;
}
function fld(label,bind,val,o2){
  o2=o2||{};const id='f-'+bind.replace(/\./g,'-');
  const type=o2.date?'date':'text';
  const mode=o2.date?'':(o2.dec?' inputmode="decimal"':(o2.num?' inputmode="numeric"':''));
  return `<label class="fld" for="${id}"><span>${esc(label)}</span><input class="in${o2.txt?' txt':''}" id="${id}" type="${type}"${mode} enterkeyhint="next" autocomplete="off" data-bind="${bind}"${o2.list?` list="${o2.list}"`:''}${o2.num||o2.dec?' data-num="1"':''}${o2.ph!=null?` placeholder="${esc(o2.ph)}" data-ph="${esc(o2.phkey||'')}"`:''} value="${val==null?'':esc(val)}"></label>`;
}
function hdrForm(o){
  return `<hr><div class="grid2">${fld('Pedido (consecutivo)','o.cod',o.cod,{txt:1})}${fld('Código de embarque','o.emb',o.emb,{txt:1})}${fld('PO','o.po',o.po,{txt:1})}${fld('Fecha','o.fecha',o.fecha,{date:1})}${fld('Semana','o.semana',o.semana,{num:1})}${fld('Factura','o.factura',o.factura,{txt:1})}</div>${fld('Cliente','o.customer',o.customer,{txt:1,list:'dl-cl'})}<datalist id="dl-cl">${catList('cliente').map(v=>`<option value="${esc(v)}"></option>`).join('')}</datalist>${fld('Cliente doméstico','o.domestic',o.domestic,{txt:1})}`;
}
/* datos del pedido para Inteligencia de negocio; van en la hoja principal aunque se capturen desde la 1.5 */
function biForm(o){
  const b=mainOf(o).bi||{},F=(k,l,o2)=>fld(l,'ob.'+k,b[k],o2||{txt:1});
  const inc=`<label class="fld" for="f-ob-incoterm"><span>INCOTERM</span><select class="in sel" id="f-ob-incoterm" data-bind="ob.incoterm"${ro?' disabled':''}><option value="">—</option>${INCOTERMS.map(x=>`<option${b.incoterm===x?' selected':''}>${x}</option>`).join('')}</select></label>`;
  return `<div class="sec">Comercial</div><div class="grid2">${F('destino','País y puerto de destino')}${inc}${F('diasPago','Días de pago',{num:1})}${F('rech','Cajas rechazadas o en reclamo',{num:1})}</div>${F('reclamo','Motivo del reclamo')}
<div class="sec">Logística</div><div class="grid2">${F('naviera','Naviera o transportista',{txt:1,list:'dl-nav'})}${F('contenedor','Contenedor o termo (# caja)',{txt:1,list:'dl-cont'})}${F('eta','ETA (llegada estimada)',{date:1})}${F('llegada','Llegada real',{date:1})}${F('demora','Demoras / demurrage (USD)',{dec:1})}</div>
<div class="sec">Operación de la línea</div><div class="grid3">${F('personas','Personas en el turno',{num:1})}${F('horas','Horas del turno',{dec:1})}${F('paro','Minutos de paro',{num:1})}</div><p class="note">Con estos datos Estadísticas › Inteligencia calcula OEE, cajas por hora y por persona, costo logístico por caja y rechazos por cliente.</p><datalist id="dl-nav">${REG.transportistas.map(x=>`<option value="${esc(x.n)}"></option>`).join('')}</datalist><datalist id="dl-cont">${REG.cajas.map(x=>`<option value="${esc(x.n)}"></option>`).join('')}</datalist>`;
}
function tabsHtml(){
  return `<div class="tabs" role="tablist">${[['captura','Captura'],['resumen','Resumen'],['excel','Excel']].map(t=>`<button class="tab" role="tab" data-act="tab:${t[0]}" aria-selected="${tab===t[0]}">${t[1]}</button>`).join('')}</div>`;
}
function orderView(o){
  const M=compute(o);
  const body=tab==='captura'?capturaTab(o,M):tab==='resumen'?summaryTab(o,M):excelTab(o,M);
  return topbar(o.cod+(o.variante==='1.5'?' · #1.5':''),'orders')+`<main class="wrap">${lockBan(o)}${labelCard(o)}${tabsHtml()}${body}</main>`+(tab==='captura'?dock(o):'');
}
function dock(o){
  if(ro)return '';
  const lo=prevLeftover(o);
  const done=canComplete(o);
  return `<div class="dock"><div class="dockin"><button class="btn" data-act="addp" data-edit>+ Agregar productor</button>${o.variante==='1.5'?(()=>{const A=seg2Avail();return A.cajas?`<button class="btn" data-act="seg2" data-edit>+ Segundas (${fmt(A.cajas)})</button>`:''})():''}${lo?`<button class="btn" data-act="addleft" data-edit>+ Sobrante ${esc(lo.from.cod)}</button>`:''}${o.variante==='1'&&sobPend(o).length?`<button class="btn" data-act="sobim" data-edit>+ Sobrantes (${fmt(sobPend(o).reduce((a,x)=>a+x.n,0))})</button>`:''}${done?'<button class="btn primary" data-act="complete" data-edit>Completar registro</button>':''}</div></div>`;
}
function completeBanner(o){
  if(o.estado==='completo'){
    return `<div class="panel okp"><strong>Registro completo</strong><p class="note" style="margin-top:4px">Este empaque quedó marcado como completo. El Excel del registro se puede descargar cuando quieras.</p><div class="pact"><button class="btn primary sm" data-act="totraz:${mainOf(o).id}">Ir a Código de Trazabilidad</button><button class="btn sm" data-act="reopen" data-edit>Reabrir registro</button></div></div>`;
  }
  return '';
}
function capturaTab(o,M){
  const lo=prevLeftover(o),sp=o.variante==='1'&&!ro?sobPend(o):[];
  let ban=completeBanner(o)+(sp.length?`<div class="panel info"><strong>Sobrantes del viaje anterior: ${fmt(sp.reduce((a,x)=>a+x.n,0))} cajas en ${sp.length} ${sp.length===1?'tarima':'tarimas'}</strong><p class="note" style="margin-top:4px">Ya están en Código de Trazabilidad. Impórtalas para que entren en el renglón SOBRANTES con su productor.</p><div class="pact"><button class="btn primary sm" data-act="sobim" data-edit>Ver e importar</button></div></div>`:'')+(lo?`<div class="panel info"><strong>Sobrante disponible de ${esc(lo.from.cod)}</strong><p class="note" style="margin-top:4px">${esc(lo.text)} · ${fmt(lo.total)} cajas. Puedes sumarlo a este pedido con el botón «+ Sobrante ${esc(lo.from.cod)}».</p></div>`:'');
  if(o.variante==='1.5'&&!ro){const A=seg2Avail();if(A.cajas)ban+=`<div class="panel info"><strong>Segundas disponibles: ${fmt(A.cajas)} cajas de ${A.prods} ${A.prods===1?'productor':'productores'}</strong><p class="note" style="margin-top:4px">Vienen de empaques anteriores y de Entrada de Fruta, separadas por productor y por entrega.</p><div class="pact"><button class="btn primary sm" data-act="seg2" data-edit>Ver y elegir segundas</button></div></div>`}
  if(!M.rows.length)return ban+`<div class="empty"><h2>Sin productores</h2><p>Agrega el primero en el orden en que pasa por la línea. El conteo de cada uno se resta del anterior.</p></div>`;
  return ban+'<div class="pgrid">'+M.rows.map((r,i)=>prodCard(o,r,i,M.rows.length)).join('')+'</div>';
}
function prodCard(o,r,i,n){
  const p=r.p,open=openP===p.id;
  const note=p.nota?`<span class="pnote">${esc(p.nota)}</span>`:'';
  const head=`<button class="prow" data-act="p:${p.id}" aria-expanded="${open}"><span class="idx">${i+1}</span><span class="pn"><span data-out="pn.${p.id}">${esc(p.nombre||'Sin nombre')}</span><small>${p.rmp?'Reempaque de otros viajes (sin pago)':p.sob2?'Sobrantes en tarima del viaje anterior':p.sob?'Sobrante del pedido anterior':codeLabel(p.codigo,o.emp)}</small>${note}</span><span class="pt" data-out="pt.${p.id}"></span><span class="chip" data-base="chip" data-out="pd.${p.id}"></span></button>`;
  if(!open)return `<article class="pc" id="pc-${p.id}">${head}</article>`;
  const b=k=>`p.${p.id}.${k}`;
  const ts=r.tipos,pg=Math.min(pageOf[p.id]||0,ts.length-1);
  const calRow=(t,c)=>{const id=`f-p-${p.id}-acc-${t}-${c.k}`,a=accOf(p,t),bt=r.byT[t];return `<div class="calrow"><span class="cl">${c.l}</span><span class="bef" data-out="b.${p.id}.${t}.${c.k}"></span><span class="accw"><input class="in" id="${id}" inputmode="numeric" enterkeyhint="next" autocomplete="off" data-bind="${b('acc.'+t+'.'+c.k)}" data-num="1" data-sum="1" data-phk="${p.id}.${t}.${c.k}" placeholder="${bt.before[c.k]}" value="${a[c.k]!=null?esc(a[c.k]):''}" aria-label="Acumulado ${c.l} ${esc(TIPO_L[t])}. Puedes escribir sumas y restas, por ejemplo +50+50-10">${ro?'':`<button type="button" class="plus" data-act="plus:${id}" tabindex="-1" aria-label="Escribir un signo más">+</button><button type="button" class="plus minus" data-act="minus:${id}" tabindex="-1" aria-label="Escribir un signo menos">−</button>`}</span><span class="dlt" data-base="dlt" data-out="d.${p.id}.${t}.${c.k}"></span></div>`};
  const sels=ts.map((t,i)=>`<select class="in sel tsel${i===pg?' on':''}" id="f-p-${p.id}-tipo-${i}" data-tipo="${p.id}:${i}" aria-label="Tipo de empaque ${i+1}"${ro?' disabled':''}>${TIPOS.filter(x=>x[0]===t||ts.indexOf(x[0])<0).map(x=>`<option value="${x[0]}"${x[0]===t?' selected':''}>${esc(x[1])}</option>`).join('')}${i>0&&!ro?'<option value="">Quitar</option>':''}</select>`).join('')
    +(!ro&&ts.length<TIPOS.length?`<button type="button" class="tadd" data-act="tadd:${p.id}" aria-label="Agregar otro tipo de empaque">+</button>`:'');
  const pages=ts.map((t,i)=>`<div class="cpage" data-pg="${i}" role="group" aria-label="Conteo ${esc(TIPO_L[t])}"><div class="calhead"><span>Calibre</span><span>Antes</span><span>Acumulado</span><span>Este</span></div><div class="calbox">${calsFor(t,o,i===0).map(c=>calRow(t,c)).join('')}</div>${t==='CTN10'?'<p class="note" style="margin-top:4px">CTN 10 lb se clasifica por su propia medida (63 a 28).</p>':''}${ts.length>1?`<div class="ptt"><span class="k">Subtotal ${esc(TIPO_L[t])}</span><b data-out="ptt.${p.id}.${t}"></b></div>`:''}</div>`).join('');
  const dots=ts.length>1?`<div class="cdots" aria-hidden="true">${ts.map((t,i)=>`<i data-dot="${i}"${i===pg?' class="on"':''}></i>`).join('')}</div>`:'';
  const cal=`<div class="cscroll" data-cs="${p.id}" data-pg0="${pg}">${pages}</div>${dots}`;
  return `<article class="pc open" id="pc-${p.id}">${head}<div class="pf pf2"><div class="pfa">
<div class="sec">Recepción</div>
<div class="grid2">${fld('Nombre en la hoja',b('nombre'),p.nombre,{txt:1})}${fld('Código del productor (número)',b('codigo'),p.codigo,{num:1})}</div>
<div class="grid3">${fld('Cajas grandes',b('k24'),p.k24,{num:1})}${fld('Cajas pequeñas',b('k18'),p.k18,{num:1})}${p.pesE&&p.invEnt&&p.invEnt.length?`<div class="fld"><span>Kilos del lote</span><output class="in pkgo" data-out="pkg.${p.id}">${p.kilos==null?'—':esc(fmt(n0(p.kilos),n0(p.kilos)%1?1:0))}</output><small class="note">Suma de pesadas</small></div>`:fld('Kilos del lote',b('kilos'),p.kilos,{dec:1})}</div>${pentHtml(o,p)}
<p class="note" style="margin-top:6px" data-out="pc.${p.id}"></p><p class="note kgw" data-base="note kgw" data-out="pkw.${p.id}"></p>${p.sob||p.sob2||p.segLot||+p.codigo===SEG_COD?'':`<div class="ptzw"><div class="sec">Tarimas (Código de Trazabilidad)</div><p class="note ptz" data-base="note ptz" data-out="ptz.${p.id}"></p></div>`}${canStats()&&(p.precioKg||p.modal)?`<p class="note acleg">Acuerdo capturado en esta hoja con una versión anterior: ${p.modal==='consig'?'consignación':money(+p.precioKg,2)+' MXN por kg'}. Sigue aplicando aquí; los acuerdos nuevos se definen en Editar productor.</p>`:''}${p.rmp?rmpRowHtml(o,p):p.sob2?sob2Html(o,p):p.c23?c23Html(o,p):p.segLot?`<div class="invnote"><span>${esc(seg2Note(p))}</span></div>`:invCardHtml(p)}${rmpSrcHtml(o,p)}</div><div class="pfb">
${p.rmp?'<div class="sec">Cajas reempacadas (aparte del contador de la línea)</div><p class="note" style="margin-bottom:6px">Se llenan solas desde la ventana Reempaque. No cambian el acumulado de los demás productores: ellos siguen con la lectura del contador.</p><p class="note" style="margin-bottom:6px">Puedes escribir':'<div class="sec">Conteo al final de la línea (acumulado)</div><p class="note" style="margin-bottom:6px">Puedes escribir'} sumas y restas, por ejemplo <b>+50+50-10</b>. Al salir de la casilla se guarda el total, y al tocarla otra vez ves la operación.</p>
<div class="fld" style="margin-bottom:8px"><span>Tipo de empaque</span><div class="tsels">${sels}</div></div>
${cal}
<div class="totline"><span class="k">Total exportación</span><b data-out="ptot.${p.id}"></b></div></div><div class="pfc">
<div class="sec">Otras cajas</div>
<div class="grid5">${fld('Segundas',b('seg'),p.seg,{num:1})}${fld('Cera',b('cera'),p.cera,{num:1})}${fld('Torreón',b('tor'),p.tor,{num:1})}${fld('Desecho',b('des'),p.des,{num:1})}${fld('Juguera',b('jug'),p.jug,{num:1})}</div>
${segLlevoHtml(p,b)}
<label class="fld" for="f-p-${p.id}-nota" style="margin-top:10px"><span>Notas u observaciones</span><textarea class="in txt ta" id="f-p-${p.id}-nota" rows="2" autocomplete="off" data-bind="${b('nota')}" placeholder="Ej. se llevó sus 2 días, fruta golpeada…">${esc(p.nota||'')}</textarea></label></div>
<div class="pact pfd"><button class="btn primary sm" data-act="share:${p.id}">Resumen para enviar</button><button class="btn sm" data-act="up:${p.id}" ${i===0?'disabled':''} aria-label="Subir productor">↑ Subir</button><button class="btn sm" data-act="down:${p.id}" ${i===n-1?'disabled':''} aria-label="Bajar productor">↓ Bajar</button><button class="btn sm danger" data-act="delp:${p.id}" data-edit>${confirmKey==='delp:'+p.id?'Toca otra vez':'Eliminar'}</button></div>
</div></article>`;
}
/* tipo de empaque cuyo manifiesto se ve en Resumen (por hoja) */
let manSel={};
function manTipoSel(o,M){const t=manSel[o.id];return TIPO_K.indexOf(t)>=0?t:M.lines[0]}
/* todos los manifiestos del pedido (hoja 1 y hoja 1.5): una fila por calidad y tipo de empaque */
function manOverview(o){
  const rs=[],selT=manTipoSel(o,compute(o));let tm=0,tf=0,anyM=false;
  sheetsOf(o).forEach(s=>{const M=compute(s);M.lines.forEach(t=>{
    const m=M.manBy[t],b=M.byTipo[t]||{},f=b.t||0;if(!m&&!f)return;
    const mv=m?m.t:null;if(m){tm+=mv;anyM=true}tf+=f;const ch=manChip(f-(mv||0),mv);
    rs.push(`<button class="mlrow" data-act="${s.id===o.id?'mtipo:'+t:'openr:'+s.id+':'+t}" aria-current="${s.id===o.id&&t===selT}"><span class="lpill q${s.variante==='1.5'?'2':'1'}">${esc(CALIDAD_S[s.variante]||s.variante)}</span><span class="mln">${esc(TIPO_CH[t])}</span><span class="mono">${mv==null?'–':fmt(mv)}</span><span class="mono">${fmt(f)}</span><span class="chip ${ch.cls||''}">${esc(ch.text)}</span></button>`);
  })});
  if(!rs.length)return '<p class="note">Todavía no hay manifiesto ni cajas empacadas.</p>';
  const ch=anyM?manChip(tf-tm,0):{text:'Sin manifiesto',cls:''};
  return `<div class="mlhead"><span title="Calidad">Cal.</span><span>Tipo</span><span>Manif.</span><span>Empac.</span><span>Resultado</span></div>${rs.join('')}<div class="totline"><span class="k">${rs.length} de 8 manifiestos posibles</span><b>${fmt(tm)} / ${fmt(tf)}</b></div><div style="margin-top:6px;text-align:right"><span class="chip ${ch.cls||''}">${esc(ch.text)}</span></div>`;
}
function summaryTab(o,M){
  const sel=manTipoSel(o,M),mb=M.manBy[sel]||{};
  const cals=sel==='CTN10'?calsFor('CTN10',o):CAL_STD.filter(c=>c.k!=='ctn'||(sel==='CTN'&&legacyCtn(o)));
  const rows=cals.map(c=>`<div class="srow"><span class="cl">${c.l}</span><input class="in" id="f-m-${sel}-${c.k}" inputmode="numeric" enterkeyhint="next" autocomplete="off" data-bind="m.${sel}.${c.k}" data-num="1" value="${mb[c.k]==null?'':mb[c.k]}" aria-label="Manifiesto ${esc(TIPO_L[sel])} ${c.l}"><span class="mono" data-out="mf.${sel}.${c.k}"></span><span class="chip" data-base="chip" data-out="md.${sel}.${c.k}"></span></div>`).join('');
  const sibs=sheetsOf(o),s1=sibs.find(x=>x.variante==='1'),s15=sibs.find(x=>x.variante==='1.5');
  const qb=(x,q,l)=>x?`<button class="btn sm" data-act="openr:${x.id}" aria-pressed="${x.id===o.id}">${l}</button>`:(ro?'':`<button class="btn sm" data-act="${q==='1.5'?'v15':'v1'}" data-edit>+ ${l}</button>`);
  const qsw=`<div class="qsw" role="group" aria-label="Calidad"><span class="k">Calidad</span>${qb(s1,'1','Primera')}${qb(s15,'1.5','1-1/2 (segunda)')}</div>`;
  const chips=`<div class="tchips" role="group" aria-label="Tipo de empaque">${TIPO_K.map(t=>`<button type="button" class="tchip" data-act="mtipo:${t}" aria-pressed="${t===sel}"><span>${esc(TIPO_CH[t])}</span><small data-out="mch.${t}"></small></button>`).join('')}</div>`;
  const lo=leftoverOf(o);
  const comp=isLeader(o)?(o.estado==='completo'?completeBanner(o):`<div class="panel"><strong>Completar registro</strong><p class="note" style="margin-top:4px">${canComplete(o)?'El manifiesto ya está capturado. Al completar, el pedido se marca como completo y su sobrante pasa al siguiente pedido. No hace falta completarlo para capturar tarimas en Código de Trazabilidad.':'Captura los productores y el manifiesto de cada tipo de empaque para poder completar el registro. Mientras tanto ya puedes capturar tarimas en Código de Trazabilidad.'}</p><div class="pact"><button class="btn primary" data-act="complete" data-edit ${canComplete(o)?'':'disabled'}>Completar registro</button></div></div>`):`<div class="panel"><p class="note">Esta hoja 1.5 acompaña a la hoja 1 de ${esc(o.cod)}. El registro se completa desde la hoja 1.</p></div>`;
  return '<div class="dsk dsum"><div class="dcol">'+comp+`<div class="sec">Tipo de empaque</div><div class="panel">${qsw}${chips}<p class="note" style="margin-top:8px">Cada tipo de empaque lleva su propio manifiesto en cada calidad: de uno (solo RPC) hasta ocho (primera y 1-1/2, cada una con RPC, CTN, CTN 10 lb y PLT). Toca un tipo para capturar su manifiesto.</p></div>
<div class="sec">Manifiesto contra empacado · ${esc(lineLabel(lineKey(o.variante,sel)))}</div><div class="panel sumbox"><div class="shead"><span>Calibre</span><span>Manifiesto</span><span style="text-align:right">Empacado</span><span style="text-align:center">Resultado</span></div>${rows}<div class="totline"><span class="k">Total ${esc(TIPO_L[sel])}</span><b><span data-out="mtm.${sel}"></span> / <span data-out="mtf.${sel}"></span></b></div><div style="margin-top:8px;text-align:right"><span class="chip" data-base="chip" data-out="mtd.${sel}"></span></div></div>
</div><div class="dcol"><div class="sec">Manifiestos del pedido</div><div class="panel" id="manov">${manOverview(o)}</div>${isLeader(o)?palShortHtml(o):''}
${lo.total?`<div class="panel info"><strong>Sobrante para el siguiente pedido</strong><p class="note" style="margin-top:4px">${esc(lo.text)} · ${fmt(lo.total)} cajas</p></div>`:''}
<div class="sec">Documentos del embarque</div><div class="panel"><p class="note">Manifiesto, manifiesto interno, packing list, código de trazabilidad, registro y etiquetas con QR de este viaje, juntos en Documentos de viaje.</p><div class="pact"><button class="btn primary" data-act="dvt:${mainOf(o).id}">Documentos de viaje</button></div></div>
<div class="sec">Totales del pedido</div><div class="panel"><div class="kv"><span>Cajas grandes recibidas</span><b data-out="st.k24"></b></div><div class="kv"><span>Cajas pequeñas recibidas</span><b data-out="st.k18"></b></div><div class="kv"><span>Kilos recibidos</span><b data-out="st.kilos"></b></div><div class="kv"><span>Total exportación</span><b data-out="st.exp"></b></div><div class="kv"><span>Segundas (nacional)</span><b data-out="st.seg"></b></div><div class="kv"><span>Segundas con cera</span><b data-out="st.cera"></b></div><div class="kv"><span>Torreón</span><b data-out="st.tor"></b></div><div class="kv"><span>Desecho</span><b data-out="st.des"></b></div><div class="kv" style="border-bottom:0"><span>Juguera</span><b data-out="st.jug"></b></div></div></div></div>`;
}
function blocks(o){
  const M=compute(o),rows=M.rows;
  const cl=s=>String(s==null?'':s).replace(/[\t\r\n]+/g,' ');
  const v=x=>x==null?'':x;
  const gap=fn=>rows.map(fn).join('\n\n');
  return [
    {key:'names',title:'Nombres de productores',hint:'Encabezado de la tabla de arriba, en una fila.',text:rows.map(r=>cl(r.p.nombre)).join('\t')},
    {key:'acc',title:'Acumulados por calibre',hint:'Tabla de arriba: '+calUI(o).map(c=>c.l).join(', ')+'. Un productor por columna.',text:calUI(o).map(c=>rows.map(r=>r.eff[c.k]).join('\t')).join('\n')},
    {key:'man',title:'Manifiesto',hint:'Columna de manifiesto, los mismos '+calUI(o).length+' calibres.',text:calUI(o).map(c=>v(M.man[c.k])).join('\n')},
    {key:'names2',title:'Nombres de la tabla de abajo',hint:'Columna PRODUCTOR, con una fila en blanco entre productores.',text:gap(r=>cl(r.p.nombre))},
    {key:'recv',title:'Código, cajas grandes y pequeñas, kilos',hint:'Cuatro columnas seguidas, una fila en blanco entre productores.',text:gap(r=>[r.p.codigo||0,v(num(r.p.k24)),v(num(r.p.k18)),v(num(r.p.kilos))].join('\t'))},
    {key:'other',title:'Segundas, Torreón y desecho',hint:'Tres columnas seguidas, una fila en blanco entre productores.',text:gap(r=>[v(num(r.p.seg)),v(num(r.p.tor)),v(num(r.p.des))].join('\t'))}
  ];
}
function excelTab(o,M){
  const bl=blocks(o);
  const sibs=sheetsOf(o);
  const has15=sibs.some(x=>x.variante==='1.5');
  const canX=typeof ExcelJS!=='undefined';
  const prods=M.rows.length>0;
  const blk=bl.map(b=>`<article class="blk"><div class="bh"><div><strong>${esc(b.title)}</strong><small>${esc(b.hint)}</small></div><button class="btn sm" data-act="copy:${b.key}" ${prods?'':'disabled'}>Copiar</button></div>${prods?`<pre class="pv">${esc(b.text.split('\n').slice(0,4).join('\n').replace(/\t/g,'  ·  '))}</pre>`:''}</article>`).join('');
  const chip=(k,l,v)=>`<button class="chipbtn" data-act="copyv:${k}"><small>${l}</small>${esc(v||'—')}</button>`;
  return `<div class="sec">Excel del registro</div><div class="panel"><p class="note">Se genera con el avance actual, aunque el empaque siga en proceso. Sale en Excel (con el logotipo, el acumulado por calibre, el manifiesto de cada tipo de empaque, los sobrantes y las fórmulas vivas), en PDF, en imagen JPG (igual al PDF) o en PowerPoint editable.${sibs.length>1?' Trae la hoja principal y la hoja 1.5.':''}</p><div class="pact"><button class="btn" data-act="dx:pv:reg" ${prods?'':'disabled'}>Vista previa</button><button class="btn primary" data-act="dx:outreg" ${prods?'':'disabled'}>Descargar o enviar</button>${canX?`<button class="btn" data-act="mailx" ${prods?'':'disabled'}>Excel por correo</button>`:''}${o.variante==='1'&&!has15?`<button class="btn" data-act="v15" data-edit>Crear hoja #1.5</button>`:''}</div><p class="note" style="margin-top:8px">«Enviar por correo» abre el menú de compartir del teléfono con el Excel adjunto; elige tu correo. Con la sincronización, el director también ve el avance en su propia cuenta.</p></div>
<details class="more"><summary>Pegar en tu propio Excel (opcional)</summary><p class="note" style="margin-top:8px">Cada bloque cubre solo columnas de captura. Selecciona la primera celda del bloque y pega.</p>${blk}<div class="chips">${chip('cod','Pedido',o.cod)}${chip('emb','Embarque',o.emb)}${chip('po','PO',o.po)}${chip('fecha','Fecha',fmtUS(o.fecha))}${chip('semana','Semana',o.semana)}${chip('factura','Factura',o.factura)}</div></details>
<div class="sec">Vista previa en vivo</div><div class="panel"><p class="note" style="margin-bottom:8px">Así sale el Excel del registro (y su PDF): se actualiza sola con lo que se captura. Acerca con + y − o pellizcando, y desliza para recorrer las hojas.</p>${xlvHtml('reg')}</div>
<div class="sec">Pedido</div><div class="pact"><button class="btn danger sm" data-act="delsheet:${o.id}" data-edit>Eliminar esta hoja (${esc(o.variante)})</button>${sibs.length>1?'<button class="btn danger sm" data-act="delorder" data-edit>Eliminar el pedido completo</button>':''}</div>`;
}

/* ---------- código de trazabilidad: pantallas ---------- */
/* v8.18: selector de semana en Código de Trazabilidad (igual que en Registro de Empaque): abre en la semana vigente y deja ver las anteriores */
const LS_TWK='empaque-traz-semana';
let trazWk=(()=>{try{return localStorage.getItem(LS_TWK)||''}catch(e){return ''}})();
function trazList(){
  const allL=mine().filter(o=>isLeader(o)),ks=[...new Set(visible().filter(isLeader).map(wkOf).filter(Boolean).concat([wkOfDate(todayISO())]))].sort().reverse();
  const sw=trazWk==='ALL'?'ALL':(ks.indexOf(trazWk)>=0?trazWk:ks[0]);
  const cnt=k=>allL.filter(o=>wkOf(o)===k).length;
  const wsel=`<div class="wkbar"><label class="fld wksel" for="twk"><span>Semana</span><select class="in sel" id="twk" data-twk="1">${ks.map(k=>`<option value="${k}"${k===sw?' selected':''}>${esc(wkLab(k))} · ${esc(wkSpan(k))} · ${cnt(k)} ${cnt(k)===1?'pedido':'pedidos'}${k===wkOfDate(todayISO())?' · vigente':''}${wkClosed(k)?' · cerrada':''}</option>`).join('')}<option value="ALL"${sw==='ALL'?' selected':''}>Todas las semanas (histórico)</option></select></label>${sw!=='ALL'?`<span class="chip ${wkClosed(sw)?'crit':'good'}">${wkClosed(sw)?LOCK_SVG+' Cerrada':'Abierta'}</span>`:''}</div>`;
  const done=allL.filter(o=>sw==='ALL'||wkOf(o)===sw).sort((a,b)=>sw==='ALL'?(wkOf(b).localeCompare(wkOf(a))||(b.completadoAt||b.createdAt)-(a.completadoAt||a.createdAt)):(b.completadoAt||b.createdAt)-(a.completadoAt||a.createdAt));
  let body;
  if(!done.length){
    body=`<section class="empty"><h2>Sin pedidos${sw!=='ALL'?' en '+esc(wkLab(sw)):''}</h2><p>Aquí aparecen los pedidos de ${esc(EMPS[emp].name)} en cuanto los creas en Registro de Empaque, aunque sigan en proceso. Con ellos armas las tarimas.${sw!=='ALL'&&allL.length?' Elige otra semana arriba para ver las anteriores.':''}</p><button class="btn" data-act="orders">Ir a Registro de Empaque</button></section>`;
  }else{
    let lastW='';
    body=`<div class="sec">Pedidos para tarimas · ${sw==='ALL'?'todas las semanas':esc(wkLab(sw))}</div><div class="ogrid">`+done.map(o=>{const w=wkOf(o),hd=sw==='ALL'&&w!==lastW?`<div class="wkhd">${esc(wkLab(w))}${wkClosed(w)?' · cerrada':''}</div>`:'';lastW=w;return hd+(()=>{
      const z=trazCalc(o);
      return `<button class="ocard" data-act="topal:${o.id}"><div class="orow"><span class="oec">${o.variante==='1.5'?'Hoja #1.5 · ':''}${esc(o.cod)}</span>${o.estado!=='completo'?'<span class="chip warn">Empaque en proceso</span>':(z.borrador?'<span class="chip warn">Borrador</span>':'<span class="chip good">Completo</span>')}</div><div class="note" style="margin-top:6px"><span class="mono">${esc(o.emb)}</span> · PO ${esc(o.po||'—')} · ${z.nPal} ${z.nPal===1?'tarima':'tarimas'} · ${fmt(z.cantTot)} cajas${z.nPal?(z.full?' · Full':' · Parcial'):''}</div></button>`;
    })()}).join('')+'</div>';
  }
  return topbar('Código de Trazabilidad','menu')+`<main class="wrap"><div class="twkw">${wsel}</div>${empSwitch()}${body}</main>`;
}
/* cajas que faltan por tarimar de un calibre en la calidad y presentación de la tarima */
function calAvail(z,p,k,q){const L=lineOfCal(p,k,null,q||qualityOfMarca(p.marca));return z.expL[L]?z.expL[L][k]-z.palL[L][k]:0}
function presAvail(z,p,t){return ['1','1.5'].reduce((s,q)=>{const L=lineKey(q,t);return s+(z.expL[L]?CAL.reduce((a,c)=>a+Math.max(0,z.expL[L][c.k]-z.palL[L][c.k]),0):0)},0)}
function calOpts(z,p,l){
  const list=(palTipo(p)==='CTN10'?PCAL_MM:PCAL.filter(x=>x!=='230 CTN'||String(l.cal)==='230 CTN'||legacyCtn(z.o))).slice();
  if(l.cal&&list.indexOf(String(l.cal))<0)list.push(String(l.cal));
  const q=lineQ(p,l);return '<option value="">Calibre</option>'+list.map(v=>{const k=PCAL_KEY[v],a=k?calAvail(z,p,k,q):0;return `<option value="${esc(v)}"${String(v)===String(l.cal)?' selected':''}>${a>0?'🟢':'⚪'} ${esc(v)}${a>0?' · '+fmt(a):''}</option>`}).join('');
}
function presOpts(z,p){const cur_=palTipo(p);return PRES.map(x=>{const a=presAvail(z,p,x[0]);return `<option value="${x[0]}"${x[0]===cur_?' selected':''}>${a>0?'🟢':'⚪'} ${esc(x[1])}${a>0?' · '+fmt(a):''}</option>`}).join('')}
function dispHtml(z,p){
  const t=palTipo(p),cs=t==='CTN10'?CAL_MM:CAL_STD.filter(c=>c.k!=='ctn'||legacyCtn(z.o)),list=[];
  ['1','1.5'].forEach(q=>cs.forEach(c=>{const a=calAvail(z,p,c.k,q);if(a>0)list.push({c:c,a:a,q:q})}));
  return `<span class="k">Por tarimar · ${esc(TIPO_L[t]||t)}</span>`+(list.length?list.map(x=>`<button type="button" class="dchip${x.q==='1.5'?' q15':''}" data-act="addlc:${p.id}:${x.q}:${esc(x.c.l)}"${ro?' disabled':''}><i></i>${CALIDAD_S[x.q]} ${esc(x.c.l)} <b>${fmt(x.a)}</b></button>`).join(''):'<span class="dnone">nada pendiente en esta presentación</span>');
}
function palOptions(sel,list,ph){return `<option value="">${ph}</option>`+list.map(v=>`<option value="${esc(v)}"${String(v)===String(sel)?' selected':''}>${esc(v)}</option>`).join('')}
function lineHtml(o,p,l,z){
  const id=p.id+'-'+l.id;
  const q=lineQ(p,l);
  /* v8.26.4: las cajas que vienen de otro viaje se corrigen aquí (calibre y cajas); el productor y la calidad se quedan como llegaron */
  if(l.de)return `<div class="pln sobl" id="ln-${id}"><span class="c0 sobq">1ª</span><select class="in sel c1" id="f-tl-${id}-cal" data-bind="tl.${p.id}.${l.id}.cal" aria-label="Calibre">${calOpts(z,p,l)}</select><input class="in c2" id="f-tl-${id}-cant" type="text" inputmode="numeric" pattern="[0-9]*" autocomplete="off" data-digits="1" data-num="1" data-bind="tl.${p.id}.${l.id}.cant" placeholder="Cajas" value="${l.cant==null?'':esc(l.cant)}" aria-label="Cantidad de cajas"><span class="c3 sobv"><span class="sobt" title="Sobrante de otro viaje">↪</span>${sobLab(l.prod,l.dn)}</span>${lgripHtml(p,l)}<button class="icon sm" data-act="dell:${p.id}:${l.id}" data-edit aria-label="Quitar línea">×</button><div class="pavl"><small class="note">Sobrante de ${esc(lineFrom(p,l).cod)}</small></div></div>`;
  return `<div class="pln" id="ln-${id}"><select class="in sel c0" id="f-tl-${id}-q" data-bind="tl.${p.id}.${l.id}.q" aria-label="Calidad de la línea"><option value="1"${q==='1'?' selected':''}>1ª</option><option value="1.5"${q==='1.5'?' selected':''}>1½</option></select><select class="in sel c1" id="f-tl-${id}-cal" data-bind="tl.${p.id}.${l.id}.cal" data-calsel="${p.id}:${l.id}" aria-label="Calibre (verde: hay cajas por tarimar)">${calOpts(z,p,l)}</select><input class="in c2" id="f-tl-${id}-cant" type="text" inputmode="numeric" pattern="[0-9]*" enterkeyhint="next" autocomplete="off" data-digits="1" data-num="1" data-bind="tl.${p.id}.${l.id}.cant" placeholder="Cajas" value="${l.cant==null?'':esc(l.cant)}" aria-label="Cantidad de cajas"><div class="c3 pcell"><input class="in txt" id="f-tl-${id}-prod" type="text" autocomplete="off" autocapitalize="characters" data-psearch="${p.id}:${l.id}" placeholder="Código o nombre" value="${esc(l.prod||'')}" aria-label="Productor: busca por código o nombre"><div class="pdd" hidden></div></div>${lgripHtml(p,l)}<button class="icon sm" data-act="dell:${p.id}:${l.id}" data-edit aria-label="Quitar línea">×</button><div class="pavl" data-out="av.${p.id}.${l.id}"></div></div>`;
}
function palHtml(o,p,i,z){
  const marcas=MARCAS[o.emp]||MARCAS.VL;
  const nT=z.t.tarimas.length;
  /* el jefe de empaque decide el orden en que suben al thermo: subir, bajar o mandar a un lugar */
  const ordH=ro||nT<2?'':`<div class="pord"><button class="btn sm" data-act="tmv:${p.id}:-1"${i===0?' disabled':''} aria-label="Subir tarima ${i+1}">↑</button><button class="btn sm" data-act="tmv:${p.id}:1"${i===nT-1?' disabled':''} aria-label="Bajar tarima ${i+1}">↓</button><select class="in sel" data-tpos="${p.id}" aria-label="Mover la tarima ${i+1} al lugar">${z.t.tarimas.map((x,j)=>`<option value="${j}"${j===i?' selected':''}>Lugar ${j+1}</option>`).join('')}</select></div>`;
  return `<article class="pal popen" id="pal-${p.id}" data-pid="${p.id}"><div class="palh"><span class="pn2">${palDot(z,p)}Pallet: ${i+1}</span>${ordH}<button class="btn sm pminb" data-act="palopen:${p.id}" aria-expanded="true" aria-label="Minimizar la tarima ${i+1}">${MIN_SVG} Minimizar</button></div>
${multiV(o)?(()=>{const pv=palV(o,p),can=ventaCan(o);return `<div class="pvsel"><label class="fld" for="f-pv-${p.id}"><span>Manifiesto (venta)</span><select class="in sel" id="f-pv-${p.id}" data-pvsel="${p.id}"${can?'':' disabled'}>${[''].concat(ventas(o).map(x=>x.id)).map(id=>`<option value="${id}"${id===pv?' selected':''}>${esc(ventaLab(o,id))}</option>`).join('')}</select></label></div>`})():''}<div class="palg"><label class="fld" for="f-t-${p.id}-empaque"><span>Presentación</span><select class="in sel" id="f-t-${p.id}-empaque" data-bind="t.${p.id}.empaque" data-pressel="${p.id}" aria-label="Presentación del pallet (verde: hay cajas por tarimar)">${presOpts(z,p)}</select></label></div>
<div class="pdisp" data-out="pdv.${p.id}">${dispHtml(z,p)}</div>
<div class="plh"><span>Calidad</span><span>Calibre</span><span>Cajas</span><span>Productor</span><span></span><span></span></div>${(p.lines||[]).map(l=>lineHtml(o,p,l,z)).join('')}
<div class="palf"><button class="btn sm" data-act="addl:${p.id}" data-edit>+ Añadir calibre</button><div class="tot"><span class="k">Cantidad Total</span><output class="qt" data-out="tt.${p.id}"></output><span class="chip" data-base="chip" data-out="tc.${p.id}"></span></div></div>
${p.from?`<p class="note sobfrom">↪ Sobrante de <b class="mono">${esc(p.from.cod)}</b> (era su tarima ${p.from.n}). Sigue llenándola con la fruta de este viaje.</p>`:''}<div class="pact" style="margin-top:8px">${palCarried(p)?'':`<button class="btn sm" data-act="dupt:${p.id}" data-edit>Duplicar tarima</button><button class="btn sm danger" data-act="delt:${p.id}" data-edit>${confirmKey==='delt:'+p.id?'Toca otra vez':'Eliminar tarima'}</button>`}${ro?'':p.from?`<button class="btn sm" data-act="palback:${p.id}" data-edit>↩ Regresar a su viaje (${esc(p.from.cod)})</button>${palFwdOk(p)?`<button class="btn sm nextb" data-act="palnext:${p.id}" data-edit>Enviar a otro viaje →</button>`:''}`:palNextOk(p)?`<button class="btn sm nextb" data-act="palnext:${p.id}" data-edit>Enviar a otro viaje →</button>`:''}</div></article>`;
}
/* v8.8: tarimas minimizadas: una tarjeta por tarima (cuadrícula en escritorio, lista en teléfono) con un asa para arrastrarla */
/* v8.8.1: todas las tarimas van minimizadas; solo una se expande a la vez (palOpen = id de la tarima abierta) */
let palOpen=null;
const EXP_SVG='<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const MIN_SVG='<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" style="vertical-align:-3px"><path d="M6 15l6-6 6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const GRIP_SVG='<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>';
/* v8.10: estado de la tarima: verde si cada línea tiene calibre, cajas y productor con cajas suficientes; rojo si falta algo o se pasa */
function palStat(z,p){
  const ls=(p.lines||[]).filter(l=>l.cal||n0(l.cant)>0||String(l.prod||'').trim());if(!ls.length)return {cls:'',t:'Sin líneas capturadas'};
  const bad=[],pend=[];ls.forEach(l=>{if(l.de)return;if(!l.cal)bad.push('falta calibre');else if(!(n0(l.cant)>0))bad.push('faltan cajas');else if(!String(l.prod||'').trim())bad.push('falta productor');else{const a=lineAvail(z,p.id,l.id);if(a&&a.cls==='bad')bad.push(a.text);else if(a&&a.cls==='pend')pend.push(a.text)}});
  return bad.length?{cls:'bad',t:bad[0]+(bad.length>1?' (y '+(bad.length-1)+' más)':'')}:pend.length?{cls:'pend',t:pend[0]+(pend.length>1?' (y '+(pend.length-1)+' más)':'')}:{cls:'ok',t:'Cuadra con Registro de Empaque'};
}
function palDot(z,p){const S=palStat(z,p);return `<i class="pdot ${S.cls}" data-out="pdot.${p.id}" title="${esc(S.t)}" role="img" aria-label="${esc(S.t)}"></i>`}
function palMiniHtml(o,p,i,z){
  const tot=palTot(p),ls=(p.lines||[]).filter(l=>l.cal&&n0(l.cant)>0),tp=palTipo(p);
  const g=new Map();ls.forEach(l=>{const k=calLab(l.cal)+(l.q==='1.5'?' (1.5)':'');g.set(k,(g.get(k)||0)+n0(l.cant))});
  const cals=[...g].map(([k,v])=>k+': '+fmt(v)).join(', ');
  return `<article class="pmini" id="pal-${p.id}" data-pid="${p.id}"><button class="pgrip" data-grip="${p.id}" aria-label="Arrastrar la tarima ${i+1} para cambiarla de lugar (o usa las flechas)"${ro?' disabled':''}>${GRIP_SVG}</button><button class="pmb" data-act="palopen:${p.id}" aria-expanded="false" aria-label="Expandir la tarima ${i+1}"><span class="pmt"><strong>Pallet ${i+1}</strong><span class="pchw">${z?palDot(z,p):''}<span class="chip${tot===palCap(tp)?' good':tot?' warn':''}">${fmt(tot)} cajas</span></span></span><small>${multiV(o)?'M'+ventaN(o,palV(o,p))+' · ':''}${p.from?'↪ de '+esc(p.from.cod)+' · ':''}${esc(TIPO_L[tp]||tp)}${cals?' · '+esc(cals):' · sin calibres'}</small></button><button class="pexp" data-act="palopen:${p.id}" aria-expanded="false" aria-label="Expandir la tarima ${i+1}" title="Expandir">${EXP_SVG}</button></article>`;
}
/* v8.10: buscador de productor: marca las tarimas que llevan fruta del productor buscado (código o nombre) */
let trazQ='';
function trazFind(z,q){
  const toks=norm(String(q||'').replace(/·/g,' ')).trim().split(/\s+/).filter(Boolean);if(!toks.length)return null;
  const nm={},cd={};Object.keys(z.empQ||{}).forEach(L=>Object.keys(z.empQ[L]).forEach(k=>{const e=z.empQ[L][k];nm[k]=e.nombre||nm[k]||'';if(/^\d+$/.test(String(e.codigo||'')))cd[k]=codeLabel(+e.codigo,z.o.emp)}));
  const hits=[],prods=new Map();
  z.t.tarimas.forEach((p,i)=>{let n=0;(p.lines||[]).forEach(l=>{if(!(n0(l.cant)>0)&&!l.prod)return;const k=resolveProd(z.sh,l.prod)||l.prod||'',name=l.dn||nm[k]||'',tx=norm(String(l.prod||'')+' '+k+' '+(cd[k]||'')+' '+name);
    if(toks.every(t=>tx.includes(t))){n+=n0(l.cant);const a=prods.get(k)||{k:k,nm:name,n:0};a.n+=n0(l.cant);prods.set(k,a)}});
    if(n>0)hits.push({p:p,i:i,n:n})});
  return {hits:hits,prods:[...prods.values()]};
}
function trazFindHtml(z){
  const R=trazFind(z,trazQ);if(!R)return '';
  if(!R.hits.length)return '<p class="note tfres">Ninguna tarima lleva fruta de ese productor.</p>';
  return `<div class="tfres"><p class="note">${R.prods.map(a=>sobLab(a.k,a.nm)+' · '+fmt(a.n)+' cajas').join('<br>')}</p><div class="tfpals">${R.hits.map(h=>`<button class="btn sm" data-act="palgo:${h.p.id}">Pallet ${h.i+1} · ${fmt(h.n)}</button>`).join('')}</div></div>`;
}
function trazFindApply(){
  const o=trazOrder();if(!o||view!=='trazo')return;const z=trazCalc(o),R=trazFind(z,trazQ),ids=R?new Set(R.hits.map(h=>h.p.id)):null;
  document.querySelectorAll('.palmini > [data-pid]').forEach(c=>{c.classList.toggle('tfhit',!!ids&&ids.has(c.dataset.pid));c.classList.toggle('tfdim',!!ids&&!ids.has(c.dataset.pid))});
  const box=document.getElementById('tfout');if(box)box.innerHTML=trazFindHtml(z);
}
function trazFindBox(z){
  if(!z.t.tarimas.length)return '';
  const opts=new Map();Object.keys(z.empQ||{}).forEach(L=>Object.keys(z.empQ[L]).forEach(k=>{const e=z.empQ[L][k];if(!opts.has(k))opts.set(k,(e.nombre&&e.nombre!==k?k+' · '+e.nombre:k))}));
  return `<div class="tfind"><label class="fld" for="f-tfind"><span>Buscar productor en las tarimas</span><span class="tfin"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M15.5 15.5L21 21" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg><input class="in txt" id="f-tfind" type="search" list="dl-tfind" autocomplete="off" autocapitalize="characters" placeholder="Código o nombre del productor" value="${esc(trazQ)}" data-tfind="1"></span></label><datalist id="dl-tfind">${[...opts.values()].map(v=>`<option value="${esc(v)}"></option>`).join('')}</datalist><div id="tfout">${trazFindHtml(z)}</div></div>`;
}
function palBarHtml(n){
  if(!n)return '';
  /* v8.21.1: botón a la vista para ordenar las tarimas como entraron los productores al empaque; nunca se ordenan solas */
  return `<p class="note palbar">${ro?'Toca una tarima para expandirla.':'Toca una tarima para expandirla y capturarla; solo una queda abierta a la vez. Arrastra el asa ☰ para cambiar el orden.'}</p>${ro?'':ordBarHtml()}`;
}
function ordBarHtml(){
  return '<div class="ordbar"><button class="btn sm primary" data-act="ordenpal" data-edit>Acomodar tarimas como el empaque</button><small>Mientras se llena el registro o al terminarlo: pone en tarimas las cajas de primera registradas que faltan, en el orden en que entraron los productores, y ordena las tarimas. Solo cuando lo tocas.</small></div>';
}
function trazView(o){
  TM=tipoMapFor(o);
  const m=mainOf(o);docLink(m);const z=trazCalc(m),t=z.t;
  const dls="";
  const cats=HDR_FIELDS.map(f=>`<datalist id="cat-${f[0]}">${catList(f[0],t.hdr.transporte).map(v=>`<option value="${esc(v)}"></option>`).join('')}</datalist>`).join('');
  const hdr=HDR_FIELDS.map(f=>`<label class="fld${['proveedor','vendedor','cliente','transporte','conductor'].indexOf(f[0])>=0?' wide':''}" for="f-z-${f[0]}"><span>${esc(f[1])}</span><input class="in txt" id="f-z-${f[0]}" type="text" list="cat-${f[0]}" autocomplete="off" data-bind="z.${f[0]}" data-learn="${f[0]}" value="${esc(t.hdr[f[0]]||'')}"></label>`).join('');
  const sentH=z.sent.length?(()=>{const g=new Map();z.sent.forEach(x=>{const k=x.p||((x.rmp?'rmp:':'piso:')+x.to.id);let a=g.get(k);if(!a)g.set(k,a={p:x.p,l:x.l,to:x.to,rmp:x.rmp,n:0});a.n+=x.n});return `<div class="panel info sobsent"><strong>Pasaron a otro viaje</strong>${[...g.values()].map(a=>`<div class="kv"><span>${a.p?'Tarima '+(lineFrom(a.p,a.l).n||'')+' · '+esc(TIPO_L[palTipo(a.p)]||'')+' · '+esc(palCals(a.p).map(calLab).join(', ')):a.rmp?'Reempacadas desde su tarima':'En piso, sin tarima'}</span><b class="mono">${fmt(a.n)} → ${esc(a.to.cod)}</b></div>`).join('')}<p class="note">Para corregir, abre ${esc([...new Set(z.sent.map(x=>x.to.cod))].join(', '))}: un reempaque se deshace en su renglón REEMPAQUE; «Regresar a su viaje» está en la tarima (Código de Trazabilidad) o, si se fue en piso, en el renglón SOBRANTES (Registro de empaque).</p></div>`})():'';
  const manH=z.manDiff.length?`<div class="panel"><strong>Contra el manifiesto</strong>${z.manDiff.map(x=>`<div class="kv"><span>${x.tp!=='RPC'?esc(TIPO_L[x.tp])+' ':''}${esc(calLab(x.ck))}: ${fmt(x.h)} en tarimas de ${fmt(x.man)}</span>${x.d>0?`<span class="chip warn">sobran ${fmt(x.d)}</span>`:`<span class="chip crit">faltan ${fmt(-x.d)}</span>`}</div>`).join('')}<p class="note">Si sobran tarimas, ábrelas y usa «Enviar a otro viaje».</p></div>`:'';
  /* v8.17: contra Registro de Empaque, por productor */
  const done=z.sh.every(x=>x.estado==='completo'),pks=[...new Set(z.lines.flatMap(L=>Object.keys(z.empQ[L]||{}).concat(Object.keys(z.palQ[L]||{}))))].sort((a,b)=>a.localeCompare(b,'es',{numeric:true}));
  const cq=pks.map(k=>{const C=prodConcord(z,k).filter(x=>x.d!==0);if(!C.length)return '';const nm=((z.empP[k]||{}).nombre)||k;return C.map(x=>`<div class="kv"><span>${esc(k)} · ${esc(nm)} · ${esc(lineLabel(x.L,true))} ${esc(calLab(x.ck))}: ${fmt(x.reg)} registradas, ${fmt(x.pal)} en tarimas</span>${x.d>0?`<span class="chip unas">faltan ${fmt(x.d)} en tarimas</span>`:`<span class="chip ${done?'crit':'info'}">${done?'sobran':'por registrar'} ${fmt(-x.d)}</span>`}</div>`).join('')}).join('');
  const concH=cq?`<div class="panel"><strong>Contra Registro de Empaque</strong>${cq}<p class="note">«Faltan en tarimas»: el productor ya registró más cajas que las que tiene en tarimas. «Por registrar»: la tarima ya está armada y faltan sus calibres en Registro de Empaque.</p></div>`:'';
  const pal=contPanel(m)+sentH+manH+concH+exisHtml(m)+(t.tarimas.length?trazFindBox(z)+palBarHtml(t.tarimas.length)+`<div class="palmini">${t.tarimas.map((p,i)=>p.id===palOpen?palHtml(m,p,i,z):palMiniHtml(m,p,i,z)).join('')}</div>`:`<div class="empty"><h2>Sin tarimas</h2><p>Toca «+ Agregar Tarima», elige la marca y captura calibre, cajas y productor en cada línea.</p></div>${ro?'':ordBarHtml()}`);
  return topbar(m.cod+' · Trazabilidad','traz')+`<main class="wrap">${lockBan(m)}${manBanHtml(m)}<section class="label"><div class="lrow"><div><div class="k">Pedido ${esc(m.emp)} · ${esc(m.emb)}</div><div class="big">${esc(m.cod)}</div></div><div style="text-align:right">${m.estado!=='completo'?'<span class="chip warn" style="margin-bottom:6px">Empaque en proceso</span><br>':''}<span class="chip" data-base="chip" data-out="zs"></span><div class="note" data-out="zn" style="margin-top:6px"></div></div></div><div data-out="zb">${borradorNota(z)}</div><div class="xnav"><button class="btn sm" data-act="open:${m.id}">Ir a Empaque ›</button>${sheetsOf(m).filter(x=>x.id!==m.id).map(x=>`<button class="btn sm" data-act="open:${x.id}">Hoja ${esc(x.variante)} ›</button>`).join('')}</div></section>
<div class="sec">Encabezado del embarque</div><button class="link" data-act="hdrz" aria-expanded="${trazHdr}">${trazHdr?'Ocultar encabezado':'Mostrar encabezado'}</button>${trazHdr?`<div class="panel"><div class="grid2 hdrgrid">${hdr}</div></div>`:''}
<div class="dsk dtraz"><div class="dcol"><div class="sec">Tarimas</div>${ro?'':`<div class="panel info"><p class="note">Arma las tarimas como en el empaque: presentación, y por renglón calidad, calibre, cajas y productor. Una tarima completa lleva ${palCap('RPC')} cajas en RPC, ${palCap('CTN')} en CTN, ${palCap('CTN10')} en CTN 10 lb y ${palCap('PLT')} en PLT. Conforme se registran los calibres en Registro de Empaque, cada renglón se marca: verde si cuadra, naranja si falta registrar.</p></div>`}${pal}</div><aside class="dcol dside">${palShortHtml(m)}
<div id="zval">${trazValidHtml(z)}</div>
<div class="sec">Código de trazabilidad</div><div class="panel"><p class="note">Genera el Código de Trazabilidad con el logotipo, el encabezado, las tarimas, el diagrama de la caja y el resumen por calidad y tipo de empaque. Si falta algo sale con la leyenda BORRADOR.</p>
<div class="orientw"><span class="k">Hoja</span><div class="seg" role="group" aria-label="Orientación de la hoja">${[['v','Vertical'],['h','Horizontal']].map(x=>`<button data-act="torient:${x[0]}" aria-pressed="${(t.orient==='h'?'h':'v')===x[0]}"${ro?' disabled':''}>${x[1]}</button>`).join('')}</div></div><p class="note">Las dos llevan las tarimas en dos tablas, con el tráiler a la derecha. ${t.orient==='h'?'Horizontal: la hoja sale apaisada.':'Vertical: el formato de siempre.'} En las dos, todo cabe en una hoja y el dibujo del tráiler sale completo.</p><div class="pact"><button class="btn" data-act="dx:pv:traz">Vista previa</button><button class="btn primary" data-act="dx:outtraz">Descargar o enviar</button><button class="btn" data-act="mailz">Excel por correo</button></div></div>
<div class="sec">Vista previa en vivo</div><div class="panel">${xlvHtml('traz')}</div>
<div class="sec">Documentos del embarque</div><div class="panel"><p class="note">Manifiesto, manifiesto interno, packing list, código de trazabilidad y etiquetas de este viaje, juntos en Documentos de viaje.</p><div class="pact"><button class="btn primary" data-act="dvt:${m.id}">Documentos de viaje</button></div></div></aside></div></main>${ro?'':`<div class="dock"><div class="dockin"><button class="btn primary" data-act="addt" data-edit>+ Agregar Tarima</button></div></div>`}${dls}${cats}`;
}
/* v8.5: aviso breve de por qué el código sigue en BORRADOR */
function borradorNota(z){
  if(!z.borrador)return '';
  const mot=z.motivos.slice();
  if(z.o.estado!=='completo')mot.unshift('el empaque sigue en proceso (aún se registran productores)');
  return `<div class="bnote" role="status"><b>Sigue en BORRADOR</b> porque: ${mot.map(esc).join('; ')}.</div>`;
}
function ordenHtml(z){
  if(!z.nPal)return '';
  const c=ordenCheck(z);
  if(c.ok)return `<div class="ordok" role="status">✓ Las tarimas siguen el orden de los productores del Registro de empaque.</div>`;
  /* v8.10: con «Permitir cambios» el aviso queda en una línea y «Ordenar como el empaque» sigue a la mano */
  /* v8.17: el jefe de empaque ordena las tarimas a su gusto; el orden del Registro solo se ofrece como opción */
  return `<div class="ordmin" role="status"><span>Orden de tarimas libre: lo decide el jefe de empaque.${ro?'':' Para acomodarlas y ordenarlas como el empaque usa el botón de arriba de las tarimas.'}</span></div>`;
  return `<div class="warnbox" role="alert"><strong>El orden de las tarimas no coincide con el Registro de empaque</strong>${c.issues.slice(0,5).map(x=>`<div>${esc(x)}</div>`).join('')}<p class="note" style="margin-top:6px">En la corrida, los primeros productores abren las primeras tarimas y los siguientes se apilan encima. Ordenar solo cambia el lugar de las tarimas y de las líneas; no cambia cantidades.</p>${ro?'':'<div class="pact" style="margin-top:6px"><button class="btn sm primary" data-act="ordenpal" data-edit>Ordenar como el empaque</button><button class="btn sm" data-act="ordlibre:1" data-edit>Permitir cambios</button></div>'}</div>`;
}
function trazValidHtml(z){
  /* v8.17: mientras el empaque sigue, lo que hay en tarimas de más es «por registrar» (la tarima se arma antes); al completar, es «sobran» */
  const done=z.sh.every(x=>x.estado==='completo');
  const chipOf=d=>d===0?'<span class="chip good">Completo</span>':d>0?`<span class="chip warn">faltan ${fmt(d)}</span>`:done?`<span class="chip crit">sobran ${fmt(-d)}</span>`:`<span class="chip info">por registrar ${fmt(-d)}</span>`;
  const blocks=z.lines.map(L=>{
    let te=0,tp=0;
    const rows=CAL.map(c=>{const e=z.expL[L][c.k],p=z.palL[L][c.k];if(!e&&!p)return '';te+=e;tp+=p;return `<div class="vrow"><span class="cl">${c.l}</span><span class="mono">${fmt(e)}</span><span class="mono">${fmt(p)}</span>${chipOf(e-p)}</div>`}).join('');
    if(!rows)return '';
    return `<div class="vline"><div class="vlh"><span class="lpill q${L.split('|')[0]==='1.5'?'2':'1'}">${esc(lineLabel(L))}</span><span class="mono">${fmt(tp)} de ${fmt(te)}</span>${chipOf(te-tp)}</div>${rows}</div>`;
  }).join('');
  const over=!z.over.length?'':done?`<div class="warnbox" role="alert"><strong>Revisa estos productores</strong>${z.over.slice(0,8).map(x=>`<div>${esc(x.msg)}</div>`).join('')}</div>`:`<div class="panel info"><strong>Tarimas armadas antes del registro</strong>${z.over.slice(0,8).map(x=>`<div class="note">${esc(x.msg.replace(': no tiene cajas de',': aún no registra cajas de').replace(' empacadas',' registradas hasta ahora'))}</div>`).join('')}<p class="note">Se igualan conforme se capturan los calibres en Registro de Empaque.</p></div>`;
  return ordenHtml(z)+`<div class="sec">Verificación contra lo empacado</div><div class="panel"><div class="vhead"><span>Calibre</span><span>Por tarimar</span><span>En tarimas</span><span>Estado</span></div>${blocks||'<p class="note">Todavía no hay cajas empacadas.</p>'}<p class="note" style="margin-top:8px">Cada calidad y tipo de empaque se verifica por separado: las cajas de una tarima de cartón solo cubren lo empacado en cartón. «Por tarimar» es lo empacado sin contar el sobrante que pasa al siguiente pedido${z.sobTot?' ('+esc(z.sobText)+'; ya está descontado de los productores)':''}. Una tarima completa lleva ${palCap('RPC')} cajas en RPC, ${palCap('CTN')} en CTN, ${palCap('CTN10')} en CTN 10 lb y ${palCap('PLT')} en PLT (se cambian en Pesos y equivalencias); en RPC, 54, 55 y 60 se aceptan como excepción.</p></div>${over}`;
}
function updateTraz(){
  const o=cur();if(!o||view!=='trazo')return;
  const z=trazCalc(o);
  $app.querySelectorAll('[data-out]').forEach(el=>{
    const k=el.dataset.out.split('.');let r=null;
    if(k[0]==='zb'){el.innerHTML=borradorNota(z);return}
    if(k[0]==='tt'){const i=z.info[k[1]];r=i?{text:fmt(i.tot)}:null}
    else if(k[0]==='tc'){const i=z.info[k[1]];if(i)r=!i.tot?{text:'—',cls:''}:i.ok?{text:i.cap+' normal',cls:'good'}:i.exc?{text:'Excepción',cls:'info'}:{text:'Normal: '+i.cap,cls:'warn'}}
    else if(k[0]==='av'){const a=lineAvail(z,k[1],k[2]);if(a){el.className='pavl '+a.cls;el.textContent=a.text}return}
    else if(k[0]==='pdot'){const p=z.t.tarimas.find(x=>x.id===k[1]);if(p){const S=palStat(z,p);el.className='pdot '+S.cls;el.title=S.t;el.setAttribute('aria-label',S.t)}return}
    else if(k[0]==='pdv'){const p=z.t.tarimas.find(x=>x.id===k[1]);if(p)el.innerHTML=dispHtml(z,p);return}
    else if(k[0]==='zs')r=z.borrador?{text:'BORRADOR',cls:'warn'}:{text:z.full?'Completo · Full':'Completo',cls:'good'};
    else if(k[0]==='zn')r={text:z.nPal+' '+(z.nPal===1?'tarima':'tarimas')+' · '+fmt(z.cantTot)+' cajas'+(z.nPal?(z.full?' · Full (24+)':' · Parcial (Full = 24+)'):'')};
    if(!r)return;
    el.textContent=r.text;if(el.dataset.base!==undefined)el.className=el.dataset.base+(r.cls?' '+r.cls:'');
  });
  const zv=document.getElementById('zval');if(zv)zv.innerHTML=trazValidHtml(z);
  if(trazQ)trazFindApply();
  /* los indicadores verdes de cada lista se rehacen, salvo la que se está usando */
  $app.querySelectorAll('select[data-calsel]').forEach(se=>{if(se===document.activeElement)return;const q=se.dataset.calsel.split(':'),p=z.t.tarimas.find(x=>x.id===q[0]),l=p&&p.lines.find(x=>x.id===q[1]);if(l)se.innerHTML=calOpts(z,p,l)});
  $app.querySelectorAll('select[data-pressel]').forEach(se=>{if(se===document.activeElement)return;const p=z.t.tarimas.find(x=>x.id===se.dataset.pressel);if(p)se.innerHTML=presOpts(z,p)});
}

/* acciones sobre tarimas */
function trazOrder(){const o=cur();return o?mainOf(o):null}
function addTarima(){
  const o=trazOrder();if(!o||ro)return;const t=ensureTraz(o);
  const last=t.tarimas[t.tarimas.length-1];
  const p={id:uid(),marca:(MARCAS[o.emp]||MARCAS.VL)[0],empaque:last?palTipo(last):'RPC',lines:[{id:uid(),q:'1',cal:'',cant:null,prod:''}]};
  t.tarimas.push(p);palOpen=p.id;touch(o);logAdd({k:'add',ctx:ctxOf(o),lab:'Tarima '+t.tarimas.length});focusId='f-tl-'+p.id+'-'+p.lines[0].id+'-cal';render();
}
function addLine(pid){
  const o=trazOrder();if(!o||ro)return;const p=ensureTraz(o).tarimas.find(x=>x.id===pid);if(!p)return;
  const prev=p.lines[p.lines.length-1];
  const l={id:uid(),q:prev?lineQ(p,prev):'1',cal:'',cant:null,prod:''};p.lines.push(l);touch(o);focusId='f-tl-'+p.id+'-'+l.id+'-cal';render();
}
/* tocar un calibre disponible lo pone en la primera línea vacía (o en una nueva) */
function addLineCal(pid,q,cal){
  const o=trazOrder();if(!o||ro)return;const p=ensureTraz(o).tarimas.find(x=>x.id===pid);if(!p)return;
  let l=p.lines.find(x=>!x.cal);if(!l){l={id:uid(),cal:'',cant:null,prod:''};p.lines.push(l)}
  l.cal=cal;l.q=q==='1.5'?'1.5':'1';syncMarca(o,p);touch(o);focusId='f-tl-'+p.id+'-'+l.id+(l.cant?'-prod':'-cant');render();
}
function delLine(pid,lid){
  const o=trazOrder();if(!o||ro)return;const p=ensureTraz(o).tarimas.find(x=>x.id===pid);if(!p)return;
  const dl=p.lines.find(l=>l.id===lid);if(dl&&dl.de){const ock=PCAL_KEY[dl.cal]||null,on=n0(dl.cant);dl.cant=0;sobLineSync(o,p,dl,ock,on)}
  if(p.lines.length<=1){p.lines=[{id:uid(),cal:'',cant:null,prod:''}]}else p.lines=p.lines.filter(l=>l.id!==lid);
  touch(o);render();
}
/* v7.9: las cajas de primera que se van empacando se acumulan solas en tarimas de 50, una presentación por tarima y juntando el mismo calibre.
   Lo que no completa una tarima queda como tarima incompleta; el jefe de empaque decide en Registro si la completa con segunda. */
const PAL_N=50; /* v8.17: solo de respaldo; la capacidad real es palCap(presentación) */
function calLab(k){const c=CAL.find(x=>x.k===k);return c?c.l:k}
function palTot(p){return (p.lines||[]).reduce((a,l)=>a+n0(l.cant),0)}
function palCals(p){const s=[];(p.lines||[]).forEach(l=>{const k=PCAL_KEY[l.cal];if(k&&n0(l.cant)>0&&s.indexOf(k)<0)s.push(k)});return s}
function palPut(o,p,q,k,pk,n){
  p.lines=(p.lines||[]).filter(l=>l.cal||n0(l.cant)>0||String(l.prod||'').trim());
  const lab=calLab(k),l=p.lines.find(x=>!x.de&&lineQ(p,x)===q&&PCAL_KEY[x.cal]===k&&x.prod===pk);
  if(l)l.cant=n0(l.cant)+n;else p.lines.push({id:uid(),q:q,cal:lab,cant:n,prod:pk});syncMarca(o,p);
}
/* v8.5: el orden de las tarimas imita la corrida del empaque.
   Los primeros productores registrados abren las primeras tarimas; los siguientes se apilan sobre las cajas del mismo calibre hasta llenarla (50).
   La segunda (1-1/2) corre al final y se agrega aparte (Completar con segunda), siempre editable. */
function prodRankMap(o){
  const m={};let i=0;
  /* v8.21.1: el renglón REEMPAQUE solo da lugar a productores que no están en la línea de este viaje
     (en un reempaque dentro del mismo viaje, el productor conserva el lugar en que entró al empaque) */
  const R=[];
  sheetsOf(o).forEach(s=>(s.productores||[]).forEach(p=>{if(p.rmp){R.push({s:s,p:p,i:i});i++;return}if(p.sob2){(p.sobAp||[]).forEach(a=>{const k=resolveProd([s],a.key);if(k&&m[k]==null)m[k]=i});i++;return}const k=prodKey(s,p);if(k&&m[k]==null)m[k]=i;i++}));
  R.forEach(x=>(x.p.sobAp||[]).forEach(a=>{const k=resolveProd([x.s],rmpKey(x.s,a));if(k&&m[k]==null)m[k]=x.i}));
  return m;
}
function palRankKey(p,RK,sh){
  /* llave de la tarima: grupo (0 con primera, 1 solo segunda) · lugar del primer productor · presentación · calibre */
  let g=1,best=null;
  (p.lines||[]).forEach(l=>{
    const key=PCAL_KEY[l.cal];if(!key||!(n0(l.cant)>0))return;
    const pk=resolveProd(sh,l.prod),r=RK[pk]==null?9999:RK[pk],q=lineQ(p,l)==='1.5'?1:0;
    const cand=[q,r,Math.max(0,PRES.findIndex(x=>x[0]===palTipo(p))),CAL_ASC.indexOf(key)];
    if(!best||cand[0]<best[0]||(cand[0]===best[0]&&(cand[1]<best[1]||(cand[1]===best[1]&&(cand[2]<best[2]||(cand[2]===best[2]&&cand[3]<best[3]))))))best=cand;
  });
  return best||[2,9999,0,0];
}
function lineRank(p,l,RK,sh){const pk=resolveProd(sh,l.prod);return [lineQ(p,l)==='1.5'?1:0,RK[pk]==null?9999:RK[pk]]}
function cmpArr(a,b){for(let i=0;i<a.length;i++){if(a[i]!==b[i])return a[i]-b[i]}return 0}
/* revisa si las tarimas (y las líneas dentro de cada una) siguen el orden de registro del empaque */
function ordenCheck(z){
  const sh=z.sh,RK=prodRankMap(z.o),T=z.t.tarimas,issues=[];
  const keys=T.map((p,i)=>({p:p,i:i,k:palRankKey(p,RK,sh)}));
  const exp=keys.slice().sort((a,b)=>cmpArr(a.k,b.k)||a.i-b.i);
  const moved=[];exp.forEach((x,j)=>{if(x.i!==j)moved.push(x)});
  /* una tarima está fuera de lugar si alguna anterior debería ir después */
  for(let i=1;i<keys.length;i++){if(keys[i].k[0]===2||keys[i-1].k[0]===2)continue;if(cmpArr(keys[i-1].k,keys[i].k)>0){issues.push('Pallet '+(i+1)+' debería ir antes que el Pallet '+i)}}
  let lineBad=0;
  T.forEach(p=>{const L=(p.lines||[]).filter(l=>l.cal&&n0(l.cant)>0).map(l=>lineRank(p,l,RK,sh));for(let i=1;i<L.length;i++){if(cmpArr(L[i-1],L[i])>0){lineBad++;break}}});
  if(lineBad)issues.push(lineBad+' '+(lineBad===1?'tarima tiene':'tarimas tienen')+' productores apilados en distinto orden al del empaque');
  return {ok:!issues.length,issues:issues,n:T.length};
}
/* solo reordena (no cambia cantidades): tarimas por orden de entrada al empaque y, dentro de cada una, primera por productor y la segunda al final */
function ordenarTarimas(o,quiet){
  const m=mainOf(o);if(!m||ro)return;const z=trazCalc(m),RK=prodRankMap(m),sh=z.sh,t=z.t;
  t.tarimas.forEach(p=>{
    const idx=new Map((p.lines||[]).map((l,i)=>[l,i]));
    p.lines=(p.lines||[]).slice().sort((a,b)=>{const ea=a.cal&&n0(a.cant)>0,eb=b.cal&&n0(b.cant)>0;if(ea!==eb)return ea?-1:1;return cmpArr(lineRank(p,a,RK,sh),lineRank(p,b,RK,sh))||idx.get(a)-idx.get(b)});
  });
  t.tarimas=t.tarimas.map((p,i)=>({p:p,i:i,k:palRankKey(p,RK,sh)})).sort((a,b)=>cmpArr(a.k,b.k)||a.i-b.i).map(x=>x.p);
  touch(m);logAdd({k:'note',ctx:ctxOf(m),lab:'Tarimas ordenadas como el empaque',o:'',n:''});
  if(!quiet)toast('Tarimas ordenadas según el Registro de empaque');
}
function autoPal(o,quiet){
  const m=mainOf(o);if(!m||ro||manClosed(m))return 0;const z=trazCalc(m),t=z.t;let added=0;
  const RK=prodRankMap(m);
  /* lista de trabajo en el orden real de la corrida: productor por productor (orden del registro), luego presentación y calibre */
  const work=[];
  z.lines.filter(L=>L.split('|')[0]==='1').forEach(L=>{
    const tp=L.split('|')[1],E=z.empQ[L]||{};
    Object.keys(E).forEach(pk=>CAL_ASC.forEach((k,ci)=>{if(PCAL_KEY[calLab(k)])work.push({L:L,tp:tp,pk:pk,k:k,r:RK[pk]==null?9999:RK[pk],ti:TIPO_K.indexOf(tp),ci:ci})}));
  });
  work.sort((a,b)=>a.r-b.r||a.ti-b.ti||a.ci-b.ci);
  work.forEach(w=>{
    const P=z.palQ[w.L]||{},E=z.empQ[w.L]||{};
    let n=(E[w.pk].by[w.k]||0)-((P[w.pk]&&P[w.pk].by[w.k])||0);
    while(n>0){
      /* se apila sobre la primera tarima de la misma presentación y calibre que no esté llena */
      let p=t.tarimas.find(x=>palTipo(x)===w.tp&&palTot(x)<palCap(w.tp)&&palQs(x).indexOf('1.5')<0&&(()=>{const c=palCals(x);return c.length===1&&c[0]===w.k})());
      if(!p)p=t.tarimas.find(x=>palTipo(x)===w.tp&&palTot(x)===0);
      if(!p){p={id:uid(),marca:marcaOfQ(m.emp,'1'),empaque:w.tp,lines:[]};t.tarimas.push(p)}
      const put=Math.min(n,palCap(w.tp)-palTot(p));palPut(m,p,'1',w.k,w.pk,put);n-=put;added+=put;
    }
  });
  if(added){touch(m);logAdd({k:'note',ctx:ctxOf(m),lab:'Tarimas acomodadas',o:'',n:fmt(added)+' cajas de primera'});if(!quiet)toast(fmt(added)+' cajas de primera acomodadas en tarimas, en el orden del empaque')}
  else if(!quiet)toast('No hay cajas de primera pendientes por tarimar');
  return added;
}
/* tarimas a las que les faltan cajas y la segunda que hay para completarlas (misma presentación, mismo calibre primero) */
function palShort(o){
  const m=mainOf(o),z=trazCalc(m);
  return z.t.tarimas.map((p,i)=>{const tot=palTot(p),cp=palCap(palTipo(p));if(!(tot>0)||tot>=cp)return null;
    const tp=palTipo(p),L=lineKey('1.5',tp),ex=z.expL[L],pl=z.palL[L];let seg=0;if(ex)CAL.forEach(c=>seg+=Math.max(0,ex[c.k]-pl[c.k]));
    return {p:p,n:i+1,tot:tot,falta:cp-tot,seg:seg,tp:tp,cals:palCals(p).map(calLab)}}).filter(Boolean);
}
function palAddSeg(o,pid){
  const m=mainOf(o);if(!m||ro)return;const z=trazCalc(m),p=z.t.tarimas.find(x=>x.id===pid);if(!p)return;
  const tp=palTipo(p),L=lineKey('1.5',tp),E=z.empQ[L]||{},P=z.palQ[L]||{};let need=palCap(tp)-palTot(p),got=0;
  const ks=palCals(p).concat(CAL_ASC.filter(k=>palCals(p).indexOf(k)<0));
  ks.forEach(k=>{if(!PCAL_KEY[calLab(k)])return;Object.keys(E).forEach(pk=>{if(need<=0)return;const a=(E[pk].by[k]||0)-((P[pk]&&P[pk].by[k])||0);if(a<=0)return;const n=Math.min(a,need);palPut(m,p,'1.5',k,pk,n);need-=n;got+=n})});
  if(!got){toast('No hay segunda de '+(TIPO_L[tp]||tp)+' para esta tarima');return}
  touch(m);logAdd({k:'note',ctx:ctxOf(m),lab:'Tarima completada con segunda',o:'',n:fmt(got)+' cajas 1-1/2'});toast('Se agregaron '+fmt(got)+' cajas de segunda a la tarima');render();
}
function palShortHtml(o){
  const L=palShort(o);if(!L.length)return '';
  return `<div class="sec">Tarimas incompletas</div><div class="panel"><p class="note">Al terminar la corrida de primera, decide si completas estas tarimas con segunda (1-1/2) de la misma presentación. Si no, se quedan así.</p>${L.map(x=>`<div class="kv"><span>Tarima ${x.n} · ${esc(TIPO_L[x.tp]||x.tp)} · ${esc(x.cals.join(', ')||'—')}<br><small class="note">${fmt(x.tot)} de ${fmt(x.tot+x.falta)} cajas · faltan ${fmt(x.falta)}</small></span>${ro?'':(x.seg>0?`<button class="btn sm" data-act="palseg:${x.p.id}" data-edit>Completar con segunda (${fmt(Math.min(x.seg,x.falta))})</button>`:'<small class="note">sin segunda disponible</small>')}</div>`).join('')}</div>`;
}
/* arrastrar una tarima minimizada por su asa (ratón o dedo); con el teclado, las flechas la suben o la bajan un lugar */
(()=>{
  let D=null;
  const cards=()=>[...document.querySelectorAll('.palmini > [data-pid]')];
  const clear=()=>cards().forEach(c=>c.classList.remove('dropb','dropa'));
  document.addEventListener('pointerdown',e=>{
    const g=e.target.closest&&e.target.closest('[data-grip]');if(!g||g.disabled||ro||e.button>0)return;
    const card=g.closest('.pmini'),L=cards();if(!card)return;e.preventDefault();
    /* mientras se arrastra, la tarima abierta se reduce a su encabezado para que todas queden a la vista */
    const r=card.getBoundingClientRect(),gr=card.parentElement;if(gr)gr.classList.add('dragging');const r2=card.getBoundingClientRect();
    D={id:g.dataset.grip,card:card,from:L.indexOf(card),to:L.indexOf(card),x0:e.clientX+(r2.left-r.left),y0:e.clientY+(r2.top-r.top),moved:false,pid:e.pointerId};
    try{g.setPointerCapture(e.pointerId)}catch(x){}
    card.classList.add('drag');card.style.zIndex=5;
  });
  document.addEventListener('pointermove',e=>{
    if(!D||e.pointerId!==D.pid)return;e.preventDefault();
    const dx=e.clientX-D.x0,dy=e.clientY-D.y0;if(Math.abs(dx)+Math.abs(dy)>4)D.moved=true;
    D.card.style.transform=`translate(${dx}px,${dy}px)`;
    /* la tarjeta bajo el dedo marca el lugar nuevo */
    D.card.style.pointerEvents='none';const el=document.elementFromPoint(e.clientX,e.clientY);D.card.style.pointerEvents='';
    const over=el&&el.closest&&el.closest('.palmini > [data-pid]');clear();
    if(over&&over!==D.card){const L=cards(),j=L.indexOf(over);D.to=j;over.classList.add(j<D.from?'dropb':'dropa')}else if(!over)D.to=D.from;
    /* desplaza la página si el dedo llega a la orilla */
    if(e.clientY<60)window.scrollBy(0,-12);else if(e.clientY>innerHeight-90)window.scrollBy(0,12);
  },{passive:false});
  const end=e=>{
    if(!D||(e&&e.pointerId!==D.pid))return;const d=D;D=null;clear();if(d.card.parentElement)d.card.parentElement.classList.remove('dragging');
    if(d.moved&&d.to!==d.from)flipPrev=flipSnap();
    d.card.classList.remove('drag');d.card.style.transform='';d.card.style.zIndex='';
    if(d.moved&&d.to!==d.from)moveTarima(d.id,d.to);
  };
  document.addEventListener('pointerup',end);document.addEventListener('pointercancel',end);
  document.addEventListener('keydown',e=>{
    const g=e.target.closest&&e.target.closest('[data-grip]');if(!g||ro)return;
    const dir={ArrowUp:-1,ArrowLeft:-1,ArrowDown:1,ArrowRight:1}[e.key];if(!dir)return;e.preventDefault();
    const L=cards(),i=L.indexOf(g.closest('[data-pid]')),id=g.dataset.grip;moveTarima(id,i+dir);
    setTimeout(()=>{const n=document.querySelector(`[data-grip="${id}"]`);if(n)n.focus()},80);
  });
})();
/* v8.10: asa ☰ en cada línea de la tarima abierta: arrastrar (ratón o dedo) o flechas ↑ ↓ cambian el orden de los productores dentro de la tarima */
function lgripHtml(p,l){const n=(p.lines||[]).length;return n<2?'<span class="lgrip lgsp" aria-hidden="true"></span>':`<button type="button" class="icon sm lgrip" data-lgrip="${p.id}:${l.id}" aria-label="Arrastrar para cambiar el orden de esta línea (o usa las flechas)"${ro?' disabled':''}>${GRIP_SVG}</button>`}
/* v8.12: las tarimas y las líneas se ven moverse a su lugar nuevo (FLIP: se toma dónde estaban, se redibuja y se animan desde ahí) */
let flipPrev=null;
const flipSel='.palmini > [data-pid], .pln[id^="ln-"]';
function flipSnap(){const m=new Map();document.querySelectorAll(flipSel).forEach(el=>{const k=el.dataset.pid?'p'+el.dataset.pid:el.id;m.set(k,el.getBoundingClientRect())});return m}
function flipPlay(prev){
  if(!prev||!prev.size||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  document.querySelectorAll(flipSel).forEach(el=>{const k=el.dataset.pid?'p'+el.dataset.pid:el.id,a=prev.get(k);if(!a)return;const b=el.getBoundingClientRect(),dx=a.left-b.left,dy=a.top-b.top;
    if(Math.abs(dx)<1&&Math.abs(dy)<1)return;if(Math.abs(dy)>innerHeight*1.5)return;
    el.classList.add('flipm');const an=el.animate([{transform:`translate(${dx}px,${dy}px)`},{transform:'none'}],{duration:340,easing:'cubic-bezier(.65,0,.35,1)'});an.onfinish=an.oncancel=()=>el.classList.remove('flipm')});
}
function moveLine(pid,lid,to){
  const o=trazOrder();if(!o||ro)return;const p=ensureTraz(o).tarimas.find(x=>x.id===pid);if(!p)return;const i=p.lines.findIndex(x=>x.id===lid);if(i<0)return;
  to=Math.max(0,Math.min(p.lines.length-1,to));if(to===i)return;
  const [x]=p.lines.splice(i,1);p.lines.splice(to,0,x);touch(o);
  logAdd({k:'note',ctx:ctxOf(o),lab:'Orden de productores en la tarima',o:'Línea '+(i+1),n:'Línea '+(to+1)});render();
}
(()=>{
  let D=null;
  const rows=c=>[...c.querySelectorAll(':scope > .pln')];
  const clear=c=>rows(c).forEach(r=>r.classList.remove('dropb','dropa'));
  document.addEventListener('pointerdown',e=>{
    const g=e.target.closest&&e.target.closest('[data-lgrip]');if(!g||g.disabled||ro||e.button>0)return;
    const row=g.closest('.pln'),box=row&&row.parentElement;if(!row||!box)return;e.preventDefault();
    const L=rows(box);D={k:g.dataset.lgrip,row:row,box:box,from:L.indexOf(row),to:L.indexOf(row),y0:e.clientY,moved:false,pid:e.pointerId};
    try{g.setPointerCapture(e.pointerId)}catch(x){}row.classList.add('ldrag');
  });
  document.addEventListener('pointermove',e=>{
    if(!D||e.pointerId!==D.pid)return;e.preventDefault();
    const dy=e.clientY-D.y0;if(Math.abs(dy)>4)D.moved=true;D.row.style.transform=`translateY(${dy}px)`;
    D.row.style.pointerEvents='none';const el=document.elementFromPoint(e.clientX,e.clientY);D.row.style.pointerEvents='';
    const over=el&&el.closest&&el.closest('.pln');clear(D.box);
    if(over&&over!==D.row&&over.parentElement===D.box){const j=rows(D.box).indexOf(over);D.to=j;over.classList.add(j<D.from?'dropb':'dropa')}else if(!over)D.to=D.from;
    if(e.clientY<60)window.scrollBy(0,-10);else if(e.clientY>innerHeight-90)window.scrollBy(0,10);
  },{passive:false});
  const end=e=>{if(!D||(e&&e.pointerId!==D.pid))return;const d=D;D=null;clear(d.box);if(d.moved&&d.to!==d.from)flipPrev=flipSnap();d.row.classList.remove('ldrag');d.row.style.transform='';
    if(d.moved&&d.to!==d.from){const q=d.k.split(':');moveLine(q[0],q[1],d.to)}};
  document.addEventListener('pointerup',end);document.addEventListener('pointercancel',end);
  document.addEventListener('keydown',e=>{
    const g=e.target.closest&&e.target.closest('[data-lgrip]');if(!g||ro)return;const dir={ArrowUp:-1,ArrowDown:1}[e.key];if(!dir)return;e.preventDefault();
    const q=g.dataset.lgrip.split(':'),o=trazOrder(),p=o&&ensureTraz(o).tarimas.find(x=>x.id===q[0]);if(!p)return;const i=p.lines.findIndex(x=>x.id===q[1]);
    moveLine(q[0],q[1],i+dir);setTimeout(()=>{const n=document.querySelector(`[data-lgrip="${q[0]}:${q[1]}"]`);if(n)n.focus()},60);
  });
})();
function moveTarima(pid,to){
  const o=trazOrder();if(!o||ro)return;const t=ensureTraz(o),i=t.tarimas.findIndex(x=>x.id===pid);if(i<0)return;
  to=Math.max(0,Math.min(t.tarimas.length-1,to));if(to===i)return;
  const [x]=t.tarimas.splice(i,1);t.tarimas.splice(to,0,x);touch(o);
  logAdd({k:'note',ctx:ctxOf(o),lab:'Orden de tarimas',o:'Lugar '+(i+1),n:'Lugar '+(to+1)});
  render();setTimeout(()=>{const el=document.getElementById('pal-'+pid);if(el)el.scrollIntoView({block:'center',behavior:'smooth'})},60);
  toast('Tarima movida al lugar '+(to+1));
}
function dupTarima(pid){
  const o=trazOrder();if(!o||ro)return;const t=ensureTraz(o),i=t.tarimas.findIndex(x=>x.id===pid);if(i<0)return;
  const c=clone(t.tarimas[i]);c.id=uid();c.lines.forEach(l=>l.id=uid());t.tarimas.splice(i+1,0,c);palOpen=c.id;touch(o);render();toast('Tarima duplicada');
}
function delTarima(pid){
  const o=trazOrder();if(!o||ro)return;
  if(confirmKey!=='delt:'+pid){armConfirm('delt:'+pid);render();return}
  const t=ensureTraz(o),ti=t.tarimas.findIndex(x=>x.id===pid);if(ti>=0)logAdd({k:'del',what:'t',ctx:ctxOf(o),snap:clone(t.tarimas[ti]),idx:ti,lab:'Tarima '+(ti+1)});t.tarimas=t.tarimas.filter(x=>x.id!==pid);confirmKey=null;touch(o);render();
}

/* ---------- buscador de productor en cada línea ---------- */
/* v8.17 · concordancia por productor: cajas registradas en Registro de Empaque contra cajas en tarimas, por calidad, presentación y calibre */
function palNums(z,pk,L,ck){const out=[];z.t.tarimas.forEach((p,i)=>{if((p.lines||[]).some(l=>n0(l.cant)>0&&PCAL_KEY[l.cal]===ck&&lineOfCal(p,ck,l)===L&&resolveProd(z.sh,l.prod)===pk))out.push(i+1)});return out}
function prodConcord(z,pk,q){
  const out=[];z.lines.forEach(L=>{if(q&&L.split('|')[0]!==q)return;const e=(z.empQ[L]||{})[pk],u=(z.palQ[L]||{})[pk];if(!e&&!u)return;
    CAL.forEach(c=>{const a=(e&&e.by[c.k])||0,b=(u&&u.by[c.k])||0;if(!a&&!b)return;out.push({L:L,ck:c.k,reg:a,pal:b,d:a-b,n:b?palNums(z,pk,L,c.k):[]})})});
  return out;
}
function concordTxt(z,pk,q,done){
  const C=prodConcord(z,pk,q);if(!C.length)return null;
  const lab=x=>calLab(x.ck)+' '+(lineLabel(x.L,true).replace(/^1ª |^1½ /,''))+(x.L.split('|')[0]==='1.5'?' (1.5)':'');
  const tn=x=>x.n.length?' (tarima '+x.n.join(', ')+')':'';
  const rows=C.map(x=>x.d===0?'✓ '+lab(x)+': '+fmt(x.reg)+' registradas, igual que en tarimas'+tn(x):x.d>0?(x.pal?'▲ '+lab(x)+': registraste '+fmt(x.reg)+' y en tarimas hay '+fmt(x.pal)+tn(x)+'. Te pasaste por '+fmt(x.d)+': súmalas a una tarima.':'▲ '+lab(x)+': '+fmt(x.reg)+' registradas y ninguna en tarimas. Agrégalas en Código de Trazabilidad.'):'• '+lab(x)+': en tarimas hay '+fmt(x.pal)+tn(x)+' y van '+fmt(x.reg)+' registradas. '+(done?'Sobran '+fmt(-x.d)+' en tarimas.':'Faltan '+fmt(-x.d)+' por registrar.'));
  const over=C.some(x=>x.d>0),under=C.some(x=>x.d<0);
  return {text:rows.join('\n'),cls:over||(done&&under)?'warn':under?'info':'good',over:over,under:under,C:C};
}
function lineAvail(z,pid,lid){
  const p=z.t.tarimas.find(x=>x.id===pid),l=p&&p.lines.find(x=>x.id===lid);if(!l)return null;
  if(!String(l.prod||'').trim())return{cls:'',text:''};
  const ck=PCAL_KEY[l.cal],L=lineOfCal(p,ck,l),pk=resolveProd(z.sh,l.prod),e=(z.empQ[L]||{})[pk],done=z.sh.every(x=>x.estado==='completo');
  /* v8.17: la tarima se arma antes de registrar calibres; mientras el empaque sigue, lo no registrado es «pendiente», no error */
  if(!e)return done?{cls:'bad',text:'No tiene cajas de '+lineLabel(L)+' registradas en este pedido'}:{cls:'pend',text:pk+' · aún sin calibres de '+lineLabel(L)+' en Registro de Empaque'};
  if(!ck)return{cls:'',text:e.nombre+' · elige el calibre'};
  const av=z.avail(L,pk,ck,0);
  return av>=0?{cls:'ok',text:e.nombre+' · '+(av?'quedan '+fmt(av)+' registradas sin tarima de calibre '+l.cal:'cuadra con Registro de Empaque')}:done?{cls:'bad',text:e.nombre+' · hay '+fmt(-av)+' cajas de calibre '+l.cal+' más que las registradas'}:{cls:'pend',text:e.nombre+' · faltan registrar '+fmt(-av)+' cajas de calibre '+l.cal+' en Registro de Empaque'};
}
let ddKeys=[];
function openPdd(inp){
  const pr=String(inp.dataset.psearch).split(':'),o=trazOrder();if(!o||ro)return;
  const z=trazCalc(o),p=z.t.tarimas.find(x=>x.id===pr[0]),l=p&&p.lines.find(x=>x.id===pr[1]);if(!l)return;
  const ck=PCAL_KEY[l.cal],L=lineOfCal(p,ck,l),E=z.empQ[L]||{},box=inp.parentNode.querySelector('.pdd');
  const own=resolveProd(z.sh,l.prod);
  const txt=norm(inp.value).trim(),same=txt&&norm(l.prod||'').trim()===txt,toks=same?[]:txt.split(/\s+/).filter(Boolean);
  /* v8.17: además de los que ya tienen cajas registradas, salen los productores del pedido y, al escribir, los de la lista: la tarima se arma antes */
  const seen=new Set(),cand=[];
  Object.keys(E).forEach(k=>{const e=E[k],av=ck?z.avail(L,k,ck,(own===k?n0(l.cant):0)):CAL.reduce((a,c)=>a+z.avail(L,k,c.k,0),0);seen.add(k);cand.push({k:k,nombre:e.nombre,av:av,reg:true})});
  z.sh.forEach(x=>(x.productores||[]).forEach(pp=>{if(pp.sob||pp.sob2||isSob(pp)||+pp.codigo===SEG_COD||pp.segLot)return;const k=prodKey(x,pp);if(seen.has(k))return;seen.add(k);cand.push({k:k,nombre:pp.nombre||k,av:0,reg:false})}));
  if(toks.length)LISTA.forEach(li=>{const k=o.emp+'-'+pad(li.c,3);if(seen.has(k))return;seen.add(k);cand.push({k:k,nombre:li.n,av:0,reg:false})});
  let list=cand.filter(x=>{
    if(!toks.length)return true;
    const h=norm(x.k+' '+x.nombre+' '+x.k.replace(/\D+/g,'').replace(/^0+/,''));
    return toks.every(t=>h.includes(t));
  });
  list.sort((a,b)=>a.k.localeCompare(b.k,'es',{numeric:true}));
  ddKeys=list.map(x=>x.k);
  box.innerHTML=(list.length?list.map((x,i)=>`<button type="button" class="pdi" data-act="ppick:${pr[0]}:${pr[1]}:${i}"><span class="pk">${/^(VL|EC)-\d+$/.test(x.k)?esc(x.k):'—'}</span><span class="pn">${esc(x.nombre)}</span><span class="pav${x.av>0?'':' z'}">${x.reg?fmt(x.av):'sin registrar'}</span></button>`).join(''):`<div class="pdn">${ck?'Ningún productor tiene cajas disponibles de calibre '+esc(l.cal)+' en '+esc(lineLabel(L))+(toks.length?' con esa búsqueda':'')+'.':'Sin coincidencias.'}</div>`)+(ck?'':'<div class="pdn">Elige primero el calibre para ver cuántas cajas quedan.</div>');
  box.hidden=false;
}
function closePdds(){document.querySelectorAll('.pdd').forEach(b=>{b.hidden=true})}
function pickProd(pid,lid,i){
  const o=trazOrder();if(!o||ro)return;const k=ddKeys[+i];if(!k)return;
  const p=ensureTraz(o).tarimas.find(x=>x.id===pid),l=p&&p.lines.find(x=>x.id===lid);if(!l)return;
  l.prod=k;touch(o);if(!l.cant)focusId='f-tl-'+pid+'-'+lid+'-cant';render();
}
function settleProd(inp){
  if(!inp.isConnected||inp.dataset.dirty!=='1')return;
  inp.dataset.dirty='';
  const pr=String(inp.dataset.psearch).split(':'),o=trazOrder();if(!o||ro)return;
  const t=ensureTraz(o),p=t.tarimas.find(x=>x.id===pr[0]),l=p&&p.lines.find(x=>x.id===pr[1]);if(!l)return;
  const v=inp.value.trim();
  if(!v){if(l.prod){l.prod='';touch(o);updateTraz()}return}
  const z=trazCalc(o),k=resolveProd(z.sh,v);
  if((z.empQ[lineOfCal(p,PCAL_KEY[l.cal],l)]||{})[k]&&k!==l.prod){l.prod=k;touch(o);inp.value=k;updateTraz();return}
  if(inp.value!==(l.prod||''))inp.value=l.prod||'';
}

/* v8.4 · una sola fuente: Control Logístico. Al elegir un dato del encabezado se completan los que dependen de él (teléfono, placas, códigos) y se reflejan en Registro de empaque y en los documentos */
function regFind(rt,v){const n=norm(v||'').trim();return n?(REG[rt]||[]).find(y=>norm(y.n).trim()===n):null}
function setCliente(m,v){
  v=String(v||'').trim();if(!v)return;
  sheetsOf(m).forEach(x=>{if(x.customer!==v){x.customer=v;touch(x)}});
  const c=regFind('clientes',v),b=(m.bi=m.bi||{});
  if(c){if(c.destino&&!b.destino)b.destino=c.destino;if(c.incoterm&&!b.incoterm&&INCOTERMS.indexOf(c.incoterm)>=0)b.incoterm=c.incoterm;if(c.diasPago&&!b.diasPago&&num(c.diasPago)!=null)b.diasPago=num(c.diasPago)}
  touch(m);
}
function onHdrChange(el){
  const f=el.dataset.learn,v=String(el.value||'').trim();learnCat(f,v);
  const o=trazOrder();if(!o||ro)return;const h=ensureTraz(o).hdr;let re=false;
  const put=(k,val,soloVacio)=>{val=String(val==null?'':val).trim();if(!val)return;if(soloVacio&&String(h[k]||'').trim())return;if(h[k]!==val){h[k]=val;re=true}};
  const deTransp=()=>{const t=regFind('transportistas',h.transporte);if(t){put('telTransporte',t.tel);put('caat',t.caat);put('alpha',t.alpha)}};
  const dueno=x=>{if(x&&x.transporte){put('transporte',x.transporte,true);deTransp()}};
  if(f==='vendedor'){const x=regFind('vendedores',v);if(x)put('tel',x.tel)}
  if(f==='transporte'){deTransp();re=true}
  if(f==='conductor'){const x=regFind('conductores',v);if(x){dueno(x);if(!String(h.trailer||'').trim())put('placas',x.placas)}}
  if(f==='trailer'){const x=regFind('trailers',v);if(x){dueno(x);put('placas',x.placas)}}
  if(f==='caja'){const x=regFind('cajas',v);if(x){dueno(x);put('placasCaja',x.placas)}}
  let bi=false;const b=(o.bi=o.bi||{});
  if(f==='cliente'&&v){setCliente(o,v);re=true}
  if(f==='transporte'&&v&&(!b.naviera||regFind('transportistas',b.naviera))&&b.naviera!==v){b.naviera=v;bi=true}
  if(f==='caja'&&v&&(!b.contenedor||regFind('cajas',b.contenedor))&&b.contenedor!==v){b.contenedor=v;bi=true}
  if(re||bi){touch(o);render()}
}
/* desde Registro de empaque: cliente, naviera o transportista y contenedor o termo alimentan el encabezado de Trazabilidad */
function onOrderLink(el){
  const b=el.dataset.bind,v=String(el.value||'').trim(),o0=cur();if(!o0||ro||!v)return;
  const o=mainOf(o0),h=ensureTraz(o).hdr;let ch=false;
  const put=(k,val)=>{val=String(val==null?'':val).trim();if(val&&h[k]!==val){h[k]=val;ch=true}};
  if(b==='o.customer'){setCliente(o,v);put('cliente',v)}
  if(b==='ob.naviera'){const t=regFind('transportistas',v);if(t){if(!String(h.transporte||'').trim()||regFind('transportistas',h.transporte)){put('transporte',t.n);put('telTransporte',t.tel);put('caat',t.caat);put('alpha',t.alpha)}}else if(!String(h.transporte||'').trim())put('transporte',v)}
  if(b==='ob.contenedor'){const x=regFind('cajas',v);if(x){if(!String(h.caja||'').trim()||regFind('cajas',h.caja)){put('caja',x.n);put('placasCaja',x.placas);if(x.transporte&&!String(h.transporte||'').trim()){put('transporte',x.transporte);const t=regFind('transportistas',x.transporte);if(t){put('telTransporte',t.tel);put('caat',t.caat);put('alpha',t.alpha)}}}}else if(!String(h.caja||'').trim())put('caja',v)}
  if(ch||b==='o.customer'){touch(o);render()}
}
$app.addEventListener('change',e=>{const el=e.target;if(el&&el.dataset&&/^(o\.customer|ob\.naviera|ob\.contenedor)$/.test(el.dataset.bind||''))onOrderLink(el)});
/* ---------- salidas calculadas ---------- */
function difChip(r){
  if(r.err)return{text:'Revisa conteo',cls:'crit'};
  if(r.dif==null)return{text:'Sin kilos',cls:''};
  const tol=Math.max(3,(r.campo||0)*0.03);
  return{text:'Dif '+(r.dif>0?'+':'')+fmt(r.dif,1),cls:Math.abs(r.dif)<=tol?'good':'warn'};
}
function manChip(d,man){
  if(man==null)return{text:'–',cls:''};
  if(d===0)return{text:'Completo',cls:'good'};
  return d>0?{text:'+'+fmt(d)+' sobran',cls:'info'}:{text:fmt(-d)+' faltan',cls:'warn'};
}
function outFor(key,M,by,o){
  const p=key.split('.');
  switch(p[0]){
    case 'b':{const r=by[p[1]],x=r&&r.byT[p[2]];return x?{text:fmt(x.before[p[3]])}:null}
    case 'ptt':{const r=by[p[1]],x=r&&r.byT[p[2]];return x?{text:fmt(x.t)}:null}
    case 'd':{const r=by[p[1]],x=r&&r.byT[p[2]];if(!x)return null;const d=x.delta[p[3]];return{text:d===0?'–':(d>0?'+':'')+fmt(d),cls:d<0?'neg':d===0?'zero':''}}
    case 'pt':{const r=by[p[1]];return r?{text:fmt(r.t)+' cajas'}:null}
    case 'ptot':{const r=by[p[1]];return r?{text:fmt(r.t)}:null}
    case 'psll':{const r=by[p[1]];return r?{text:segLlevoTxt(r.p)}:null}
    case 'pn':{const r=by[p[1]];return r?{text:r.p.nombre||'Sin nombre'}:null}
    case 'pc':{const r=by[p[1]];return r?{text:r.campo==null?'Captura los kilos para ver las cajas campo.':'Cajas campo ≈ '+fmt(r.campo,1)+' (kilos ÷ '+M.kg+')'+(r.kgE>0?' · Empacado ≈ '+fmt(r.kgE,0)+' kg ('+r.tipos.map(t=>TIPO_L[t]+' × '+fmt(M.W[t],2)).join(', ')+')':'')}:null}
    case 'pd':{const r=by[p[1]];return r?difChip(r):null}
    case 'ptz':{const r=by[p[1]];if(!r||!o)return null;const z=trazCalc(o),pk=prodKey(o,r.p),x=concordTxt(z,pk,o.variante,sheetsOf(o).every(y=>y.estado==='completo'));return x?{text:x.text,cls:x.cls}:{text:'Todavía no hay tarimas ni calibres de este productor.',cls:''}}
    case 'pse':{const r=by[p[1]];if(!r)return null;const t=pseTxt(r.p,p[2]);return {text:t,cls:/Falta el peso/.test(t)?'warn':''}}
    case 'pkg':{const r=by[p[1]];return r?{text:r.p.kilos==null?'—':fmt(n0(r.p.kilos),n0(r.p.kilos)%1?1:0)}:null}
    case 'pkw':{const r=by[p[1]];if(!r)return null;const x=r.p.sob||r.p.sob2||r.p.segLot||+r.p.codigo===SEG_COD?null:kgCajaChk(r.p.kilos,r.p.k18,r.p.k24);return {text:kgCajaTxt(x),cls:x?'on':''}}
    case 'sf':return{text:fmt(M.final[p[1]])}
    case 'stp':{const v=(M.byTipo[p[1]]||{})[p[2]]||0;return{text:v?fmt(v):'–'}}
    case 'sd':return manChip(M.final[p[1]]-(M.man[p[1]]||0),M.man[p[1]]);
    case 'mf':return{text:fmt((M.byTipo[p[1]]||{})[p[2]]||0)}
    case 'md':{const m=M.manBy[p[1]],mv=m?m[p[2]]:null;return manChip(((M.byTipo[p[1]]||{})[p[2]]||0)-(mv||0),mv)}
    case 'mtm':return{text:fmt((M.manBy[p[1]]||{}).t||0)}
    case 'mtf':return{text:fmt((M.byTipo[p[1]]||{}).t||0)}
    case 'mtd':{const m=M.manBy[p[1]];return m?manChip(((M.byTipo[p[1]]||{}).t||0)-m.t,0):{text:'Captura el manifiesto',cls:''}}
    case 'mch':{const m=M.manBy[p[1]],b=M.byTipo[p[1]];return{text:m?fmt(m.t):(b&&b.t?fmt(b.t)+' emp.':'')}}
    case 'sman':return{text:fmt(M.manT)}
    case 'sfin':return{text:fmt(M.finT)}
    case 'sdt':{const any=CAL.some(c=>M.man[c.k]!=null);return any?manChip(M.finT-M.manT,0):{text:'Captura el manifiesto',cls:''}}
    case 'st':return{text:fmt(M.tot[p[1]])}
    case 'pinv':{const r=by[p[1]];return r?{text:invNote(r.p)}:null}
    case 'h':
      if(p[1]==='cod')return{text:o.cod||'—'};
      if(p[1]==='emb')return{text:o.emb||'—'};
      return{text:'PO '+(o.po||'—')+' · Semana '+(o.semana||'—')+' · '+fmtDate(o.fecha)};
  }
  return null;
}
function updateDerived(){
  const o=cur();if(!o)return;
  const M=compute(o);const by={};M.rows.forEach(r=>by[r.p.id]=r);
  $app.querySelectorAll('[data-out]').forEach(el=>{
    const r=outFor(el.dataset.out,M,by,o);
    if(!r)return;
    el.textContent=r.text;
    if(el.dataset.base!==undefined)el.className=el.dataset.base+(r.cls?' '+r.cls:'');
  });
  const mo=document.getElementById('manov');if(mo)mo.innerHTML=manOverview(o);
  $app.querySelectorAll('[data-phk]').forEach(el=>{const q=el.dataset.phk.split('.');const x=by[q[0]]&&by[q[0]].byT[q[1]];if(x)el.placeholder=String(x.before[q[2]])});
}

/* ---------- lista de productores ---------- */
function searchLista(q){
  q=norm(q).trim();const toks=q.split(/\s+/);
  const res=LISTA.filter(x=>{const h=norm('vl-'+pad(x.c,3)+' ec-'+pad(x.c,3)+' '+x.c+' '+x.n);return toks.every(t=>h.includes(t))});
  res.sort((a,b)=>{const an=norm(a.n).startsWith(toks[0])?0:1,bn=norm(b.n).startsWith(toks[0])?0:1;return an-bn||a.n.localeCompare(b.n)});
  return res.slice(0,10);
}
function recents(){
  const seen=new Set(),out=[];
  visible().sort((a,b)=>b.createdAt-a.createdAt).slice(0,4).forEach(o=>o.productores.forEach(p=>{
    const k=norm(p.nombre);if(!k||seen.has(k)||/^(ec|vl)-?(\d{4}-)?\d+$/.test(k))return;seen.add(k);out.push({c:p.codigo||null,n:p.nombre});
  }));
  return out.slice(0,8);
}
function resultsHtml(q){
  const has=q.trim().length>0;
  const items=has?searchLista(q):invFirst().concat(recents().filter(x=>!invFirst().some(y=>norm(y.n)===norm(x.n))));
  sheet.items=items;
  let h='';
  if(!has)h+=items.length?'<div class="sec" style="margin-top:6px">'+(items.some(x=>x.inv)?'Con fruta en inventario y recientes':'Recientes')+'</div>':'<p class="note">Escribe el nombre o el número del productor.</p>';
  h+=items.map((x,i)=>`<button class="res" data-act="pick:${i}"><span>${esc(x.n)}${x.inv?`<small class="invtag">En inventario: ${esc(invTxt(x.inv.av))}</small>`:''}</span><span class="mono">${x.c?codeLabel(x.c,(cur()||{emp:emp}).emp):'sin código'}</span></button>`).join('');
  if(has)h+=`<button class="res" data-act="pickfree"><span>Agregar «${esc(q.trim())}» sin buscar en la lista</span><span class="mono">nuevo</span></button>`;
  return h;
}
/* ---------- pedidos nuevos ---------- */
/* Consecutivo interno: VL-189. Cada empresa lleva el suyo y vuelve a 1 cada año. */
function nextCons(e,y){let mx=0;visible().forEach(o=>{if(o.emp===e&&+o.anio===+y&&(o.cons||0)>mx)mx=o.cons});return mx+1}
/* Código de embarque: VL264101 = empresa + año + semana + número de empaque de esa semana. */
function nextPed(e,y,w){const s=new Set();visible().forEach(o=>{if(o.emp===e&&+o.anio===+y&&String(o.semana)===String(w))s.add(o.emb)});return s.size+1}
function newDefaults(){
  const fecha=todayISO(),y=fecha.slice(0,4),w=isoWeek(fecha);
  const last=mine().sort((a,b)=>b.createdAt-a.createdAt)[0]||visible().sort((a,b)=>b.createdAt-a.createdAt)[0];
  const cu=last?last.customer:(emp==='VL'?'VERALIMES USA':'');
  return{emp:emp,hojas:'1',fecha,semana:w,nEC:nextCons(emp,y),nPed:nextPed(emp,y,w),po:'',factura:nextFactura(cu),facAuto:true,customer:cu,domestic:last?last.domestic:''};
}
/* Hoja: EC-2026-182 (empresa, año y consecutivo del año). Embarque: JC264601 (Citrilar) o VL264601 (Vera Limes) = prefijo + año + semana + empaque de la semana. */
const EMB_PRE={EC:'JC',VL:'VL'};
function codOf(e,y,cons){return e+'-'+y+'-'+(cons==null?'':cons)}
function embOf(e,y,w,n){return (EMB_PRE[e]||e)+String(y).slice(2)+pad(w||0,2)+pad(n||0,2)}
function codesFrom(d){
  const e=d.emp||emp,y=String(d.fecha||'').slice(0,4);
  return{emp:e,anio:+y||null,cons:num(d.nEC),cod:codOf(e,y,num(d.nEC)),emb:embOf(e,y,d.semana,d.nPed)};
}
/* Factura por cliente: la siguiente después de la última de ese cliente (VM20179 → VM20180) */
function nextFactura(cust){
  const k=norm(cust||'').trim();if(!k)return '';
  const last=visible().filter(o=>norm(o.customer||'').trim()===k&&String(o.factura||'').trim()).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0))[0];
  if(!last)return '';const f=String(last.factura).trim(),m=f.match(/^(.*?)(\d+)$/);
  return m?m[1]+String(+m[2]+1).padStart(m[2].length,'0'):'';
}
function datalist(id,key){
  const vals=[...new Set(visible().map(o=>o[key]).filter(Boolean).concat(key==='customer'?REG.clientes.map(x=>x.n):[]))];
  return `<datalist id="${id}">${vals.map(v=>`<option value="${esc(v)}">`).join('')}</datalist>`;
}
function newSheetHtml(){
  const d=sheet.d,c=codesFrom(d),E=EMPS[d.emp||emp];
  const f=(l,k,t,list)=>`<label class="fld" for="n-${k}"><span>${l}</span><input class="in${t==='text'?' txt':''}" id="n-${k}" type="${t==='date'?'date':'text'}" ${t==='num'?'inputmode="numeric"':''}${list?` list="${list}"`:''} autocomplete="off" data-sf="${k}" value="${esc(d[k])}"></label>`;
  return `<h3>Nuevo pedido · ${esc(E.name)}</h3>${empToggle(d.emp||emp,'nemp','Empresa')}<div class="grid2">${f('Fecha','fecha','date')}${f('Semana','semana','num')}${f('Consecutivo del año ('+E.id+')','nEC','num')}${f('Empaque de la semana','nPed','num')}${f('PO (si el cliente lo da)','po','text')}${f('Factura (sigue la del cliente)','factura','text')}</div>${f('Cliente','customer','text','dl-cust')}${f('Cliente doméstico','domestic','text','dl-dom')}${datalist('dl-cust','customer')}${datalist('dl-dom','domestic')}<label class="fld" for="n-hojas"><span>Hojas que se crean</span><select class="in sel" id="n-hojas" data-sf="hojas"><option value="1"${(d.hojas||'1')==='1'?' selected':''}>Hoja 1 (primeras)</option><option value="1.5"${d.hojas==='1.5'?' selected':''}>Solo hoja 1.5 (todo segundas)</option><option value="ambas"${d.hojas==='ambas'?' selected':''}>Hoja 1 y hoja 1.5</option></select></label><div class="panel"><div class="k">Códigos que se generan</div><div class="mono" id="newprev" style="margin-top:6px;font-weight:600">${esc(c.cod)} · ${esc(c.emb)}</div><p class="note" style="margin-top:6px">Puedes corregir los números si el empaque ya traía otro consecutivo.</p></div><div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="create">Crear pedido</button></div>`;
}

/* ---------- ejemplo ---------- */
function loadExample(){
  if(cfgOK()){toast('Con la base de datos conectada no se cargan ejemplos: se mezclarían con los pedidos reales');return}
  const base={emp:emp,anio:2026,cons:163,cod:codOf(emp,2026,163),emb:embOf(emp,2026,38,2),po:'3872',fecha:'2026-09-17',semana:38,customer:'CITRICOS J&C LLC',domestic:'VILLAMEX FARMS LLC',factura:'VM-26161',ejemplo:true};
  const o=newOrder(base);
  /* manifiesto por tipo: RPC por calibre y 240 cajas de cartón de 230 */
  o.manT={RPC:{c250:85,c230:150,c200:375,c175:225,c150:115,c110:50},CTN:{c230:240}};syncManSum(o);
  const D=[
    [codOf(emp,2026,162),null,null,214,3852,[17,61,69,35,20,12],null,null,null,'Sobrante del pedido anterior'],
    ['LUCIANO CALLES',6,19,null,471,[20,69,73,37,20,13],8,null,null,''],
    ['MELISA SANCHEZ',null,null,102,1777,[24,81,90,57,35,22],20,null,2,''],
    ['JOSE ANTONIO S',57,71,null,1310,[38,89,116,65,38,23],12,null,1,''],
    ['SALATIEL',156,474,null,11820,[68,95,291,164,81,43],69,null,5,'',{c230:240}],
    ['RIGOBERTO MORENO',209,null,200,3200,[74,130,349,210,106,53],null,null,null,'se llevo sus 2 das 29.5'],
    ['EMILIO NAVARRO',4,43,null,1044,[82,145,359,216,110,54],13,null,1,''],
    ['PRIMITIVO TOLENTINO',null,null,31,590,[83,152,369,223,113,55],4,null,null,''],
    ['ROBERTO REBOLLAR',null,null,25,480,[85,160,375,225,115,56],5,null,1,'']
  ];
  const CK=['c250','c230','c200','c175','c150','c110'];
  const mk=(sh,d)=>{const p=newProd(d[0],d[1],d[9]);p.k24=d[2];p.k18=d[3];p.kilos=d[4];CK.forEach((k,i)=>{p.acc[k]=d[5][i]||null});p.seg=d[6];p.tor=d[7];p.des=d[8];if(d[10]){p.tipos=['RPC','CTN'];Object.assign(accOf(p,'CTN',true),d[10])}sh.productores.push(p)};
  D.forEach(d=>mk(o,d));
  orders.push(o);touch(o);
  /* hoja 1-1/2: segunda en RPC */
  const s2=newOrder(Object.assign({variante:'1.5'},base));
  s2.manT={RPC:{c230:60,c200:90,c175:50}};syncManSum(s2);
  [['SALATIEL',156,null,null,null,[0,40,60,30,0,0],null,null,null,''],['RIGOBERTO MORENO',209,null,null,null,[0,62,92,52,0,0],null,null,null,'']].forEach(d=>mk(s2,d));
  orders.push(s2);touch(s2);
  /* tarimas de muestra para el manifiesto y el packing list */
  const mks=MARCAS[emp]||MARCAS.VL,t=ensureTraz(o),L=(cal,cant,prod)=>({id:uid(),cal:cal,cant:cant,prod:prod});
  t.hdr.cliente='CITRICOS J&C LLC';t.hdr.poCliente='3872';
  t.tarimas.push({id:uid(),marca:mks[0],empaque:'RPC',lines:[L('200',50,emp+'-156')]});
  t.tarimas.push({id:uid(),marca:mks[0],empaque:'RPC',lines:[L('200',30,emp+'-156'),L('175',20,emp+'-156')]});
  t.tarimas.push({id:uid(),marca:mks[0],empaque:'CTN',lines:[L('230',50,emp+'-156')]});
  t.tarimas.push({id:uid(),marca:mks[1],empaque:'1.5',lines:[L('200',30,emp+'-209'),L('200',20,emp+'-156')]});
  touch(o);
  curId=o.id;view='order';tab='captura';openP=null;render();
}

/* ---------- estadísticas ---------- */
const MESES=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const isSob=p=>!!p.sob2||!p.codigo&&/^(ec|vl)-?(\d{4}-)?\d+$/.test(norm(p.nombre).trim());
function periodOf(f){const w=!!f.week&&f.week!=='ALL',c=!w&&!!(f.desde||f.hasta);return{custom:c,year:c||w?'ALL':f.year,month:c||w?'ALL':f.month,desde:w?'':f.desde||'',hasta:w?'':f.hasta||'',week:w?f.week:'ALL'}}
/* Filtro combinado exacto del requerimiento; el periodo personalizado manda sobre año y mes. */
/* v8.16: con pedidos reales, los de ejemplo no entran en Estadísticas ni en Finanzas */
function exMix(){return orders.some(o=>!o.deleted&&!o.ejemplo)}
function statsList(f,over){
  const g=Object.assign({},f,periodOf(f),over||{}),xm=exMix();
  return orders.filter(o=>!o.deleted&&(!o.ejemplo||!xm)&&(g.emp==='ALL'||o.emp===g.emp)&&(g.cal==='ALL'||o.variante===g.cal)&&(g.year==='ALL'||String(o.anio)===String(g.year))&&(g.month==='ALL'||String(o.fecha||'').slice(5,7)===g.month)&&(!g.desde||(o.fecha||'')>=g.desde)&&(!g.hasta||(o.fecha||'')<=g.hasta)&&(!g.week||g.week==='ALL'||wkOf(o)===g.week));
}
function aggregate(list){
  const prods=new Map(),T={hojas:list.length,pedidos:new Set(list.map(o=>o.emp+'|'+o.cod)).size,kilos:0,exp:0,seg:0,tor:0,des:0,eqv:0,campoR:0,cal:{}};
  CAL.forEach(c=>T.cal[c.k]=0);
  list.forEach(o=>{
    const M=compute(o);
    M.rows.forEach(r=>{
      const p=r.p;
      if(p.sob2||!p.codigo&&/^(ec|vl)-?(\d{4}-)?\d+$/.test(norm(p.nombre).trim()))return; /* sobrante heredado: ya cuenta en el pedido que lo empacó */
      const key=pKey(p);
      let a=prods.get(key);
      if(!a){const pc=pCode(p),li=pc?LISTA.find(x=>x.c===pc):null;a={key:key,codigo:pc||null,nombre:(li&&li.n)||p.nombre||'Sin nombre',ped:new Set(),kilos:0,exp:0,seg:0,tor:0,des:0,eqv:0,campoR:0,cal:{}};CAL.forEach(c=>a.cal[c.k]=0);prods.set(key,a)}
      a.ped.add(o.emp+'|'+o.cod);a.kilos+=n0(p.kilos);a.exp+=r.t;a.seg+=segC(p);a.tor+=n0(p.tor);a.des+=n0(p.des);a.jug=(a.jug||0)+n0(p.jug);
      CAL.forEach(c=>{const d=Math.max(0,r.delta[c.k]);a.cal[c.k]+=d;T.cal[c.k]+=d});
      if(r.rend!=null){a.eqv+=r.eqv;a.campoR+=r.campo;T.eqv+=r.eqv;T.campoR+=r.campo}
      T.kilos+=n0(p.kilos);T.exp+=r.t;T.seg+=segC(p);T.tor+=n0(p.tor);T.des+=n0(p.des);T.jug=(T.jug||0)+n0(p.jug);
    });
  });
  const rows=[...prods.values()];
  rows.forEach(a=>{a.rend=a.campoR>0?a.eqv/a.campoR:null});
  T.rend=T.campoR>0?T.eqv/T.campoR:null;
  return{rows:rows,T:T,map:prods,list:list};
}
const dayAdd=(s,n)=>{const d=new Date(s+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)};
const dayDiff=(a,b)=>Math.round((new Date(b+'T12:00:00Z')-new Date(a+'T12:00:00Z'))/86400000);
/* Periodo de comparación automático */
function refPeriod(f){
  if(f.week&&f.week!=='ALL'){const k=wkPrevYear(f.week);return{over:{week:k,year:'ALL',month:'ALL',desde:'',hasta:''},label:'la misma semana de '+k.slice(0,4)}}
  if(f.desde||f.hasta){
    if(!(f.desde&&f.hasta))return null;
    const days=dayDiff(f.desde,f.hasta)+1,h=dayAdd(f.desde,-1),d=dayAdd(f.desde,-days);
    return{over:{year:'ALL',month:'ALL',desde:d,hasta:h},label:'el periodo anterior de '+days+' días ('+fmtDate(d)+' al '+fmtDate(h)+')'};
  }
  if(f.year!=='ALL'){
    const y=String(+f.year-1);
    return f.month!=='ALL'?{over:{year:y,month:f.month,desde:'',hasta:''},label:MESES[+f.month-1]+' de '+y}:{over:{year:y,month:'ALL',desde:'',hasta:''},label:'el año '+y};
  }
  return null;
}
function statsData(){
  const f=statsF;if(!f.emp)f.emp=emp;
  const key=[f.emp,f.cal,f.year,f.month,f.desde,f.hasta,f.week].join('|');
  if(f._cache&&f._cache.key===key)return f._cache.data;
  const cur=aggregate(statsList(f)),rp=refPeriod(f);
  let ref=null;
  if(rp){const r=aggregate(statsList(f,rp.over));if(r.T.hojas>0)ref={agg:r,label:rp.label}}
  const data={f:f,cur:cur,ref:ref,hasRef:!!rp,fin:finAgg(cur.list),finRef:ref?finAgg(ref.agg.list):null};
  f._cache={key:key,data:data};
  return data;
}
const ppV=(a,b)=>(a==null||b==null)?null:(a-b)*100;
const relV=(a,b)=>(b>0)?(a-b)/b*100:null;
function varChip(v,unit,good){ /* good: 'up' favorable al subir, 'down' favorable al bajar, null neutro */
  if(v==null)return '<span class="chip">Sin datos comparables</span>';
  const z=Math.abs(v)<(unit==='pp'?0.05:0.5);
  const cls=z||!good?'info':((v>0)===(good==='up')?'good':'warn');
  return `<span class="chip ${z?'':cls}">${z?'=':(v>0?'▲ +':'▼ ')}${z?'':fmt(Math.abs(v),1).replace(/^/,v<0?'−':'')}${z?' sin cambio':(unit==='pp'?' pp':' %')}</span>`;
}
function filtersHtml(D){
  const f=statsF;
  const years=[...new Set(visible().map(o=>o.anio).filter(Boolean))].sort((a,b)=>b-a);
  const wk=!!f.week&&f.week!=='ALL',custom=wk||!!(f.desde||f.hasta),wks=weekKeys(false).filter(k=>f.year==='ALL'||wk||k.slice(0,4)===String(f.year));
  const sel=(id,label,val,opts,dis)=>`<label class="fld" for="${id}"><span>${label}</span><select id="${id}" data-sf2="${id.replace('st-','')}"${dis?' disabled':''}>${opts.map(o=>`<option value="${o[0]}"${String(o[0])===String(val)?' selected':''}>${esc(o[1])}</option>`).join('')}</select></label>`;
  const chips=(f.desde?`<button class="rchip" data-act="clrd" aria-label="Quitar fecha desde">Desde ${fmtDate(f.desde)} ✕</button>`:'')+(f.hasta?`<button class="rchip" data-act="clrh" aria-label="Quitar fecha hasta">Hasta ${fmtDate(f.hasta)} ✕</button>`:'');
  return `<div class="filters">${sel('st-emp','Empresa',f.emp,[['VL','Vera Limes'],['EC','Citrilar'],['ALL','Ambas']])}${sel('st-cal','Calidad del empaque',f.cal,[['ALL','Todas'],['1','Primera (1)'],['1.5','Segundas']])}${sel('st-year','Año',f.year,[['ALL','Todos']].concat(years.map(y=>[y,y])),custom)}${sel('st-month','Mes',f.month,[['ALL','— (todo el año)']].concat(MESES.map((m,i)=>[pad(i+1,2),m.charAt(0).toUpperCase()+m.slice(1)])),f.year==='ALL'||custom)}${sel('st-week','Semana',wk?f.week:'ALL',[['ALL','— (todas)']].concat(wks.map(k=>[k,wkLab(k)+(wkClosed(k)?' · cerrada':'')])))}</div>
<div class="perrow"><button class="btn sm" data-act="per" aria-expanded="${!!f._per}"${wk?' disabled':''}>Establecer periodo</button>${wk?'':chips}</div>${f._per&&!wk?`<div class="grid2 perbox"><label class="fld" for="st-desde"><span>Desde</span><input class="in txt" id="st-desde" type="date" data-sf2="desde" value="${esc(f.desde)}"></label><label class="fld" for="st-hasta"><span>Hasta</span><input class="in txt" id="st-hasta" type="date" data-sf2="hasta" value="${esc(f.hasta)}"></label></div>`:''}`;
}
function infoLine(D){
  const l=D.cur.list,f=statsF;
  const ds=l.map(o=>o.fecha).filter(Boolean).sort();
  const per=ds.length?'del '+fmtDate(ds[0])+' al '+fmtDate(ds[ds.length-1]):'sin fechas';
  const e=f.emp==='ALL'?'Ambas empresas':EMPS[f.emp].name;
  const c=f.cal==='ALL'?'Todas las calidades':f.cal==='1'?'Primera':'Segundas';
  return `Mostrando ${fmt(l.length)} ${l.length===1?'hoja':'hojas'} · ${fmt(D.cur.T.pedidos)} ${D.cur.T.pedidos===1?'pedido':'pedidos'} · ${per} · ${e} · ${c}`;
}
function tileHtml(label,val,sub,chip,tone){return `<div class="tile ${tone||''}"><span class="k">${label}</span><b>${val}</b>${sub?`<small>${sub}</small>`:''}${chip?`<div class="tv">${chip}</div>`:''}</div>`}
function wkPanelHtml(){
  return perAdmin()?(()=>{const k=wkcDefault(),S=wkStats(k),j=jugCandidates(k).reduce((s,l)=>s+l.av,0);return `<section class="dbpanel wkpanel"><div><strong>Cierre de semana</strong><small>${esc(wkLab(k))} ${wkClosed(k)?'cerrada':'abierta'} · ${S.ped} ${S.ped===1?'pedido':'pedidos'}${j?' · '+fmt(j)+' cajas de segunda irían a Juguera':''}</small></div><div class="pact" style="margin:0"><button class="btn" data-act="peropen">Periodos</button><button class="btn primary" data-act="wkclose">Cerrar semana</button></div></section>`})():'';
}
function statsView(){
  const f=statsF;if(!f.emp)f.emp=emp;
  const D=statsData(),T=D.cur.T,R=D.ref?D.ref.agg.T:null;
  const nocmp='<span class="chip">Sin datos comparables</span>';
  const tiles=tileHtml('Hojas',fmt(T.hojas),fmt(T.pedidos)+(T.pedidos===1?' pedido':' pedidos'),R?varChip(relV(T.hojas,R.hojas),'%',null):nocmp)
   +tileHtml('Rendimiento ponderado',T.rend==null?'–':fmt(T.rend*100,1)+'%','primeras sobre cajas campo',R?varChip(ppV(T.rend,R.rend),'pp','up'):nocmp,T.rend==null?'':'')
   +tileHtml('Kilos recibidos',fmt(T.kilos),T.hojas?fmt(T.kilos/T.hojas)+' kg por hoja':'',R?varChip(relV(T.kilos,R.kilos),'%',null):nocmp)
   +tileHtml('Cajas exportación',fmt(T.exp),'segundas '+fmt(T.seg)+' · torreón '+fmt(T.tor)+' · desecho '+fmt(T.des)+(T.jug?' · juguera '+fmt(T.jug):''),R?varChip(relV(T.exp,R.exp),'%','up'):nocmp);
  const cmpTxt=D.ref?`Comparado con ${esc(D.ref.label)}.`:(D.hasRef?'Sin datos comparables en el periodo anterior.':'Sin datos comparables: elige un año, un mes o un periodo para comparar.');
  const vbtn=(k,t)=>`<button class="btn sm" data-act="vw:${k}" aria-pressed="${f.view===k}">${t}</button>`;
  const dirBtn=`<button class="btn sm" data-act="dir" aria-label="Invertir orden" title="Invertir orden">↑↓ ${f.dir==='desc'?'Mayor primero':'Menor primero'}</button>`;
  let body;const fin=false,bi=false;
  if(!T.hojas)body=`<section class="empty"><h2>Sin datos con estos filtros</h2><p>Las estadísticas se llenan solas con cada empaque que registres.</p>${bi&&!ro&&!cfgOK()?'<button class="btn" data-act="biexample" data-edit>Cargar historial de ejemplo</button>':''}</section>`;
  else body=bi?biView(D):fin?finView(D):f.view==='cal'?calView(D):prodView(D);
  const tabs='';
  const wkp='';
  return topbar('Estadísticas','menu')+`<main class="wrap"><section class="dbpanel"><div><strong>Base de datos completa</strong><small>Todo el histórico de ambas empresas, listo para Excel.</small></div><button class="btn primary dbbtn" data-act="dbopen">Descargar Base de Datos</button></section>${wkp}
${filtersHtml(D)}<p class="statline" role="status">${infoLine(D)}</p>${tabs}${fin?`<p class="note" style="margin-top:8px">${cmpTxt}</p>${body}</main>`:`<div class="tiles">${tiles}</div><p class="note" style="margin-top:8px">${cmpTxt}</p>
<div class="srt">${vbtn('rend','Por rendimiento')}${vbtn('kilos','Por kilos')}${vbtn('cal','Por calibres')}${dirBtn}</div>${body}<p class="note" style="margin-top:12px">Rendimiento de primeras = cajas de calibre ÷ cajas campo (kilos ÷ ${KG_DEF}), sumando primero todo el periodo y dividiendo una sola vez. Solo cuenta productores con kilos capturados.</p></main>`}`;
}
function prodView(D){
  const f=statsF,T=D.cur.T,dir=f.dir==='asc'?1:-1;
  const val=a=>f.view==='kilos'?a.kilos:(a.rend==null?-1:a.rend);
  const rows=D.cur.rows.slice().sort((a,b)=>((val(a)-val(b))*dir)||a.nombre.localeCompare(b.nombre));
  return `<div class="sec">${f.view==='kilos'?'Por kilos aportados':'Por rendimiento'} · ${rows.length} ${rows.length===1?'productor':'productores'}</div><div class="cgrid">`+rows.map(a=>{
    const r=D.ref?D.ref.agg.map.get(a.key):null;
    let big,vch;
    if(f.view==='kilos'){big=T.kilos>0?fmt(a.kilos/T.kilos*100,1)+'%':'–';vch=r&&r.kilos>0?varChip(relV(a.kilos,r.kilos),'%',null):nocmpChip();}
    else{big=a.rend==null?'–':fmt(a.rend*100,1)+'%';vch=r&&r.rend!=null&&a.rend!=null?varChip(ppV(a.rend,r.rend),'pp','up'):nocmpChip();}
    const share=T.exp>0?fmt(a.exp/T.exp*100,1)+'%':'–';
    return `<div class="prd"><div class="r1"><div class="pnm">${esc(a.nombre)}<small>${a.codigo?'#'+pad(a.codigo,3):'sin código'} · ${a.ped.size} ${a.ped.size===1?'pedido':'pedidos'}</small></div><div class="rend" title="${f.view==='kilos'?'Parte de los kilos del periodo':'Rendimiento ponderado'}">${big}<small>${f.view==='kilos'?'de los kilos':'rendimiento'}</small></div></div><div class="r2">${fmt(a.kilos)} kg · exportación ${fmt(a.exp)} cajas · segundas ${fmt(a.seg)} · Torreón ${fmt(a.tor)} · desecho ${fmt(a.des)}</div><div class="r3"><span>Aporta ${fmt(a.exp)} cajas de ${fmt(T.exp)} totales, ${share}</span>${vch}</div></div>`;
  }).join('')+'</div>';
}
function nocmpChip(){return '<span class="chip">Sin datos comparables</span>'}
function calView(D){
  const f=statsF,T=D.cur.T,dir=f.dir==='asc'?1:-1;
  const list=CAL.filter(c=>(!isMM(c.k)&&c.k!=='ctn')||T.cal[c.k]>0).map(c=>({c:c,n:T.cal[c.k]})).sort((a,b)=>((a.n-b.n)*dir)||a.c.l.localeCompare(b.c.l));
  return `<div class="sec">Distribución por calibre</div>`+list.map(x=>{
    const k=x.c.k,pct=T.exp>0?x.n/T.exp*100:0,open=openCal===k;
    let inner='';
    if(open){
      const ps=D.cur.rows.filter(a=>a.cal[k]>0).sort((a,b)=>((b.cal[k]-a.cal[k])*(f.dir==='asc'?-1:1))||a.nombre.localeCompare(b.nombre));
      inner=`<div class="calbody">${ps.length?ps.map(a=>{
        const r=D.ref?D.ref.agg.map.get(a.key):null;
        const inCal=x.n>0?a.cal[k]/x.n*100:0,calIn=a.exp>0?a.cal[k]/a.exp*100:0;
        return `<div class="crow"><div class="cn">${esc(a.nombre)}<small>${a.codigo?'#'+pad(a.codigo,3):'sin código'}</small></div><div class="cv">${fmt(a.cal[k])} cajas</div><div class="cp"><span>Aporte al calibre ${x.c.l}: <b>${fmt(inCal,1)}%</b></span><span>Peso del ${x.c.l} en el productor: <b>${fmt(calIn,1)}%</b></span></div><div class="cd">${r&&r.cal[k]>0?varChip(relV(a.cal[k],r.cal[k]),'%',null):nocmpChip()}</div></div>`}).join(''):'<p class="note">Ningún productor aportó este calibre.</p>'}</div>`;
    }
    return `<div class="cacc"><button class="chead" data-act="calo:${k}" aria-expanded="${open}"><span class="cl">${x.c.l}</span><span class="cbar" role="img" aria-label="${fmt(pct,1)}% de la exportación"><i style="width:${pct.toFixed(2)}%"></i></span><span class="cn2"><b>${fmt(x.n)}</b> cajas<small>${fmt(pct,1)}% de la exportación</small></span></button>${inner}</div>`;
  }).join('')+`<p class="note" style="margin-top:8px">Porcentajes: el del encabezado es la participación del calibre en la exportación del periodo; al abrirlo ves cuánto aporta cada productor a ese calibre y cuánto pesa el calibre dentro de cada productor.</p>`;
}
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset||!t.dataset.sf2)return;
  const k=t.dataset.sf2,v=t.value;
  if(k==='desde'||k==='hasta'){
    statsF[k]=/^\d{4}-\d{2}-\d{2}$/.test(v)?v:'';
    if(statsF.desde&&statsF.hasta&&statsF.desde>statsF.hasta){const x=statsF.desde;statsF.desde=statsF.hasta;statsF.hasta=x}
  }else{
    statsF[k]=v;
    if(k==='year'&&v==='ALL')statsF.month='ALL';
  }
  invalidateStats();saveStatsF();render();
});

/* ---------- finanzas: precios y costos (catálogo «finanzas», solo el administrador los cambia) ---------- */
const LS_FIN='empaque-finanzas';
function finDefaults(){
  /* valores de ejemplo para ver la sección funcionando; el administrador los ajusta en «Precios y costos» */
  const e=()=>({tc:18.5,venta:{RPC:{'1':22,'1.5':16},CTN:{'1':24,'1.5':18},CTN10:{'1':14,'1.5':10},PLT:{'1':22,'1.5':16}},kg:8,seg:120,tor:90,mat:{RPC:12,CTN:28,CTN10:14,PLT:20},mo:9,flete:52000,cruce:6500,cal:{}});
  return {VL:e(),EC:e(),ejemplo:true,ts:0,dirty:false,v:2};
}
let FIN=finDefaults();
(function(){try{const r=JSON.parse(localStorage.getItem(LS_FIN)||'null');if(r&&r.VL&&r.EC)FIN=Object.assign(finDefaults(),r)}catch(e){}finMigrate()})();
/* v7.0 guardaba flete y cruce en dólares; desde v7.1 todos los costos van en pesos */
function finMigrate(){if(FIN.v===2)return;['VL','EC'].forEach(e=>{const F=FIN[e];if(!F)return;if(FIN.ejemplo){F.flete=52000;F.cruce=6500}else{const tc=+F.tc||0;F.flete=Math.round((+F.flete||0)*tc);F.cruce=Math.round((+F.cruce||0)*tc)}F.cal=F.cal||{}});FIN.v=2}
/* calibres que lleva cada tipo de empaque */
/* el cartón ya es un tipo de empaque: CTN usa los mismos calibres (250, 230, 200…), sin la vieja fila «230 CTN» */
function calsForTipo(t){return t==='CTN10'?CAL_MM:CAL_STD.filter(c=>c.k!=='ctn')}
/* precio de venta en dólares por caja: el del calibre si está capturado, si no el general del tipo y calidad */
function precioUSD(F,tp,q,ck){const c=F.cal&&F.cal[tp]&&F.cal[tp][q],v=c?c[ck]:null;return v!=null&&v!==''&&isFinite(+v)?+v:(((F.venta[tp]||{})[q])||0)}
function saveFin(stamp){if(stamp){FIN.ts=Date.now();FIN.dirty=true;FIN.ejemplo=false}try{localStorage.setItem(LS_FIN,JSON.stringify(FIN))}catch(e){}invalidateStats();setSync()}
async function syncFin(){
  try{
    if(FIN.dirty&&!ro&&isAdmin()){
      await sb('/rest/v1/catalogos?on_conflict=clave',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{clave:'finanzas',updated_at:FIN.ts,data:{VL:FIN.VL,EC:FIN.EC,v:2,par:{VL:(parVer('VL',curWk())||{}).id||'',EC:(parVer('EC',curWk())||{}).id||''}}}]});
      FIN.dirty=false;saveFin(false);
    }
    const r=await sb('/rest/v1/catalogos?select=updated_at,data&clave=eq.finanzas');
    if(r&&r[0]&&r[0].data&&r[0].data.VL&&Number(r[0].updated_at)>(FIN.ts||0)&&!FIN.dirty){remoteN++;FIN.VL=r[0].data.VL;FIN.EC=r[0].data.EC;FIN.ejemplo=false;FIN.ts=Number(r[0].updated_at);FIN.v=r[0].data.v||1;finMigrate();if(!r[0].data.par)parFromOld();saveFin(false)}
    finFromPar();
  }catch(e){}
}
/* ---------- v8.14 · peso por caja de cada tipo de empaque ----------
   Kilos de una caja empacada de cada presentación. Con ellos salen los kilos empacados, el rendimiento de primeras y la diferencia
   de cada productor en Registro de empaque y en su Excel. Se ajustan con el engrane de Registro de empaque (catálogo «pesos-empaque»;
   como Precios y costos, solo el administrador los cambia). Un pedido completo guarda los pesos con los que se completó (o.kgT);
   los pedidos en proceso usan los vigentes. */
/* v8.16 · «Pesos y equivalencias»: además del peso de cada tipo de empaque, aquí viven la caja de campo, la caja de segunda
   (segundas, Torreón, desecho y Juguera), la tara de la caja de plástico y el rango esperado de kilos por caja de campo para avisar dedazos.
   Todos los cálculos y los Excel los toman de aquí, así ya no hay pesos distintos escritos en cada lugar. */
const LS_PESOS='empaque-pesos';
const PESO_DEF={campo:17.8,RPC:17.8,CTN:16,CTN10:4.53,PLT:17.8,seg:18,tara:1.64,min:12,max:25,palRPC:50,palCTN:60,palCTN10:210,palPLT:50};
const PESO_KEYS=Object.keys(PESO_DEF);
const PESO_L={campo:'Caja de campo',RPC:'RPC',CTN:'CTN (cartón)',CTN10:'CTN 10 lb',PLT:'PLT (plástico)',seg:'Caja de segunda',tara:'Tara caja de plástico',min:'Mínimo kg/caja',max:'Máximo kg/caja',palRPC:'Tarima RPC',palCTN:'Tarima CTN',palCTN10:'Tarima CTN 10 lb',palPLT:'Tarima PLT'};
/* v8.17: cajas estándar por tarima según su presentación (la segunda 1-1/2 va en RPC) */
function palCap(tp){const t=tp==='1.5'?'RPC':tp,v=PESOS.kg['pal'+t];return v>0?Math.round(v):50}
function pesosClean(k){const o={};PESO_KEYS.forEach(t=>{const v=num(k&&k[t]);o[t]=v!=null&&v>0?v:PESO_DEF[t]});if(!(o.max>o.min)){o.min=PESO_DEF.min;o.max=PESO_DEF.max}return o}
let PESOS={kg:pesosClean(PESO_DEF),ts:0,dirty:false};
function applyPesos(){const K=PESOS.kg;KG_DEF=K.campo;SOB_KG=K.campo;SEG_KG=K.seg;TARA_KG=K.tara}
(function(){try{const r=JSON.parse(localStorage.getItem(LS_PESOS)||'null');if(r&&r.kg)PESOS={kg:pesosClean(r.kg),ts:+r.ts||0,dirty:!!r.dirty}}catch(e){}applyPesos()})();
function pesosOf(o){return pesosClean((o&&o.estado==='completo'&&o.kgT)||PESOS.kg)}
const pesosTxt=(k,keys)=>(keys||PESO_KEYS).map(t=>PESO_L[t]+' '+fmt(k[t],t.indexOf('pal')===0?0:2)+(t==='min'||t==='max'?'':t.indexOf('pal')===0?' cajas':' kg')).join(' · ');
function savePesos(stamp){if(stamp){PESOS.ts=Date.now();PESOS.dirty=true}applyPesos();try{localStorage.setItem(LS_PESOS,JSON.stringify(PESOS))}catch(e){}invalidateStats();setSync()}
/* aviso de captura: kilos entre cajas de campo (las grandes cuentan como 1.5 pequeñas, como en la hoja semanal de entrada) */
function kgCajaChk(kilos,k18,k24){const kg=num(kilos),c=n0(k18)+1.5*n0(k24);if(!(kg>0)||!(c>0))return null;const v=kg/c,K=PESOS.kg;return (v<K.min||v>K.max)?{v:v,min:K.min,max:K.max}:null}
function kgCajaTxt(x){return x?'Revisa kilos o cajas: salen '+fmt(x.v,1)+' kg por caja de campo y lo esperado es de '+fmt(x.min,0)+' a '+fmt(x.max,0)+' kg (las grandes cuentan como 1.5 pequeñas).':''}
async function syncPesos(){
  try{
    if(PESOS.dirty&&perAdmin()){
      await sb('/rest/v1/catalogos?on_conflict=clave',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{clave:'pesos-empaque',updated_at:PESOS.ts,data:{kg:PESOS.kg,v:1}}]});
      PESOS.dirty=false;savePesos(false);
    }
    const r=await sb('/rest/v1/catalogos?select=updated_at,data&clave=eq.pesos-empaque');
    if(r&&r[0]&&r[0].data&&r[0].data.kg&&Number(r[0].updated_at)>(PESOS.ts||0)&&!PESOS.dirty){remoteN++;PESOS.kg=pesosClean(r[0].data.kg);PESOS.ts=Number(r[0].updated_at);savePesos(false)}
    await syncDec();
  }catch(e){}
}
function pesosCanEdit(){return perAdmin()}
function kgempHtml(){
  const o=view==='order'?cur():null,ed=pesosCanEdit(),K=PESOS.kg,fz=o&&o.estado==='completo'&&o.kgT?pesosClean(o.kgT):null,same=fz&&PESO_KEYS.every(t=>fz[t]===K[t]);
  const lab={campo:'Caja de campo · kg',RPC:'RPC · kg por caja',CTN:'CTN (cartón) · kg por caja',CTN10:'CTN 10 lb · kg por caja',PLT:'PLT (plástico) · kg por caja',seg:'Caja de segunda · kg',tara:'Tara caja de plástico · kg',min:'Mínimo · kg por caja de campo',max:'Máximo · kg por caja de campo',palRPC:'RPC · cajas por tarima',palCTN:'CTN · cajas por tarima',palCTN10:'CTN 10 lb · cajas por tarima',palPLT:'PLT · cajas por tarima'};
  const inp=t=>`<label class="fld" for="kge-${t}"><span>${esc(lab[t])}</span><input class="in" id="kge-${t}" inputmode="decimal" autocomplete="off" value="${esc(String(K[t]))}" placeholder="${esc(String(PESO_DEF[t]))}"${ed?'':' readonly'} aria-label="${esc(lab[t])}"><small class="note">Predeterminado: ${fmt(PESO_DEF[t],2)}</small></label>`;
  return `<h3>Pesos y equivalencias</h3><p class="note" style="margin-bottom:6px">Todos los pesos que usa la app salen de aquí: cálculos, avisos y Excel.</p>
<div class="sec">Cajas empacadas</div><p class="note">Con ellos salen los kilos empacados, el rendimiento de primeras y la diferencia de cada productor, aquí y en el Excel del registro.</p>
<div class="grid2">${TIPO_K.map(inp).join('')}</div>
<div class="sec">Conversiones</div><p class="note">Caja de campo: kilos ÷ este peso = cajas campo (también los kilos de los sobrantes). Caja de segunda: kilos de segundas, Torreón, desecho, Juguera y del renglón CITRILAR SEGUNDAS. Tara: plástico de las cajas que van a Juguera (Excel de segundas de la semana).</p>
<div class="grid2">${['campo','seg','tara'].map(inp).join('')}</div>
<div class="sec">Aviso de captura</div><p class="note">Si los kilos entre las cajas de campo (grandes × 1.5 + pequeñas) salen fuera de este rango, la app avisa en Entrada de Fruta, en Registro de Empaque y en Pendientes.</p>
<div class="grid2">${['min','max'].map(inp).join('')}</div>
<div class="sec">Cajas por tarima</div><p class="note">Cantidad estándar de cajas de una tarima completa en Código de Trazabilidad, según su presentación. La segunda (1-1/2) va en RPC.</p>
<div class="grid2">${['palRPC','palCTN','palCTN10','palPLT'].map(inp).join('')}</div>
${fz&&!same?`<div class="panel info" style="margin-top:6px"><p class="note"><b>Este pedido ya está completo</b> y se calculó con: ${esc(pesosTxt(fz,TIPO_K.concat(['campo'])))}. Los pesos nuevos aplican a los pedidos en proceso; para aplicarlos aquí, reabre el registro.</p></div>`:''}
<p class="note" style="margin-top:8px">${ed?'Aplica a todos los pedidos en proceso y a los que se completen después. Los pedidos completos se quedan con los pesos con los que se completaron.':'Solo el administrador cambia estos pesos.'}</p>
<div class="srow2">${ed?'<button class="btn" data-act="kgdef">Restablecer predeterminados</button><button class="btn primary" data-act="kgsave">Guardar</button>':''}<button class="btn" data-act="closesheet">${ed?'Cancelar':'Cerrar'}</button></div>`;
}
function kgempSave(def){
  if(!pesosCanEdit())return;
  const nk={};
  for(const t of PESO_KEYS){
    if(def){nk[t]=PESO_DEF[t];continue}
    const i=document.getElementById('kge-'+t),v=num(i&&i.value);
    if(v==null||!(v>0)||v>(t.indexOf('pal')===0?1000:100)){toast('Escribe un valor válido en «'+PESO_L[t]+'»');if(i)i.focus();return}
    nk[t]=Math.round(v*1000)/1000;
  }
  if(def){PESO_KEYS.forEach(t=>{const i=document.getElementById('kge-'+t);if(i)i.value=String(nk[t])});toast('Valores predeterminados listos: toca Guardar');return}
  if(!(nk.max>nk.min)){toast('El máximo de kilos por caja debe ser mayor que el mínimo');return}
  const old=PESOS.kg,ch=PESO_KEYS.filter(t=>old[t]!==nk[t]);
  if(!ch.length){closeSheet();return}
  PESOS.kg=nk;savePesos(true);
  logAdd({k:'param',ctx:{t:'p',id:'',cod:'Pesos y equivalencias'},path:'pesos',lab:'Pesos y equivalencias',o:pesosTxt(old,ch),n:pesosTxt(nk,ch)});
  closeSheet();render();toast('Pesos guardados');
}
/* ---------- v8.16 · decisiones de dirección ----------
   Reglas con efecto en dinero que la app aplica sola y puntos del Excel manual que esperan respuesta. El administrador registra quién
   las aprobó, cuándo y la respuesta (catálogo «decisiones»). Mientras falten, salen en Pendientes y en los resultados que dependen de ellas. */
const LS_DEC='empaque-decisiones';
const DEC_ITEMS=[
  {k:'jug',g:'Regla',t:'La Juguera es venta del empaque',d:'Desde la v8.7.1 toda la Juguera (de corridas de primera, de hojas 1.5 y de las segundas que pasan al cerrar) es venta del empaque: no se le paga al productor y no cuenta como merma. Antes (v8.6) la Juguera de corridas de primera se pagaba al productor.',q:'¿Dirección la aprueba y los acuerdos con productores la respaldan?'},
  {k:'cera',g:'Regla',t:'La cera se paga como segunda',d:'Las segundas con cera se pagan al productor con el precio de Segundas de Clasificación.',q:'¿Dirección la aprueba?'},
  {k:'cierre',g:'Regla',t:'Al cerrar la semana, las segundas sin procesar se van a Juguera',d:'Las segundas y la cera que siguen disponibles al cerrar una semana se registran como venta a Juguera. Ahora el cierre muestra cajas y monto, y pide escribir la semana para confirmar.',q:'¿Dirección la aprueba?'},
  {k:'fv1',g:'FORMATO VIAJES',t:'Celda G18 (17.5)',d:'Tiene la etiqueta «MAQ. Y SEGURO», pero G19 la usa como tipo de cambio y E14 la multiplica por kilos como si fuera precio por kilo.',q:'¿Qué es G18: tipo de cambio, maquila o precio por kilo?'},
  {k:'fv2',g:'FORMATO VIAJES',t:'Columna F frente a G15:G24',d:'Las etiquetas de la columna F no corresponden a los valores de la columna G (kg por caja, 0.4, retorno 5, gastos 45).',q:'¿Qué representa cada valor de G15 a G24?'},
  {k:'fv3',g:'FORMATO VIAJES',t:'Celda L33',d:'L33 = J10 compara cajas campo con el peso de corrida; por la etiqueta parece que debía ser J8 (kilos de báscula). Así, M33 mezcla cajas con kilos.',q:'¿L33 debe tomar J8?'}];
let DEC={m:{},ts:0,dirty:false};
(function(){try{const r=JSON.parse(localStorage.getItem(LS_DEC)||'null');if(r&&r.m)DEC={m:r.m,ts:+r.ts||0,dirty:!!r.dirty}}catch(e){}})();
function saveDec(stamp){if(stamp){DEC.ts=Date.now();DEC.dirty=true}try{localStorage.setItem(LS_DEC,JSON.stringify(DEC))}catch(e){}setSync()}
async function syncDec(){
  try{
    if(DEC.dirty&&perAdmin()){await sb('/rest/v1/catalogos?on_conflict=clave',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{clave:'decisiones',updated_at:DEC.ts,data:{m:DEC.m,v:1}}]});DEC.dirty=false;saveDec(false)}
    const r=await sb('/rest/v1/catalogos?select=updated_at,data&clave=eq.decisiones');
    if(r&&r[0]&&r[0].data&&r[0].data.m&&Number(r[0].updated_at)>(DEC.ts||0)&&!DEC.dirty){remoteN++;DEC.m=r[0].data.m;DEC.ts=Number(r[0].updated_at);saveDec(false)}
  }catch(e){}
}
const decOk=k=>!!(DEC.m[k]&&DEC.m[k].by);
const decPend=()=>DEC_ITEMS.filter(x=>!decOk(x.k));
const fvPend=()=>['fv1','fv2','fv3'].filter(k=>!decOk(k));
function decHtml(){
  const ed=perAdmin(),open=sheet.ed||'';
  const row=x=>{const r=DEC.m[x.k]||{},ok=decOk(x.k),edit=ed&&(open===x.k||!ok);
    return `<article class="decr${ok?' ok':''}"><div class="dech"><div><small class="k">${esc(x.g)}</small><strong>${esc(x.t)}</strong></div><span class="chip ${ok?'good':'unas'}">${ok?'Registrada':'Pendiente'}</span></div><p class="note">${esc(x.d)}</p>
${ok&&!edit?`<div class="kv"><span>Aprobó</span><b>${esc(r.by)}</b></div><div class="kv"><span>Fecha</span><b>${esc(fmtDate(r.fecha)||'—')}</b></div>${r.resp?`<p class="decresp">${esc(r.resp)}</p>`:''}<small class="note">Registró ${esc(r.u||'—')} · ${esc(fmtTs(r.at||0))}</small>${ed?`<div class="pact"><button class="btn sm" data-act="decedit:${x.k}">Corregir</button></div>`:''}`:''}
${edit?`<p class="note"><b>${esc(x.q)}</b></p><div class="grid2"><label class="fld" for="dec-${x.k}-by"><span>Aprobó (nombre y cargo)</span><input class="in txt" id="dec-${x.k}-by" autocomplete="off" value="${esc(r.by||'')}"></label><label class="fld" for="dec-${x.k}-f"><span>Fecha</span><input class="in" id="dec-${x.k}-f" type="date" value="${esc(r.fecha||todayISO())}"></label></div><label class="fld" for="dec-${x.k}-r"><span>Respuesta o condiciones</span><textarea class="in txt ta" id="dec-${x.k}-r" rows="2">${esc(r.resp||'')}</textarea></label><div class="pact">${ok?`<button class="btn sm" data-act="decedit:">Cancelar</button>`:''}<button class="btn sm primary" data-act="decsave:${x.k}">Registrar</button></div>`:''}
${!ed&&!ok?'<p class="note">Solo el administrador registra las decisiones.</p>':''}</article>`};
  return `<h3>Decisiones de dirección</h3><p class="note" style="margin-bottom:8px">Reglas con efecto en dinero que la app aplica sola y puntos del Excel manual que esperan respuesta. Al registrar quién las aprobó y cuándo, dejan de salir como pendientes.</p>${DEC_ITEMS.map(row).join('')}<div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
function decSave(k){
  if(!perAdmin())return;const x=DEC_ITEMS.find(y=>y.k===k);if(!x)return;
  const by=String((document.getElementById('dec-'+k+'-by')||{}).value||'').trim(),f=(document.getElementById('dec-'+k+'-f')||{}).value||'',r=String((document.getElementById('dec-'+k+'-r')||{}).value||'').trim();
  if(!by){toast('Escribe quién la aprobó');const i=document.getElementById('dec-'+k+'-by');if(i)i.focus();return}
  if(x.g==='FORMATO VIAJES'&&!r){toast('Escribe la respuesta');return}
  const old=DEC.m[k];DEC.m[k]={by:by,fecha:f,resp:r,u:authUser.name||authUser.user||'—',at:Date.now()};saveDec(true);
  logAdd({k:'param',ctx:{t:'p',id:k,cod:'Decisiones de dirección'},path:'dec.'+k,lab:x.g+' · '+x.t,o:old&&old.by?old.by+' · '+(old.resp||''):'Pendiente',n:by+' · '+fmtDate(f)+(r?' · '+r:'')});
  sheet.ed='';renderSheet();render();toast('Decisión registrada');
}
/* ---------- v8.16 · Pendientes: lo que falta configurar o revisar, separado por quién lo resuelve ---------- */
function pendItems(){
  const out=[],add=(who,lvl,t,d,go,rows)=>out.push({who:who,lvl:lvl,t:t,d:d,go:go,rows:rows||[]}),xm=exMix(),L=visible().filter(o=>!o.ejemplo||!xm);
  if(!isContador()){
    const cp=[].concat(...visible().filter(isLeader).map(contPend));
    if(cp.length)add('Jefe de empaque','warn',cp.length+(cp.length===1?' conteo de tarima por autorizar':' conteos de tarima por autorizar'),'El personal de tarima ya contó estas cajas. Autorízalas en Código de Trazabilidad para que entren a la tarima.','traz',cp.map(c=>({t:c.cod+' · '+c.prod+' · '+fmt(contTot(c))+' cajas'})));
    const P=entProc(),SA=entSinAsignar(),sa=entradas().filter(e=>P.has(e.id)&&SA.has(e.id));
    if(sa.length)add('Jefe de empaque','warn',sa.length+(sa.length===1?' entrada sin asignar':' entradas sin asignar'),'Sus kilos ya están en un empaque, pero no cuadran con los calibres y las casillas de clasificación.','invproc',sa.map(e=>({t:(e.nombre||'Sin nombre')+' · '+fmtDate(e.fecha)})));
    const kw=entradas().map(e=>({e:e,x:kgCajaChk(e.kilos,e.k18,e.k24)})).filter(z=>z.x);
    if(kw.length)add('Jefe de empaque','warn',kw.length+(kw.length===1?' entrada con kilos por caja fuera de rango':' entradas con kilos por caja fuera de rango'),'Lo esperado es de '+fmt(PESOS.kg.min,0)+' a '+fmt(PESOS.kg.max,0)+' kg por caja de campo. Puede ser un dedazo en kilos o en cajas.','inv',kw.map(z=>({t:(z.e.nombre||'Sin nombre')+' · '+fmtDate(z.e.fecha)+' · '+fmt(z.x.v,1)+' kg por caja',act:'pent:'+z.e.id})));
    const dl=[],kr=[];
    L.filter(o=>o.estado!=='completo'&&!orderLocked(o)).forEach(o=>compute(o).rows.forEach(r=>{const p=r.p;if(p.sob||p.sob2||isSob(p)||+p.codigo===SEG_COD||p.segLot)return;
      if(r.dif!=null&&difChip(r).cls!=='good')dl.push({t:o.cod+(o.variante==='1.5'?' (1.5)':'')+' · '+(p.nombre||'Sin nombre')+' · Dif '+(r.dif>0?'+':'')+fmt(r.dif,1),act:'open:'+o.id});
      const x=kgCajaChk(p.kilos,p.k18,p.k24);if(x)kr.push({t:o.cod+' · '+(p.nombre||'Sin nombre')+' · '+fmt(x.v,1)+' kg por caja',act:'open:'+o.id})}));
    if(dl.length)add('Jefe de empaque','warn',dl.length+(dl.length===1?' productor con diferencia sin cuadrar':' productores con diferencia sin cuadrar'),'En pedidos en proceso: falta repartir kilos en calibres y casillas, o sobran cajas.','',dl);
    if(kr.length)add('Jefe de empaque','warn',kr.length+(kr.length===1?' renglón de empaque con kilos por caja fuera de rango':' renglones de empaque con kilos por caja fuera de rango'),'Revisa kilos o cajas del productor en Registro de Empaque.','',kr);
    const tz=[];L.filter(o=>isLeader(o)&&!orderLocked(o)).forEach(o=>{const z=trazCalc(o);if(!z.t.tarimas.length)return;const pks=new Set(z.lines.flatMap(Lx=>Object.keys(z.empQ[Lx]||{})));pks.forEach(k=>prodConcord(z,k).forEach(x=>{if(x.d>0)tz.push({t:o.cod+' · '+k+' · '+calLab(x.ck)+' '+(TIPO_L[x.L.split('|')[1]]||'')+(x.L.split('|')[0]==='1.5'?' (1.5)':'')+': '+fmt(x.reg)+' registradas, '+fmt(x.pal)+' en tarimas',act:'topal:'+o.id})}))});
    if(tz.length)add('Jefe de empaque','warn',tz.length+(tz.length===1?' calibre registrado de más contra sus tarimas':' calibres registrados de más contra sus tarimas'),'El productor ya registró más cajas que las que tiene en tarimas: súmalas a una tarima en Código de Trazabilidad o revisa el conteo.','',tz);
    {const P=entProc(),EP=entradas().filter(e=>!P.has(e.id)),sc=[],sl=[],sk=[];
      EP.forEach(e=>{if(!INV_F.some(f=>n0(e[f])>0)){sc.push({t:(e.nombre||'Sin nombre')+' · '+fmtDate(e.fecha),act:'pent:'+e.id});return}
        const W=entWhy(e);if(/No está ligada/.test(W.msg[0]||'')&&W.fix.length)sl.push({t:(e.nombre||'Sin nombre')+' · '+fmtDate(e.fecha)+' · hay renglón sin ligar',act:'pent:'+e.id});
        else if(W.fix.some(f=>f.act.indexOf('epes1:')===0))sk.push({t:(e.nombre||'Sin nombre')+' · '+fmtDate(e.fecha)+' · '+W.msg[0].replace(/^.*quedan sin pasar al empaque: /,'quedan ').replace(/\.$/,''),act:'pent:'+e.id})});
      if(sl.length)add('Jefe de empaque','warn',sl.length+(sl.length===1?' entrada empacada sin ligar':' entradas empacadas sin ligar'),'El productor ya está en un empaque, pero su renglón no está ligado a la entrega; por eso no pasa a Procesado. Ábrela y toca «Ligar con…».','',sl);
      if(sk.length)add('Jefe de empaque','warn',sk.length+(sk.length===1?' entrada con kilos distintos a la báscula':' entradas con kilos distintos a la báscula'),'Las cajas ya pasaron completas, pero el renglón tiene kilos escritos a mano. Ábrela y toca «Usar el peso de báscula» (cambia el pago de ese productor).','',sk);
      if(sc.length)add('Jefe de empaque','warn',sc.length+(sc.length===1?' entrada sin cantidades':' entradas sin cantidades'),'Sin cajas ni kilos no puede pasar a Procesado. Captúralas o elimina la entrada si fue un error.','',sc);}
    const np=[];L.forEach(o=>{if(wkClosed(wkOf(o)))return;(o.productores||[]).forEach(p=>{if(!p.inv||!p.invEnt)return;p.invEnt.forEach(id=>{const e=INV.entradas.find(x=>x.id===id);if(e&&!(num(e.kilos)>0))np.push({t:o.cod+' · '+(p.nombre||'Sin nombre')+' · entrega '+diaTxt(e.fecha),act:'open:'+o.id})})})});
    if(np.length)add('Jefe de empaque','warn',np.length+(np.length===1?' entrega en proceso sin peso de báscula':' entregas en proceso sin peso de báscula'),'Ya están en una corrida, pero falta su peso de báscula. Captúralo en la tarjeta del productor o en Entrada de Fruta cuando llegue el ticket.','',np);
    const sf=L.filter(o=>!o.fecha&&!wkClosed(wkOf(o)));
    if(sf.length)add('Jefe de empaque','warn',sf.length+(sf.length===1?' hoja sin fecha':' hojas sin fecha'),'Sin fecha en el encabezado, el registro no tiene día de empaque. Captúrala en «Editar encabezado».','',sf.map(o=>({t:o.cod+(o.variante==='1.5'?' (1.5)':''),act:'open:'+o.id})));
    const nm=L.filter(o=>o.variante==='1'&&o.estado!=='completo'&&(o.productores||[]).length&&!Object.keys(compute(o).manBy).length);
    if(nm.length)add('Jefe de empaque','info',nm.length+(nm.length===1?' viaje en proceso sin manifiesto':' viajes en proceso sin manifiesto'),'Sin manifiesto no se puede ver qué falta o sobra por calibre.','',nm.map(o=>({t:o.cod+' · '+(o.emb||''),act:'open:'+o.id})));
  }
  if(canFin()){
    const ej=FIN.ejemplo||PAR.list.some(v=>v.origen==='migrado'&&v.nota==='valores de ejemplo'&&parVer(v.emp,curWk())===v);
    if(ej)add('Administrador','crit','Precios de ejemplo activos','Finanzas calcula con valores de prueba hasta que guardes los precios reales en Precios y costos.','fin');
    const ex=visible().filter(o=>o.ejemplo);
    if(ex.length&&xm)add('Administrador','warn',ex.length+(ex.length===1?' hoja de ejemplo entre los pedidos reales':' hojas de ejemplo entre los pedidos reales'),'No cuentan en Estadísticas ni en Finanzas, pero se ven en las listas y se sincronizan. Quítalas cuando ya no sirvan.','exdel',[...new Set(ex.map(o=>o.cod))].slice(0,12).map(c=>({t:c})));
    const sp=[];L.forEach(o=>{if(wkClosed(wkOf(o)))return;(o.productores||[]).forEach(p=>{if(isGrande(p)&&n0(p.kilos)>0&&grPkg(o,p).src==='sin')sp.push({t:o.cod+' · '+(p.nombre||'Sin nombre')+' · '+fmt(n0(p.kilos))+' kg',act:'open:'+o.id})})});
    if(sp.length)add('Administrador','crit',sp.length+(sp.length===1?' entrega de productor grande sin precio':' entregas de productores grandes sin precio'),'Su pago sale en 0. Captura el precio por kilo en Finanzas › Grandes o en Precios y costos.','',sp);
    const ow=weekKeys(false).filter(k=>k<curWk()&&!wkClosed(k)&&visible().some(o=>wkOf(o)===k&&!o.ejemplo));
    if(ow.length)add('Administrador','info',ow.length+(ow.length===1?' semana pasada sin cerrar':' semanas pasadas sin cerrar'),'Al cerrar se congelan precios y pedidos, y las segundas sin procesar pasan a Juguera.','per',ow.map(k=>({t:wkLab(k)+' · '+wkSpan(k)})));
  }
  const dp=decPend();
  if(dp.length&&(canFin()||perAdmin()))add('Dirección','warn',dp.length+(dp.length===1?' decisión sin registrar':' decisiones sin registrar'),'Reglas con efecto en dinero y puntos de FORMATO VIAJES que esperan aprobación.','dec',dp.map(x=>({t:x.g+' · '+x.t})));
  return out;
}
function pendPanel(){
  if(!authUser)return '';
  if(isMarco())return pendTable();
  const I=pendItems();
  if(!I.length)return `<section class="pendp ok"><div class="pendh"><strong>Pendientes</strong><span class="chip good">Todo al día</span></div></section>`;
  const n=I.reduce((a,x)=>a+(x.rows.length||1),0);
  return `<section class="pendp"><div class="pendh"><strong>Pendientes</strong><span class="chip unas">${fmt(n)}</span></div>${I.slice(0,4).map(x=>`<div class="pendl ${x.lvl}"><span>${esc(x.t)}</span><small>${esc(x.who)}</small></div>`).join('')}${I.length>4?`<p class="note">y ${I.length-4} más</p>`:''}<div class="pact"><button class="btn sm primary" data-act="pendopen">Ver pendientes</button></div></section>`;
}
function pendHtml(){
  const I=pendItems(),G=['Jefe de empaque','Administrador','Dirección'];
  const goB=x=>x.go==='invproc'?'<button class="btn sm" data-act="pgo:invproc">Ir a Procesado</button>':x.go==='inv'?'<button class="btn sm" data-act="pgo:inv">Ir a Entrada de Fruta</button>':x.go==='fin'?'<button class="btn sm" data-act="pgo:fin">Ir a Finanzas</button>':x.go==='per'?'<button class="btn sm" data-act="peropen">Periodos</button>':x.go==='dec'?'<button class="btn sm primary" data-act="decopen">Decisiones de dirección</button>':x.go==='exdel'&&perAdmin()?`<button class="btn sm danger" data-act="exdel">${confirmKey==='exdel'?'Toca otra vez para quitarlas':'Quitar hojas de ejemplo'}</button>`:'';
  const body=G.map(g=>{const L=I.filter(x=>x.who===g);if(!L.length)return '';return `<div class="sec">${esc(g)}</div>`+L.map(x=>`<article class="pendi ${x.lvl}"><strong>${esc(x.t)}</strong><p class="note">${esc(x.d)}</p>${x.rows.length?`<div class="pendrows">${x.rows.slice(0,30).map(r=>r.act?`<button class="pendr" data-act="${esc(r.act)}">${esc(r.t)}<span aria-hidden="true">›</span></button>`:`<div class="pendr">${esc(r.t)}</div>`).join('')}${x.rows.length>30?`<p class="note">y ${x.rows.length-30} más</p>`:''}</div>`:''}<div class="pact">${goB(x)}</div></article>`).join('')}).join('');
  return `<h3>Pendientes</h3><p class="note" style="margin-bottom:6px">Lo que falta capturar, configurar o aprobar para que los resultados de la app sean confiables. Toca un renglón para ir a corregirlo.</p>${body||'<div class="panel okp"><strong>Todo al día</strong><p class="note">No hay nada pendiente.</p></div>'}<div class="srow2"><button class="btn" data-act="pgo:kg">Pesos y equivalencias</button><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
function exDel(){
  if(!perAdmin())return;const ex=visible().filter(o=>o.ejemplo);if(!ex.length)return;
  ex.forEach(o=>{o.deleted=true;touch(o)});logAdd({k:'del',ctx:{t:'p',id:'',cod:'Pedidos de ejemplo'},lab:'Quitó '+ex.length+' hojas de ejemplo'});
  confirmKey=null;invalidateStats();renderSheet();render();toast('Se quitaron '+ex.length+' hojas de ejemplo');
}
/* ---------- v8.0 · historial de parámetros ----------
   Cada cambio en Precios y costos es una versión nueva con la semana desde la que aplica (tabla «parametros»).
   Al cerrar una semana se congela la foto de lo que aplicaba (tabla «cierres»). Ninguna de las dos se edita ni se borra.
   Un pedido usa: la foto si su semana está cerrada; si no, la versión con la semana «desde» más alta que no pase de la suya. */
const LS_PAR='empaque-parametros',LS_CIE='empaque-cierres';
const FIN_KEYS=['tc','venta','cal','kg','seg','tor','mat','mo','flete','cruce','fijo','meta','salHr','comis','oee','horas','personas','paro','acu','plazoProd','plazoFlete','fijos','umbralCT','matMerma','jug','jugModo','jugProd','jugRet','jugKg','clas','cierre','gpag'];
let PAR={list:[],dirty:[],noTable:false,pulled:false},CIE={list:[],dirty:[],noTable:false,pulled:false};
(function(){try{const a=JSON.parse(localStorage.getItem(LS_PAR)||'null');if(a&&Array.isArray(a.list))PAR=Object.assign(PAR,{list:a.list,dirty:a.dirty||[]})}catch(e){}try{const b=JSON.parse(localStorage.getItem(LS_CIE)||'null');if(b&&Array.isArray(b.list))CIE=Object.assign(CIE,{list:b.list,dirty:b.dirty||[]})}catch(e){}})();
function savePar(){try{localStorage.setItem(LS_PAR,JSON.stringify({list:PAR.list,dirty:PAR.dirty}));localStorage.setItem(LS_CIE,JSON.stringify({list:CIE.list,dirty:CIE.dirty}))}catch(e){}invalidateStats();setSync()}
const curWk=()=>wkOfDate(todayISO());
/* copia completa de los parámetros de una empresa; los de BI que falten toman su valor por defecto (el mismo que ya usaba la app) */
function valsOf(F){const v={};FIN_KEYS.forEach(k=>{if(F&&F[k]!==undefined)v[k]=clone(F[k])});v.cal=v.cal||{};Object.keys(BI_DEF).forEach(k=>{if(v[k]==null||v[k]===''||!isFinite(+v[k]))v[k]=BI_DEF[k];else v[k]=+v[k]});return v}
function canon(x){if(Array.isArray(x))return x.map(canon);if(x&&typeof x==='object'){const o={};Object.keys(x).sort().forEach(k=>{if(x[k]!=null&&x[k]!=='')o[k]=canon(x[k])});return o}return x}
function finEq(a,b){return JSON.stringify(canon(valsOf(a)))===JSON.stringify(canon(valsOf(b)))}
const parNewer=(a,b)=>a.desde>b.desde||(a.desde===b.desde&&(a.at||0)>(b.at||0));
/* versión que aplica a la semana k; las semanas anteriores a todas las versiones usan la migrada (los precios de siempre) o, si no hay, la primera */
function parVer(e,k){let best=null,first=null,mig=null;PAR.list.forEach(v=>{if(v.emp!==e)return;if(v.origen==='migrado')mig=v;if(!first||v.desde<first.desde||(v.desde===first.desde&&(v.at||0)>(first.at||0)))first=v;if(k&&v.desde<=k&&(!best||parNewer(v,best)))best=v});return best||mig||first}
function parVerVals(e,k){const v=parVer(e,k);return v?v.vals:valsOf(FIN[e]||FIN.VL)}
function parFoto(k){let b=null;CIE.list.forEach(c=>{if(c.semana===k&&(!b||(c.at||0)>(b.at||0)))b=c});return b}
function parsDe(e,k){
  if(!k)return FIN[e]||FIN.VL;
  const ck=e+'|'+k;if(parCache.has(ck))return parCache.get(ck);
  let F=null;if(wkClosed(k)){const f=parFoto(k);if(f&&f[e])F=f[e]}
  if(!F){const v=parVer(e,k);F=v?v.vals:(FIN[e]||FIN.VL)}
  parCache.set(ck,F);return F;
}
/* semana desde la que aplica un cambio: la actual, o la siguiente abierta si la actual ya se cerró */
function finDesdeDef(){let k=curWk(),i=0;while(wkClosed(k)&&i++<60)k=wkNext(k);return k}
function finDesdeOpts(){const s=new Set(weekKeys(true).filter(k=>!wkClosed(k)));s.add(finDesdeDef());return [...s].sort().reverse()}
const parBy=()=>authUser?(authUser.name||authUser.user||'—'):'—';
/* el FIN vigente (catálogo «finanzas», el que leen las versiones anteriores de la app) sigue a la versión de la semana actual */
function finFromPar(){
  let ch=false;['VL','EC'].forEach(e=>{if(!PAR.list.some(v=>v.emp===e))return;const v=parVerVals(e,curWk());if(!finEq(FIN[e],v)){FIN[e]=clone(v);ch=true}});
  if(ch)saveFin(isAdmin());
}
/* un teléfono con la versión anterior cambió los precios sin crear versión: se registra como versión nueva desde la semana actual */
function parFromOld(){
  if(!isAdmin())return;
  ['VL','EC'].forEach(e=>{if(!PAR.list.some(v=>v.emp===e))return;const k=finDesdeDef(),cur=parVerVals(e,k);if(finEq(FIN[e],cur))return;
    const v=parAdd(e,k,valsOf(FIN[e]),'cliente-viejo','Cambio hecho desde una versión anterior de la app');
    logAdd({k:'param',where:'Precios y costos',ctx:{t:'f',id:e,cod:EMPS[e].name+' · desde '+wkLab(k)},path:'fin.'+e,lab:'Precios y costos cambiados desde una versión anterior de la app',o:'',n:'Versión nueva '+v.id})});
}
function parAdd(e,k,vals,origen,nota){
  const now=Date.now(),me=authUser&&authUser.id||'';
  /* varios cambios seguidos de la misma persona, misma semana y aún sin subir, quedan en una sola versión */
  const L=PAR.list.find(v=>v.emp===e&&v.desde===k&&v.uid===me&&v.origen===origen&&PAR.dirty.indexOf(v.id)>=0&&now-(v.at||0)<180000);
  if(L){L.vals=vals;L.at=now;savePar();return L}
  const v={id:e+'|'+k+'|'+now+'|'+(me||'local'),emp:e,desde:k,vals:vals,origen:origen,by:parBy(),uid:me,at:now,nota:nota||''};
  PAR.list.push(v);PAR.dirty.push(v.id);savePar();return v;
}
/* migración: el FIN actual pasa a ser la versión vigente desde la semana más antigua con pedidos; las cifras no cambian */
function parNeedsMig(){return ['VL','EC'].some(e=>!PAR.list.some(v=>v.emp===e))||Object.keys(PER.list).some(k=>PER.list[k].closed&&!parFoto(k))}
function parMigrate(force){
  if(!isAdmin()||!parNeedsMig())return 0;
  if(!force&&cfgOK()&&!(PAR.pulled&&CIE.pulled&&!PAR.noTable&&!CIE.noTable))return 0;
  const now=Date.now();let nv=0,nf=0;const desde={};
  ['VL','EC'].forEach(e=>{
    if(PAR.list.some(v=>v.emp===e))return;
    const L=visible().filter(o=>o.emp===e),R=L.filter(o=>!o.ejemplo),ks=(R.length?R:L).map(wkOf).filter(Boolean).sort();
    desde[e]=ks[0]||curWk();
    PAR.list.push({id:'mig|'+e,emp:e,desde:desde[e],vals:valsOf(FIN[e]),origen:'migrado',by:parBy(),uid:authUser.id||'',at:now,nota:FIN.ejemplo?'valores de ejemplo':''});PAR.dirty.push('mig|'+e);nv++;
  });
  Object.keys(PER.list).sort().forEach(k=>{if(!PER.list[k].closed||parFoto(k))return;
    CIE.list.push({id:'mig|'+k,semana:k,VL:clone(parVerVals('VL',k)),EC:clone(parVerVals('EC',k)),version:{VL:(parVer('VL',k)||{}).id||'',EC:(parVer('EC',k)||{}).id||''},by:parBy(),at:now,origen:'migrado'});CIE.dirty.push('mig|'+k);nf++});
  savePar();
  logAdd({k:'param',where:'Precios y costos',ctx:{t:'f',id:'',cod:'Migración v8.0'},path:'fin',lab:'Migración v8.0 de precios y costos',o:'Sin historial',n:(nv?'Vigentes desde '+Object.keys(desde).map(e=>e+' '+wkLab(desde[e])).join(', '):'Versiones ya existían')+(nf?' · '+nf+(nf===1?' semana cerrada congelada':' semanas cerradas congeladas'):'')+(FIN.ejemplo?' · con valores de ejemplo':'')});
  return nv+nf;
}
/* foto congelada al cerrar la semana k */
function parFotoAdd(k,origen){
  const now=Date.now(),prev=parFoto(k);
  const f={id:k+'|'+now,semana:k,VL:clone(parVerVals('VL',k)),EC:clone(parVerVals('EC',k)),version:{VL:(parVer('VL',k)||{}).id||'',EC:(parVer('EC',k)||{}).id||''},by:parBy(),at:now,origen:origen||'cierre'};
  CIE.list.push(f);CIE.dirty.push(f.id);savePar();
  if(prev){const d=['VL','EC'].filter(e=>!finEq(prev[e],f[e]));if(d.length)logAdd({k:'period',where:'Periodos',ctx:{t:'w',id:k,cod:wkLab(k)},lab:'Foto de cierre de '+wkLab(k)+' distinta a la anterior',o:'',n:'Cambiaron los precios y costos de '+d.map(e=>EMPS[e].name).join(' y ')})}
  return f;
}
/* sincronización: solo se insertan filas nuevas; lo que ya está en el servidor manda */
async function syncParTab(S,tb){
  try{
    if(isAdmin()&&S.dirty.length){
      const send=S.dirty.map(id=>S.list.find(x=>x.id===id)).filter(Boolean);
      for(let i=0;i<send.length;i+=100){const part=send.slice(i,i+100);await sb('/rest/v1/'+tb+'?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=minimal'},body:part.map(x=>({id:x.id,data:x}))})}
    }
    const rows=(await sb('/rest/v1/'+tb+'?select=id,data&order=id.asc&limit=20000'))||[];
    rows.forEach(r=>{if(!r.data)return;const i=S.list.findIndex(x=>x.id===r.id);if(i<0){S.list.push(r.data);remoteN++}else{if(JSON.stringify(S.list[i])!==JSON.stringify(r.data))remoteN++;S.list[i]=r.data}});
    S.dirty=S.dirty.filter(id=>!rows.some(r=>r.id===id));S.noTable=false;S.pulled=true;
  }catch(e){if(e&&(e.status===404||e.status===400))S.noTable=true}
}
async function syncPar(){await syncParTab(PAR,'parametros');await syncParTab(CIE,'cierres');savePar();if(parMigrate())await syncPar0()}
async function syncPar0(){await syncParTab(PAR,'parametros');await syncParTab(CIE,'cierres');savePar()}
/* nombre y divisa de cada casilla, para la bitácora */
function finLab(p){
  const q=x=>x==='1'?'Primera':'Segundas',T=t=>TIPO_L[t]||t;
  if(p[0]==='venta')return 'Venta '+q(p.slice(2).join('.'))+' '+T(p[1])+' (USD por caja)';
  if(p[0]==='cal')return 'Precio '+q(p.slice(2,-1).join('.'))+' '+T(p[1])+' calibre '+(CAL_LAB[p[p.length-1]]||p[p.length-1])+' (USD por caja)';
  if(p[0]==='mat')return 'Material '+T(p[1])+' (MXN por caja)';
  if(p[0]==='fijos'){const c=FIJO_CAT.find(x=>x[0]===p[1]);return 'Costo fijo · '+(c?c[1]:p[1])+' · '+(p[2]==='p'?'periodicidad':'monto (MXN)')}
  if(p[0]==='acu'){const c=+p[1],li=LISTA.find(x=>x.c===c);return 'Acuerdo de compra · #'+pad(c,3)+(li?' '+li.n:'')+' · '+(p[2]==='modal'?'modalidad':'precio (MXN por kg)')}
  if(p[0]==='clas'){const f=CLAS_F.find(x=>x[0]===p[2]);return 'Clasificación de productores · '+(PCLS_L[p[1]]||p[1])+' · '+(f?f[1]+' ('+f[2]+')':p[2])}
  if(p[0]==='cierre'){const f=CIERRE_F.find(x=>x[0]===p[1]);return 'Cierre semanal · '+(f?f[1]+' ('+f[2]+')':p[1])}
  return ({jug:'Juguera · venta (MXN por caja)',jugModo:'Juguera · forma de pago al productor',jugProd:'Juguera · pago fijo al productor (MXN por caja)',jugProdKg:'Juguera · pago fijo al productor (MXN por kg)',jugVKg:'Juguera · venta (MXN por kg)',jugKg:'Juguera · kilos por caja',jugRet:'Juguera · retención del empaque (%)',tc:'Tipo de cambio (MXN por 1 USD)',kg:'Pago al productor (MXN por kg)',seg:'Segunda nacional (MXN por caja)',tor:'Torreón (MXN por caja)',mo:'Mano de obra (MXN por caja)',flete:'Flete (MXN por embarque)',cruce:'Cruce y aduana (MXN por embarque)',fijo:'Costos fijos por semana (MXN)',meta:'Meta de cajas por hora',salHr:'Salario por hora hombre (MXN)',comis:'Comisión en consignación (%)',oee:'OEE encendido (1) o apagado (0)',plazoProd:'Días para pagar a productores',umbralCT:'Umbral del hueco de capital de trabajo (MXN)',matMerma:'Material usado en merma (MXN por caja)',plazoFlete:'Días para pagar flete',horas:'Horas del turno',personas:'Personas en el turno',paro:'Minutos de paro'})[p[0]]||p.join('.');
}
/* un cambio en Precios y costos: versión nueva desde la semana k con todos los valores, más una línea en la bitácora */
function finEdit(e0,p,v,k){
  if(!isAdmin())return null;
  if(!PAR.list.some(x=>x.emp===e0))parMigrate(true);
  k=k||finDesdeDef();if(wkClosed(k)){toast(wkLab(k)+' está cerrada; elige otra semana');return null}
  const o=clone(parVerVals(e0,k));o.cal=o.cal||{};o.venta=o.venta||{};o.mat=o.mat||{};
  let old;
  if(p[0]==='cal'){const tp=p[1],ck=p[p.length-1],q=p.slice(2,-1).join('.');o.cal[tp]=o.cal[tp]||{};o.cal[tp][q]=o.cal[tp][q]||{};old=o.cal[tp][q][ck];if(v==null)delete o.cal[tp][q][ck];else o.cal[tp][q][ck]=v}
  else if(p[0]==='venta'){const q=p.slice(2).join('.');o.venta[p[1]]=o.venta[p[1]]||{};old=o.venta[p[1]][q];o.venta[p[1]][q]=v}
  else if(p[0]==='mat'){old=o.mat[p[1]];o.mat[p[1]]=v}
  else if(p[0]==='fijos'){o.fijos=o.fijos||{};const c=p[1],fk=p[2];o.fijos[c]=o.fijos[c]||{};old=o.fijos[c][fk];if(v==null||v==='')delete o.fijos[c][fk];else o.fijos[c][fk]=v;if(!Object.keys(o.fijos[c]).length)delete o.fijos[c];if(!Object.keys(o.fijos).length)delete o.fijos}
  else if(p[0]==='acu'){o.acu=o.acu||{};const c=p[1],fk=p[2];o.acu[c]=o.acu[c]||{};old=o.acu[c][fk];if(v==null||v==='')delete o.acu[c][fk];else o.acu[c][fk]=v;if(!Object.keys(o.acu[c]).length)delete o.acu[c]}
  else if(p[0]==='clas'){o.clas=o.clas||{};const c=p[1],fk=p[2];o.clas[c]=o.clas[c]||{};old=o.clas[c][fk];if(v==null||v==='')delete o.clas[c][fk];else o.clas[c][fk]=v;if(!Object.keys(o.clas[c]).length)delete o.clas[c];if(!Object.keys(o.clas).length)delete o.clas}
  else if(p[0]==='gpag'){o.gpag=o.gpag||{};const id=p[1],fk=p[2];o.gpag[id]=o.gpag[id]||{};old=o.gpag[id][fk];if(v==null||v==='')delete o.gpag[id][fk];else o.gpag[id][fk]=v;if(!Object.keys(o.gpag[id]).length)delete o.gpag[id];if(!Object.keys(o.gpag).length)delete o.gpag}
  else if(p[0]==='cierre'){o.cierre=o.cierre||{};const fk=p[1];old=o.cierre[fk];if(v==null||v==='')delete o.cierre[fk];else o.cierre[fk]=v;if(!Object.keys(o.cierre).length)delete o.cierre}
  else{old=o[p[0]];o[p[0]]=v}
  if(sv(old)===sv(v))return null;
  const ver=parAdd(e0,k,valsOf(o),'admin','');
  logAdd({k:'param',where:'Precios y costos',ctx:{t:'f',id:e0,cod:EMPS[e0].name+' · desde '+wkLab(k)},path:'fin.'+e0+'.'+p.join('.'),lab:finLab(p),o:sv(old),n:sv(v),ver:ver.id});
  FIN.ejemplo=false;finFromPar();saveFin(true);
  return ver;
}
/* Estadísticas no es para el jefe de empaque */
function canStats(){return !!authUser&&authUser.rol!=='jefe'}
const money=(v,d)=>v==null||!isFinite(v)?'–':(v<0?'−$':'$')+fmt(Math.abs(v),d||0);
const pctTxt=v=>v==null||!isFinite(v)?'–':fmt(v*100,1)+'%';

/* ---------- v8.4 · Juguera ----------
   Cajas a Juguera por empresa, semana y productor: las de la casilla Juguera del pedido (semana del pedido) y las segundas
   que pasan al cerrar la semana (semana que se cerró). La Juguera se cobra por semana en MXN: manda la liquidación registrada
   en Por cobrar; sin ella, cajas × precio de venta de Precios y costos.
   v8.7.1: toda la Juguera (corridas de primera, corridas 1.5 y segundas que pasan al cerrar la semana) es venta del empaque.
   No se le paga al productor ni es merma. Lo capturado antes en «pago a productores» (jugModo, jugProd, jugRet) se conserva
   en los datos pero ya no se usa. */
function jugKgDe(F){const v=num(F.jugKg);return v>0?v:SEG_KG}
/* el pago por kilo no se guarda aparte: sale del pago por caja entre los kilos por caja */
function jugVKgTxt(F){const c=num(F.jug);if(c==null)return null;return String(Math.round(c/jugKgDe(F)*10000)/10000)}
function jugKgTxt(F){const c=num(F.jugProd);if(c==null)return null;return String(Math.round(c/jugKgDe(F)*10000)/10000)}
function jugPar(e,wk){const F=parsDe(e,wk);return {precio:num(F.jug),modo:F.jugModo==='pase'?'pase':'fijo',prod:num(F.jugProd),ret:num(F.jugRet),kg:jugKgDe(F)}}
function jugData(){
  if(statsF._jug)return statsF._jug;
  const W=new Map(),row=new Map(),pe=new Map(),L=visible(),lots=seg2Lots(),pkey=(c,n)=>c?'c'+c:'n'+norm(n||'sin nombre');
  L.forEach(o=>(o.productores||[]).forEach(p=>{const k=pkey(p.codigo,p.nombre),m=pe.get(k)||{};m[o.emp]=(m[o.emp]||0)+n0(p.kilos)+1;pe.set(k,m)}));
  const empOf=(c,n)=>{const m=pe.get(pkey(c,n));if(!m)return 'VL';return Object.keys(m).sort((a,b)=>m[b]-m[a])[0]};
  /* own: cajas del empaque (segundas), sin pago al productor */
  const add=(e,wk,c,n,caj,src,rk,own)=>{if(!(caj>0)||!wk||!EMPS[e])return;const k=e+'|'+wk;let w=W.get(k);if(!w){w={emp:e,wk:wk,caj:0,ped:0,cie:0,man:0,own:0,prods:new Map()};W.set(k,w)}
    w.caj+=caj;w[src]+=caj;if(rk){let r=row.get(rk);if(!r){r=[];row.set(rk,r)}r.push({k:k,n:caj,own:!!own})}
    if(own){w.own+=caj;return}
    const pk=pkey(c,n);let a=w.prods.get(pk);if(!a){const li=c?LISTA.find(x=>x.c===c):null;a={key:pk,codigo:c||null,nombre:(li&&li.n)||n||'Sin nombre',caj:0,ped:0,cie:0,man:0};w.prods.set(pk,a)}
    a.caj+=caj;a[src]+=caj};
  L.forEach(o=>{const wk=wkOf(o);(o.productores||[]).forEach(p=>{if(isSob(p))return;const j=n0(p.jug);if(j<=0)return;const rk='o.'+o.id+'.'+p.id;
    /* v8.7.1: toda la Juguera es venta del empaque; no se le paga al productor */
    const own=true;
    add(o.emp,wk,p.codigo,p.nombre,j,'ped',rk,own)})});
  Object.keys(PER.list).forEach(k=>{const w=PER.list[k];if(!(w&&w.closed&&w.jug))return;(w.jug.lots||[]).forEach(x=>{const n=n0(x.n);if(n<=0)return;
    let e=null,rk=null;if(x.lot&&x.lot[0]==='o'){const o=L.find(z=>z.id===String(x.lot).split('.')[1]);if(o){e=o.emp;rk=lotRow(x.lot)}}
    add(e||empOf(x.codigo,x.nombre),k,x.codigo,x.nombre,n,'cie',rk,true)})});
  /* v8.13: envíos a Juguera hechos con el botón, en la semana en que se mandaron */
  jugManAll().forEach(z=>{const n=n0(z.n);if(n<=0||!z.wk)return;add(z.emp||empOf(z.codigo,z.nombre),z.wk,z.codigo,z.nombre,n,'man',z.src==='o'?lotRow(z.lot):null,true)});
  W.forEach(w=>{const P=jugPar(w.emp,w.wk),ref='cxj|'+w.emp+'|'+w.wk,lq=lastMov(COB,ref,'fact');
    w.ref=ref;w.par=P;w.calc=P.precio!=null?r2(w.caj*P.precio):null;w.liq=lq&&+lq.monto>=0?r2(+lq.monto):null;w.base=w.liq!=null?w.liq:(w.calc||0);
    w.unit=w.caj>0?w.base/w.caj:0;w.prodUnit=P.modo==='fijo'?(P.prod||0):w.unit*(1-(P.ret||0)/100);
    w.prods.forEach(a=>{a.pago=r2(a.caj*w.prodUnit)});w.pago=[...w.prods.values()].reduce((s,a)=>s+a.pago,0);w.ret=r2(w.base-w.pago);w.ownIng=r2(w.own*w.unit)});
  statsF._jug={W:W,row:row};return statsF._jug;
}
/* Ingresos y costos de un conjunto de hojas: totales, por tipo de empaque, por productor y por periodo */
function finAgg(list){
  if(list.some(o=>o.ejemplo)&&exMix())list=list.filter(o=>!o.ejemplo);
  const T={ingExp:0,ingUSD:0,ingNac:0,ingJug:0,frutaJug:0,jugCaj:0,ing:0,fruta:0,mat:0,mo:0,flete:0,cost:0,util:0,cajas:0,kilos:0,cajT:{},ingT:{},usdT:{},cajC:{},usdC:{},ingC:{}},prods=new Map(),bk=new Map(),ords=new Map(),JG=jugData();
  TIPO_K.forEach(t=>{T.cajT[t]=0;T.ingT[t]=0;T.usdT[t]=0});
  /* el flete se paga una vez por pedido y se reparte entre sus hojas y productores por cajas de exportación */
  /* v8.21: las cajas reempacadas se venden (y pagan flete) en el viaje que las recibe; pedCajF es sin descontarlas (para la consignación) */
  const pedCaj={},pedCajF={};list.forEach(o=>{const k=o.emp+'|'+o.cod,e=compute(o).tot.exp;pedCajF[k]=(pedCajF[k]||0)+e;pedCaj[k]=(pedCaj[k]||0)+e-rmpOutsOf(o.id).reduce((s,a)=>s+n0(a.n0),0)-(rmpIdx().sob.get(o.id)||[]).reduce((s,a)=>s+n0(a.n0),0)});
  const span=(()=>{const d=list.map(o=>o.fecha).filter(Boolean).sort();return d.length?dayDiff(d[0],d[d.length-1]):0})(),weekly=span<=70;
  list.forEach(o=>{
    const wk=wkOf(o),F=parsDe(o.emp,wk),q=o.variante==='1.5'?'1.5':'1',tc=+F.tc||0,M=compute(o),pk=o.emp+'|'+o.cod;
    const fr=fleteReal(o.emp,o.cod),fletePed=fr!=null?fr:(+F.flete||0)+(+F.cruce||0),expPed=pedCaj[pk]||0,expPedF=pedCajF[pk]||0;
    const bkey=weekly?(o.anio||String(o.fecha||'').slice(0,4))+'-S'+pad(o.semana||0,2):String(o.fecha||'').slice(0,7),blab=weekly?'Sem '+(o.semana||'?'):(()=>{const p=String(o.fecha||'').split('-');return p.length>1?MESES[+p[1]-1].slice(0,3)+' '+p[0].slice(2):'s/f'})();
    let b=bk.get(bkey);if(!b){b={k:bkey,l:blab,ing:0,cost:0,util:0,cajas:0,kilos:0,usd:0,fruta:0};bk.set(bkey,b)}
    let od=ords.get(o.id);if(!od){od={o:o,ing:0,usd:0,nac:0,fruta:0,mat:0,mo:0,flete:0,cost:0,cajas:0,kilos:0,cajC:{},fr:fr!=null};ords.set(o.id,od)}
    M.rows.forEach(r=>{
      const p=r.p;if(isSob(p)&&!p.rmp)return;
      const key=pKey(p);
      let a=prods.get(key);
      if(!a){const pc=pCode(p),li=pc?LISTA.find(x=>x.c===pc):null;a={key:key,codigo:pc||null,nombre:(li&&li.n)||p.nombre||'Sin nombre',ped:new Set(),kilos:0,cajas:0,ing:0,cost:0,pago:0,util:0};prods.set(key,a)}
      /* v8.21 · reempaque: las cajas que salieron a otra presentación no se venden aquí (om); su empaque y mano de obra sí se gastaron aquí */
      let usd=0,caj=0,mat=0,usdF=0,cajF=0;const cc={},om=rmpOutAll(o,p);
      r.tipos.forEach(t0=>{const d=r.byT[t0].delta;CAL.forEach(c=>{const nF=Math.max(0,d[c.k]||0);if(!nF)return;const tp=lineType(t0,c.k),pr=precioUSD(F,tp,q,c.k),ok=tp+'|'+c.k,out=Math.min(nF,om[ok]||0);if(out)om[ok]-=out;const n=nF-out;usdF+=nF*pr;cajF+=nF;mat+=nF*((F.mat||{})[tp]||0);if(!n)return;usd+=n*pr;cc[c.k]=(cc[c.k]||0)+n;T.cajC[c.k]=(T.cajC[c.k]||0)+n;T.usdC[c.k]=(T.usdC[c.k]||0)+n*pr;T.ingC[c.k]=(T.ingC[c.k]||0)+n*pr*tc;caj+=n;T.cajT[tp]=(T.cajT[tp]||0)+n;T.usdT[tp]=(T.usdT[tp]||0)+n*pr;T.ingT[tp]=(T.ingT[tp]||0)+n*pr*tc})});
      const internal=+p.codigo===SEG_COD||!!p.segLot||!!p.rmp;
      /* fruta: precio acordado con el productor (MXN/kg) o el general; en consignación se le paga lo que vale su fruta menos la comisión */
      /* Juguera: venta a la Juguera y pago al productor, a lo de su semana (ver jugData) */
      let jIng=0,jPag=0,jCaj=0;(JG.row.get('o.'+o.id+'.'+p.id)||[]).forEach(z=>{const w=JG.W.get(z.k);if(!w)return;jCaj+=z.n;jIng+=z.n*w.unit;if(!z.own)jPag+=z.n*w.prodUnit});
      const nac=segC(p)*(+F.seg||0)+n0(p.tor)*(+F.tor||0)+jIng,mo=cajF*(+F.mo||0),fl=expPed>0?fletePed*caj/expPed:0,ing=usd*tc+nac;
      /* consignación: su fruta se valúa como en este primer empaque, aunque parte se haya reempacado (ingF y flF sin descontar el reempaque) */
      const ingF=usdF*tc+nac,flF=expPedF>0?fletePed*cajF/expPedF:0;
      const ac=(F.acu&&p.codigo&&F.acu[p.codigo])||{},consig=!internal&&(p.modal||ac.modal)==='consig',frutaKg=internal?0:consig?Math.max(0,ingF-jIng-mat-mo-flF)*(1-biPar(o.emp,'comis',wk)/100):n0(p.kilos)*pkgOf(F,o,p),fruta=frutaKg+jPag;
      const cost=fruta+mat+mo+fl;if(consig)a.consig=true;
      const pkil=p.rmp?0:n0(p.kilos); /* v8.21.3: los kilos del REEMPAQUE ya cuentan en su primer empaque */
      od.ing+=ing;od.usd+=usd;od.nac+=nac;od.jug=(od.jug||0)+jIng;od.fruta+=fruta;od.mat+=mat;od.mo+=mo;od.flete+=fl;od.cost+=cost;od.cajas+=caj;od.kilos+=pkil;Object.keys(cc).forEach(k=>od.cajC[k]=(od.cajC[k]||0)+cc[k]);
      T.ingUSD+=usd;T.ingExp+=usd*tc;T.ingNac+=nac;T.ingJug+=jIng;T.frutaJug+=jPag;T.jugCaj+=jCaj;T.fruta+=fruta;T.mat+=mat;T.mo+=mo;T.flete+=fl;T.cajas+=caj;T.kilos+=pkil;
      a.ped.add(pk);a.kilos+=pkil;a.cajas+=caj;a.ing+=ing;a.cost+=cost;a.pago+=frutaKg;a.pagoJug=(a.pagoJug||0)+jPag;
      b.ing+=ing;b.cost+=cost;b.fruta+=fruta;b.cajas+=caj;b.kilos+=pkil;b.usd+=usd;
    });
  });
  T.ing=T.ingExp+T.ingNac;T.cost=T.fruta+T.mat+T.mo+T.flete;T.util=T.ing-T.cost;
  T.margen=T.ing>0?T.util/T.ing:null;T.precio=T.cajas>0?T.ingUSD/T.cajas:null;T.costoCaja=T.cajas>0?T.cost/T.cajas:null;
  T.utilKg=T.kilos>0?T.util/T.kilos:null;T.ingKg=T.kilos>0?T.ing/T.kilos:null;
  const rows=[...prods.values()];rows.forEach(a=>{a.util=a.ing-a.cost;a.margen=a.ing>0?a.util/a.ing:null});
  const buckets=[...bk.values()].sort((a,b)=>a.k.localeCompare(b.k));buckets.forEach(b=>{b.util=b.ing-b.cost;b.margen=b.ing>0?b.util/b.ing:null;b.precio=b.cajas>0?b.usd/b.cajas:null;b.costoCaja=b.cajas>0?b.cost/b.cajas:null;b.utilKg=b.kilos>0?b.util/b.kilos:null});
  return {T:T,rows:rows,map:prods,buckets:buckets,weekly:weekly,ords:[...ords.values()]};
}
/* indicadores: valor, formato, si subir es bueno y cómo se ve por periodo */
const KPI=[
  {k:'ing',l:'Ingresos',cur:'MXN',f:v=>money(v),good:'up',sub:T=>'exportación '+mxn(T.ingExp)+' (= '+usd(T.ingUSD)+') · nacional '+mxn(T.ingNac)},
  {k:'cost',l:'Costos',cur:'MXN',f:v=>money(v),good:'down',sub:T=>'fruta '+mxn(T.fruta)+' · empaque '+mxn(T.mat+T.mo)+' · flete '+mxn(T.flete)},
  {k:'util',l:'Utilidad bruta',cur:'MXN',f:v=>money(v),good:'up',sub:T=>T.util<0?'pérdida en el periodo':'ingresos menos costos'},
  {k:'margen',l:'Margen',cur:'%',f:pctTxt,good:'up',pp:true,sub:()=>'utilidad sobre ingresos'},
  {k:'precio',l:'Precio de venta promedio',cur:'USD',f:v=>money(v,2),good:'up',sub:()=>'por caja de exportación'},
  {k:'costoCaja',l:'Costo por caja',cur:'MXN',f:v=>money(v,2),good:'down',sub:()=>'todo el costo entre cajas de exportación'},
  {k:'utilKg',l:'Utilidad por kg',cur:'MXN',f:v=>money(v,2),good:'up',sub:T=>mxn(T.ingKg,2)+' de ingreso por kg recibido'},
  {k:'fruta',l:'Pago a productores',cur:'MXN',f:v=>money(v),good:null,sub:T=>fmt(T.kilos)+' kg a '+mxn(T.kilos>0?T.fruta/T.kilos:0,2)+' por kg'}
];
const mxn=(v,d)=>money(v,d)+' MXN',usd=(v,d)=>money(v,d)+' USD';
const curTxt=(x,v)=>x.cur==='%'?x.f(v):x.f(v)+' '+x.cur;
function kpiVal(T,k){return T[k]}
function finView(D){
  const f=statsF,F=D.fin.T,R=D.finRef?D.finRef.T:null,sel=KPI.find(x=>x.k===f.kpi)||KPI[2];
  const tiles=KPI.map(x=>{
    const v=kpiVal(F,x.k),r=R?kpiVal(R,x.k):null,ch=R&&r!=null&&v!=null?varChip(x.pp?ppV(v,r):relV(v,Math.abs(r)),x.pp?'pp':'%',x.good):nocmpChip();
    return `<button class="tile ktile${x.k===sel.k?' on':''}${x.k==='util'&&F.util<0?' neg':''}" data-act="kpi:${x.k}" aria-pressed="${x.k===sel.k}"><span class="k">${x.l}</span><b>${x.f(v)}${x.cur!=='%'?`<em class="cur">${x.cur}</em>`:''}</b><small>${x.sub(F)}</small><div class="tv">${ch}</div></button>`;
  }).join('');
  const warn=FIN.ejemplo?`<div class="warnbox finwarn" role="note"><strong>Precios de ejemplo</strong><div>Las cifras usan precios y costos de muestra. ${isAdmin()?'Pon los reales en «Precios y costos».':'El administrador los ajusta en «Precios y costos».'}</div></div>`:'';
  const es=f.emp==='ALL'?['VL','EC']:[f.emp],ed=isAdmin(),X=fijoPeriodo([...new Set(D.cur.list.map(wkOf).filter(Boolean))],es);
  const tcs=es.map(e=>`<label class="tcf" for="tc-${e}"><span>Tipo de cambio${es.length>1?' '+esc(EMPS[e].name):''}</span><span class="tcin"><em>1 USD =</em><input class="in" id="tc-${e}" inputmode="decimal" data-fin="${e}.tc" value="${esc(FIN[e].tc)}"${ed?'':' readonly'} aria-label="Pesos por dólar${es.length>1?' '+esc(EMPS[e].name):''}"><em>MXN</em></span></label>`).join('');
  return `${warn}<div class="finbar"><div class="tcs">${tcs}</div><button class="btn sm" data-act="finset">Precios y costos</button></div><p class="note" style="margin-top:6px">La fruta se vende en dólares (USD) y se convierte a pesos con el tipo de cambio${ed?'':', que solo el administrador cambia'}. Todos los costos están en pesos mexicanos (MXN).</p>
<div class="tiles ktiles">${tiles}</div><p class="note" style="margin-top:6px">Toca un indicador para ver su tendencia.</p>
<div class="sec">Tendencia · ${sel.l}${sel.cur!=='%'?' ('+sel.cur+')':''} ${D.fin.weekly?'por semana':'por mes'}</div><div class="panel chartp">${trendSvg(D.fin.buckets,sel)}</div>
<div class="dsk fin2"><div class="dcol"><div class="sec">Estado de resultados</div><div class="panel">${plHtml(F,X)}</div>
<div class="sec">Costos fijos y margen absorbido</div><div class="panel">${absHtml(F,X)}</div>
<div class="sec">Escenario rápido</div><div class="panel">${simHtml(F)}</div></div>
<div class="dcol"><div class="sec">Por tipo de empaque</div><div class="panel">${tipoFinHtml(F)}</div><div class="sec">Por calibre</div><div class="panel">${calFinHtml(F)}</div></div></div>
<div class="sec">Merma valorizada</div>${mermaHtml(D.cur.list)}
<div class="sec">Rentabilidad por productor</div>${prodFinHtml(D)}`;
}
/* barras por periodo, una sola serie; las negativas bajan del cero; tooltip al pasar o enfocar */
function trendSvg(B,sel){
  const data=B.map(b=>({l:b.l,v:b[sel.k]})).filter(d=>d.v!=null&&isFinite(d.v));
  if(!data.length)return '<p class="note">Sin datos para graficar en este periodo.</p>';
  const wide=window.innerWidth>=1000,W=Math.round(Math.max(320,Math.min(1180,window.innerWidth-(wide?100:56)))),H=wide?260:220,L=wide?84:70,Rr=12,Tp=16,Bt=34,pw=W-L-Rr,ph=H-Tp-Bt;
  const mx=Math.max(0,...data.map(d=>d.v)),mn=Math.min(0,...data.map(d=>d.v)),rng=(mx-mn)||1;
  const y=v=>Tp+(mx-v)/rng*ph,y0=y(0),n=data.length,bw=Math.min(48,pw/n*0.62),gap=pw/n;
  const ticks=[mx,mx-rng/2,mn].filter((v,i,a)=>a.indexOf(v)===i);
  let g=ticks.map(v=>`<line x1="${L}" x2="${W-Rr}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" class="gl"/><text x="${L-8}" y="${(y(v)+4).toFixed(1)}" class="ax" text-anchor="end">${esc(sel.f(v))}</text>`).join('');
  g+=`<line x1="${L}" x2="${W-Rr}" y1="${y0.toFixed(1)}" y2="${y0.toFixed(1)}" class="zl"/>`;
  const step=Math.max(1,Math.ceil(n/Math.max(1,Math.floor(pw/64))));
  data.forEach((d,i)=>{
    const cx=L+gap*i+gap/2,x=cx-bw/2,top=d.v>=0?y(d.v):y0,hh=Math.max(1,Math.abs(y(d.v)-y0)),r=Math.min(4,hh/2,bw/2);
    const path=d.v>=0?`M${x},${y0}V${top+r}Q${x},${top} ${x+r},${top}H${x+bw-r}Q${x+bw},${top} ${x+bw},${top+r}V${y0}Z`:`M${x},${y0}V${y0+hh-r}Q${x},${y0+hh} ${x+r},${y0+hh}H${x+bw-r}Q${x+bw},${y0+hh} ${x+bw},${y0+hh-r}V${y0}Z`;
    g+=`<g class="bar${d.v<0?' neg':''}" tabindex="0" data-tip="${esc(d.l+': '+curTxt(sel,d.v))}"><rect x="${(cx-gap/2).toFixed(1)}" y="${Tp}" width="${gap.toFixed(1)}" height="${ph}" class="hit"/><path d="${path}"/></g>`;
    if(i%step===0)g+=`<text x="${cx.toFixed(1)}" y="${H-12}" class="ax" text-anchor="middle">${esc(d.l)}</text>`;
  });
  const tbl=`<details class="ctbl"><summary>Ver como tabla</summary><table><thead><tr><th>Periodo</th><th>${esc(sel.l)}${sel.cur!=='%'?' ('+sel.cur+')':''}</th></tr></thead><tbody>${data.map(d=>`<tr><td>${esc(d.l)}</td><td>${esc(sel.f(d.v))}</td></tr>`).join('')}</tbody></table></details>`;
  return `<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(sel.l)} por periodo">${g}</svg><div class="ctip" hidden></div></div>${tbl}`;
}
function plHtml(F,X){
  const base=Math.max(F.ing,F.cost,1),bar=(v,cls)=>`<span class="plb"><i class="${cls||''}" style="width:${Math.min(100,Math.abs(v)/base*100).toFixed(1)}%"></i></span>`;
  const row=(l,v,cls,b,sub)=>`<div class="plr${b?' tot':''}"><span class="pl1">${l}${sub?`<small>${sub}</small>`:''}</span>${bar(v,cls)}<b class="${v<0?'negv':''}">${money(v)}</b></div>`;
  return `<p class="note plcur">Montos en pesos mexicanos (MXN)</p>`+row('Exportación',F.ingExp,'in',0,fmt(F.cajas)+' cajas · '+usd(F.ingUSD)+' a '+money(F.ingUSD>0?F.ingExp/F.ingUSD:0,2)+' MXN/USD')+row('Nacional',F.ingNac,'in',0,F.ingJug?'segundas, Torreón y Juguera ('+mxn(F.ingJug)+' · '+fmt(F.jugCaj,F.jugCaj%1?1:0)+' cajas)':'segundas y Torreón')+row('Ingresos',F.ing,'in',1)
   +row('Compra de fruta',F.fruta,'out',0,fmt(F.kilos)+' kg al productor'+(F.frutaJug?' · Juguera '+mxn(F.frutaJug):''))+row('Material de empaque',F.mat,'out')+row('Mano de obra',F.mo,'out')+row('Flete y cruce',F.flete,'out')+row('Costos',F.cost,'out',1)
   +row('Utilidad bruta',F.util,F.util<0?'neg':'ut',1,'margen '+pctTxt(F.margen))
   +(X?row('Costos fijos',X.tot,'out',0,X.nW+(X.nW===1?' semana':' semanas'))+row('Utilidad después de fijos',F.util-X.tot,F.util-X.tot<0?'neg':'ut',1,'margen '+pctTxt(F.ing>0?(F.util-X.tot)/F.ing:null)):'');
}
function simHtml(F){
  return `<p class="note" style="margin-bottom:8px">Mueve el precio de venta y el tipo de cambio para ver cómo cambiaría la utilidad del periodo. No cambia ningún dato.</p>
<label class="fld simf" for="sim-p"><span>Precio de venta (USD) <b data-out="simp">0%</b></span><input type="range" id="sim-p" min="-30" max="30" step="1" value="0" data-sim="p"></label>
<label class="fld simf" for="sim-t"><span>Tipo de cambio (MXN por USD) <b data-out="simt">0%</b></span><input type="range" id="sim-t" min="-15" max="15" step="1" value="0" data-sim="t"></label>
<div class="simres"><div><span>Utilidad</span><b data-out="simu">${mxn(F.util)}</b></div><div><span>Margen</span><b data-out="simm">${pctTxt(F.margen)}</b></div><div><span>Diferencia</span><b data-out="simd">$0 MXN</b></div></div>`;
}
function simCalc(F,p,t){
  /* solo la venta de exportación está en dólares; todos los costos van en pesos */
  const ing=F.ingExp*(1+p)*(1+t)+F.ingNac,cost=F.fruta+F.mat+F.mo+F.flete,u=ing-cost;
  return {u:u,m:ing>0?u/ing:null,d:u-F.util};
}
function tipoFinHtml(F){
  const ts=TIPO_K.filter(t=>F.cajT[t]>0);if(!ts.length)return '<p class="note">Sin cajas de exportación en el periodo.</p>';
  const mx=Math.max(...ts.map(t=>F.ingT[t]),1);
  return ts.map(t=>`<div class="tfr"><div class="tf1"><strong>${esc(TIPO_L[t])}</strong><small>${fmt(F.cajT[t])} cajas · ${usd(F.usdT[t]/F.cajT[t],2)} por caja</small></div><span class="plb"><i class="in" style="width:${(F.ingT[t]/mx*100).toFixed(1)}%"></i></span><b>${mxn(F.ingT[t])}<small>${pctTxt(F.ingExp>0?F.ingT[t]/F.ingExp:null)}</small></b></div>`).join('');
}
function calFinHtml(F){
  const cs=CAL_ASC.filter(k=>F.cajC[k]>0);if(!cs.length)return '<p class="note">Sin cajas de exportación en el periodo.</p>';
  const mx=Math.max(...cs.map(k=>F.ingC[k]),1);
  return cs.map(k=>`<div class="tfr"><div class="tf1"><strong>${esc(CAL_LAB[k])}</strong><small>${fmt(F.cajC[k])} cajas · ${usd(F.usdC[k]/F.cajC[k],2)} por caja</small></div><span class="plb"><i class="in" style="width:${(F.ingC[k]/mx*100).toFixed(1)}%"></i></span><b>${mxn(F.ingC[k])}<small>${pctTxt(F.ingExp>0?F.ingC[k]/F.ingExp:null)}</small></b></div>`).join('');
}
function prodFinHtml(D){
  const f=statsF,s=f.fsort||'util',dir=f.dir==='asc'?1:-1;
  const val=a=>s==='margen'?(a.margen==null?-1e9:a.margen):s==='pago'?a.pago:a.util;
  const rows=D.fin.rows.filter(a=>a.ing||a.cost).sort((a,b)=>((val(a)-val(b))*dir)||a.nombre.localeCompare(b.nombre));
  const mx=Math.max(1,...rows.map(a=>Math.abs(a.util)));
  const b=(k,t)=>`<button class="btn sm" data-act="fsort:${k}" aria-pressed="${s===k}">${t}</button>`;
  return `<div class="srt">${b('util','Por utilidad')}${b('margen','Por margen')}${b('pago','Por pago')}<button class="btn sm" data-act="dir">↑↓ ${f.dir==='desc'?'Mayor primero':'Menor primero'}</button></div>
<div class="cgrid">${rows.map(a=>{const r=D.finRef?D.finRef.map.get(a.key):null;return `<div class="prd pfin"><div class="r1"><div class="pnm">${esc(a.nombre)}<small>${a.codigo?'#'+pad(a.codigo,3):'sin código'} · ${a.ped.size} ${a.ped.size===1?'pedido':'pedidos'}</small></div><div class="rend${a.util<0?' negv':''}">${money(a.util)}<em class="cur">MXN</em><small>utilidad · margen ${pctTxt(a.margen)}</small></div></div>
<div class="dvb" aria-hidden="true"><span class="dvl">${a.util<0?`<i style="width:${(Math.abs(a.util)/mx*100).toFixed(1)}%"></i>`:''}</span><span class="dvr">${a.util>=0?`<i style="width:${(a.util/mx*100).toFixed(1)}%"></i>`:''}</span></div>
<div class="r2">${fmt(a.kilos)} kg · ${fmt(a.cajas)} cajas · ingresos ${mxn(a.ing)} · costos ${mxn(a.cost)}</div><div class="r3"><span>A pagar por fruta: <b>${mxn(a.pago)}</b></span>${r?varChip(relV(a.util,Math.abs(r.util)),'%','up'):nocmpChip()}</div></div>`}).join('')}</div>
<p class="note" style="margin-top:8px">Utilidad por productor = lo que vale su fruta empacada (exportación y nacional) menos lo que se le paga por kilo, el material, la mano de obra y su parte del flete. Sirve para comparar; no es un estado contable.</p>`;
}
/* ---------- hoja «Precios y costos» ---------- */
/* precio por calibre: si una casilla queda vacía se usa el precio general del tipo y calidad */
/* precios por calibre en carrusel: se desliza con el dedo o con los botones, sin volver a dibujar la ventana */
function calPriceHtml(e,F,inp){
  const t=TIPO_K.indexOf(sheet.ct)>=0?sheet.ct:'RPC';
  const tabs=TIPO_K.map(k=>`<button class="btn sm" data-act="fincal:${k}" aria-pressed="${t===k}">${esc(TIPO_L[k])}</button>`).join('');
  const slide=k=>{const C=(F.cal&&F.cal[k])||{},cs=calsForTipo(k);return `<div class="fcs" data-ct="${k}" role="group" aria-label="${esc(TIPO_L[k])}"><div class="fcst">${esc(TIPO_L[k])}</div><div class="fingrid"><span></span><span class="fh">Primera</span><span class="fh">Segundas</span>${cs.map(c=>`<span class="fl">${esc(c.l)}</span>${inp('cal.'+k+'.1.'+c.k,(C['1']||{})[c.k],'Primera '+TIPO_L[k]+' calibre '+c.l,F.venta[k]['1'])}${inp('cal.'+k+'.1.5.'+c.k,(C['1.5']||{})[c.k],'Segundas '+TIPO_L[k]+' calibre '+c.l,F.venta[k]['1.5'])}`).join('')}</div></div>`};
  return `<div class="sec">Precio por calibre (USD por caja)</div><p class="note" style="margin-bottom:6px">Opcional. Lo que dejes vacío usa el precio general de arriba. Desliza para cambiar de presentación.</p><div class="srt fctabs">${tabs}</div>
<div class="fcar" id="fcar" data-start="${t}">${TIPO_K.map(slide).join('')}</div><div class="fdots" aria-hidden="true">${TIPO_K.map(k=>`<i data-dot="${k}"${t===k?' class="on"':''}></i>`).join('')}</div>`;
}
function fcarGo(k,smooth){const c=document.getElementById('fcar'),sl=c&&c.querySelector('[data-ct="'+k+'"]');if(!sl)return;c.scrollTo({left:sl.offsetLeft-c.offsetLeft,behavior:smooth?'smooth':'auto'});fcarMark(k)}
function fcarMark(k){if(sheet&&sheet.kind==='fin')sheet.ct=k;document.querySelectorAll('.fctabs [data-act^="fincal:"]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.act==='fincal:'+k));document.querySelectorAll('.fdots i').forEach(i=>i.classList.toggle('on',i.dataset.dot===k))}
let fcarT=null;
document.addEventListener('scroll',e=>{const c=e.target;if(!(c&&c.id==='fcar'))return;clearTimeout(fcarT);fcarT=setTimeout(()=>{const i=Math.round(c.scrollLeft/Math.max(1,c.clientWidth)),sl=c.children[i];if(sl)fcarMark(sl.dataset.ct)},60)},true);
function finDesdeHtml(e,k,ops,ed){
  const nx=PAR.list.filter(v=>v.emp===e&&v.desde>k).sort((a,b)=>a.desde.localeCompare(b.desde))[0],v=parVer(e,k);
  const sel=ed?`<label class="fld" for="fin-desde"><span>Los cambios aplican desde</span><select class="in sel" id="fin-desde" data-findesde="1">${ops.map(x=>`<option value="${x}"${x===k?' selected':''}>${esc(wkLab(x))} · ${esc(wkSpan(x))}</option>`).join('')}</select></label>`:'';
  return `<div class="panel fdesde">${sel}<p class="note">${v?`Mostrando la versión vigente para ${esc(wkLab(k))}: desde ${esc(wkLab(v.desde))}, ${esc(v.origen==='migrado'?'migrada':v.origen==='cliente-viejo'?'de una versión anterior de la app':'guardada')} por ${esc(v.by||'—')} (${esc(fmtTs(v.at))}).`:'Todavía no hay versiones guardadas: se usan los precios actuales.'}${nx?` Hay otra versión desde ${esc(wkLab(nx.desde))}: lo que cambies aquí aplica hasta la semana anterior a esa.`:''} Las semanas cerradas no cambian: usan la foto guardada al cerrarlas.</p>${v&&v.nota==='valores de ejemplo'?'<div class="warnbox"><strong>La versión migrada tiene valores de ejemplo</strong><div>Captura los precios reales eligiendo desde qué semana aplican.</div></div>':''}</div>`;
}
function parHistHtml(e){
  const L=PAR.list.filter(v=>v.emp===e).sort((a,b)=>parNewer(a,b)?-1:1),n=sheet.hn||8;
  if(!L.length)return '';
  const O={migrado:'Migrada',admin:'Guardada','cliente-viejo':'Desde versión anterior de la app'};
  return `<details class="parhist"><summary>Historial de versiones (${L.length})</summary>${L.slice(0,n).map(v=>`<div class="kv"><span>Desde ${esc(wkLab(v.desde))}<br><small class="note">${esc(O[v.origen]||v.origen)} · ${esc(v.by||'—')} · ${esc(fmtTs(v.at))}${v.nota?' · '+esc(v.nota):''}${PAR.dirty.indexOf(v.id)>=0&&cfgOK()?' · sin subir':''}</small></span><b>${money(+v.vals.tc||0,2)} MXN/USD</b></div>`).join('')}${L.length>n?'<button class="btn sm" data-act="parmore">Ver más</button>':''}<p class="note">Las versiones no se editan ni se borran. Para corregir una, guarda otra desde la misma semana.</p></details>`;
}
function finSetHtml(){
  const e=sheet.e||'VL',ops=finDesdeOpts(),k=ops.indexOf(sheet.desde)>=0?sheet.desde:finDesdeDef(),F=parVerVals(e,k),ed=isAdmin(),dis=ed?'':' readonly';sheet.desde=k;
  const bp=x=>F[x]!=null&&F[x]!==''?F[x]:BI_DEF[x];
  const inp=(path,v,lab,ph)=>`<label class="fld" for="fin-${path.replace(/\./g,'-')}"><span>${lab}</span><input class="in" id="fin-${path.replace(/\./g,'-')}" inputmode="decimal" data-fin="${e}.${path}" value="${v==null?'':esc(v)}"${ph!=null?` placeholder="${esc(ph)}"`:''}${dis}></label>`;
  const tabs=['VL','EC'].map(k=>`<button class="btn sm" data-act="finemp:${k}" aria-pressed="${e===k}">${EMPS[k].name}</button>`).join('');
  return `<div class="shhead"><h3>Precios y costos</h3><button type="button" class="shx" data-act="closesheet" aria-label="Cerrar precios y costos">✕</button></div><p class="note" style="margin-bottom:8px">${ed?'Se guardan al salir de cada casilla y se usan en Estadísticas › Finanzas.':'Solo el administrador puede cambiarlos.'}${FIN.ejemplo?' Ahora son valores de ejemplo.':''}</p><div class="srt">${tabs}</div>
${finDesdeHtml(e,k,ops,ed)}
<div class="sec">Tipo de cambio</div><div class="grid2">${inp('tc',F.tc,'Pesos por dólar (MXN por 1 USD)')}</div>
<div class="sec">Venta de exportación · precio general (USD por caja)</div><div class="fingrid"><span></span><span class="fh">Primera</span><span class="fh">Segundas</span>${TIPO_K.map(t=>`<span class="fl">${esc(TIPO_L[t])}</span>${inp('venta.'+t+'.1',F.venta[t]['1'],'Primera '+TIPO_L[t])}${inp('venta.'+t+'.1.5',F.venta[t]['1.5'],'Segundas '+TIPO_L[t])}`).join('')}</div>
${calPriceHtml(e,F,inp)}
<div class="sec">Fruta y venta nacional (MXN)</div><div class="grid2">${inp('kg',F.kg,'Pago al productor (MXN por kg)')}${inp('seg',F.seg,'Segunda nacional (MXN por caja)')}${inp('tor',F.tor,'Torreón (MXN por caja)')}<fieldset class="jugbox"><legend>Juguera · venta del empaque</legend>${inp('jugKg',F.jugKg,'Kilos por caja',fmt(SEG_KG)+' kg')}${inp('jugVKg',jugVKgTxt(F),'Venta por kg (MXN)','sin capturar')}${inp('jug',F.jug,'Venta por caja (MXN)','sin capturar')}</fieldset></div><p class="note">La Juguera es venta del empaque: no se le paga al productor y no es merma. Escribe la venta por kilo o por caja y la otra se calcula con los kilos por caja (vacío: ${fmt(SEG_KG)} kg). Se guarda la venta por caja. Se cobra por semana en Finanzas › Por cobrar (Juguera); si registras la liquidación, esa manda.</p>
<div class="sec">Empaque (MXN por caja)</div><div class="grid2">${TIPO_K.map(t=>inp('mat.'+t,F.mat[t],'Material '+TIPO_L[t]+' (MXN)')).join('')}${inp('mo',F.mo,'Mano de obra (MXN por caja)')}</div>
<div class="sec">Por embarque (MXN)</div><div class="grid2">${inp('flete',F.flete,'Flete (MXN)')}${inp('cruce',F.cruce,'Cruce y aduana (MXN)')}</div><p class="note">Si en Finanzas › Por pagar se registra el flete real de un embarque, ese monto prevalece sobre estos dos.</p>
<div class="sec">Merma</div><div class="grid2">${inp('matMerma',F.matMerma,'Material usado en merma (MXN por caja de desecho)','sin capturar')}</div>
<div class="sec">Cuentas por pagar (días de crédito)</div><div class="grid2">${inp('plazoProd',F.plazoProd,'Días para pagar a productores (después de terminar la semana)','sin capturar')}${inp('plazoFlete',F.plazoFlete,'Días para pagar flete y cruce (después del embarque)','sin capturar')}</div><p class="note">Vacío: vence el último día de la semana o el día del embarque.</p>
<div class="sec">Capital de trabajo</div><div class="grid2">${inp('umbralCT',F.umbralCT,'Umbral del hueco de capital de trabajo (MXN)','sin umbral')}</div><p class="note">Si lo que falta por cobrar (convertido a MXN) menos lo que falta por pagar pasa de este monto, sale una alerta. Vacío: sin alerta.</p>
${fijosFormHtml(e,F,inp,ed)}
<div class="sec">Inteligencia de negocio</div><div class="grid2">${inp('fijo',bp('fijo'),F.fijos?'Costos fijos por semana sin separar (no se usa: hay categorías)':'Costos fijos por semana (MXN), si no los separas por categoría')}${inp('meta',bp('meta'),'Meta de cajas por hora')}${inp('salHr',bp('salHr'),'Salario por hora hombre (MXN)')}${inp('comis',bp('comis'),'Comisión en consignación (%)')}</div>
${parHistHtml(e)}
<div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset||!t.dataset.fin||!isAdmin())return;
  /* venta.RPC.1.5: la calidad lleva punto */
  const p=t.dataset.fin.split('.'),e0=p.shift(),v=t.dataset.fstr?(String(t.value||'')||null):num(String(t.value).replace(',','.'));
  const k=t.dataset.fk?t.dataset.fk:sheet&&sheet.kind==='fin'&&t.closest('.sheet')?sheet.desde:finDesdeDef();
  if(p[0]==='jugVKg'){const kg=jugKgDe(parVerVals(e0,k));finEdit(e0,['jug'],v==null?null:Math.round(v*kg*10000)/10000,k)}
  else if(p[0]==='jugProdKg'){const kg=jugKgDe(parVerVals(e0,k));finEdit(e0,['jugProd'],v==null?null:Math.round(v*kg*10000)/10000,k)}
  else{finEdit(e0,p,v,k);t.value=v==null?'':v}
  if(view==='stats'||view==='fin')render();if(t.dataset.grp&&sheet&&sheet.kind==='grandes')grUpdate(t.dataset.grp);if(sheet&&sheet.kind==='fin'&&t.closest('.sheet')&&(p[0]==='fijos'||p[0]==='jugModo'||/^jug(|VKg|Prod|ProdKg|Kg)$/.test(p[0])))renderSheet();
});
/* Juguera: caja y kilo se acompañan mientras se escribe */
document.addEventListener('input',e=>{
  const t=e.target;if(!t||!t.dataset||!t.dataset.fin)return;const p=t.dataset.fin.split('.');if(!/^jug(|VKg|Kg)$/.test(p[1]))return;
  const val=id=>{const x=document.getElementById(id);return x?num(String(x.value).replace(',','.')):null};
  const kg=val('fin-jugKg')||SEG_KG,v=num(String(t.value).replace(',','.')),r4=x=>String(Math.round(x*10000)/10000);
  const cj=document.getElementById('fin-jug'),kgo=document.getElementById('fin-jugVKg');if(!cj||!kgo)return;
  if(p[1]==='jug')kgo.value=v==null?'':r4(v/kg);
  else if(p[1]==='jugVKg')cj.value=v==null?'':r4(v*kg);
  else{const c=val('fin-jug');kgo.value=c==null?'':r4(c/kg)}
});
document.addEventListener('input',e=>{
  const t=e.target;if(!t||!t.dataset||!t.dataset.sim)return;
  const D=statsData();if(!D.fin)return;
  const p=+document.getElementById('sim-p').value/100,tc=+document.getElementById('sim-t').value/100,r=simCalc(D.fin.T,p,tc);
  const set=(k,v)=>{const el=document.querySelector('[data-out="'+k+'"]');if(el)el.textContent=v};
  set('simp',(p>0?'+':'')+Math.round(p*100)+'%');set('simt',(tc>0?'+':'')+Math.round(tc*100)+'%');set('simu',mxn(r.u));set('simm',pctTxt(r.m));set('simd',(r.d>=0?'+':'')+mxn(r.d));
});
/* tooltip de la gráfica */
function chartTip(e){
  /* barras y puntos (matriz de productores): al pasar el cursor, enfocar o tocar se ve de quién es */
  const g=e.target&&e.target.closest&&e.target.closest('.bar,.dot');const ch=e.target&&e.target.closest&&e.target.closest('.chart');if(!ch)return;
  const tip=ch.querySelector('.ctip');if(!tip)return;
  ch.querySelectorAll('.dot.on').forEach(x=>{if(x!==g)x.classList.remove('on')});
  if(!g||e.type==='mouseleave'||e.type==='focusout'){tip.hidden=true;return}
  g.classList.add('on');
  const r=ch.getBoundingClientRect(),b=(g.querySelector('path')||g.querySelector('.pt')||g).getBoundingClientRect();
  tip.textContent=g.dataset.tip;tip.hidden=false;
  tip.style.maxWidth=Math.max(120,r.width-16)+'px';const hw=tip.offsetWidth/2,x=Math.min(r.width-8-hw,Math.max(8+hw,b.left-r.left+b.width/2));tip.style.left=x+'px';tip.style.top=Math.max(0,b.top-r.top-8)+'px';
}
['mouseover','focusin','click'].forEach(t=>document.addEventListener(t,chartTip));
/* con el dedo no hay «salir del punto»: la etiqueta queda hasta tocar otro lugar */
let tipTouch=false;document.addEventListener('pointerdown',e=>{tipTouch=e.pointerType==='touch'||e.pointerType==='pen'},true);document.addEventListener('pointermove',e=>{if(e.pointerType==='mouse')tipTouch=false},true);
document.addEventListener('mouseout',e=>{if(tipTouch)return;if(e.target&&e.target.closest&&e.target.closest('.bar,.dot')&&!(e.relatedTarget&&e.relatedTarget.closest&&e.relatedTarget.closest('.bar,.dot'))){const ch=e.target.closest('.chart');const tip=ch&&ch.querySelector('.ctip');if(tip)tip.hidden=true;if(ch)ch.querySelectorAll('.dot.on').forEach(x=>x.classList.remove('on'))}});

/* ---------- periodos: semanas de producción que el administrador abre y cierra ---------- */
const LS_PER='empaque-periodos',LS_LWK='empaque-listwk';
let PER={list:{},ts:0,dirty:false};
(function(){try{const r=JSON.parse(localStorage.getItem(LS_PER)||'null');if(r&&r.list)PER=Object.assign({list:{},ts:0,dirty:false},r)}catch(e){}})();
let listWk=(()=>{try{return localStorage.getItem(LS_LWK)||''}catch(e){return ''}})();
function savePer(stamp){if(stamp){PER.ts=Date.now();PER.dirty=true}try{localStorage.setItem(LS_PER,JSON.stringify(PER))}catch(e){}invalidateStats();setSync()}
async function syncPer(){
  try{
    const r=await sb('/rest/v1/catalogos?select=updated_at,data&clave=eq.periodos');
    const rem=(r&&r[0]&&r[0].data&&r[0].data.list)||{};
    Object.keys(rem).forEach(k=>{const a=PER.list[k],b=rem[k];if(b&&(!a||(+b.ts||0)>(+a.ts||0))){PER.list[k]=b;remoteN++}});
    const ahead=Object.keys(PER.list).some(k=>!rem[k]||(+PER.list[k].ts||0)>(+rem[k].ts||0));
    if(ahead&&perAdmin()){await sb('/rest/v1/catalogos?on_conflict=clave',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{clave:'periodos',updated_at:Date.now(),data:{list:PER.list}}]})}
    PER.dirty=false;savePer(false);
  }catch(e){}
}
/* año y semana ISO de una fecha (lunes a domingo) */
function wkOfDate(s){const d=new Date(String(s||'')+'T12:00:00Z');if(!s||isNaN(d))return '';const t=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()));t.setUTCDate(t.getUTCDate()+4-(t.getUTCDay()||7));return t.getUTCFullYear()+'-S'+pad(isoWeek(s),2)}
function wkOf(o){const w=num(o&&o.semana),y=+(o&&o.anio)||+String((o&&o.fecha)||'').slice(0,4);return w&&y?y+'-S'+pad(w,2):wkOfDate(o&&o.fecha)}
function wkRange(k){const m=/^(\d{4})-S(\d{2})$/.exec(k||'');if(!m)return null;const j4=new Date(Date.UTC(+m[1],0,4)),mon=new Date(j4);mon.setUTCDate(j4.getUTCDate()-(j4.getUTCDay()||7)+1+(+m[2]-1)*7);const a=mon.toISOString().slice(0,10);return {a:a,b:dayAdd(a,6)}}
function wkLab(k,short){const m=/^(\d{4})-S(\d{2})$/.exec(k||'');return m?(short?'Sem '+(+m[2]):'Semana '+(+m[2])+' · '+m[1]):String(k||'')}
function wkSpan(k){const r=wkRange(k);if(!r)return '';const a=r.a.split('-'),b=r.b.split('-');return (+a[2])+(a[1]!==b[1]?' '+MES_C[+a[1]-1]:'')+' al '+(+b[2])+' '+MES_C[+b[1]-1]}
function wkNext(k){const r=wkRange(k);return r?wkOfDate(dayAdd(r.a,7)):''}
function wkPrevYear(k){const m=/^(\d{4})-S(\d{2})$/.exec(k||'');return m?(+m[1]-1)+'-S'+m[2]:''}
const wkClosed=k=>!!(PER.list[k]&&PER.list[k].closed);
function orderLocked(o){return !!o&&wkClosed(wkOf(o))}
function perAdmin(){return !roRole&&!!authUser&&authUser.rol==='admin'&&(!cfgOK()||(!!session&&roleOf(session.access_token)==='admin'))}
function weekKeys(withNow){const s=new Set();visible().forEach(o=>{const k=wkOf(o);if(k)s.add(k)});Object.keys(PER.list).forEach(k=>s.add(k));if(withNow)s.add(wkOfDate(todayISO()));return [...s].filter(Boolean).sort().reverse()}
function wkStats(k){
  const L=visible().filter(o=>wkOf(o)===k),fs=L.map(o=>o.createdAt||0).filter(Boolean);let caj=0;L.forEach(o=>caj+=compute(o).tot.exp);
  return {L:L,ped:new Set(L.map(o=>o.emp+'|'+o.cod)).size,caj:caj,first:fs.length?Math.min(...fs):0,proc:L.filter(o=>o.estado!=='completo'&&isLeader(o)).length};
}
/* segundas que siguen en almacén al cerrar la semana: las de esa semana y anteriores pasan a Juguera (v8.13: la semana de una segunda es la del empaque donde salió) */
function jugCandidates(k){const out=[];seg2Lots().forEach(l=>{if(l.av<=0)return;const lk=l.wk||(l.fecha?wkOfDate(l.fecha):'');if(!lk||lk<=k)out.push(l)});return out.sort((a,b)=>a.nombre.localeCompare(b.nombre)||(a.fecha||'').localeCompare(b.fecha||''))}
/* v8.16: cajas que se irían a Juguera al cerrar, separadas en segundas y cera, con su venta estimada (precio de Juguera de cada empresa) */
function jugCandMoney(k){const L=visible();let seg=0,cera=0,cob=0,sin=false;jugCandidates(k).forEach(l=>{const n=n0(l.av);if(l.cera)cera+=n;else seg+=n;const o=String(l.id)[0]==='o'?L.find(z=>z.id===String(l.id).split('.')[1]):null,P=jugPar(o?o.emp:'VL',k);if(P.precio==null)sin=true;else cob+=n*P.precio});return {seg:seg,cera:cera,cob:cob,sin:sin}}
function jugByProd(lots){const g=new Map();lots.forEach(l=>{const k=l.key||invKey(l.codigo,l.nombre);let x=g.get(k);if(!x){x={nombre:l.nombre,codigo:l.codigo,n:0,lots:[]};g.set(k,x)}x.n+=n0(l.n!=null?l.n:l.av);x.lots.push(l)});return [...g.values()]}
function closeWeek(k){
  if(!perAdmin()||!k)return;if(wkClosed(k)){toast(wkLab(k)+' ya está cerrada');return}
  const lots=jugCandidates(k).map(l=>({lot:l.id,key:l.key,n:l.av,nombre:l.nombre,codigo:l.codigo,fecha:l.fecha,de:l.de,cera:l.cera||undefined})),caj=lots.reduce((s,x)=>s+x.n,0),S=wkStats(k),now=Date.now();
  const p=PER.list[k]||{k:k};if(!p.openAt){p.openAt=S.first||now;p.openBy=p.openBy||''}
  Object.assign(p,{k:k,closed:true,closeBy:authUser.name||authUser.user||'—',closeAt:now,ts:now,jug:{cajas:caj,lots:lots,envio:wkNext(k)}});
  (p.hist=p.hist||[]).push({a:'close',by:p.closeBy,at:now,jug:caj});
  parFotoAdd(k,'cierre');
  PER.list[k]=p;savePer(true);
  logAdd({k:'period',where:'Periodos',ctx:{t:'w',id:k,cod:wkLab(k)},lab:'Cierre de '+wkLab(k),o:'Abierta',n:'Cerrada'+(caj?' · '+fmt(caj)+' cajas de segunda a Juguera':'')});
  confirmKey=null;sheet={kind:'wkdone',k:k};renderSheet();render();
  toast(caj?'Se registraron '+fmt(caj)+' cajas a Juguera':wkLab(k)+' cerrada');
}
function openWeek(k,motivo){
  motivo=String(motivo||'').trim();
  if(!perAdmin()||!k||!motivo)return false;const p=PER.list[k];if(!p||!p.closed)return false;
  const now=Date.now(),back=(p.jug&&p.jug.cajas)||0;
  Object.assign(p,{closed:false,openBy:authUser.name||authUser.user||'—',openAt:now,ts:now,jug:null});
  (p.hist=p.hist||[]).push({a:'open',by:p.openBy,at:now,jug:-back,motivo:motivo});
  savePer(true);confirmKey=null;
  logAdd({k:'period',where:'Periodos',ctx:{t:'w',id:k,cod:wkLab(k)},lab:'Reapertura de '+wkLab(k),o:'Cerrada',n:'Abierta · motivo: '+motivo+(back?' · '+fmt(back)+' cajas regresan de Juguera al almacén':''),motivo:motivo});
  renderSheet();render();toast(wkLab(k)+' reabierta'+(back?'. '+fmt(back)+' cajas de segunda regresan al almacén':''));return true;
}
const LOCK_SVG='<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2"/></svg>';
function lockBan(o){
  if(!orderLocked(o))return '';const k=wkOf(o),p=PER.list[k]||{};
  return `<div class="panel lockp" role="note"><strong>${LOCK_SVG} ${esc(wkLab(k))} cerrada</strong><p class="note" style="margin-top:4px">Cerrada por ${esc(p.closeBy||'—')} (${esc(fmtTs(p.closeAt))}). Puedes verla y descargarla; para corregir algo un administrador la reabre en Periodos.</p>${perAdmin()?'<div class="pact"><button class="btn sm" data-act="peropen">Periodos</button></div>':''}</div>`;
}
/* tabla de periodos, como «Open/Close Periods» */
function perHtml(){
  const ks=weekKeys(true),n=sheet.n||12,shown=ks.slice(0,n),adm=perAdmin();
  const rows=shown.map(k=>{
    const p=PER.list[k]||{},S=wkStats(k),cl=!!p.closed,oa=p.openAt||S.first,ck=(cl?'pro:':'prc:')+k;
    const jug=cl&&p.jug?fmt(p.jug.cajas):'';
    return `<tr class="${cl?'wcl':''}"><th scope="row"><b>${esc(wkLab(k))}</b><small>${esc(wkSpan(k))} · ${S.ped} ${S.ped===1?'pedido':'pedidos'}</small></th><td class="c"><span class="pbox${cl?' on':''}" role="img" aria-label="${cl?'Cerrada':'Abierta'}">${cl?'✓':''}</span></td><td>${esc(p.openBy||(oa?'Automático':'—'))}</td><td class="m">${oa?esc(fmtTs(oa)):'—'}</td><td>${esc(cl?p.closeBy||'—':'')}</td><td class="m">${cl?esc(fmtTs(p.closeAt)):''}</td><td class="m r">${jug}</td><td>${adm?`<button class="btn sm${cl?'':' primary'}" data-act="${ck}">${confirmKey===ck?'Toca otra vez':(cl?'Reabrir':'Cerrar')}</button>`:''}</td></tr>`;
  }).join('');
  const ro0=sheet.reopen&&wkClosed(sheet.reopen)?sheet.reopen:null;
  const reo=ro0?`<div class="panel reop" role="group" aria-label="Reabrir ${esc(wkLab(ro0))}"><strong>Reabrir ${esc(wkLab(ro0))}</strong><p class="note" style="margin:4px 0 8px">Sus cifras dejarán de usar la foto del cierre hasta que la vuelvas a cerrar. El motivo queda en la bitácora.</p><label class="fld" for="reo-m"><span>Motivo (obligatorio)</span><textarea class="in txt" id="reo-m" rows="2">${esc(sheet.reoTxt||'')}</textarea></label>${sheet.reoErr?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.reoErr)}</p>`:''}<div class="pact"><button class="btn sm" data-act="reono">Cancelar</button><button class="btn sm primary" data-act="reogo:${ro0}">Reabrir</button></div></div>`:'';
  return `<h3>Periodos · semanas de producción</h3><p class="note" style="margin-bottom:8px">${adm?'Cerrar una semana deja sus pedidos en solo lectura, congela sus precios y costos, y manda a Juguera las segundas que sigan en almacén (se envían la semana siguiente). Reabrirla pide un motivo y las regresa al almacén.':'Solo un administrador abre o cierra semanas.'}</p>${reo}
<div class="tblx"><table class="ptbl"><thead><tr><th>Periodo</th><th>Cerrado</th><th>Abierto por</th><th>Fecha apertura</th><th>Cerrado por</th><th>Fecha cierre</th><th>Juguera</th><th><span class="sr">Acción</span></th></tr></thead><tbody>${rows}</tbody></table></div>
${ks.length>n?`<div class="more"><button class="btn sm" data-act="permore">Ver ${Math.min(12,ks.length-n)} semanas anteriores</button></div>`:''}<div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
/* hoja «Cerrar semana»: resumen para contabilidad, pago a productores y segundas que pasan a Juguera */
function wkcDefault(){const open=weekKeys(false).filter(k=>!wkClosed(k)&&wkStats(k).L.length);const now=wkOfDate(todayISO());return open.filter(k=>k<now)[0]||open[0]||now}
/* Juguera de una semana: lo ya registrado más las segundas que pasarían al cerrarla */
function jugPreview(k){
  const JG=jugData(),m=new Map(),L=visible();
  const put=(c,n,caj,unit,pu)=>{const key=c?'c'+c:'n'+norm(n||'');let a=m.get(key);if(!a){const li=c?LISTA.find(x=>x.c===c):null;a={nombre:(li&&li.n)||n||'Sin nombre',codigo:c||null,caj:0,cob:0,pago:0};m.set(key,a)}a.caj+=caj;a.cob+=caj*unit;a.pago+=caj*pu};
  let sinPrecio=false,own=0,ownCob=0;
  Object.keys(EMPS).forEach(e=>{const w=JG.W.get(e+'|'+k);if(w){if(w.liq==null&&w.par.precio==null)sinPrecio=true;w.prods.forEach(a=>put(a.codigo,a.nombre,a.caj,w.unit,w.prodUnit));own+=w.own;ownCob+=w.own*w.unit}});
  /* segundas que pasarán al cerrar: son del empaque */
  if(!wkClosed(k))jugCandidates(k).forEach(l=>{const o=String(l.id)[0]==='o'?L.find(z=>z.id===String(l.id).split('.')[1]):null,e=o?o.emp:'VL',w=JG.W.get(e+'|'+k),P=jugPar(e,k);
    if(!(w&&w.liq!=null)&&P.precio==null)sinPrecio=true;const unit=w&&w.liq!=null?w.unit:(P.precio||0);own+=l.av;ownCob+=l.av*unit});
  const R=[...m.values()].sort((a,b)=>b.caj-a.caj),pc=R.reduce((s,a)=>s+a.caj,0),pcob=R.reduce((s,a)=>s+a.cob,0);
  return {R:R,pcaj:pc,own:own,ownCob:ownCob,caj:pc+own,cob:pcob+ownCob,pago:R.reduce((s,a)=>s+a.pago,0),sinPrecio:sinPrecio};
}
function jugOldTxt(k){const e=Object.keys(EMPS).filter(x=>{const F=parsDe(x,k);return num(F.jugProd)!=null||F.jugModo==='pase'});return e.length&&!decOk('jug')?'<p class="note"><span class="chip unas">Regla anterior</span> '+esc(e.map(x=>EMPS[x].name).join(' y '))+' '+(e.length>1?'tienen':'tiene')+' guardado un pago de Juguera al productor de la versión 8.6. Ya no se usa: la Juguera es venta del empaque. Registra la regla en Decisiones de dirección para dejarla firmada.</p>':''}
function jugWeekHtml(k){
  const J=jugPreview(k);if(!J.caj)return '<p class="note">Sin cajas a Juguera esta semana.</p>'+jugOldTxt(k);const f1=v=>fmt(v,v%1?1:0);
  return `<div class="ig wkg"><div><span>Cajas a Juguera</span><b>${f1(J.caj)}</b></div><div><span>Venta a la Juguera${J.sinPrecio?' · falta el precio':''}</span><b>${amt(J.cob,'MXN')}</b></div></div><p class="note">La Juguera es venta del empaque: no se le paga al productor y no cuenta como merma. Se cobra en Finanzas › Por cobrar (Juguera).</p>`+jugOldTxt(k);
}
function wkcHtml(){
  const ks=weekKeys(true).filter(k=>!wkClosed(k)),k=ks.indexOf(sheet.k)>=0?sheet.k:(ks[0]||'');sheet.k=k;
  if(!k)return `<h3>Cerrar semana</h3><p class="note">Todas las semanas están cerradas.</p><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
  const S=wkStats(k),F=finAgg(S.L),T=F.T,J=jugCandidates(k),jt=J.reduce((s,l)=>s+l.av,0),G=jugByProd(J.map(l=>Object.assign({},l,{n:l.av}))),ck='wkcgo:'+k;
  const pays=F.rows.filter(a=>a.pago>0||a.kilos>0).sort((a,b)=>b.pago-a.pago),JM=jugCandMoney(k),wn=(/S(\d+)$/.exec(k)||['',''])[1];
  return `<h3>Cerrar semana</h3><label class="fld" for="wkc-k"><span>Semana</span><select class="in sel" id="wkc-k" data-wkc="1">${ks.map(x=>`<option value="${x}"${x===k?' selected':''}>${esc(wkLab(x))} · ${esc(wkSpan(x))}</option>`).join('')}</select></label>
${S.proc?`<div class="warnbox"><strong>${S.proc} ${S.proc===1?'pedido sigue':'pedidos siguen'} en proceso</strong><div>Al cerrar quedan en solo lectura tal como están.</div></div>`:''}
<div class="ig tot wkg"><div><span>Pedidos</span><b>${fmt(S.ped)}</b></div><div><span>Cajas exportación</span><b>${fmt(T.cajas)}</b></div><div><span>Kilos</span><b>${fmt(T.kilos)}</b></div><div><span>Utilidad bruta</span><b class="${T.util<0?'neg':''}">${mxn(T.util)}</b></div></div>
<div class="sec">Pago a productores</div>${pays.length?`<div class="tblx"><table class="ptbl pay"><thead><tr><th>Productor</th><th>Kilos</th><th>Cajas</th><th>A pagar (MXN)</th></tr></thead><tbody>${pays.map(a=>`<tr><th scope="row">${esc(a.nombre)}<small>${a.codigo?'#'+pad(a.codigo,3):'sin código'}${a.consig?' · consignación':''}</small></th><td class="m r">${fmt(a.kilos)}</td><td class="m r">${fmt(a.cajas)}</td><td class="m r"><b>${money(a.pago)}</b></td></tr>`).join('')}<tr class="tot"><th scope="row">Total</th><td class="m r">${fmt(T.kilos)}</td><td class="m r">${fmt(T.cajas)}</td><td class="m r"><b>${money(T.fruta)}</b></td></tr></tbody></table></div>`:'<p class="note">Sin productores esta semana.</p>'}
<div class="sec">Segundas que pasan a Juguera</div>${jt?`<div class="panel jugp"><p><b>${fmt(jt)} cajas</b> siguen en almacén sin procesar. Al cerrar se registran a Juguera y se envían en la ${esc(wkLab(wkNext(k)))}.</p><div class="ig wkg"><div><span>Segundas</span><b>${fmt(JM.seg)}</b></div><div><span>Con cera</span><b>${fmt(JM.cera)}</b></div><div><span>Venta estimada</span><b>${JM.sin&&!JM.cob?'Sin precio':amt(JM.cob,'MXN')}</b></div></div><p class="note">Al productor ya se le pagaron como segundas${JM.cera?' (la cera también se paga como segunda)':''}; la venta a Juguera es del empaque.${decOk('cierre')?'':' <b class="unastx">Regla sin aprobación registrada en Decisiones de dirección.</b>'}</p>${G.map(x=>`<div class="kv"><span>${esc(x.nombre)}${x.codigo?' · #'+pad(x.codigo,3):''}</span><b>${fmt(x.n)}</b></div>`).join('')}</div>`:'<p class="note">No quedan segundas en almacén.</p>'}
<div class="sec">Juguera de la semana (MXN)</div>${jugWeekHtml(k)}
${perAdmin()?`<label class="fld" for="wkc-conf" style="margin-top:10px"><span>Para confirmar, escribe el número de la semana (${esc(wn)})</span><input class="in" id="wkc-conf" inputmode="numeric" autocomplete="off" data-wkcconf="${esc(wn)}"></label>`:''}
<div class="srow2"><button class="btn" data-act="wkcx:${k}">Descargar cierre</button><button class="btn primary" id="wkc-go" data-act="${ck}" disabled>Cerrar ${esc(wkLab(k,true))}</button></div><div class="srow2"><button class="btn" data-act="peropen">Periodos</button><button class="btn" data-act="closesheet">Cancelar</button></div>`;
}
function wkdoneHtml(){
  const k=sheet.k,p=PER.list[k]||{},j=p.jug||{cajas:0,lots:[]},G=jugByProd(j.lots||[]);
  return `<h3>${esc(wkLab(k))} cerrada</h3><div class="jugnote${j.cajas?'':' none'}" role="status">${j.cajas?`<b>Se registraron ${fmt(j.cajas)} cajas a Juguera</b><span>Segundas que quedaron sin procesar al cierre. Se envían en la ${esc(wkLab(j.envio||wkNext(k)))}.</span>`:'<b>No había segundas en almacén</b><span>No se registró nada a Juguera.</span>'}</div>
${G.length?'<div class="panel">'+G.map(x=>`<div class="kv"><span>${esc(x.nombre)}${x.codigo?' · #'+pad(x.codigo,3):''}</span><b>${fmt(x.n)}</b></div>`).join('')+'</div>':''}
<p class="note" style="margin-top:8px">Los pedidos de esta semana quedaron en solo lectura.</p><div class="srow2"><button class="btn" data-act="wkcx:${k}">Descargar cierre</button><button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
document.addEventListener('input',e=>{const t=e.target;if(!t||!t.dataset||t.dataset.wkcconf==null)return;const b=document.getElementById('wkc-go');if(b)b.disabled=!(t.value!==''&&String(+t.value)===String(+t.dataset.wkcconf))});
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset)return;
  if(t.dataset.wkc&&sheet&&sheet.kind==='wkc'){sheet.k=t.value;confirmKey=null;renderSheet();return}
  if(t.dataset.findesde&&sheet&&sheet.kind==='fin'){sheet.desde=t.value;renderSheet();return}
  if(t.dataset.isrt){const s=invSortOf(invTab);s.k=t.value;s.dir=t.value==='az'?'asc':'desc';invSortSet(invTab,s);render();return}
  if(t.dataset.twk){trazWk=t.value;try{localStorage.setItem(LS_TWK,trazWk)}catch(x){}render();return}
  if(t.dataset.lwk){listWk=t.value;try{localStorage.setItem(LS_LWK,listWk)}catch(x){}listAll=false;render();return}
});
/* ---------- Inteligencia de negocio (BI) ---------- */
const INCOTERMS=['FOB','FCA','EXW','CPT','CIP','CFR','CIF','DAP','DPU','DDP'];
/* OEE configurable: turno, personas y paro por pedido salen de aquí cuando el pedido no los trae; oee=0 lo apaga */
const BI_DEF={fijo:180000,meta:130,salHr:65,comis:12,oee:1,horas:9,personas:24,paro:30};
function biPar(e,k,wk){const F=wk?parsDe(e,wk):FIN[e],v=F&&F[k];return v!=null&&v!==''&&isFinite(+v)?+v:BI_DEF[k]}
function biOf(o){return (mainOf(o).bi)||{}}
function zonaOf(p){const e=p&&p.invEnt&&INV.entradas.find(x=>x.id===p.invEnt[0]);return String((e&&e.zona)||p.zona||'').trim()}
function muesOf(p){const e=p&&p.invEnt&&INV.entradas.find(x=>x.id===p.invEnt[0]);if(e&&num(e.mPri)!=null)return {pri:num(e.mPri),seg:num(e.mSeg),des:num(e.mDes)};return p&&p.mues||null}
const median=a=>{const s=a.slice().sort((x,y)=>x-y),n=s.length;return n?(n%2?s[(n-1)/2]:(s[n/2-1]+s[n/2])/2):0};
/* recta de mínimos cuadrados sobre las últimas semanas */
function linFit(ys){const n=ys.length;if(n<2)return null;let sx=0,sy=0,sxy=0,sxx=0;ys.forEach((y,i)=>{sx+=i;sy+=y;sxy+=i*y;sxx+=i*i});const d=n*sxx-sx*sx;if(!d)return null;const b=(n*sxy-sx*sy)/d,a=(sy-b*sx)/n;return {a:a,b:b,at:i=>a+b*i}}
function weekSeries(f,upto){
  const L=statsList(f,{year:'ALL',month:'ALL',desde:'',hasta:'',week:'ALL'}),g=new Map();
  L.forEach(o=>{const k=wkOf(o);if(!k||(upto&&k>upto))return;if(!g.has(k))g.set(k,[]);g.get(k).push(o)});
  return [...g.keys()].sort().slice(-8).map(k=>{const T=finAgg(g.get(k)).T;return {k:k,l:wkLab(k,true),cajas:T.cajas,util:T.util,ing:T.ing}});
}
function biCalc(D){
  const f=statsF,list=D.cur.list,FA=D.fin,T=FA.T,es=f.emp==='ALL'?['VL','EC']:[f.emp];
  const wks=[...new Set(list.map(wkOf).filter(Boolean))].sort(),nW=Math.max(1,wks.length);
  /* punto de equilibrio: costos fijos de las semanas del periodo entre lo que deja cada caja */
  const FP=fijoPeriodo(wks,es),fijo=wks.length?FP.tot:es.reduce((s,e)=>s+fijoSem(e),0),fijoW=fijo/nW,contrib=T.cajas>0?(T.ing-T.cost)/T.cajas:null;
  const be=contrib>0?Math.ceil(fijo/contrib):null,neta=T.util-fijo;
  /* por pedido (todas sus hojas juntas) */
  const peds=new Map();
  FA.ords.forEach(x=>{const o=x.o,k=o.emp+'|'+o.cod;let p=peds.get(k);if(!p){p={k:k,m:mainOf(o),emp:o.emp,cod:o.cod,wk:wkOf(o),ing:0,usd:0,nac:0,fruta:0,mat:0,mo:0,cost:0,cajas:0,kilos:0,flete:0,cajC:{}};peds.set(k,p)}['ing','usd','nac','fruta','mat','mo','cost','cajas','kilos','flete'].forEach(q=>p[q]+=x[q]);Object.keys(x.cajC).forEach(c=>p.cajC[c]=(p.cajC[c]||0)+x.cajC[c])});
  const P=[...peds.values()];P.forEach(p=>{p.util=p.ing-p.cost;p.bi=p.m.bi||{};p.rech=n0(p.bi.rech);p.tc=+parsDe(p.emp,p.wk).tc||0});
  /* clientes */
  const cm=new Map();
  P.forEach(p=>{const nm=String(p.m.customer||'').trim()||'Sin cliente',k=norm(nm);let c=cm.get(k);if(!c){c={nombre:nm,ped:0,cajas:0,ing:0,cost:0,rech:0,dias:[],dest:new Set(),inc:new Set(),cajC:{}};cm.set(k,c)}
    c.ped++;c.cajas+=p.cajas;c.ing+=p.ing;c.cost+=p.cost;c.rech+=p.rech;if(num(p.bi.diasPago)!=null)c.dias.push(num(p.bi.diasPago));if(p.bi.destino)c.dest.add(String(p.bi.destino).trim());if(p.bi.incoterm)c.inc.add(p.bi.incoterm);Object.keys(p.cajC).forEach(k2=>c.cajC[k2]=(c.cajC[k2]||0)+p.cajC[k2])});
  const C=[...cm.values()];C.forEach(c=>{c.util=c.ing-c.cost;c.margen=c.ing>0?c.util/c.ing:null;c.rechP=c.cajas>0?c.rech/c.cajas:null;c.diasP=c.dias.length?c.dias.reduce((a,b)=>a+b,0)/c.dias.length:null});
  C.sort((a,b)=>(b.margen==null?-9:b.margen)-(a.margen==null?-9:a.margen)||b.util-a.util);
  /* productores: dinero, rendimiento, calidad y zona */
  const opM=D.cur.map,zm=new Map(),mues=new Map();
  list.forEach(o=>compute(o).rows.forEach(r=>{const p=r.p;if(isSob(p)||+p.codigo===SEG_COD||p.segLot)return;const key=pKey(p);
    const z=zonaOf(p)||'Sin zona';let a=zm.get(z);if(!a){a={zona:z,kilos:0,eqv:0,campo:0,prods:new Set()};zm.set(z,a)}a.kilos+=n0(p.kilos);a.prods.add(key);if(r.rend!=null){a.eqv+=r.eqv;a.campo+=r.campo}
    const m=muesOf(p);if(m&&m.pri!=null){let q=mues.get(key);if(!q){q={s:0,n:0};mues.set(key,q)}q.s+=m.pri;q.n++}}));
  const Z=[...zm.values()];Z.forEach(z=>{z.rend=z.campo>0?z.eqv/z.campo:null});Z.sort((a,b)=>(b.rend==null?-1:b.rend)-(a.rend==null?-1:a.rend));
  const R=FA.rows.filter(a=>a.kilos>0||a.cajas>0).map(a=>{const op=opM.get(a.key)||{};const tot=n0(op.exp)+n0(op.seg)+n0(op.tor)+n0(op.des)+n0(op.jug),mq=mues.get(a.key);return Object.assign({},a,{rend:op.rend==null?null:op.rend,desP:tot>0?(n0(op.des)+n0(op.tor))/tot:null,mPri:mq?mq.s/mq.n/100:null,zona:''})});
  const bestR=Math.max(0.0001,...R.map(a=>a.rend||0));
  R.forEach(a=>{if(a.rend==null){a.iq=null;return}const r=Math.min(1,a.rend/bestR),d=1-Math.min(1,a.desP||0),m=a.mPri!=null?Math.min(1,a.mPri):a.rend;a.iq=Math.round(100*(0.6*r+0.25*d+0.15*Math.min(1,m)))});
  /* matriz BCG: volumen (kilos) contra margen */
  const kMed=median(R.map(a=>a.kilos)),mRef=T.margen==null?0:T.margen;
  R.forEach(a=>{const hv=a.kilos>=kMed,hm=(a.margen==null?-1:a.margen)>=mRef;a.q=hv&&hm?'star':hv?'cow':hm?'q':'dog'});
  /* Pareto de cajas */
  const par=R.slice().sort((a,b)=>b.cajas-a.cajas);let acc=0;const tc=par.reduce((s,a)=>s+a.cajas,0)||1;par.forEach(a=>{acc+=a.cajas;a.cum=acc/tc;a.share=a.cajas/tc});
  const n80=par.findIndex(a=>a.cum>=0.8)+1;
  /* productividad de la línea */
  const L={ped:0,cajas:0,horas:0,horasOp:0,personas:0,hh:0,rech:0,cajasAll:0,costMO:0,metaH:0};
  P.forEach(p=>{L.cajasAll+=p.cajas;L.rech+=p.rech;if(!biPar(p.emp,'oee',p.wk))return;const h=num(p.bi.horas)||biPar(p.emp,'horas',p.wk),pe=num(p.bi.personas)||biPar(p.emp,'personas',p.wk);if(!(h>0&&pe>0))return;const pa=num(p.bi.paro)!=null?num(p.bi.paro):biPar(p.emp,'paro',p.wk),op=Math.max(0,h-pa/60);p.hE=h;p.peE=pe;p.paroE=pa;
    L.ped++;L.cajas+=p.cajas;L.horas+=h;L.horasOp+=op;L.personas+=pe;L.hh+=pe*h;L.costMO+=pe*h*biPar(p.emp,'salHr',p.wk);L.metaH+=op*biPar(p.emp,'meta',p.wk);p.cph=op>0?p.cajas/op:null});
  L.cph=L.horasOp>0?L.cajas/L.horasOp:null;L.cpp=L.personas>0?L.cajas/L.personas:null;L.cphh=L.hh>0?L.cajas/L.hh:null;
  L.disp=L.horas>0?L.horasOp/L.horas:null;L.perf=L.metaH>0?Math.min(1,L.cajas/L.metaH):null;L.cal=L.cajasAll>0?1-L.rech/L.cajasAll:null;
  L.oee=L.disp!=null&&L.perf!=null&&L.cal!=null?L.disp*L.perf*L.cal:null;L.moCaja=L.cajas>0?L.costMO/L.cajas:null;
  /* logística */
  const G={ped:P.length,flete:0,dem:0,demMXN:0,cajas:0,eta:0,ontime:0,delay:0,nav:new Map()};
  P.forEach(p=>{G.flete+=p.flete;G.cajas+=p.cajas;const dm=n0(p.bi.demora);G.dem+=dm;G.demMXN+=dm*p.tc;if(p.bi.eta&&p.bi.llegada){const d=dayDiff(p.bi.eta,p.bi.llegada);G.eta++;if(d<=0)G.ontime++;G.delay+=Math.max(0,d)}
    const nv=String(p.bi.naviera||'').trim();if(nv){let x=G.nav.get(nv);if(!x){x={n:nv,ped:0,delay:0,eta:0,dem:0};G.nav.set(nv,x)}x.ped++;x.dem+=dm;if(p.bi.eta&&p.bi.llegada){x.eta++;x.delay+=Math.max(0,dayDiff(p.bi.eta,p.bi.llegada))}}});
  G.logCaja=G.cajas>0?(G.flete+G.demMXN)/G.cajas:null;G.punt=G.eta?G.ontime/G.eta:null;G.delayP=G.eta?G.delay/G.eta:null;
  /* comparativa Vera Limes contra Citrilar con los mismos filtros */
  const cmp=['VL','EC'].map(e=>{const l=statsList(f,{emp:e}),A=aggregate(l),Fa=finAgg(l).T;let rech=0;const ps=new Set();l.forEach(o=>{const k=o.emp+'|'+o.cod;if(ps.has(k))return;ps.add(k);rech+=n0(biOf(o).rech)});return {e:e,A:A.T,F:Fa,rech:Fa.cajas>0?rech/Fa.cajas:null}});
  /* proyección de 4 semanas */
  const upto=wks.length?wks[wks.length-1]:wkOfDate(todayISO()),S=weekSeries(f,upto),fc=linFit(S.map(s=>s.cajas)),fu=linFit(S.map(s=>s.util));
  const proj=[];if(S.length>=3&&fc){let k=S[S.length-1].k;for(let i=1;i<=4;i++){k=wkNext(k);proj.push({k:k,l:wkLab(k,true),cajas:Math.max(0,Math.round(fc.at(S.length-1+i))),util:fu?fu.at(S.length-1+i):null})}}
  const B={cash:cashKpi(f.emp||'ALL'),FP:FP,wks:wks,nW:nW,fijoW:fijoW,fijo:fijo,contrib:contrib,be:be,neta:neta,peds:P,C:C,R:R,Z:Z,par:par,n80:n80,kMed:kMed,mRef:mRef,L:L,G:G,cmp:cmp,S:S,proj:proj};
  B.alerts=biAlerts(D,B);
  return B;
}
function biAlerts(D,B){
  const T=D.fin.T,A=[],R0=D.finRef?D.finRef.T:null,add=(l,t,d)=>A.push({l:l,t:t,d:d});
  if(FIN.ejemplo)add('info','Precios de ejemplo','Las cifras de dinero usan precios y costos de muestra hasta que el administrador ponga los reales.');
  if(T.margen!=null&&T.margen<0)add('crit','Pérdida en el periodo','El margen bruto es '+pctTxt(T.margen)+'.');else if(T.margen!=null&&T.margen<0.1)add('warn','Margen bajo','El margen bruto es '+pctTxt(T.margen)+', debajo del 10 %.');
  if(B.be!=null&&T.cajas<B.be)add('crit','Debajo del punto de equilibrio','Van '+fmt(T.cajas)+' cajas; se necesitan '+fmt(B.be)+' para cubrir los costos fijos.');
  if(R0&&R0.costoCaja>0&&T.costoCaja!=null&&T.costoCaja>R0.costoCaja*1.1)add('warn','Costo por caja al alza','Subió '+fmt((T.costoCaja/R0.costoCaja-1)*100,1)+' % contra '+D.ref.label+'.');
  B.C.forEach(c=>{if(c.rechP!=null&&c.rechP>0.03)add('warn','Rechazos altos · '+c.nombre,fmt(c.rech)+' cajas rechazadas ('+pctTxt(c.rechP)+' de lo enviado).')});
  const rs=B.R.filter(a=>a.rend!=null),avg=D.cur.T.rend;
  if(avg)rs.forEach(a=>{if(a.rend<avg*0.8&&a.kilos>0)add('warn','Rendimiento bajo · '+a.nombre,'Rinde '+pctTxt(a.rend)+' contra '+pctTxt(avg)+' de promedio.')});
  B.R.forEach(a=>{if(a.util<0)add('warn','Productor con pérdida · '+a.nombre,'Su fruta dejó '+mxn(a.util)+' en el periodo.')});
  const K=B.cash;if(K){if(K.over)add('crit','Hueco de capital de trabajo arriba del umbral','Por cobrar '+mxn(K.cxcMXN)+' contra por pagar '+mxn(K.cxp)+': el hueco es '+mxn(K.gap)+' y el umbral '+mxn(K.umbral)+'.');if(K.b60>0.005)add('warn','Cobranza vencida a más de 60 días',usd(K.b60)+' por cobrar a clientes.');if(K.b60p>0.005)add('warn','Pagos vencidos a más de 60 días',mxn(K.b60p)+' por pagar.')}
  if(B.G.dem>0)add('warn','Demoras (demurrage)',usd(B.G.dem)+' en '+B.peds.filter(p=>n0(p.bi.demora)>0).length+' embarques.');
  if(B.G.delayP!=null&&B.G.delayP>1)add('warn','Llegadas tarde','Los embarques llegan en promedio '+fmt(B.G.delayP,1)+' días después del ETA.');
  if(B.L.ped&&B.L.oee!=null&&B.L.oee<0.6)add('warn','OEE bajo','La eficiencia de la línea es '+pctTxt(B.L.oee)+'; la referencia de clase mundial es 85 %.');
  const now=wkOfDate(todayISO()),old=weekKeys(false).filter(k=>!wkClosed(k)&&k<now&&wkStats(k).L.length).length;
  if(old>1)add('info','Semanas sin cerrar',old+' semanas anteriores siguen abiertas. Ciérralas para que contabilidad y el pago a productores queden firmes.');
  const ss=seg2Lots();let sv=0;ss.forEach(l=>{if(l.av>0&&l.fecha&&dayDiff(l.fecha,todayISO())>7)sv+=l.av});if(sv)add('info','Segundas con más de 7 días en almacén',fmt(sv)+' cajas. Al cerrar la semana pasan a Juguera.');
  const ord={crit:0,warn:1,info:2};return A.sort((a,b)=>ord[a.l]-ord[b.l]);
}
/* ----- gráficas ----- */
function chartBox(W,H,body,lab,tbl){return `<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(lab)}">${body}</svg><div class="ctip" hidden></div></div>${tbl||''}`}
function chartW(){const wide=window.innerWidth>=1000;return Math.round(Math.max(320,Math.min(wide?560:1180,window.innerWidth-(wide?100:56))))}
function paretoSvg(par){
  const d=par.slice(0,15);if(!d.length)return '<p class="note">Sin cajas en el periodo.</p>';
  const W=chartW(),H=230,L=46,Rr=10,Tp=12,Bt=40,pw=W-L-Rr,ph=H-Tp-Bt,gap=pw/d.length,bw=Math.min(36,gap*0.62),y=v=>Tp+(1-v)*ph;
  let g=[0,0.5,0.8,1].map(v=>`<line x1="${L}" x2="${W-Rr}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" class="${v===0.8?'rl':'gl'}"/><text x="${L-6}" y="${(y(v)+4).toFixed(1)}" class="ax" text-anchor="end">${v*100}%</text>`).join('');
  let pts='';
  d.forEach((a,i)=>{const cx=L+gap*i+gap/2,top=y(a.share),h=Math.max(1,y(0)-top),r=Math.min(4,h/2);
    g+=`<g class="bar${a.cum<=0.8||i===0?'':' dim'}" tabindex="0" data-tip="${esc(a.nombre+': '+fmt(a.cajas)+' cajas · '+pctTxt(a.share)+' · acumulado '+pctTxt(a.cum))}"><rect x="${(cx-gap/2).toFixed(1)}" y="${Tp}" width="${gap.toFixed(1)}" height="${ph}" class="hit"/><path d="M${cx-bw/2},${y(0)}V${top+r}Q${cx-bw/2},${top} ${cx-bw/2+r},${top}H${cx+bw/2-r}Q${cx+bw/2},${top} ${cx+bw/2},${top+r}V${y(0)}Z"/></g>`;
    pts+=(i?'L':'M')+cx.toFixed(1)+','+y(a.cum).toFixed(1);
    if(d.length<=10||i%2===0)g+=`<text x="${cx.toFixed(1)}" y="${H-24}" class="ax" text-anchor="middle">${esc(a.codigo?pad(a.codigo,3):String(a.nombre).slice(0,4))}</text>`;
  });
  g+=`<path d="${pts}" class="cum"/>`+d.map((a,i)=>`<circle cx="${(L+gap*i+gap/2).toFixed(1)}" cy="${y(a.cum).toFixed(1)}" r="3.5" class="cumd"/>`).join('');
  g+=`<text x="${W-Rr}" y="${(y(0.8)-5).toFixed(1)}" class="ax" text-anchor="end">80 %</text><text x="${L}" y="${H-6}" class="ax">${W<600?'Barras: participación · línea: acumulado':'Barras: participación de cada productor · línea: acumulado'}</text>`;
  const tbl=`<details class="ctbl"><summary>Ver como tabla</summary><table><thead><tr><th>Productor</th><th>Cajas</th><th>Acumulado</th></tr></thead><tbody>${par.map(a=>`<tr><td>${esc(a.nombre)}</td><td>${fmt(a.cajas)}</td><td>${pctTxt(a.cum)}</td></tr>`).join('')}</tbody></table></details>`;
  return chartBox(W,H,g,'Pareto de cajas por productor',tbl);
}
const Q_LAB={star:'Estrellas',cow:'Vacas lecheras',q:'Interrogantes',dog:'Por revisar'},Q_TXT={star:'mucho volumen y buen margen: cuidarlos',cow:'mucho volumen y margen bajo: renegociar precio o mejorar calidad',q:'poco volumen y buen margen: buscar que traigan más',dog:'poco volumen y margen bajo: revisar si conviene'};
function bcgSvg(B){
  const R=B.R.filter(a=>a.margen!=null&&a.kilos>0);if(R.length<2)return '<p class="note">Hacen falta al menos dos productores con kilos e ingresos.</p>';
  const W=chartW(),H=300,L=52,Rr=12,Tp=14,Bt=36,pw=W-L-Rr,ph=H-Tp-Bt;
  const xm=Math.max(...R.map(a=>a.kilos))*1.08,ms=R.map(a=>a.margen),y1=Math.max(B.mRef,...ms),y0=Math.min(B.mRef,...ms),pad_=(y1-y0)*0.12||0.05,top=y1+pad_,bot=y0-pad_;
  const X=v=>L+v/xm*pw,Y=v=>Tp+(top-v)/(top-bot)*ph,xc=X(B.kMed),yc=Y(B.mRef);
  let g=`<rect x="${xc}" y="${Tp}" width="${W-Rr-xc}" height="${yc-Tp}" class="qz star"/><rect x="${L}" y="${Tp}" width="${xc-L}" height="${yc-Tp}" class="qz q"/><rect x="${xc}" y="${yc}" width="${W-Rr-xc}" height="${Tp+ph-yc}" class="qz cow"/><rect x="${L}" y="${yc}" width="${xc-L}" height="${Tp+ph-yc}" class="qz dog"/>`;
  g+=`<line x1="${xc}" x2="${xc}" y1="${Tp}" y2="${Tp+ph}" class="zl"/><line x1="${L}" x2="${W-Rr}" y1="${yc}" y2="${yc}" class="zl"/>`;
  g+=`<text x="${W-Rr-4}" y="${Tp+14}" class="ql" text-anchor="end">Estrellas</text><text x="${L+4}" y="${Tp+14}" class="ql">Interrogantes</text><text x="${W-Rr-4}" y="${Tp+ph-6}" class="ql" text-anchor="end">Vacas lecheras</text><text x="${L+4}" y="${Tp+ph-6}" class="ql">Por revisar</text>`;
  g+=[top,B.mRef,bot].map(v=>`<text x="${L-6}" y="${(Y(v)+4).toFixed(1)}" class="ax" text-anchor="end">${fmt(v*100,0)}%</text>`).join('')+`<text x="${L}" y="${H-6}" class="ax">${W<600?'Kilos → · margen ↑':'Kilos → (línea: mediana '+fmt(B.kMed)+' kg) · margen ↑ (línea: margen del periodo)'}</text>`;
  g+=R.map(a=>`<g class="dot" tabindex="0" data-tip="${esc(a.nombre+': '+fmt(a.kilos)+' kg · margen '+pctTxt(a.margen)+' · '+Q_LAB[a.q])}"><circle cx="${X(a.kilos).toFixed(1)}" cy="${Y(a.margen).toFixed(1)}" r="12" class="hit"/><circle cx="${X(a.kilos).toFixed(1)}" cy="${Y(a.margen).toFixed(1)}" r="5.5" class="pt"/></g>`).join('');
  const tbl=`<details class="ctbl"><summary>Ver como tabla</summary><table><thead><tr><th>Productor</th><th>Kilos</th><th>Margen</th><th>Cuadrante</th></tr></thead><tbody>${R.map(a=>`<tr><td>${esc(a.nombre)}</td><td>${fmt(a.kilos)}</td><td>${pctTxt(a.margen)}</td><td>${Q_LAB[a.q]}</td></tr>`).join('')}</tbody></table></details>`;
  return chartBox(W,H,g,'Matriz de productores: kilos contra margen',tbl);
}
function fcSvg(S,P){
  const d=S.map(s=>({l:s.l,v:s.cajas,p:false})).concat(P.map(s=>({l:s.l,v:s.cajas,p:true})));if(!d.length)return '<p class="note">Sin semanas con datos.</p>';
  const W=chartW(),H=210,L=56,Rr=10,Tp=12,Bt=30,pw=W-L-Rr,ph=H-Tp-Bt,mx=Math.max(1,...d.map(x=>x.v)),y=v=>Tp+(1-v/mx)*ph,gap=pw/d.length,bw=Math.min(40,gap*0.62);
  let g=[mx,mx/2].map(v=>`<line x1="${L}" x2="${W-Rr}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" class="gl"/><text x="${L-6}" y="${(y(v)+4).toFixed(1)}" class="ax" text-anchor="end">${fmt(v)}</text>`).join('')+`<line x1="${L}" x2="${W-Rr}" y1="${y(0)}" y2="${y(0)}" class="zl"/>`;
  d.forEach((x,i)=>{const cx=L+gap*i+gap/2,top=y(x.v),h=Math.max(1,y(0)-top),r=Math.min(4,h/2);
    g+=`<g class="bar${x.p?' proj':''}" tabindex="0" data-tip="${esc(x.l+(x.p?' (proyección)':'')+': '+fmt(x.v)+' cajas')}"><rect x="${(cx-gap/2).toFixed(1)}" y="${Tp}" width="${gap.toFixed(1)}" height="${ph}" class="hit"/><path d="M${cx-bw/2},${y(0)}V${top+r}Q${cx-bw/2},${top} ${cx-bw/2+r},${top}H${cx+bw/2-r}Q${cx+bw/2},${top} ${cx+bw/2},${top+r}V${y(0)}Z"/></g><text x="${cx.toFixed(1)}" y="${H-10}" class="ax" text-anchor="middle">${esc(x.l.replace('Sem ',''))}</text>`});
  const tbl=`<details class="ctbl"><summary>Ver como tabla</summary><table><thead><tr><th>Semana</th><th>Cajas</th></tr></thead><tbody>${d.map(x=>`<tr><td>${esc(x.l)}${x.p?' (proyección)':''}</td><td>${fmt(x.v)}</td></tr>`).join('')}</tbody></table></details>`;
  return chartBox(W,H,g,'Cajas por semana y proyección',tbl);
}
/* ----- vista ----- */
function meter(v,cls){return `<span class="plb"><i class="${cls||'in'}" style="width:${Math.max(0,Math.min(100,(v||0)*100)).toFixed(1)}%"></i></span>`}
function semTone(v,g,w){return v==null?'':v>=g?'good':v>=w?'warn':'crit'}
function biView(D){
  const B=D.bi||(D.bi=biCalc(D)),T=D.fin.T,f=statsF,es=f.emp==='ALL'?['VL','EC']:[f.emp],ed=isAdmin();
  const tag={crit:'Urgente',warn:'Atención',info:'Aviso'};
  const alerts=B.alerts.length?B.alerts.map(a=>`<div class="alr ${a.l}"><span class="chip ${a.l}">${tag[a.l]}</span><div><strong>${esc(a.t)}</strong><small>${esc(a.d)}</small></div></div>`).join(''):'<p class="note">Todo en orden con estos filtros.</p>';
  const prog=B.be?Math.min(1,T.cajas/B.be):0,falta=B.be?B.be-T.cajas:null;
  const finp=(k,l,suf)=>es.map(e=>`<label class="fld" for="bi-${k}-${e}"><span>${l}${es.length>1?' · '+esc(EMPS[e].name):''}</span><input class="in" id="bi-${k}-${e}" inputmode="decimal" data-fin="${e}.${k}" value="${esc(biPar(e,k))}"${ed?'':' readonly'}></label>`).join('');
  const star=`<div class="bestar"><div class="k">Punto de equilibrio</div>${B.be?`<p class="beh">A partir de la caja <b>${fmt(B.be+1)}</b> empiezas a ganar</p><div class="beprog" role="img" aria-label="${fmt(T.cajas)} de ${fmt(B.be)} cajas">${meter(prog,T.cajas>=B.be?'ut':'out')}</div><p class="note">${T.cajas>=B.be?`Ya pasaste el punto de equilibrio por ${fmt(T.cajas-B.be)} cajas.`:`Van ${fmt(T.cajas)} cajas: faltan ${fmt(falta)} para cubrir los costos fijos.`}</p>`:`<p class="beh">${T.cajas?'Cada caja cuesta más de lo que deja: no hay punto de equilibrio con estos precios.':'Sin cajas en el periodo.'}</p>`}
<div class="ig tot beg"><div><span>Cada caja deja</span><b>${B.contrib==null?'–':money(B.contrib,2)}</b><small>MXN después de costos variables</small></div><div><span>Costos fijos del periodo</span><b>${money(B.fijo)}</b><small>${B.nW} ${B.nW===1?'semana':'semanas'} × ${money(B.fijoW)}</small></div><div><span>Utilidad neta</span><b class="${B.neta<0?'neg':''}">${money(B.neta)}</b><small>MXN, bruta menos fijos</small></div></div>
<div class="grid2 beinp">${es.some(e=>fijoCats(e,curWk()))?`<div class="fld"><span>Costos fijos por semana (MXN)</span><b class="fixv">${money(es.reduce((s,e)=>s+fijoSem(e,curWk()),0))}</b><small class="note">Suma de las categorías de Precios y costos.</small></div>`:finp('fijo','Costos fijos por semana (MXN)')}<label class="fld" for="be-plan"><span>¿Cuántas cajas planeas?</span><input class="in" id="be-plan" inputmode="numeric" data-beplan="1" value="${B.be?Math.max(B.be,T.cajas):T.cajas||0}"></label></div><p class="note" data-out="beplan">${esc(bePlanTxt(B,B.be?Math.max(B.be,T.cajas):T.cajas||0))}</p>${ed?'':'<p class="note">Solo el administrador cambia los costos fijos.</p>'}</div>`;
  /* comparativas */
  const cm=B.cmp,rowC=(l,a,b,fm,good)=>{const d=(a!=null&&b!=null)?a-b:null;return `<tr><th scope="row">${l}</th><td>${fm(a)}</td><td>${fm(b)}</td><td class="${d==null||!good||Math.abs(d)<1e-9?'':(d>0)===(good==='up')?'gv':'bv'}">${d==null?'–':(d>0?'+':'')+fm(d)}</td></tr>`};
  const cmpEmp=`<div class="tblx"><table class="ctab"><thead><tr><th></th><th>Vera Limes</th><th>Citrilar</th><th>Diferencia</th></tr></thead><tbody>${rowC('Cajas exportación',cm[0].F.cajas,cm[1].F.cajas,v=>fmt(v),'up')}${rowC('Kilos',cm[0].A.kilos,cm[1].A.kilos,v=>fmt(v),null)}${rowC('Rendimiento',cm[0].A.rend,cm[1].A.rend,pctTxt,'up')}${rowC('Ingresos (MXN)',cm[0].F.ing,cm[1].F.ing,v=>money(v),'up')}${rowC('Utilidad (MXN)',cm[0].F.util,cm[1].F.util,v=>money(v),'up')}${rowC('Margen',cm[0].F.margen,cm[1].F.margen,pctTxt,'up')}${rowC('Precio por caja (USD)',cm[0].F.precio,cm[1].F.precio,v=>v==null?'–':money(v,2),'up')}${rowC('Costo por caja (MXN)',cm[0].F.costoCaja,cm[1].F.costoCaja,v=>v==null?'–':money(v,2),'down')}${rowC('Rechazos',cm[0].rech,cm[1].rech,pctTxt,'down')}</tbody></table></div>`;
  const R0=D.finRef?D.finRef.T:null,A0=D.ref?D.ref.agg.T:null;
  const cmpRef=R0?`<div class="tblx"><table class="ctab"><thead><tr><th></th><th>Ahora</th><th>${esc(D.ref.label)}</th><th>Cambio</th></tr></thead><tbody>${rowC('Cajas exportación',T.cajas,R0.cajas,v=>fmt(v),'up')}${rowC('Rendimiento',D.cur.T.rend,A0.rend,pctTxt,'up')}${rowC('Utilidad (MXN)',T.util,R0.util,v=>money(v),'up')}${rowC('Margen',T.margen,R0.margen,pctTxt,'up')}${rowC('Precio por caja (USD)',T.precio,R0.precio,v=>v==null?'–':money(v,2),'up')}${rowC('Costo por caja (MXN)',T.costoCaja,R0.costoCaja,v=>v==null?'–':money(v,2),'down')}</tbody></table></div>`:`<p class="note">${D.hasRef?'Sin datos en el periodo de comparación.':'Elige una semana, un mes o un año en los filtros para comparar contra el mismo periodo del año anterior.'}</p>`;
  const pu=B.proj.reduce((s,p)=>s+p.cajas,0),pul=B.proj.reduce((s,p)=>s+(p.util||0),0);
  const fc=B.proj.length?`<p class="note">Con la tendencia de las últimas ${B.S.length} semanas se esperan <b>${fmt(pu)} cajas</b> y <b>${mxn(pul)}</b> de utilidad bruta en las próximas 4 semanas. Es una recta de tendencia: sirve para planear, no es un compromiso.</p>`:'<p class="note">Hacen falta al menos 3 semanas con datos para proyectar.</p>';
  /* clientes */
  const mxC=Math.max(1,...B.C.map(c=>Math.abs(c.util)));
  const cli=B.C.length?B.C.map((c,i)=>{const mix=CAL_ASC.filter(k=>c.cajC[k]>0),tc=mix.reduce((s,k)=>s+c.cajC[k],0)||1;return `<div class="prd cli"><div class="r1"><div class="pnm"><span class="rk">${i+1}</span>${esc(c.nombre)}<small>${c.ped} ${c.ped===1?'pedido':'pedidos'} · ${fmt(c.cajas)} cajas${c.dest.size?' · '+esc([...c.dest].join(', ')):''}${c.inc.size?' · '+esc([...c.inc].join('/')):''}</small></div><div class="rend${c.util<0?' negv':''}">${pctTxt(c.margen)}<small>margen · ${mxn(c.util)}</small></div></div>
<div class="dvb" aria-hidden="true"><span class="dvl">${c.util<0?`<i style="width:${(Math.abs(c.util)/mxC*100).toFixed(1)}%"></i>`:''}</span><span class="dvr">${c.util>=0?`<i style="width:${(c.util/mxC*100).toFixed(1)}%"></i>`:''}</span></div>
<div class="r3"><span>Rechazos <b class="${c.rechP>0.03?'negv':''}">${c.rechP==null?'–':pctTxt(c.rechP)}</b> (${fmt(c.rech)} cajas)</span><span>Pago a <b>${c.diasP==null?'–':fmt(c.diasP,0)+' días'}</b></span></div>
${mix.length?`<div class="mix" role="img" aria-label="Mezcla de calibres: ${esc(mix.map(k=>CAL_LAB[k]+' '+pctTxt(c.cajC[k]/tc)).join(', '))}">${mix.map((k,j)=>`<i class="m${j%6}" style="width:${(c.cajC[k]/tc*100).toFixed(2)}%" title="${esc(CAL_LAB[k]+': '+fmt(c.cajC[k])+' cajas')}"></i>`).join('')}</div><div class="mixl">${mix.map((k,j)=>`<span><i class="m${j%6}"></i>${esc(CAL_LAB[k])} ${pctTxt(c.cajC[k]/tc)}</span>`).join('')}</div>`:''}</div>`}).join(''):'<p class="note">Sin clientes en el periodo.</p>';
  /* productores */
  const iqT=B.R.filter(a=>a.iq!=null).sort((a,b)=>b.iq-a.iq);
  const iq=iqT.length?`<div class="tblx"><table class="ctab iq"><thead><tr><th>Productor</th><th>Índice</th><th>Rendimiento</th><th>Desecho y Torreón</th><th>Cuadrante</th></tr></thead><tbody>${iqT.map(a=>`<tr><th scope="row">${esc(a.nombre)}</th><td><span class="chip ${semTone(a.iq/100,0.8,0.6)}">${a.iq}</span></td><td>${pctTxt(a.rend)}</td><td>${pctTxt(a.desP)}</td><td>${Q_LAB[a.q]}</td></tr>`).join('')}</tbody></table></div>`:'<p class="note">Sin rendimientos capturados.</p>';
  const zon=B.Z.length?B.Z.map(z=>`<div class="tfr"><div class="tf1"><strong>${esc(z.zona)}</strong><small>${z.prods.size} ${z.prods.size===1?'productor':'productores'} · ${fmt(z.kilos)} kg</small></div>${meter(z.rend,'in')}<b>${pctTxt(z.rend)}</b></div>`).join(''):'';
  const qs=['star','cow','q','dog'].map(q=>{const n=B.R.filter(a=>a.q===q);return `<div class="qcard ${q}"><b>${Q_LAB[q]} · ${n.length}</b><small>${Q_TXT[q]}</small>${n.length?`<span>${esc(n.slice(0,6).map(a=>a.nombre).join(', '))}${n.length>6?'…':''}</span>`:''}</div>`}).join('');
  /* línea */
  const L=B.L,lt=(l,v,s,tone)=>`<div class="tile ${tone||''}"><span class="k">${l}</span><b>${v}</b>${s?`<small>${s}</small>`:''}</div>`;
  const oeeOn=es.some(e=>biPar(e,'oee')),oeeSel=es.map(e=>`<label class="fld" for="bi-oee-${e}"><span>OEE${es.length>1?' · '+esc(EMPS[e].name):''}</span><select class="in sel" id="bi-oee-${e}" data-fin="${e}.oee"${ed?'':' disabled'}><option value="1"${biPar(e,'oee')?' selected':''}>Activo</option><option value="0"${biPar(e,'oee')?'':' selected'}>Apagado</option></select></label>`).join('');
  const oeeCfg=`<details class="more oeecfg"${L.ped?'':' open'}><summary>Configurar OEE</summary><p class="note" style="margin-top:8px">Valores de un turno por pedido. Si un pedido trae sus propios datos, se usan los del pedido.</p><div class="grid2 beinp">${oeeSel}${finp('horas','Horas del turno')}${finp('personas','Personas en el turno')}${finp('paro','Minutos de paro por turno')}${finp('meta','Meta de cajas por hora')}${finp('salHr','Salario por hora hombre (MXN)')}</div></details>`;
  const line=(L.ped?`<div class="tiles">${lt('OEE',pctTxt(L.oee),'disponibilidad × rendimiento × calidad')}${lt('Cajas por hora',L.cph==null?'–':fmt(L.cph,0),'meta '+fmt(es.reduce((s,e)=>s+biPar(e,'meta'),0)/es.length,0)+' por hora')}${lt('Cajas por persona',L.cpp==null?'–':fmt(L.cpp,0),fmt(L.hh,0)+' horas hombre')}${lt('Mano de obra por caja',L.moCaja==null?'–':money(L.moCaja,2)+' MXN','con salario de '+money(es.reduce((s,e)=>s+biPar(e,'salHr'),0)/es.length,0)+' por hora')}</div>
<div class="panel" style="margin-top:10px"><div class="tfr"><div class="tf1"><strong>Disponibilidad</strong><small>horas sin paro entre horas de turno</small></div>${meter(L.disp)}<b>${pctTxt(L.disp)}</b></div><div class="tfr"><div class="tf1"><strong>Rendimiento</strong><small>cajas por hora contra la meta</small></div>${meter(L.perf)}<b>${pctTxt(L.perf)}</b></div><div class="tfr"><div class="tf1"><strong>Calidad</strong><small>cajas sin rechazo</small></div>${meter(L.cal)}<b>${pctTxt(L.cal)}</b></div></div><p class="note" style="margin-top:6px">${L.ped} ${L.ped===1?'pedido':'pedidos'} en el periodo.</p>`:`<p class="note">${oeeOn?'Sin pedidos en el periodo para calcular el OEE.':'El OEE está apagado. Actívalo en Configurar OEE.'}</p>`)+oeeCfg;
  const G=B.G,navs=[...G.nav.values()];
  const logi=`<div class="tiles">${lt('Logística por caja',G.logCaja==null?'–':money(G.logCaja,2)+' MXN','flete, cruce y demoras')}${lt('Llegadas a tiempo',pctTxt(G.punt),G.eta?G.eta+' embarques con ETA y llegada':'captura ETA y llegada real')}${lt('Retraso promedio',G.delayP==null?'–':fmt(G.delayP,1)+' días','después del ETA')}${lt('Demoras (demurrage)',usd(G.dem),'≈ '+mxn(G.demMXN),G.dem>0?'neg':'')}</div>${navs.length?`<div class="tblx" style="margin-top:10px"><table class="ctab"><thead><tr><th>Naviera o transportista</th><th>Embarques</th><th>Retraso promedio</th><th>Demoras (USD)</th></tr></thead><tbody>${navs.map(x=>`<tr><th scope="row">${esc(x.n)}</th><td>${x.ped}</td><td>${x.eta?fmt(x.delay/x.eta,1)+' días':'–'}</td><td>${money(x.dem)}</td></tr>`).join('')}</tbody></table></div>`:''}`;
  const demo=!ro&&!cfgOK()&&new Set(visible().map(wkOf)).size<4?`<div class="panel info"><strong>Pocas semanas para ver tendencias</strong><p class="note" style="margin-top:4px">Puedes cargar 8 semanas de pedidos de ejemplo de ambas empresas (con clientes, logística y datos de la línea) para probar esta sección. Se marcan como ejemplo y se pueden borrar.</p>${cfgOK()?'':'<div class="pact"><button class="btn sm" data-act="biexample" data-edit>Cargar historial de ejemplo</button></div>'}</div>`:'';
  return `${demo}<section class="dbpanel bipanel"><div><strong>Reporte e indicadores</strong><small>Excel con hojas, tablas y fórmulas que se recalculan; PDF ejecutivo para la junta.</small></div><div class="pact" style="margin:0"><button class="btn" data-act="biout:pdf">Reporte ejecutivo (PDF)</button><button class="btn primary" data-act="biout:xlsx">Excel BI</button></div></section>
<div class="dsk fin2"><div class="dcol"><div class="sec">Indicador estrella</div>${star}</div><div class="dcol"><div class="sec">Alertas · ${B.alerts.length}</div><div class="panel alrs">${alerts}</div></div></div>
<div class="sec">Capital de trabajo · al día de hoy</div>${cashTilesHtml(B.cash)}
<div class="dsk fin2"><div class="dcol"><div class="sec">Vera Limes contra Citrilar</div>${cmpEmp}</div><div class="dcol"><div class="sec">Contra el periodo anterior</div>${cmpRef}</div></div>
<div class="dsk fin2"><div class="dcol"><div class="sec">Pareto 80/20 de productores</div><div class="panel chartp">${paretoSvg(B.par)}<p class="note">${B.n80?`<b>${B.n80} de ${B.par.length}</b> productores (${pctTxt(B.n80/B.par.length)}) aportan el 80 % de las cajas.`:''}</p></div></div><div class="dcol"><div class="sec">Proyección a 4 semanas</div><div class="panel chartp">${fcSvg(B.S,B.proj)}${fc}</div></div></div>
<div class="sec">Clientes · ranking por margen</div><div class="cgrid">${cli}</div>
<div class="sec">Matriz de productores (kilos contra margen)</div><div class="dsk fin2"><div class="dcol"><div class="panel chartp">${bcgSvg(B)}</div></div><div class="dcol"><div class="qgrid">${qs}</div></div></div>
<div class="dsk fin2"><div class="dcol"><div class="sec">Índice de calidad del proveedor</div>${iq}<p class="note" style="margin-top:6px">Índice de 0 a 100: 60 % rendimiento contra el mejor del periodo, 25 % lo que no fue desecho ni Torreón y 15 % el muestreo de primera de Entrada de Fruta (si no hay muestreo, cuenta el rendimiento).</p></div><div class="dcol"><div class="sec">Rendimiento por zona o huerta</div><div class="panel">${zon||'<p class="note">Captura la zona o huerta en Entrada de Fruta.</p>'}</div></div></div>
<div class="sec">Indicadores de operación</div>${line}
<div class="sec">Logística</div>${logi}`;
}
function bePlanTxt(B,n){
  if(B.contrib==null)return '';const u=n*B.contrib-B.fijo;
  return 'Con '+fmt(n)+' cajas y lo que deja cada caja hoy, la utilidad neta sería '+mxn(u)+'.';
}
document.addEventListener('input',e=>{const t=e.target;if(!t||!t.dataset||!t.dataset.beplan)return;const D=statsData(),B=D.bi;if(!B)return;const el=document.querySelector('[data-out="beplan"]');if(el)el.textContent=bePlanTxt(B,n0(String(t.value).replace(/\D+/g,'')))});

/* ----- historial de ejemplo para probar BI ----- */
function loadBiExample(){
  if(ro||roRole)return;
  if(cfgOK()){toast('Con la base de datos conectada no se cargan ejemplos: se mezclarían con los pedidos reales');return}
  const CL=[['CITRICOS J&C LLC','McAllen, TX · EUA','FCA',21],['VILLAMEX FARMS LLC','Nogales, AZ · EUA','FOB',30],['FRESH LIME CO','Los Ángeles, CA · EUA','DAP',45],['NORDIC FRUIT AB','Rotterdam · Países Bajos','CIF',60]];
  const NAV=['Transportes del Golfo','Fletes Cuitláhuac','Maersk','Hapag-Lloyd'],ZON=['Cuitláhuac','Yanga','Carrillo Puerto','Cosamaloapan'];
  const pool=LISTA.filter(x=>x.c&&x.c!==SEG_COD&&x.n).slice(0,14);if(pool.length<6){toast('Faltan productores en el catálogo');return}
  const CK=['c250','c230','c200','c175','c150','c110'],MIX=[0.06,0.18,0.32,0.24,0.13,0.07];
  let seed=7;const rnd=()=>{seed=(seed*9301+49297)%233280;return seed/233280};
  const now=todayISO();let made=0;
  const weeks=[];for(let i=8;i>=1;i--)weeks.push(dayAdd(now,-7*i));
  [-52,-51,-50].forEach(i=>weeks.push(dayAdd(now,7*i)));
  weeks.forEach((d0,wi)=>['VL','EC'].forEach((e,ei)=>{
    const nped=1+(rnd()<0.5?1:0);
    for(let j=0;j<nped;j++){
      const fecha=dayAdd(d0,1+j*2+ei),y=+fecha.slice(0,4),w=isoWeek(fecha),cons=nextCons(e,y);let np=nextPed(e,y,w);while(visible().some(x=>x.emp===e&&x.emb===embOf(e,y,w,np)))np++;
      const c=CL[Math.floor(rnd()*CL.length)];
      const o=newOrder({emp:e,anio:y,cons:cons,cod:codOf(e,y,cons),emb:embOf(e,y,w,np),po:String(4000+Math.floor(rnd()*900)),fecha:fecha,semana:w,customer:c[0],domestic:'',factura:'',ejemplo:true});
      o.estado='completo';const eta=dayAdd(fecha,c[3]>40?18:3);
      o.bi={destino:c[1],incoterm:c[2],diasPago:c[3],rech:Math.round(rnd()<0.3?rnd()*60:rnd()*12),naviera:NAV[c[3]>40?2+Math.floor(rnd()*2):Math.floor(rnd()*2)],contenedor:(c[3]>40?'MSKU':'CAJA')+Math.floor(100000+rnd()*899999),eta:eta,llegada:dayAdd(eta,Math.round(rnd()*3-0.6)),demora:rnd()<0.2?Math.round(150+rnd()*600):0,personas:20+Math.round(rnd()*8),horas:8+Math.round(rnd()*2),paro:Math.round(rnd()*70)};
      const ps=pool.slice().sort(()=>rnd()-0.5).slice(0,5+Math.floor(rnd()*3));
      const acc=[0,0,0,0,0,0];
      ps.forEach((li,k)=>{
        const q=0.5+((li.c*37)%25)/100,kilos=Math.round(1200+rnd()*5200),campo=kilos/KG_DEF,exp=Math.round(campo*q*(0.9+rnd()*0.15));
        const p=newProd(li.n,li.c,'');p.kilos=kilos;p.k24=Math.round(kilos/24);p.zona=ZON[li.c%ZON.length];
        CK.forEach((ck,i)=>{acc[i]+=Math.round(exp*MIX[i]*(0.8+rnd()*0.4));p.acc[ck]=acc[i]});
        p.seg=Math.round(campo*0.12*rnd());p.tor=Math.round(campo*0.05*rnd());p.des=Math.round(campo*0.03*rnd());p.segLlevo=p.seg;p.jug=Math.round(campo*0.04);
        o.productores.push(p);
      });
      orders.push(o);touch(o);made++;
    }
  }));
  invalidateStats();render();toast('Se cargaron '+made+' pedidos de ejemplo');
}
/* ----- contexto de BI para cualquier lista (los filtros de Estadísticas o una semana al cerrarla) ----- */
function biCtx(f,label){
  const list=statsList(f),cur=aggregate(list),rp=refPeriod(f);let ref=null;
  if(rp){const r=aggregate(statsList(f,rp.over));if(r.T.hojas>0)ref={agg:r,label:rp.label}}
  return {f:f,label:label,cur:cur,ref:ref,hasRef:!!rp,fin:finAgg(list),finRef:ref?finAgg(ref.agg.list):null};
}
function biLabel(f){
  const p=periodOf(f),e=f.emp==='ALL'?'Vera Limes y Citrilar':EMPS[f.emp].name;
  const per=p.week!=='ALL'?wkLab(p.week)+' ('+wkSpan(p.week)+')':p.custom?((f.desde?'del '+fmtDate(f.desde):'')+(f.hasta?' al '+fmtDate(f.hasta):'')):p.year==='ALL'?'Todo el histórico':(p.month!=='ALL'?MESES[+p.month-1].replace(/^./,c=>c.toUpperCase())+' ':'')+p.year;
  return {e:e,per:per};
}
function openOutBi(D){
  const B=D.bi||(D.bi=biCalc(D)),lb=D.label||biLabel(D.f||statsF),fm={};
  if(typeof ExcelJS!=='undefined')fm.xlsx=async()=>wbBlob(await buildBiWb(D));
  fm.pdf=async()=>pagesToPdf(await biPages(D));
  fm.pptx=async()=>pagesToPptx(await biPages(D),'Reporte ejecutivo');
  const base=(D.cierre?'Cierre_':'Reporte_BI_')+fileSafe(lb.per)+'_'+fileSafe(lb.e);
  openOut({pages:()=>biPages(D),title:(D.cierre?'Cierre · ':'Reporte ejecutivo · ')+lb.per,base:base,fmts:fm,note:'El Excel trae las hojas Tablero, Pedidos, Productores, Clientes, Semanas, Calibres y Alertas. Las casillas amarillas del Tablero se pueden cambiar y todo se recalcula.'});
}
/* ----- Excel BI: casillas editables en el Tablero y fórmulas en todas las hojas ----- */
async function buildBiWb(D){
  const B=D.bi||(D.bi=biCalc(D)),T=D.fin.T,f=D.f||statsF,lb=D.label||biLabel(f),wb=newWb();wb.calcProperties.fullCalcOnLoad=true;
  const NAVY='FF1B2C46',font=o=>Object.assign({name:'Calibri',size:10},o||{}),fill=c=>({type:'pattern',pattern:'solid',fgColor:{argb:c}});
  const thin={style:'thin',color:{argb:'FFB7B7B7'}},BOX={top:thin,left:thin,bottom:thin,right:thin};
  const NUM='#,##0;-#,##0;"-"',MON='"$"#,##0;[Red]-"$"#,##0;"-"',MON2='"$"#,##0.00;[Red]-"$"#,##0.00;"-"',PCT='0.0%';
  const title=(ws,t,sub,span)=>{ws.mergeCells(1,1,1,span||8);const c=ws.getCell(1,1);c.value=t;c.font=font({size:16,bold:true,color:{argb:NAVY}});ws.getRow(1).height=24;const s=ws.getCell(2,1);s.value=sub;s.font=font({size:9,italic:true,color:{argb:'FF555555'}})};
  const head=(ws,r,cols,color)=>{cols.forEach((c,i)=>{ws.getColumn(i+1).width=c.w||12;const x=ws.getCell(r,i+1);x.value=c.h;x.font=font({size:9,bold:true,color:{argb:'FFFFFFFF'}});x.fill=fill(color||NAVY);x.alignment={horizontal:'center',vertical:'middle',wrapText:true};x.border=BOX});ws.getRow(r).height=32};
  const cell=(ws,r,c,v,st)=>{const x=ws.getCell(r,c);if(v!==undefined&&v!==null&&v!=='')x.value=v;x.border=BOX;x.font=font(st&&st.font);if(st&&st.fmt)x.numFmt=st.fmt;if(st&&st.fill)x.fill=st.fill;x.alignment=st&&st.al||{vertical:'middle'};return x};
  const L=c=>{let s='';while(c>0){const m=(c-1)%26;s=String.fromCharCode(65+m)+s;c=Math.floor((c-1)/26)}return s};
  const sub=lb.e+' · '+lb.per+' · generado el '+fmtDate(todayISO());
  /* --- Tablero --- */
  const tb=wb.addWorksheet('Tablero',{views:[{showGridLines:false}]});
  title(tb,(D.cierre?'Cierre de semana · ':'Tablero BI · ')+APP_NAME,sub,6);
  tb.getColumn(1).width=38;tb.getColumn(2).width=18;tb.getColumn(3).width=4;tb.getColumn(4).width=38;tb.getColumn(5).width=18;
  const IN=fill('FFFFF2CC'),es=f.emp==='ALL'?['VL','EC']:[f.emp];
  const sec=(r,c,t)=>{tb.mergeCells(r,c,r,c+1);const x=tb.getCell(r,c);x.value=t;x.font=font({bold:true,color:{argb:'FFFFFFFF'}});x.fill=fill(NAVY);x.alignment={vertical:'middle'}};
  sec(4,1,'Datos que puedes cambiar (casillas amarillas)');
  const inp=[['Tipo de cambio Vera Limes (MXN por USD)',+FIN.VL.tc||0,MON2],['Tipo de cambio Citrilar (MXN por USD)',+FIN.EC.tc||0,MON2],['Costos fijos por semana (MXN)',B.fijoW,MON],['Semanas en el periodo',B.nW,NUM],['Meta de cajas por hora',es.reduce((s,e)=>s+biPar(e,'meta'),0)/es.length,NUM],['Salario por hora hombre (MXN)',es.reduce((s,e)=>s+biPar(e,'salHr'),0)/es.length,MON2],['Cajas que planeas vender',Math.max(B.be||0,T.cajas),NUM]];
  inp.forEach((x,i)=>{cell(tb,5+i,1,x[0]);cell(tb,5+i,2,x[1],{fmt:x[2],fill:IN,font:{bold:true}})});
  const TCV='Tablero!$B$5',TCE='Tablero!$B$6';
  /* --- Pedidos --- */
  const pc=[{h:'Empresa',w:11},{h:'Pedido',w:12},{h:'Semana',w:10},{h:'Fecha',w:11},{h:'Cliente',w:24},{h:'Destino',w:20},{h:'INCOTERM',w:9},{h:'Días de pago',w:8},{h:'Cajas exportación',w:10},{h:'Kilos',w:10},{h:'Venta exportación USD',w:12},{h:'Venta nacional MXN',w:12},{h:'Ingreso MXN',w:13},{h:'Fruta MXN',w:12},{h:'Material MXN',w:11},{h:'Mano de obra MXN',w:11},{h:'Flete y cruce MXN',w:11},{h:'Costo MXN',w:13},{h:'Utilidad MXN',w:13},{h:'Margen',w:8},{h:'Cajas rechazadas',w:9},{h:'% rechazo',w:8},{h:'Personas',w:8},{h:'Horas turno',w:8},{h:'Paro (min)',w:8},{h:'Cajas por hora',w:9},{h:'Naviera / transportista',w:18},{h:'Contenedor / caja',w:14},{h:'ETA',w:11},{h:'Llegada real',w:11},{h:'Días de retraso',w:8},{h:'Demoras USD',w:10}];
  const pw=wb.addWorksheet('Pedidos',{views:[{state:'frozen',xSplit:2,ySplit:4,showGridLines:false}]});title(pw,'Pedidos del periodo',sub,10);head(pw,4,pc);
  const P=B.peds.slice().sort((a,b)=>(a.wk||'').localeCompare(b.wk||'')||(a.m.fecha||'').localeCompare(b.m.fecha||''));
  const d0=s=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s||'');return m?new Date(Date.UTC(+m[1],+m[2]-1,+m[3])):null};
  P.forEach((p,i)=>{const r=5+i,b=p.bi,z=i%2?fill('FFF2F5F0'):undefined,st=(fm2,al)=>({fmt:fm2,fill:z,al:al});
    const v=[EMPS[p.emp].name,p.cod,wkLab(p.wk,true),d0(p.m.fecha),p.m.customer||'',b.destino||'',b.incoterm||'',num(b.diasPago),p.cajas,p.kilos,Math.round(p.usd*100)/100,Math.round(p.nac),
      {formula:`K${r}*IF(A${r}="${EMPS.EC.name}",${TCE},${TCV})+L${r}`,result:p.ing},Math.round(p.fruta),Math.round(p.mat),Math.round(p.mo),Math.round(p.flete),{formula:`SUM(N${r}:Q${r})`,result:p.cost},{formula:`M${r}-R${r}`,result:p.util},{formula:`IF(M${r}>0,S${r}/M${r},"")`,result:p.ing>0?p.util/p.ing:''},
      p.rech,{formula:`IF(I${r}>0,U${r}/I${r},"")`,result:p.cajas>0?p.rech/p.cajas:''},p.peE!=null?p.peE:num(b.personas),p.hE!=null?p.hE:num(b.horas),p.paroE!=null?p.paroE:num(b.paro),{formula:`IF(AND(X${r}>0,X${r}-Y${r}/60>0),I${r}/(X${r}-Y${r}/60),"")`,result:p.cph||''},b.naviera||'',b.contenedor||'',d0(b.eta),d0(b.llegada),{formula:`IF(AND(AC${r}<>"",AD${r}<>""),AD${r}-AC${r},"")`,result:b.eta&&b.llegada?dayDiff(b.eta,b.llegada):''},n0(b.demora)];
    const fmts=[0,0,0,'dd/mm/yyyy',0,0,0,NUM,NUM,NUM,MON2,MON,MON,MON,MON,MON,MON,MON,MON,PCT,NUM,PCT,NUM,NUM,NUM,NUM,0,0,'dd/mm/yyyy','dd/mm/yyyy',NUM,MON];
    v.forEach((x,c)=>cell(pw,r,c+1,x,st(fmts[c]||undefined,c===2||c===6?{horizontal:'center',vertical:'middle'}:undefined)));
  });
  const pl=4+Math.max(1,P.length),tr=pl+1;
  cell(pw,tr,1,'TOTAL',{font:{bold:true}});[9,10,11,12,13,14,15,16,17,18,19,21,32].forEach(c=>cell(pw,tr,c,{formula:`SUBTOTAL(9,${L(c)}5:${L(c)}${pl})`},{font:{bold:true},fmt:c>=11&&c<=19?MON:c===32?MON:NUM}));
  cell(pw,tr,20,{formula:`IF(M${tr}>0,S${tr}/M${tr},"")`},{font:{bold:true},fmt:PCT});cell(pw,tr,22,{formula:`IF(I${tr}>0,U${tr}/I${tr},"")`},{font:{bold:true},fmt:PCT});
  pw.autoFilter={from:{row:4,column:1},to:{row:pl,column:pc.length}};
  const PR=c=>`Pedidos!$${c}$5:$${c}$${pl}`;
  /* --- indicadores del Tablero, todos con fórmula --- */
  sec(4,4,'Indicadores (se recalculan)');
  const K=[['Cajas de exportación',`SUM(${PR('I')})`,NUM],['Kilos recibidos',`SUM(${PR('J')})`,NUM],['Ingresos (MXN)',`SUM(${PR('M')})`,MON],['Costos variables (MXN)',`SUM(${PR('R')})`,MON],['Utilidad bruta (MXN)','E7-E8',MON],['Margen bruto','IF(E7>0,E9/E7,"")',PCT],['Precio promedio (USD por caja)',`IF(E5>0,SUM(${PR('K')})/E5,"")`,MON2],['Costo por caja (MXN)','IF(E5>0,E8/E5,"")',MON2],['Cada caja deja (MXN)','IF(E5>0,E9/E5,"")',MON2],['Costos fijos del periodo (MXN)','B7*B8',MON],['Punto de equilibrio (cajas)','IF(E13>0,ROUNDUP(E14/E13,0),"No se alcanza")',NUM],['Empiezas a ganar a partir de la caja','IF(ISNUMBER(E15),E15+1,"–")',NUM],['Utilidad neta (MXN)','E9-E14',MON],['Utilidad neta con las cajas planeadas','IF(ISNUMBER(E13),B11*E13-E14,"")',MON],['Cajas rechazadas',`SUM(${PR('U')})`,NUM],['% de rechazo','IF(E5>0,E19/E5,"")',PCT],['Horas hombre',`SUMPRODUCT(${PR('W')},${PR('X')})`,NUM],['Cajas por hora hombre',`IF(E21>0,SUMIFS(${PR('I')},${PR('W')},">0",${PR('X')},">0")/E21,"")`,'0.0'],['Mano de obra real por caja (MXN)',`IF(E21>0,E21*B10/SUMIFS(${PR('I')},${PR('W')},">0",${PR('X')},">0"),"")`,MON2],['Demoras (USD)',`SUM(${PR('AF')})`,MON]];
  K.forEach((x,i)=>{cell(tb,5+i,4,x[0],{font:{bold:i===10||i===11}});cell(tb,5+i,5,{formula:x[1]},{fmt:x[2],font:{bold:true,color:{argb:i===10||i===11?'FF3D6C10':'FF000000'}}})});
  tb.getCell(13,1).value='Cómo leerlo';tb.getCell(13,1).font=font({bold:true});
  ['Cambia el tipo de cambio y los costos fijos: los ingresos de cada pedido y el punto de equilibrio se recalculan.','Punto de equilibrio = costos fijos del periodo ÷ lo que deja cada caja después de costos variables.','Las hojas Pedidos, Productores y Clientes tienen filtros: usa la flecha del encabezado para clasificar.'].forEach((t,i)=>{tb.mergeCells(14+i,1,14+i,2);const c=tb.getCell(14+i,1);c.value=t;c.font=font({size:9,color:{argb:'FF555555'}});c.alignment={wrapText:true,vertical:'top'};tb.getRow(14+i).height=30});
  /* --- Productores --- */
  const rc=[{h:'Productor',w:30},{h:'Código',w:8},{h:'Zona / huerta',w:16},{h:'Pedidos',w:8},{h:'Kilos',w:10},{h:'Cajas exportación',w:10},{h:'Rendimiento 1ras',w:10},{h:'Ingreso MXN',w:13},{h:'Costo MXN',w:13},{h:'Utilidad MXN',w:13},{h:'Margen',w:8},{h:'Pago por fruta MXN',w:13},{h:'Participación cajas',w:10},{h:'Acumulado (Pareto)',w:10},{h:'Cuadrante',w:15},{h:'Índice de calidad',w:9}];
  const rw=wb.addWorksheet('Productores',{views:[{state:'frozen',xSplit:1,ySplit:4,showGridLines:false}]});title(rw,'Productores: rentabilidad, Pareto y calidad',sub,10);head(rw,4,rc,'FF4F6B0A');
  const zP={};D.cur.list.forEach(o=>compute(o).rows.forEach(r=>{const p=r.p,k=p.codigo?'c'+p.codigo:'n'+norm(p.nombre||'sin nombre'),z=zonaOf(p);if(z)zP[k]=z}));
  const RR=B.par,rl=4+Math.max(1,RR.length);
  RR.forEach((a,i)=>{const r=5+i,z=i%2?fill('FFF2F5F0'):undefined;
    const v=[a.nombre,a.codigo?pad(a.codigo,3):'',zP[a.key]||'',a.ped.size,a.kilos,a.cajas,a.rend,Math.round(a.ing),Math.round(a.cost),{formula:`H${r}-I${r}`,result:a.util},{formula:`IF(H${r}>0,J${r}/H${r},"")`,result:a.margen==null?'':a.margen},Math.round(a.pago),{formula:`IF(SUM($F$5:$F$${rl})>0,F${r}/SUM($F$5:$F$${rl}),"")`,result:a.share},{formula:`IF(SUM($F$5:$F$${rl})>0,SUM($F$5:F${r})/SUM($F$5:$F$${rl}),"")`,result:a.cum},
      {formula:`IF(AND(E${r}>=MEDIAN($E$5:$E$${rl}),K${r}>=Tablero!$E$10),"Estrellas",IF(E${r}>=MEDIAN($E$5:$E$${rl}),"Vacas lecheras",IF(K${r}>=Tablero!$E$10,"Interrogantes","Por revisar")))`,result:Q_LAB[a.q]},a.iq];
    const fm2=[0,0,0,NUM,NUM,NUM,PCT,MON,MON,MON,PCT,MON,PCT,PCT,0,NUM];v.forEach((x,c)=>cell(rw,r,c+1,x,{fmt:fm2[c]||undefined,fill:z}))});
  rw.autoFilter={from:{row:4,column:1},to:{row:rl,column:rc.length}};
  /* --- Clientes --- */
  const cc=[{h:'Ranking',w:8},{h:'Cliente',w:28},{h:'Pedidos',w:8},{h:'Cajas',w:10},{h:'Ingreso MXN',w:13},{h:'Costo MXN',w:13},{h:'Utilidad MXN',w:13},{h:'Margen',w:8},{h:'Cajas rechazadas',w:9},{h:'% rechazo',w:8},{h:'Días de pago (prom.)',w:9},{h:'Destinos',w:24},{h:'INCOTERM',w:10}].concat(CAL_ASC.filter(k=>B.C.some(c=>c.cajC[k])).map(k=>({h:'Cal. '+CAL_LAB[k],w:8,k:k})));
  const cw=wb.addWorksheet('Clientes',{views:[{state:'frozen',xSplit:2,ySplit:4,showGridLines:false}]});title(cw,'Clientes: ranking por margen, rechazos y mezcla de calibres',sub,10);head(cw,4,cc,'FF9C5700');
  B.C.forEach((c,i)=>{const r=5+i,z=i%2?fill('FFF2F5F0'):undefined;
    const v=[{formula:`RANK(H${r},$H$5:$H$${4+B.C.length})`,result:i+1},c.nombre,c.ped,c.cajas,Math.round(c.ing),Math.round(c.cost),{formula:`E${r}-F${r}`,result:c.util},{formula:`IF(E${r}>0,G${r}/E${r},"")`,result:c.margen==null?'':c.margen},c.rech,{formula:`IF(D${r}>0,I${r}/D${r},"")`,result:c.rechP==null?'':c.rechP},c.diasP==null?null:Math.round(c.diasP),[...c.dest].join(', '),[...c.inc].join(', ')].concat(cc.slice(13).map(x=>c.cajC[x.k]||0));
    v.forEach((x,k)=>cell(cw,r,k+1,x,{fmt:[NUM,0,NUM,NUM,MON,MON,MON,PCT,NUM,PCT,NUM,0,0][k]||(k>=13?NUM:undefined),fill:z}))});
  cw.autoFilter={from:{row:4,column:1},to:{row:4+Math.max(1,B.C.length),column:cc.length}};
  /* --- Semanas y proyección con PRONOSTICO --- */
  const sw=wb.addWorksheet('Semanas',{views:[{showGridLines:false}]});title(sw,'Semanas y proyección a 4 semanas',sub,6);head(sw,4,[{h:'#',w:6},{h:'Semana',w:14},{h:'Cajas',w:12},{h:'Ingreso MXN',w:14},{h:'Utilidad MXN',w:14},{h:'Tipo',w:14}]);
  const S=B.S,sl=4+S.length;
  S.forEach((s,i)=>{const r=5+i;[i+1,s.l+' · '+s.k.slice(0,4),s.cajas,Math.round(s.ing),Math.round(s.util),'Real'].forEach((x,c)=>cell(sw,r,c+1,x,{fmt:[NUM,0,NUM,MON,MON,0][c]||undefined}))});
  if(S.length>=3)B.proj.forEach((p,i)=>{const r=sl+1+i,z=fill('FFFFF2CC');[S.length+1+i,p.l+' · '+p.k.slice(0,4),{formula:`MAX(0,ROUND(FORECAST(A${r},$C$5:$C$${sl},$A$5:$A$${sl}),0))`,result:p.cajas},{formula:`FORECAST(A${r},$D$5:$D$${sl},$A$5:$A$${sl})`},{formula:`FORECAST(A${r},$E$5:$E$${sl},$A$5:$A$${sl})`,result:p.util||0},'Proyección'].forEach((x,c)=>cell(sw,r,c+1,x,{fmt:[NUM,0,NUM,MON,MON,0][c]||undefined,fill:z,font:{italic:true}}))});
  /* --- Calibres --- */
  const kw=wb.addWorksheet('Calibres',{views:[{showGridLines:false}]});title(kw,'Mezcla de calibres',sub,5);head(kw,4,[{h:'Calibre',w:12},{h:'Cajas',w:12},{h:'Ingreso MXN',w:14},{h:'USD por caja',w:12},{h:'% de cajas',w:11}],'FF4F6B0A');
  const ks=CAL_ASC.filter(k=>T.cajC[k]>0),kl=4+Math.max(1,ks.length);
  ks.forEach((k,i)=>{const r=5+i;[CAL_LAB[k],T.cajC[k],Math.round(T.ingC[k]),Math.round(T.usdC[k]/T.cajC[k]*100)/100,{formula:`B${r}/SUM($B$5:$B$${kl})`,result:T.cajas?T.cajC[k]/T.cajas:0}].forEach((x,c)=>cell(kw,r,c+1,x,{fmt:[0,NUM,MON,MON2,PCT][c]||undefined,al:c===0?{horizontal:'center'}:undefined}))});
  /* --- Alertas --- */
  const aw=wb.addWorksheet('Alertas',{views:[{showGridLines:false}]});title(aw,'Alertas',sub,3);head(aw,4,[{h:'Nivel',w:11},{h:'Alerta',w:40},{h:'Detalle',w:80}],'FFB3261E');
  const AL={crit:'Urgente',warn:'Atención',info:'Aviso'};B.alerts.forEach((a,i)=>{[AL[a.l],a.t,a.d].forEach((x,c)=>cell(aw,5+i,c+1,x,{font:{bold:c===0,color:{argb:a.l==='crit'?'FFB3261E':a.l==='warn'?'FF9A5F00':'FF245AA5'}}}))});
  if(D.cierre){
    const jw=wb.addWorksheet('Juguera',{views:[{showGridLines:false}]});const pk=PER.list[D.cierre]||{},j=pk.closed&&pk.jug?pk.jug:null,lots=j?j.lots:jugCandidates(D.cierre).map(l=>({nombre:l.nombre,codigo:l.codigo,fecha:l.fecha,de:l.de,n:l.av}));
    title(jw,(j?'Segundas registradas a Juguera':'Segundas que pasarán a Juguera al cerrar')+' · '+wkLab(D.cierre),sub,5);head(jw,4,[{h:'Productor',w:30},{h:'Código',w:9},{h:'Fecha',w:12},{h:'Origen',w:40},{h:'Cajas',w:10}]);
    lots.forEach((l,i)=>[l.nombre,l.codigo?pad(l.codigo,3):'',l.fecha?d0(l.fecha):'',l.de||'',l.n].forEach((x,c)=>cell(jw,5+i,c+1,x,{fmt:[0,0,'dd/mm/yyyy',0,NUM][c]||undefined})));
    const r=5+lots.length;cell(jw,r,1,'TOTAL',{font:{bold:true}});cell(jw,r,5,{formula:`SUM(E5:E${Math.max(5,r-1)})`},{fmt:NUM,font:{bold:true}});
  }
  return wb;
}
/* ----- PDF ejecutivo (hoja carta vertical, 150 ppp) ----- */
async function biPages(D){
  const B=D.bi||(D.bi=biCalc(D)),T=D.fin.T,f=D.f||statsF,lb=D.label||biLabel(f),e0=f.emp==='ALL'?emp:f.emp,E=EMPS[e0];
  const W=1275,H=1650,M=70,INK='#14221b',MUT='#5b6b60',LN='#d5ddd6',BR=e0==='EC'?'#38582a':'#1b2c46',AC=e0==='EC'?'#f08030':'#98c858';
  const lg=await asset(LOGO[e0]).catch(()=>null),pages=[];let ops,y;
  const R=(x,y_,w,h,p)=>ops.push(Object.assign({t:'r',x:x,y:y_,w:w,h:h},p)),TX=(s,x,y_,w,h,p)=>ops.push(Object.assign({t:'t',s:s==null?'':String(s),x:x,y:y_,w:w,h:h,size:22,color:INK},p)),LI=(x,y_,w,h,c)=>ops.push({t:'l',x:x,y:y_,w:w,h:h,line:c||LN,lw:2});
  const page=()=>{ops=[];pages.push({w:W,h:H,ops:ops});R(0,0,W,120,{fill:BR});if(lg){const h=80,w=Math.min(220,h*lg.w/lg.h);R(M-6,20,w+12,h,{fill:'#ffffff',rad:8});ops.push({t:'i',b64:lg.b64,x:M,y:20,w:w,h:h})}
    TX(D.cierre?'CIERRE DE SEMANA':'REPORTE EJECUTIVO',360,24,W-360-M,44,{size:34,bold:true,color:'#ffffff',align:'right'});TX(lb.e+' · '+lb.per,360,70,W-360-M,32,{size:20,color:'#ffffff',align:'right'});
    TX(APP_NAME+' · generado el '+fmtDate(todayISO())+' · página '+pages.length,M,H-50,W-2*M,28,{size:16,color:MUT,align:'center'});y=150};
  const head=t=>{TX(t,M,y,W-2*M,34,{size:24,bold:true,color:BR});R(M,y+38,W-2*M,3,{fill:AC});y+=54};
  const table=(cols,rows,rh)=>{rh=rh||34;let x=M;R(M,y,W-2*M,rh,{fill:BR});cols.forEach(c=>{TX(c.h,x,y,c.w,rh,{size:16,bold:true,color:'#ffffff',align:c.al||'left'});x+=c.w});y+=rh;
    rows.forEach((r,i)=>{if(i%2)R(M,y,W-2*M,rh,{fill:'#f2f5f0'});x=M;cols.forEach((c,k)=>{TX(r[k],x,y,c.w,rh,{size:17,align:c.al||'left',bold:!!(r.b&&k===0)||(c.b),color:r.c&&r.c[k]||INK});x+=c.w});y+=rh});y+=14};
  page();
  /* indicadores */
  const tiles=[['Ingresos',mxn(T.ing)],['Utilidad bruta',mxn(T.util)],['Margen',pctTxt(T.margen)],['Cajas exportación',fmt(T.cajas)],['Precio promedio',usd(T.precio,2)],['Costo por caja',mxn(T.costoCaja,2)],['Rendimiento 1ras',pctTxt(D.cur.T.rend)],['Pago a productores',mxn(T.fruta)]];
  const tw=(W-2*M-30)/4;tiles.forEach((t,i)=>{const x=M+(i%4)*(tw+10),yy=y+Math.floor(i/4)*118;R(x,yy,tw,108,{fill:'#f6f8f5',line:LN,lw:2,rad:10});TX(t[0],x+10,yy+10,tw-20,28,{size:17,color:MUT});TX(t[1],x+10,yy+44,tw-20,52,{size:32,bold:true,color:i===1&&T.util<0?'#b3261e':INK})});y+=250;
  /* punto de equilibrio */
  R(M,y,W-2*M,190,{fill:'#ffffff',line:BR,lw:3,rad:12});TX('INDICADOR ESTRELLA · PUNTO DE EQUILIBRIO',M+20,y+12,W-2*M-40,28,{size:18,bold:true,color:MUT});
  TX(B.be?'A partir de la caja '+fmt(B.be+1)+' empiezas a ganar':'Con estos precios no se alcanza el punto de equilibrio',M+20,y+44,W-2*M-40,50,{size:36,bold:true,color:BR});
  const bw=W-2*M-40,pr=B.be?Math.min(1,T.cajas/B.be):0;R(M+20,y+104,bw,22,{fill:'#e6ebe6',rad:11});if(pr>0)R(M+20,y+104,Math.max(22,bw*pr),22,{fill:T.cajas>=(B.be||1e12)?'#2b7a3b':AC,rad:11});
  TX(`Van ${fmt(T.cajas)} cajas · cada caja deja ${mxn(B.contrib,2)} · costos fijos ${mxn(B.fijo)} (${B.nW} sem.) · utilidad neta ${mxn(B.neta)}`,M+20,y+138,W-2*M-40,36,{size:19,color:INK});y+=214;
  /* tendencia semanal de utilidad */
  head('Cajas por semana y proyección');
  const sd=B.S.map(s=>({l:s.l,v:s.cajas,p:0})).concat(B.proj.map(s=>({l:s.l,v:s.cajas,p:1})));
  if(sd.length){const ch=220,mx=Math.max(1,...sd.map(s=>s.v)),gw=(W-2*M)/sd.length,b2=Math.min(70,gw*0.6);LI(M,y+ch,W-2*M,0,MUT);
    sd.forEach((s,i)=>{const h=s.v/mx*(ch-30),x=M+gw*i+(gw-b2)/2;R(x,y+ch-h,b2,h,s.p?{fill:'#ffffff',line:BR,lw:3}:{fill:BR});TX(fmt(s.v),x-20,y+ch-h-28,b2+40,26,{size:15,align:'center',color:MUT});TX(s.l+(s.p?'*':''),x-20,y+ch+4,b2+40,26,{size:15,align:'center',color:MUT})});
    y+=ch+40;TX(B.proj.length?'* Proyección por tendencia de las últimas '+B.S.length+' semanas: '+fmt(B.proj.reduce((s,p)=>s+p.cajas,0))+' cajas en 4 semanas.':'Hacen falta 3 semanas con datos para proyectar.',M,y,W-2*M,28,{size:16,color:MUT});y+=44}
  /* alertas */
  head('Alertas');
  const tg={crit:['URGENTE','#b3261e','#f8dcd9'],warn:['ATENCIÓN','#9a5f00','#f8ebcf'],info:['AVISO','#245aa5','#dce8f7']};
  B.alerts.slice(0,Math.max(1,Math.floor((H-120-y)/62))).forEach(a=>{const g=tg[a.l];R(M,y,130,30,{fill:g[2],rad:6});TX(g[0],M,y,130,30,{size:15,bold:true,color:g[1],align:'center'});TX(a.t,M+145,y-2,W-2*M-145,30,{size:19,bold:true});TX(a.d,M+145,y+26,W-2*M-145,28,{size:16,color:MUT});y+=62});
  if(!B.alerts.length){TX('Sin alertas con estos filtros.',M,y,W-2*M,30,{size:18,color:MUT});y+=40}
  /* página 2: productores y clientes */
  page();head('Productores · Pareto 80/20 y matriz');
  const top=B.par.slice(0,16);
  table([{h:'Productor',w:350},{h:'Cajas',w:110,al:'right'},{h:'Particip.',w:110,al:'right'},{h:'Acumulado',w:120,al:'right'},{h:'Margen',w:110,al:'center'},{h:'Cuadrante',w:190},{h:'Índice',w:145,al:'right'}],top.map(a=>[a.nombre,fmt(a.cajas),pctTxt(a.share),pctTxt(a.cum),pctTxt(a.margen),Q_LAB[a.q],a.iq==null?'–':String(a.iq)]));
  TX((B.n80?B.n80+' de '+B.par.length+' productores aportan el 80 % de las cajas.':'')+(B.par.length>16?' Se muestran los primeros 16.':''),M,y-6,W-2*M,28,{size:16,color:MUT});y+=36;
  head('Clientes · ranking por margen');
  table([{h:'Cliente',w:330},{h:'Pedidos',w:90,al:'right'},{h:'Cajas',w:110,al:'right'},{h:'Utilidad MXN',w:170,al:'right'},{h:'Margen',w:110,al:'right'},{h:'Rechazo',w:110,al:'right'},{h:'Días pago',w:115,al:'right'}],B.C.slice(0,8).map(c=>Object.assign([c.nombre,String(c.ped),fmt(c.cajas),money(c.util),pctTxt(c.margen),pctTxt(c.rechP),c.diasP==null?'–':fmt(c.diasP,0)],{c:[0,0,0,c.util<0?'#b3261e':0,0,c.rechP>0.03?'#b3261e':0,0]})));
  /* página 3 si no cabe: línea, logística y comparativa */
  {const K=B.cash;if(K){if(y>H-330)page();head('Capital de trabajo · al día de hoy');table([{h:'Indicador',w:480},{h:'Valor',w:655}],[['DSO · días para cobrar',K.dso==null?'–':fmt(K.dso,0)+' días'],['DPO · días para pagar',K.dpo==null?'–':fmt(K.dpo,0)+' días'],['Ciclo de conversión de efectivo (DSO − DPO)',K.cce==null?'–':fmt(K.cce,0)+' días'],['Por cobrar (USD convertidos) menos por pagar',mxn(K.gap)+(K.umbral!=null?' · umbral '+mxn(K.umbral):' · sin umbral')]],32)}}
  if(y>H-560)page();
  head('Línea, logística y comparativa');
  const L=B.L,G=B.G,cm=B.cmp;
  table([{h:'Indicador',w:480},{h:'Valor',w:655}],[['OEE (disponibilidad × rendimiento × calidad)',pctTxt(L.oee)],['Cajas por hora / por persona',(L.cph==null?'–':fmt(L.cph,0))+' / '+(L.cpp==null?'–':fmt(L.cpp,0))],['Mano de obra real por caja',L.moCaja==null?'–':mxn(L.moCaja,2)],['Costo logístico por caja',G.logCaja==null?'–':mxn(G.logCaja,2)],['Llegadas a tiempo · retraso promedio',pctTxt(G.punt)+' · '+(G.delayP==null?'–':fmt(G.delayP,1)+' días')],['Demoras (demurrage)',usd(G.dem)]],32);
  table([{h:'',w:385},{h:'Vera Limes',w:250,al:'right'},{h:'Citrilar',w:250,al:'right'},{h:'Diferencia',w:250,al:'right'}],[['Cajas exportación',fmt(cm[0].F.cajas),fmt(cm[1].F.cajas),fmt(cm[0].F.cajas-cm[1].F.cajas)],['Utilidad bruta',mxn(cm[0].F.util),mxn(cm[1].F.util),mxn(cm[0].F.util-cm[1].F.util)],['Margen',pctTxt(cm[0].F.margen),pctTxt(cm[1].F.margen),cm[0].F.margen!=null&&cm[1].F.margen!=null?fmt((cm[0].F.margen-cm[1].F.margen)*100,1)+' pp':'–'],['Rendimiento',pctTxt(cm[0].A.rend),pctTxt(cm[1].A.rend),cm[0].A.rend!=null&&cm[1].A.rend!=null?fmt((cm[0].A.rend-cm[1].A.rend)*100,1)+' pp':'–']],32);
  if(D.cierre){const pk=PER.list[D.cierre]||{},j=pk.closed&&pk.jug?pk.jug.cajas:jugCandidates(D.cierre).reduce((s,l)=>s+l.av,0);if(y>H-200)page();head('Juguera');TX((pk.closed?'Se registraron ':'Al cerrar se registrarán ')+fmt(j)+' cajas de segunda a Juguera (se envían en la '+wkLab(wkNext(D.cierre))+').',M,y,W-2*M,34,{size:20});y+=50}
  return pages;
}

/* ---------- Excel (ExcelJS + xl.js) ---------- */
const XLSX_MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const assetCache={};
async function asset(path){
  if(assetCache[path])return assetCache[path];
  let b64;const emb=String(path).indexOf('data:')===0?path:(window.EMP_ASSETS&&window.EMP_ASSETS[path]);
  if(emb)b64=String(emb).split(',')[1];
  else{
    const r=await fetch(path);if(!r.ok)throw new Error('asset '+path);
    const buf=new Uint8Array(await r.arrayBuffer());let s='';
    for(let i=0;i<buf.length;i+=0x8000)s+=String.fromCharCode.apply(null,buf.subarray(i,i+0x8000));
    b64=btoa(s);
  }
  const im=new Image();
  await new Promise(res=>{im.onload=res;im.onerror=res;im.src='data:image/jpeg;base64,'+b64});
  return assetCache[path]={b64:b64,w:im.naturalWidth||560,h:im.naturalHeight||350};
}
async function wbBlob(wb){const buf=await wb.xlsx.writeBuffer();return new Blob([buf],{type:XLSX_MIME})}
function newWb(){const wb=new ExcelJS.Workbook();wb.creator=APP_NAME;wb.created=new Date();return wb}
/* v8.18.3: fecha del registro. Si la hoja no tiene «Fecha» en su encabezado, toma la de la otra hoja del pedido, la fecha de salida
   de Código de Trazabilidad o, al final, el día en que se creó el pedido; así el Excel nunca sale con la fecha en blanco */
function regFecha(o){const m=mainOf(o),t=(m.traz&&m.traz.hdr)||{},ok=v=>/^\d{4}-\d{2}-\d{2}$/.test(String(v||''));
  if(ok(o.fecha))return {f:o.fecha,src:'hoja'};const s=sheetsOf(o).find(x=>ok(x.fecha));if(s)return {f:s.fecha,src:'pedido'};if(ok(t.salida))return {f:t.salida,src:'salida'};
  const c=o.createdAt?new Date(o.createdAt):null;return c?{f:c.getFullYear()+'-'+pad(c.getMonth()+1,2)+'-'+pad(c.getDate(),2),src:'creado'}:{f:'',src:''}}
const dmyTxt=f=>{const a=String(f||'').split('-');return a.length===3?a[1]+'/'+a[2]:''};
function addRegSheet(wb,x,logo){
  const M=compute(x),lines=M.lines.filter(t=>M.manBy[t]||(M.byTipo[t]&&M.byTipo[t].t)).map(t=>({t:t,label:TIPO_CH[t],man:M.manBy[t]||{},fin:M.byTipo[t]||{}}));
  const RF=regFecha(x),S=pesShares(),entTxt={};
  (x.productores||[]).forEach(p=>{if(!p.inv||!p.invEnt||p.invEnt.length<1||!p.pesE)return;entTxt[p.id]='Entregas: '+p.invEnt.map(id=>{const e=INV.entradas.find(y=>y.id===id);if(!e)return '';const z=S.get(id),i=z?z.R.findIndex(r=>r.p===p):-1,k=i>=0&&num(e.kilos)>0?num(e.kilos)*z.sh[i]:null;return dmyTxt(e.fecha)+(k!=null?' ('+fmt(k,0)+' kg)':' (sin peso)')}).filter(Boolean).join(' + ')});
  XL.addRegistro(wb,{o:x,M:M,lines:lines,entTxt:entTxt,fechaDate:RF.f?(a=>a[1]+'/'+a[2]+'/'+a[0])(RF.f.split('-')):'', /* v8.18.5: formato americano MM/DD/AAAA */calidad:CALIDAD_L[x.variante]||x.variante,logo:logo,sheetName:x.variante==='1.5'?x.cod+' 1.5':x.cod,estado:x.estado,titulo:x.cod,sobrante:leftoverOf(x),notasP:(()=>{const r={};(x.productores||[]).forEach(p=>{const L=(p.sob2?(p.rmp?rmpNoteLines(p):sobNoteLines(p)):[]).concat(rmpOutNotes(x,p));if(L.length)r[p.id]=L});return r})(),cal:calUI(x),tipoTxt:tipoText(x),tipoNames:TIPO_L,tipoCh:TIPO_CH,pesos:M.W,pesosK:TIPO_K,kgSeg:M.W.seg});
}
async function buildRegistroWb(o){
  const wb=newWb(),logo=await asset(LOGO[o.emp]);
  sheetsOf(o).forEach(x=>addRegSheet(wb,x,logo));
  return wb;
}
/* v8.15 · Excel de viajes de la semana: el Registro de cada viaje de la semana en un solo libro.
   Viaje por viaje en el orden en que se fueron agregando: la hoja de primera (hoja 1) y justo al lado su hoja 1.5.
   Cada pestaña lleva el nombre de su viaje (la de segunda con « 1.5»). */
function wkTripSheets(wk){
  const L=visible().filter(o=>wkOf(o)===wk),G=new Map();
  L.forEach(o=>{const k=o.emp+'|'+o.cod;if(!G.has(k))G.set(k,[]);G.get(k).push(o)});
  const t0=g=>{const m=g.find(x=>x.variante!=='1.5')||g[0];return m.createdAt||0};
  return [...G.values()].sort((a,b)=>t0(a)-t0(b)||String(a[0].cod).localeCompare(String(b[0].cod),'es',{numeric:true}))
    .flatMap(g=>g.sort((a,b)=>(a.variante==='1.5'?1:0)-(b.variante==='1.5'?1:0)));
}
async function buildWkTripsWb(wk){
  const wb=newWb(),logos={};
  for(const x of wkTripSheets(wk)){if(!(x.emp in logos))logos[x.emp]=await asset(LOGO[x.emp]);addRegSheet(wb,x,logos[x.emp])}
  return wb;
}
async function wkTripsPages(wk){const wb=await buildWkTripsWb(wk);return xlPages(wb,wb.worksheets)}
function openOutWkTrips(){
  const ks=[...new Set(visible().map(wkOf).filter(Boolean))].sort().reverse(),wk=listWk==='ALL'?null:(ks.indexOf(listWk)>=0?listWk:ks[0]);
  if(!wk){toast('Elige una semana');return}
  const S=wkTripSheets(wk);if(!S.length){toast('Esta semana no tiene viajes');return}
  const m=/^(\d{4})-S(\d+)$/.exec(wk),n1=S.filter(x=>x.variante!=='1.5').length,n2=S.length-n1,f={};
  if(typeof ExcelJS!=='undefined')f.xlsx=async()=>wbBlob(await buildWkTripsWb(wk));
  f.pdf=async()=>pagesToPdf(await wkTripsPages(wk));
  openOut({pages:()=>wkTripsPages(wk),title:'Viajes de la '+wkLab(wk),base:fileSafe('Viajes_Semana_'+(m?+m[2]+'_'+m[1]:wk)),fmts:f,
    note:'Un solo Excel con el Registro de Empaque de cada viaje de la semana, en el orden en que se agregaron: '+n1+(n1===1?' hoja de primera':' hojas de primera')+(n2?' y '+n2+(n2===1?' de segunda (1.5), al lado de su viaje':' de segunda (1.5), cada una al lado de su viaje'):'')+'. Cada pestaña lleva el nombre de su viaje.'});
}
const fileSafe=s=>String(s||'').replace(/[^\w.-]+/g,'_');
async function exportRegistro(share){
  const o=cur();if(!o)return;
  if(typeof ExcelJS==='undefined'){toast('La descarga no está disponible aquí');return}
  try{
    const wb=await buildRegistroWb(o);
    await saveFile('Registro_'+fileSafe(o.cod)+'.xlsx',await wbBlob(wb),share?'Registro '+o.cod+' · '+o.emb:null);
  }catch(e){toast('No se pudo generar el Excel')}
}
function drawTrailer(count,used){
  const cv=document.createElement('canvas'),rows=Math.ceil(count/2),W=190,top=84,rh=36,H=top+rows*rh+24;cv.width=W;cv.height=H;
  const x=cv.getContext('2d');x.fillStyle='#ffffff';x.fillRect(0,0,W,H);
  x.fillStyle='#4f7fb8';x.beginPath();x.roundRect?x.roundRect(30,4,130,64,14):x.rect(30,4,130,64);x.fill();
  x.fillStyle='#cfe3f7';x.fillRect(44,14,102,20);x.fillStyle='#2b4f7e';x.fillRect(14,20,12,28);x.fillRect(164,20,12,28);
  x.fillStyle='#e8eef5';x.strokeStyle='#4f7fb8';x.lineWidth=3;x.fillRect(12,top-8,W-24,rows*rh+20);x.strokeRect(12,top-8,W-24,rows*rh+20);
  x.font='bold 14px Arial';x.textAlign='center';x.textBaseline='middle';
  for(let i=0;i<count;i++){
    const r=Math.floor(i/2),c=i%2,bx=22+c*76,by=top+r*rh;const on=i<used;
    x.fillStyle=on?'#2f6fb0':'#d3dce6';x.fillRect(bx,by,70,rh-6);
    x.fillStyle=on?'#ffffff':'#7d8b99';x.fillText(String(i+1),bx+35,by+(rh-6)/2+1);
  }
  return{b64:cv.toDataURL('image/png').split(',')[1],w:W,h:H};
}
async function buildTrazWb(o){
  TM=tipoMapFor(o);
  const m=mainOf(o),z=trazCalc(m),wb=newWb(),logo=await asset(LOGO_F2[m.emp]);
  /* v8.7: tractor en foto y caja dibujada con un lugar por tarima */
  const ph=await trailerComposite(z.nPal),trailer=ph||drawTrailer(Math.max(24,z.nPal),z.nPal);
  const pallets=z.t.tarimas.map((p,i)=>({n:i+1,cap:palCap(palTipo(p)),marca:palMarcaTxt(p,o.emp),tag:EMP_TAG[palEmp(p)]||'',lines:(p.lines||[]).map(l=>({cal:l.cal,cant:l.cant,prod:resolveProd(z.sh,l.prod)}))}));
  const ws=XL.addTraz(wb,{o:m,hdr:z.t.hdr,pallets:pallets,borrador:z.borrador,motivos:z.motivos,logo:logo,trailer:trailer,pad:0,sheetName:m.emb||m.cod,full:z.nPal?z.full:undefined,orient:z.t.orient==='h'?'h':'v'});
  const keys=new Map();
  Object.keys(z.empP).forEach(k=>keys.set(k,z.empP[k].nombre));
  Object.keys(z.palP).forEach(k=>{if(!keys.has(k))keys.set(k,k)});
  const productores=[...keys.entries()].map(([k,nombre])=>({key:k,nombre:nombre,pal:(z.palP[k]&&z.palP[k].by)||{},palTot:(z.palP[k]&&z.palP[k].t)||0,emp:(z.empP[k]&&z.empP[k].t)||0}));
  const calP=CAL.filter(c=>(!isMM(c.k)&&c.k!=='ctn')||Object.keys(z.empP).some(k=>z.empP[k].by[c.k])||Object.keys(z.palP).some(k=>z.palP[k].by[c.k]));
  const calibres=calP.map(c=>({l:c.l,e1:z.exp['1'][c.k],p1:z.pal['1'][c.k],e15:z.exp['1.5'][c.k],p15:z.pal['1.5'][c.k]}));
  const lineas=[];z.lines.forEach(L=>{const a=L.split('|');CAL.forEach(c=>{const e=z.expL[L][c.k],p=z.palL[L][c.k];if(e||p)lineas.push({q:CALIDAD_L[a[0]],t:TIPO_CH[a[1]],l:c.l,e:e,p:p})})});
  XL.addResumen(wb,{o:m,cal:calP,borrador:z.borrador,trazSheet:ws.name,productores:productores,calibres:calibres,lineas:lineas});
  return wb;
}
async function exportTraz(share){
  const o=cur();if(!o)return;
  if(typeof ExcelJS==='undefined'){toast('La descarga no está disponible aquí');return}
  try{
    const m=mainOf(o),wb=await buildTrazWb(m);
    await saveFile('Trazabilidad_'+fileSafe(m.emb||m.cod)+(trazCalc(m).borrador?'_BORRADOR':'')+'.xlsx',await wbBlob(wb),share?'Código de Trazabilidad '+m.cod+' · '+m.emb:null);
  }catch(e){toast('No se pudo generar el Excel')}
}

/* ---------- base de datos completa ---------- */
const DBCOLS=[
  {k:'empresa',h:'Empresa',w:12},{k:'pedido',h:'Pedido',w:11},{k:'embarque',h:'Embarque',w:12},{k:'anio',h:'Año',w:7,al:'center'},{k:'semana',h:'Semana',w:8,al:'center'},{k:'fecha',h:'Fecha',w:12,al:'center'},
  {k:'calidad',h:'Calidad',w:13},{k:'estado',h:'Estado',w:11},{k:'po',h:'PO',w:10},{k:'cliente',h:'Cliente',w:22},{k:'domestico',h:'Cliente doméstico',w:22},{k:'factura',h:'Factura',w:12},
  {k:'tipo',h:'Tipo',w:11},{k:'empaque',h:'Tipo de empaque',w:14},{k:'productor',h:'Productor',w:30},{k:'codigo',h:'Código productor',w:12,al:'center'},
  {k:'k24',h:'Cajas grandes',w:10,fmt:'#,##0'},{k:'k18',h:'Cajas pequeñas',w:10,fmt:'#,##0'},{k:'kilos',h:'Kilos',w:11,fmt:'#,##0.0'},{k:'campo',h:'Cajas campo',w:11,fmt:'#,##0.0'}
].concat(CAL.map(c=>({k:'c_'+c.k,h:c.l,w:9,fmt:'#,##0',grp:'cal'})),[
  {k:'exp',h:'Total exportación',w:12,fmt:'#,##0',grp:'cal'},{k:'seg',h:'Segundas',w:10,fmt:'#,##0',grp:'out'},{k:'cera',h:'Segundas con cera',w:10,fmt:'#,##0',grp:'out'},{k:'tor',h:'Torreón',w:10,fmt:'#,##0',grp:'out'},{k:'des',h:'Desecho',w:10,fmt:'#,##0',grp:'out'},{k:'jug',h:'Juguera',w:10,fmt:'#,##0',grp:'out'},
  {k:'rend',h:'Rendimiento 1ras',w:12,fmt:'0.0%',grp:'out'},{k:'dif',h:'Diferencia',w:11,fmt:'#,##0.0',grp:'out'},{k:'nota',h:'Notas',w:34}
]);
function dbRows(){
  const out=[];
  visible().slice().sort((a,b)=>(a.emp<b.emp?-1:a.emp>b.emp?1:0)||(+a.anio-+b.anio)||((a.cons||0)-(b.cons||0))||(a.variante>b.variante?1:-1)).forEach(o=>{
    const M=compute(o);
    M.rows.forEach(r=>{
      const p=r.p,row={empresa:EMPS[o.emp].name,pedido:o.cod,embarque:o.emb,anio:o.anio,semana:num(o.semana),fecha:o.fecha||'',calidad:o.variante==='1.5'?'Segundas':'Primera',estado:o.estado==='completo'?'Completo':'En proceso',po:o.po||'',cliente:o.customer||'',domestico:o.domestic||'',factura:o.factura||'',tipo:(p.sob||isSob(p))?'Sobrante':'Productor',empaque:tiposTxt(p),productor:p.nombre||'',codigo:p.codigo?o.emp+'-'+pad(p.codigo,3):'',k24:num(p.k24),k18:num(p.k18),kilos:num(p.kilos),campo:r.campo==null?null:Math.round(r.campo*100)/100,exp:r.t,seg:num(p.seg),cera:num(p.cera),tor:num(p.tor),des:num(p.des),jug:num(p.jug),rend:r.rend,dif:r.dif==null?null:Math.round(r.dif*100)/100,nota:p.nota||''};
      CAL.forEach(c=>row['c_'+c.k]=r.delta[c.k]);
      out.push(row);
    });
  });
  return out;
}
function dbTarimas(){
  const out=[];
  const EL={};EMPAQUES.forEach(e=>EL[e[0]]=e[1]);
  visible().filter(o=>o.traz&&o.traz.tarimas).forEach(o=>{
    TM=tipoMapFor(o);
    o.traz.tarimas.forEach((p,i)=>(p.lines||[]).forEach(l=>out.push({empresa:EMPS[o.emp].name,pedido:o.cod,embarque:o.emb,pallet:i+1,marca:marcaOfQ(o.emp,lineQ(p,l)),empaque:EL[palEmp(p)]||palEmp(p),calibre:l.cal,cajas:num(l.cant),productor:resolveProd(sheetsOf(o),l.prod)})));
  });
  return out;
}
/* un renglón por pedido, calidad, tipo de empaque y calibre: manifiesto contra empacado */
function dbManifiestos(){
  const out=[];
  visible().slice().sort((a,b)=>(a.emp<b.emp?-1:a.emp>b.emp?1:0)||(+a.anio-+b.anio)||((a.cons||0)-(b.cons||0))||(a.variante>b.variante?1:-1)).forEach(o=>{
    const M=compute(o);
    M.lines.forEach(t=>{const m=M.manBy[t]||{},b=M.byTipo[t]||{};if(!M.manBy[t]&&!b.t)return;CAL.forEach(c=>{const mv=m[c.k]==null?null:m[c.k],f=b[c.k]||0;if(mv==null&&!f)return;out.push({empresa:EMPS[o.emp].name,pedido:o.cod,embarque:o.emb,calidad:CALIDAD_L[o.variante]||o.variante,empaque:TIPO_CH[t],calibre:c.l,manifiesto:mv,empacado:f,diferencia:mv==null?null:f-mv})})});
  });
  return out;
}
const csvCell=v=>{if(v==null)return '';const s=String(v);return /[",\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s};
/* columnas de la base: la vieja columna «230 CTN» solo sale si algún pedido viejo la tiene */
function dbCols(rows){return DBCOLS.filter(c=>c.k!=='c_ctn'||rows.some(r=>n0(r.c_ctn)>0))}
function dbCsv(rows){
  const cols=dbCols(rows).map(c=>c.k==='rend'?{k:'rend',h:'Rendimiento 1ras (%)'}:c);
  const lines=[cols.map(c=>csvCell(c.h)).join(',')];
  rows.forEach(r=>lines.push(cols.map(c=>c.k==='rend'?csvCell(r.rend==null?'':Math.round(r.rend*10000)/100):csvCell(r[c.k])).join(',')));
  return '﻿'+lines.join('\r\n');
}
async function exportDb(kind){
  const rows=dbRows(),stamp=todayISO();
  try{
    if(kind==='csv')await saveFile('Base_de_datos_empaque_'+stamp+'.csv',new Blob([dbCsv(rows)],{type:'text/csv;charset=utf-8'}));
    else if(kind==='json')await saveFile('Base_de_datos_empaque_'+stamp+'.json',new Blob([JSON.stringify({app:APP_NAME,exportado:new Date().toISOString(),pedidos:visible(),filas:rows,manifiestos:dbManifiestos(),tarimas:dbTarimas(),entradas:entradas()},null,1)],{type:'application/json'}));
    else{
      if(typeof ExcelJS==='undefined'){toast('La descarga en Excel no está disponible aquí');return}
      const wb=newWb(),A=aggregate(visible()),pr=A.rows.slice().sort((a,b)=>(b.rend==null?-1:b.rend)-(a.rend==null?-1:a.rend)).map(a=>({nombre:a.nombre,codigo:a.codigo?pad(a.codigo,3):'',pedidos:a.ped.size,kilos:a.kilos,exp:a.exp,seg:a.seg,tor:a.tor,des:a.des,rend:a.rend}));
      const tot=CAL.reduce((s,c)=>s+A.T.cal[c.k],0);
      XL.addBase(wb,{titulo:APP_NAME+' · Base de datos',sub:'Exportado el '+fmtDate(stamp)+' · '+rows.length+' filas · '+visible().length+' hojas',cols:dbCols(rows),rows:rows,pr:pr,cal:CAL.filter(c=>c.k!=='ctn'||A.T.cal.ctn>0).map(c=>({l:c.l,n:A.T.cal[c.k],pct:tot>0?A.T.cal[c.k]/tot:0})),extra:[invSheetSpec(),{name:'Manifiestos',cols:[{k:'empresa',h:'Empresa',w:12},{k:'pedido',h:'Pedido',w:11},{k:'embarque',h:'Embarque',w:12},{k:'calidad',h:'Calidad',w:13},{k:'empaque',h:'Tipo de empaque',w:15},{k:'calibre',h:'Calibre',w:10,al:'center'},{k:'manifiesto',h:'Manifiesto',w:11,fmt:'#,##0'},{k:'empacado',h:'Empacado',w:11,fmt:'#,##0'},{k:'diferencia',h:'Diferencia',w:11,fmt:'#,##0;-#,##0;"-"'}],rows:dbManifiestos()},{name:'Tarimas',cols:[{k:'empresa',h:'Empresa',w:12},{k:'pedido',h:'Pedido',w:11},{k:'embarque',h:'Embarque',w:12},{k:'pallet',h:'Pallet',w:8,al:'center'},{k:'marca',h:'Marca',w:24},{k:'empaque',h:'Empaque',w:15},{k:'calibre',h:'Calibre',w:10,al:'center'},{k:'cajas',h:'Cajas',w:9,fmt:'#,##0'},{k:'productor',h:'Productor / código',w:26}],rows:dbTarimas()}]});
      await saveFile('Base_de_datos_empaque_'+stamp+'.xlsx',await wbBlob(wb));
    }
  }catch(e){toast('No se pudo generar el archivo')}
}
function mailSummary(){
  const o=cur();if(!o)return;const M=compute(o),lo=leftoverOf(o);
  const body=[o.cod+' · '+o.emb+' · PO '+(o.po||'—')+' · Semana '+(o.semana||'—'),'Estado: '+(o.estado==='completo'?'completo':'en proceso'),'Productores: '+M.rows.length,'Exportación: '+fmt(M.tot.exp)+' cajas (manifiesto '+fmt(M.manT)+')','Segundas: '+fmt(M.tot.seg)+' · Torreón: '+fmt(M.tot.tor)+' · Desecho: '+fmt(M.tot.des)].concat(lo.total?['Sobrante: '+lo.text]:[]).join('\n');
  location.href='mailto:?subject='+encodeURIComponent('Registro de empaque '+o.cod)+'&body='+encodeURIComponent(body);
}
function blobToB64(blob){
  return new Promise(function(res,rej){const r=new FileReader();r.onload=function(){res(String(r.result).split(',')[1]||'')};r.onerror=function(){rej(r.error)};r.readAsDataURL(blob)});
}
/* v8.16 · Descargar de verdad. Antes, en el teléfono «Guardar» abría el menú de compartir y en algunos equipos no dejaba guardar
   sin mandarlo a alguien. Ahora:
   · App de Android: se guarda en Documentos › Empaque Vera Limes (pide el permiso de archivos en Android 10 o anterior) y se puede abrir o compartir después.
   · Navegador (computadora, Android, iPhone): descarga directa a la carpeta de descargas.
   Compartir queda solo en los botones de WhatsApp / Compartir. */
const SAVE_DIR='Empaque Vera Limes';
const MIME_X={xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',pdf:'application/pdf',jpg:'image/jpeg',png:'image/png',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',json:'application/json',csv:'text/csv'};
const isNative=()=>{const C=window.Capacitor;return !!(C&&C.isNativePlatform&&C.isNativePlatform())};
async function nativeSave(name,blob){
  const P=window.Capacitor.Plugins||{},FS=P.Filesystem;if(!FS)throw new Error('fs');
  /* Android 10 o anterior necesita el permiso de almacenamiento; en Android 11 o más nuevo se concede solo */
  try{const st=await FS.checkPermissions();if(st&&st.publicStorage&&st.publicStorage!=='granted'){const r=await FS.requestPermissions();if(!r||r.publicStorage!=='granted')throw Object.assign(new Error('perm'),{perm:true})}}catch(e){if(e&&e.perm)throw e}
  const dot=name.lastIndexOf('.'),base=dot>0?name.slice(0,dot):name,ext=dot>0?name.slice(dot):'';
  let fn=name;for(let i=2;i<200;i++){try{await FS.stat({path:SAVE_DIR+'/'+fn,directory:'DOCUMENTS'});fn=base+' ('+i+')'+ext}catch(e){break}}
  const w=await FS.writeFile({path:SAVE_DIR+'/'+fn,data:await blobToB64(blob),directory:'DOCUMENTS',recursive:true});
  return {uri:w.uri,name:fn};
}
async function saveFile(name,blob,title){
  const ext=String(name).split('.').pop().toLowerCase(),mime=blob.type||MIME_X[ext]||'application/octet-stream';
  try{
    if(isNative()){
      const P=window.Capacitor.Plugins||{};
      try{const r=await nativeSave(name,blob);sheet={kind:'saved',uri:r.uri,name:r.name,mime:mime,title:title||r.name};renderSheet();return}
      catch(e){
        /* sin permiso o sin espacio: como último recurso se abre Compartir, y se dice por qué */
        toast(e&&e.perm?'Sin permiso de archivos. Dalo en Ajustes › Aplicaciones › Empaque Vera Limes › Permisos. Por ahora se abre Compartir.':'No se pudo guardar en Documentos. Por ahora se abre Compartir.');
        const w=await P.Filesystem.writeFile({path:name,data:await blobToB64(blob),directory:'CACHE'});
        await P.Share.share({title:title||name,url:w.uri,dialogTitle:'Guardar o enviar'});return;
      }
    }
    if(window.claude&&typeof window.claude.use==='function'){
      let dl=null;try{dl=await window.claude.use('downloads')}catch(x){}
      if(dl){try{await dl.save({filename:name,data:blob});return}catch(x){if(x&&x.code==='declined')return;throw x}}
    }
    const b=blob.type?blob:new Blob([blob],{type:mime});
    const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.rel='noopener';document.body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},60000);
    toast('Descargado: '+name+'. Búscalo en Descargas.');
  }catch(e){toast('No se pudo descargar el archivo')}
}
function savedHtml(){
  const s=sheet,P=(window.Capacitor&&window.Capacitor.Plugins)||{};
  return `<h3>Archivo guardado</h3><p class="note">Está en el teléfono, en <b>Documentos › ${esc(SAVE_DIR)}</b>:</p><p class="mono savedn">${esc(s.name)}</p><p class="note">Lo encuentras con la app «Archivos» o «Mis archivos». Desde ahí también se puede subir a OneDrive o adjuntar en un correo.</p>
<div class="srow2">${P.FileOpener?'<button class="btn" data-act="savedopen">Abrir</button>':''}${P.Share?'<button class="btn" data-act="savedshare">Compartir</button>':''}<button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
async function savedAct(a){
  const s=sheet;if(!s||s.kind!=='saved')return;const P=(window.Capacitor&&window.Capacitor.Plugins)||{};
  try{
    if(a==='open'&&P.FileOpener)await P.FileOpener.open({filePath:s.uri,contentType:s.mime,openWithDefault:true});
    else if(a==='share'&&P.Share)await P.Share.share({title:s.title,url:s.uri,dialogTitle:'Compartir'});
  }catch(e){toast(a==='open'?'No hay una app para abrir este archivo. Instala Excel, un lector de PDF o la que corresponda.':'No se pudo compartir')}
}

/* ---------- resumen por productor ---------- */
function prodText(o,r){
  const p=r.p;
  return '*'+o.cod+' · '+o.emb+'*'+(o.variante==='1.5'?' (hoja #1.5)':'')+'\nPO '+(o.po||'—')+' · Semana '+(o.semana||'—')+' · '+fmtUS(o.fecha)+'\nProductor: '+(p.nombre||'Sin nombre')+' ('+codeLabel(p.codigo,o.emp)+')\nRecibido: '+fmt(n0(p.k24))+' cajas grandes · '+fmt(n0(p.k18))+' cajas pequeñas · '+fmt(n0(p.kilos))+' kg\nCalibres: '+calUI(o).map(c=>c.l.replace(' ','')+' '+fmt(r.delta[c.k])).join(' | ')+'\nCalidad: '+calidadTxt(o)+'\nTipo de empaque: '+tiposTxt(p)+(r.tipos.length>1?' ('+r.tipos.map(t=>TIPO_L[t]+' '+fmt(r.byT[t].t)).join(' · ')+')':'')+'\nTotal exportación: '+fmt(r.t)+'\nRendimiento: '+(r.rend==null?'—':fmt(r.rend*100,1)+'%')+'\nSegundas: '+fmt(n0(p.seg))+' · Torreón: '+fmt(n0(p.tor))+' · Desecho: '+fmt(n0(p.des))+(p.aportes&&p.aportes.length?'\nAportan: '+p.aportes.map(a=>(a.nombre||'')+' '+fmt(n0(a.n))).join(' · '):'')+(p.nota?'\nNota: '+p.nota:'');
}
/* v8.9.3: la calidad de la hoja (primera o segunda 1.5) va en el resumen */
function calidadTxt(o){return o.variante==='1.5'?'Segunda (1.5)':'Primera'}
/* calibres de la tarjeta, por tipo de empaque: solo los que llevan cajas (todos los que lleve); sin cajas, los del pedido */
function cardRows(o,r){
  const ts=r.tipos&&r.tipos.length?r.tipos:[(r.p.tipos&&r.p.tipos[0])||'RPC'];
  return ts.map(t=>{const d=(r.byT&&r.byT[t]&&r.byT[t].delta)||r.delta;let cs=CAL.filter(c=>n0(d[c.k])!==0);if(!cs.length)cs=calUI(o).filter(c=>c.k!=='ctn').slice(0,6);
    return {t:t,lab:TIPO_L[t]||t,tot:(r.byT&&r.byT[t]&&r.byT[t].t)!=null?r.byT[t].t:r.t,cs:cs.map(c=>({l:c.l,n:n0(d[c.k])}))}});
}
function drawCard(o,r){
  const W=1080,PER=7,TR=cardRows(o,r);
  const CY=574,ROWH=196,H=CY+TR.reduce((t,T)=>t+40+Math.ceil(T.cs.length/PER)*ROWH,0)+386;
  const cv=document.createElement('canvas');cv.width=W;cv.height=H;const x=cv.getContext('2d');
  const D="'Barlow Condensed','Arial Narrow',Arial,sans-serif",B="Barlow,Arial,sans-serif",Mo="'IBM Plex Mono',Menlo,monospace";
  const INK='#14221b',MUT='#566a5d',LINE='#cdd8cf';
  const fit=(t,max,w,s,f)=>{do{x.font=w+' '+s+'px '+f;}while(x.measureText(t).width>max&&--s>28)};
  const E=EMPS[o.emp]||EMPS[emp];
  x.fillStyle='#fbfcf8';x.fillRect(0,0,W,H);
  x.fillStyle=E.card;x.fillRect(0,0,W,176);
  x.fillStyle=E.cardInk;x.textBaseline='alphabetic';x.textAlign='left';
  const tl=o.cod+(o.variante==='1.5'?'  #1.5':'');
  fit(tl,W-96-430,700,68,D);x.fillText(tl,48,80);
  x.font='500 30px '+Mo;x.fillText(o.emb,48,124);
  x.font='500 26px '+Mo;x.fillText('PO '+(o.po||'—')+'  ·  Sem '+(o.semana||'—')+'  ·  '+fmtUS(o.fecha),48,160);
  const RX=W-48-240,LX=RX-14-170;
  x.fillStyle='#ffffff';x.beginPath();x.roundRect?x.roundRect(RX,18,240,140,14):x.rect(RX,18,240,140);x.fill();
  x.textAlign='center';x.fillStyle=MUT;x.font='500 20px '+Mo;x.fillText('RENDIMIENTO',RX+120,50);
  const rtxt=r.rend==null?'—':fmt(r.rend*100,1)+'%';x.fillStyle=INK;fit(rtxt,240-24,700,92,D);x.fillText(rtxt,RX+120,132);
  x.textAlign='left';
  x.fillStyle='#ffffff';x.beginPath();x.roundRect?x.roundRect(LX,18,170,140,14):x.rect(LX,18,170,140);x.fill();
  const lg=logoImg(o.emp);
  if(lg&&lg.complete&&lg.naturalWidth){const k=Math.min(154/lg.naturalWidth,124/lg.naturalHeight);const lw=lg.naturalWidth*k,lh=lg.naturalHeight*k;x.drawImage(lg,LX+(170-lw)/2,18+(140-lh)/2,lw,lh)}
  const p=r.p;
  x.fillStyle=INK;fit(p.nombre||'Sin nombre',W-96,700,92,D);x.fillText(p.nombre||'Sin nombre',48,290);
  x.fillStyle=MUT;x.font='500 34px '+Mo;const cl=codeLabel(p.codigo,o.emp).toUpperCase();x.fillText(cl,48,340);
  /* calidad y tipo de empaque, a la derecha del código */
  const chip=(t,xr,bg,ink)=>{x.font='700 30px '+D;const w=x.measureText(t).width+32;x.fillStyle=bg;x.beginPath();x.roundRect?x.roundRect(xr-w,306,w,46,23):x.rect(xr-w,306,w,46);x.fill();x.fillStyle=ink;x.fillText(t,xr-w+16,340);return xr-w-12};
  let xr=W-48;xr=chip('CALIDAD '+calidadTxt(o).toUpperCase(),xr,o.variante==='1.5'?'#f3e3b5':'#dcebd3',INK);
  chip(TR.map(t=>t.lab).join(' + '),xr,'#e4e9ee',INK);
  const box=(bx,by,bw,bh,lab,val,vs)=>{x.strokeStyle=LINE;x.lineWidth=2;x.strokeRect(bx,by,bw,bh);x.fillStyle=MUT;x.font='500 22px '+Mo;x.fillText(lab,bx+14,by+34);x.fillStyle=INK;fit(val,bw-28,700,vs,D);x.fillText(val,bx+14,by+bh-20)};
  const w3=(W-96-40)/3;
  box(48,380,w3,130,'CAJAS GRANDES',fmt(n0(p.k24)),72);box(48+w3+20,380,w3,130,'CAJAS PEQUEÑAS',fmt(n0(p.k18)),72);box(48+2*(w3+20),380,w3,130,'KILOS',fmt(n0(p.kilos)),72);
  /* cajas por calibre: una fila por tipo de empaque, con todos los calibres que lleve */
  let y=CY;
  TR.forEach(T=>{
    x.fillStyle=MUT;x.font='500 24px '+Mo;x.fillText('CAJAS POR CALIBRE · '+T.lab.toUpperCase()+(TR.length>1?' · '+fmt(T.tot)+' CAJAS':''),48,y);y+=20;
    for(let i0=0;i0<T.cs.length;i0+=PER){
      const cs=T.cs.slice(i0,i0+PER),n=Math.max(cs.length,4),w7=(W-96-(n-1)*10)/n;
      cs.forEach((c,i)=>{const bx=48+i*(w7+10);x.strokeStyle=LINE;x.lineWidth=2;x.strokeRect(bx,y,w7,170);x.fillStyle=MUT;x.font='700 36px '+D;x.fillText(c.l,bx+12,y+48);x.fillStyle=INK;fit(fmt(c.n),w7-20,700,84,D);x.fillText(fmt(c.n),bx+12,y+146)});
      y+=ROWH;
    }
    y+=20;
  });
  const yb=y-40+42;
  x.fillStyle=INK;x.fillRect(48,yb,W-96,4);
  x.fillStyle=MUT;x.font='500 24px '+Mo;x.fillText('TOTAL EXPORTACIÓN',48,yb+54);
  x.fillStyle=INK;x.font='700 150px '+D;x.fillText(fmt(r.t),48,yb+184);
  /* v8.9.3: sin Juguera */
  [['SEGUNDAS',segC(p)],['TORREÓN',p.tor],['DESECHO',p.des]].forEach((q,i)=>box(W-48-(3-i)*170-(2-i)*12,yb+74,170,130,q[0],fmt(n0(q[1])),58));
  x.fillStyle=MUT;x.font='500 26px '+Mo;
  x.fillText(r.campo==null?'Sin kilos capturados':'Cajas campo ≈ '+fmt(r.campo,1)+'  ·  Dif '+(r.dif>0?'+':'')+fmt(r.dif,1),48,yb+284);
  if(p.nota){fit('Nota: '+p.nota,W-96,500,28,B);x.fillStyle=INK;x.fillText('Nota: '+p.nota,48,yb+330)}
  return cv;
}
const WA_SVG='<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>';
/* Enviar a WhatsApp: en la app (APK) y en el teléfono abre la hoja de compartir con el archivo y el texto, donde WhatsApp sale en la lista.
   En computadora baja el archivo y abre WhatsApp con el texto. */
async function shareWA(name,blob,text,title){
  try{
    const C=window.Capacitor;
    if(C&&C.isNativePlatform&&C.isNativePlatform()){
      const P=C.Plugins||{};
      const w=await P.Filesystem.writeFile({path:name,data:await blobToB64(blob),directory:'CACHE'});
      await P.Share.share({title:title||name,text:text||'',url:w.uri,dialogTitle:'Enviar por WhatsApp'});
      return;
    }
    const f=new File([blob],name,{type:blob.type||'application/octet-stream'});
    if(navigator.canShare&&navigator.canShare({files:[f]})){
      try{await navigator.share({files:[f],text:text||'',title:title||name});return}catch(e){if(e&&e.name==='AbortError')return}
    }
    await saveFile(name,blob,title);
    window.open('https://wa.me/?text='+encodeURIComponent(text||title||name),'_blank');
    toast('Adjunta el archivo descargado en el chat de WhatsApp');
  }catch(e){toast('No se pudo abrir WhatsApp')}
}
const logoCache={};
function logoImg(e){
  if(!LOGO[e])return null;
  if(!logoCache[e]){const i=new Image();i.src=LOGO[e];logoCache[e]=i}
  return logoCache[e];
}
async function openShare(pid){
  const o=cur();if(!o)return;const M=compute(o);const r=M.rows.find(x=>x.p.id===pid);if(!r)return;
  try{if(document.fonts&&document.fonts.ready)await document.fonts.ready}catch(e){}
  try{const li=logoImg(o.emp);if(li&&li.decode)await li.decode()}catch(e){}
  const cv=drawCard(o,r);
  sheet={kind:'prod',pid:pid,cv:cv,url:cv.toDataURL('image/png'),text:prodText(o,r),name:(r.p.nombre||'productor')};
  renderSheet();
}

/* ---------- modales ---------- */
function confirmHtml(){
  return `<h3>${esc(sheet.title)}</h3><p style="margin-bottom:6px">${esc(sheet.msg)}</p>${sheet.extra?`<p class="note">${esc(sheet.extra)}</p>`:''}<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn ${sheet.danger?'danger':'primary'}" data-act="${sheet.act}">${esc(sheet.ok)}</button></div>`;
}
function doneHtml(){
  const lo=sheet.lo;
  return `<h3>Listo, empaque para Distribución</h3><p style="margin-bottom:8px">El pedido ${esc(sheet.cod)} ya aparece en Código de Trazabilidad para armar las tarimas.</p>${lo&&lo.total?`<div class="panel info" role="status"><strong>Sobrante disponible para el siguiente pedido</strong><p class="note" style="margin-top:4px">${esc(lo.text)} · ${fmt(lo.total)} cajas</p></div>`:''}<div class="srow2"><button class="btn" data-act="closesheet">Seguir aquí</button><button class="btn primary" data-act="totraz:${esc(sheet.id||'')}">Ir a Código de Trazabilidad</button></div>`;
}
function dbHtml(){
  const n=dbRows().length;
  return `<h3>Descargar Base de Datos</h3><p class="note" style="margin-bottom:10px">Todo el histórico de las dos empresas (${fmt(n)} filas, una por productor y hoja). La columna de calidad indica Primera o Segundas; los calibres llevan solo el número.</p><div class="dbopts"><button class="btn primary" data-act="dbx">Excel decorado (.xlsx)</button><button class="btn" data-act="dbc">CSV</button><button class="btn" data-act="dbj">JSON (con tarimas)</button></div><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
/* ---------- editor de productores (solo administrador) ---------- */
const LS_LOPS='empaque-lista-ops';
function isAdmin(){if(ro)return false;if(!authUser||authUser.rol!=='admin')return false;if(!cfgOK())return true;return !!session&&roleOf(session.access_token)==='admin'}
function listaOps(){try{return JSON.parse(localStorage.getItem(LS_LOPS)||'[]')||[]}catch(e){return []}}
function listaOpsSave(a){try{localStorage.setItem(LS_LOPS,JSON.stringify(a))}catch(e){}}
function listaPersist(){_LN=null;try{localStorage.setItem(LS_LISTA,JSON.stringify(LISTA))}catch(e){}invalidateStats();setSync()}
function prodSet(c,n,k){
  c=Math.floor(+c);n=String(n||'').trim().replace(/\s+/g,' ').toUpperCase();
  if(!(c>0&&c<10000))return 'Escribe un código de 1 a 9999.';
  if(n.length<2)return 'Escribe el nombre del productor.';
  const kk=PCLS_L[k]?k:undefined,i=LISTA.findIndex(x=>x.c===c);
  if(i<0){const x={c:c,n:n};if(kk)x.k=kk;LISTA.push(x)}else{LISTA[i].n=n;if(kk)LISTA[i].k=kk}
  LISTA.sort((a,b)=>a.c-b.c);listaPersist();
  const op={t:'set',c:c,n:n};if(kk)op.k=kk;
  listaOpsSave(listaOps().filter(x=>x.c!==c).concat([op]));setSync();return '';
}
function prodDel(c){
  LISTA=LISTA.filter(x=>x.c!==c);listaPersist();
  listaOpsSave(listaOps().filter(x=>x.c!==c).concat([{t:'del',c:c}]));setSync();
}
async function flushLista(){
  const ops=listaOps();if(!ops.length||ro)return;
  for(const op of ops){
    if(op.t==='set'){
      const body={codigo:op.c,nombre:op.n};if(op.k&&PCLS_SRV!=='no')body.clasificacion=op.k;
      const go=()=>sb('/rest/v1/productores?on_conflict=codigo',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[body]});
      try{await go()}catch(e){if(body.clasificacion&&e&&(e.status===400||e.status===404)){PCLS_SRV='no';delete body.clasificacion;await go()}else throw e}
    }
    else await sb('/rest/v1/productores?codigo=eq.'+op.c,{method:'DELETE'});
  }
  listaOpsSave([]);
}
/* acuerdo de compra del productor: vive en la versión de precios y costos de cada empresa (aplica desde una semana y se congela al cerrar) */
function acuOf(e,c,k){const a=parVerVals(e,k||finDesdeDef()).acu;return (a&&a[c])||{}}
function acuDesc(a){return a.modal==='consig'?'consignación':+a.precioKg>0?money(+a.precioKg,2)+' MXN/kg':''}
function acuTxt(c){const t=['VL','EC'].map(e=>{const d=acuDesc(acuOf(e,c));return d?e+' '+d:''}).filter(Boolean).join(' · ');return t?`<small class="acs">Acuerdo: ${esc(t)}</small>`:''}
function acuFormHtml(c){
  const ops=finDesdeOpts(),k=finDesdeDef();
  const row=e=>{const a=acuOf(e,c,k);return `<div class="acrow"><b>${esc(EMPS[e].name)}</b><label class="fld" for="ac-${e}-m"><span>Modalidad</span><select class="in sel" id="ac-${e}-m"><option value="">Compra por kilo</option><option value="consig"${a.modal==='consig'?' selected':''}>Consignación</option></select></label><label class="fld" for="ac-${e}-pk"><span>Precio acordado (MXN por kg)</span><input class="in" id="ac-${e}-pk" inputmode="decimal" value="${a.precioKg!=null?esc(a.precioKg):''}" placeholder="general ${esc(parVerVals(e,k).kg)}"></label></div>`};
  return `<div class="acform"><div class="sec">Acuerdo de compra</div>${row('VL')}${row('EC')}<label class="fld" for="ac-desde"><span>Aplica desde</span><select class="in sel" id="ac-desde">${ops.map(x=>`<option value="${x}"${x===k?' selected':''}>${esc(wkLab(x))} · ${esc(wkSpan(x))}</option>`).join('')}</select></label><p class="note">Vacío usa el pago general por kilo de Precios y costos. En consignación se le paga lo que vale su fruta menos la comisión. Las semanas cerradas no cambian.</p></div>`;
}
function acuSave(c){
  const k=(document.getElementById('ac-desde')||{}).value||finDesdeDef();
  ['VL','EC'].forEach(e=>{const pe=document.getElementById('ac-'+e+'-pk'),me=document.getElementById('ac-'+e+'-m');if(!pe||!me)return;const pk=num(String(pe.value||'').replace(',','.'));finEdit(e,['acu',String(c),'modal'],me.value||null,k);finEdit(e,['acu',String(c),'precioKg'],pk>0?pk:null,k)});
}
function prodRowsHtml(){
  const max=LISTA.reduce((m,x)=>Math.max(m,x.c),0),q=norm(sheet.q||'').trim().split(/\s+/).filter(Boolean);
  let h='',shown=0;
  for(let c=1;c<=max;c++){
    const x=LISTA.find(y=>y.c===c),n=x?x.n:'';
    if(sheet.only==='vac'&&n)continue;
    if(q.length){const t=norm(codeLabel(c,emp)+' '+c+' '+n);if(!q.every(w=>t.includes(w)))continue}
    shown++;
    if(sheet.edit===c){h+=`<div class="cprow edit"><span class="mono">${codeLabel(c,emp)}</span><input class="in txt" id="pe-n" type="text" autocomplete="off" autocapitalize="characters" value="${esc(n)}" placeholder="Nombre del productor">${clsSelHtml('pe-k',clsOf(c))}<button class="btn sm primary" data-act="psave:${c}">Guardar</button><button class="btn sm" data-act="pcancel">Cancelar</button>${acuFormHtml(c)}</div>`;continue}
    h+=`<div class="cprow${n?'':' vac'}"><span class="mono">${codeLabel(c,emp)}</span><span class="pnm">${n?esc(n)+clsChip(c):'Espacio vacío'}${n?acuTxt(c):''}</span><button class="btn sm" data-act="pedit:${c}">${n?'Editar':'Asignar'}</button>${n?`<button class="btn sm danger" data-act="pdel:${c}">${confirmKey==='pdel:'+c?'Toca otra vez':'Eliminar'}</button>`:''}</div>`;
  }
  return h||'<p class="note">Sin resultados.</p>';
}
function prodsHtml(){
  const max=LISTA.reduce((m,x)=>Math.max(m,x.c),0),vac=[];for(let c=1;c<=max;c++)if(!LISTA.some(x=>x.c===c))vac.push(c);
  const pend=listaOps().length;
  return `<h3>Productores</h3><p class="note" style="margin-bottom:8px">${LISTA.length} con código · ${vac.length} ${vac.length===1?'espacio vacío':'espacios vacíos'}${pend?' · '+pend+' cambios por enviar (se envían al sincronizar)':''}.</p>
<div class="padd"><input class="in" id="pn-c" type="text" inputmode="numeric" pattern="[0-9]*" data-digits="1" placeholder="Código" value="${vac[0]||max+1}" aria-label="Código nuevo"><input class="in txt" id="pn-n" type="text" autocomplete="off" autocapitalize="characters" placeholder="Nombre del productor" aria-label="Nombre del productor nuevo"><select class="in sel" id="pn-k" aria-label="Clasificación del productor nuevo">${PCLS.map(x=>`<option value="${x[0]}">${x[1]}</option>`).join('')}</select><button class="btn primary sm" data-act="padd">Agregar</button></div>${sheet.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.err)}</p>`:''}
<label class="fld" for="pq" style="margin-top:8px"><span>Buscar por nombre o código</span><input class="in txt" id="pq" type="text" autocomplete="off" data-psq="1" value="${esc(sheet.q||'')}"></label>
<div class="seg" role="group" aria-label="Filtro" style="margin:8px 0"><button data-act="pfil:all" aria-pressed="${sheet.only!=='vac'}">Todos</button><button data-act="pfil:vac" aria-pressed="${sheet.only==='vac'}">Vacíos</button></div>
<div id="plist" class="plist">${prodRowsHtml()}</div><div class="srow2"><button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
const REGSPEC={
  trailers:{t:'Trailers',one:'trailer',f:[['n','Número económico','Núm. económico'],['placas','Placas del tractor','Placas del tractor'],['transporte','Transportista','Transportista','transp']],vac:'Aún no hay trailers.',uso:'Trazabilidad: Trailer y Placas del tractor · Manifiesto: Trailer (núm. económico) y Placas del tractor.'},
  cajas:{t:'Termos',one:'termo',f:[['n','Termo (# caja)','Número del termo'],['placas','Placas del termo','Placas del termo'],['transporte','Transportista','Transportista','transp']],vac:'Aún no hay termos.',uso:'Registro: Contenedor o termo · Trazabilidad: Termo (# caja) y Placas del termo · Manifiesto: Placas del termo.'},
  conductores:{t:'Conductores',one:'conductor',f:[['n','Nombre','Nombre del conductor'],['tel','Teléfono','Teléfono'],['placas','Placas del tractor','Placas del tractor'],['transporte','Transportista','Transportista','transp']],vac:'Aún no hay conductores.',uso:'Trazabilidad: Conductor · Manifiesto: Conductor y Placas del tractor.'},
  transportistas:{t:'Transportistas',one:'transportista',f:[['n','Nombre','Nombre del transportista'],['tel','Teléfono','Teléfono'],['caat','Código CAAT','Código CAAT'],['alpha','Código ALPHA','Código ALPHA']],vac:'Aún no hay transportistas.',uso:'Registro: Naviera o transportista · Trazabilidad: Transportista y su teléfono · Manifiesto: Transportista, CAAT y ALPHA.'},
  vendedores:{t:'Vendedores',one:'vendedor',f:[['n','Nombre','Nombre del vendedor'],['tel','Teléfono','Teléfono']],vac:'Aún no hay vendedores.',uso:'Trazabilidad: Vendedor y su teléfono · Packing List: Vendedor y Teléfono del vendedor.'},
  clientes:{t:'Clientes',one:'cliente',f:[['n','Nombre','Nombre del cliente'],['destino','País y puerto de destino','Destino'],['incoterm','INCOTERM','FOB, CIF…'],['diasPago','Días de pago','Días de pago']],vac:'Aún no hay clientes.',uso:'Registro: Cliente, destino, INCOTERM y días de pago · Trazabilidad: Cliente · Manifiesto: Compañía · Packing List: Cliente.'}
};
const LG={rt:null,q:'',edit:null,err:''};
const PV={q:'',only:'all',cls:'all'};
function regS(){return sheet&&sheet.kind==='regs'?sheet:(view==='log'&&LG.rt?LG:null)}
function regRefresh(S){if(S===LG)render();else renderSheet()}
function regLabel(sp,f,i){return `<label class="fld" for="${i[0]}${i[1]}"><span>${esc(f[1])}</span><input class="in txt" id="${i[0]}${i[1]}" type="${f[0]==='tel'?'tel':'text'}" autocomplete="off" autocapitalize="${f[0]==='tel'?'off':'characters'}" placeholder="${esc(f[2])}"${f[3]==='transp'?' list="rdl-t"':''}${i[2]!=null?` value="${esc(i[2])}"`:''}></label>`}
function regsRowsHtml(S){
  S=S||sheet;const sp=REGSPEC[S.rt],L=REG[S.rt],q=norm(S.q||'').trim().split(/\s+/).filter(Boolean),adm=canCat();
  const rows=L.filter(x=>!q.length||q.every(w=>norm(sp.f.map(f=>x[f[0]]||'').join(' ')).includes(w)));
  if(!rows.length)return `<p class="note">${L.length?'Sin resultados.':sp.vac}</p>`;
  return rows.map(x=>{
    if(S.edit===x.id)return `<div class="rrow edit">${sp.f.map((f,i)=>regLabel(sp,f,['re-',i,x[f[0]]||''])).join('')}<div class="rbt"><button class="btn sm primary" data-act="rsave:${x.id}">Guardar</button><button class="btn sm" data-act="rcancel">Cancelar</button></div></div>`;
    const sub=sp.f.slice(1).map(f=>x[f[0]]?`${f[1]}: ${x[f[0]]}`:'').filter(Boolean).join(' · ');
    return `<div class="rrow"><div class="rtx"><strong>${esc(x[sp.f[0][0]]||'—')}</strong><small>${esc(sub||'sin más datos')}</small></div>${adm?`<div class="rbt"><button class="btn sm" data-act="redit:${x.id}">Editar</button><button class="btn sm danger" data-act="rdel:${x.id}">${confirmKey==='rdel:'+x.id?'Toca otra vez':'Eliminar'}</button></div>`:''}</div>`;
  }).join('');
}
function regsAddHtml(S){
  const sp=REGSPEC[S.rt];
  return `<div class="radd">${sp.f.map((f,i)=>regLabel(sp,f,['rn-',i,null])).join('')}<button class="btn primary sm" data-act="radd">Agregar</button></div><datalist id="rdl-t">${catList('transporte').map(v=>`<option value="${esc(v)}"></option>`).join('')}</datalist>${S.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(S.err)}</p>`:''}`;
}
function regsHtml(){
  const sp=REGSPEC[sheet.rt];
  const tabs=Object.keys(REGSPEC).map(k=>`<button data-act="rtab:${k}" aria-pressed="${sheet.rt===k}">${REGSPEC[k].t}</button>`).join('');
  return `<h3>Control Logístico</h3><div class="seg seg6" role="group" aria-label="Lista">${tabs}</div>
<p class="note" style="margin:8px 0">${REG[sheet.rt].length} registrados. ${esc(sp.uso)}</p>
${regsAddHtml(sheet)}
<label class="fld" for="rq" style="margin-top:8px"><span>Buscar</span><input class="in txt" id="rq" type="text" autocomplete="off" data-rsq="1" value="${esc(sheet.q||'')}"></label>
<div id="rlist" class="plist">${regsRowsHtml(sheet)}</div><div class="srow2"><button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
function regVals(prefix,S){S=S||sheet;const sp=REGSPEC[S.rt];return sp.f.map((f,i)=>{let v=String((document.getElementById(prefix+i)||{}).value||'').trim().replace(/\s+/g,' ');return f[0]==='tel'?v:v.toUpperCase()})}
function regSave(id,S){
  S=S||sheet;const sp=REGSPEC[S.rt],v=regVals(id?'re-':'rn-',S);
  if(v[0].length<1)return 'Escribe '+(S.rt==='cajas'?'el número del termo.':S.rt==='trailers'?'el número económico.':'el nombre.');
  const L=REG[S.rt],ti=sp.f.findIndex(f=>f[3]==='transp');
  if(id){const x=L.find(y=>y.id===id);if(!x)return '';
    if(L.some(y=>y.id!==id&&norm(y.n).trim()===norm(v[0]).trim()&&(ti<0||norm(y.transporte||'')===norm(v[ti]))))return 'Ya existe «'+v[0]+'».';
    sp.f.forEach((f,i)=>{x[f[0]]=v[i]})}
  else{
    if(L.some(y=>norm(y.n).trim()===norm(v[0]).trim()&&(ti<0||norm(y.transporte||'')===norm(v[ti]))))return 'Ya existe «'+v[0]+'». Usa Editar para cambiarlo.';
    const x={id:uid()};sp.f.forEach((f,i)=>{x[f[0]]=v[i]});L.push(x);
  }
  L.sort((a,b)=>String(a.n).localeCompare(String(b.n),'es',{numeric:true}));
  saveReg(true);return '';
}
async function syncReg(){
  try{
    if(REG.dirty&&!ro&&canCat()){
      await sb('/rest/v1/catalogos?on_conflict=clave',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{clave:'registros',updated_at:REG.ts,data:{vendedores:REG.vendedores,conductores:REG.conductores,cajas:REG.cajas,transportistas:REG.transportistas,trailers:REG.trailers,clientes:REG.clientes}}]});
      REG.dirty=false;saveReg(false);
    }
    const r=await sb('/rest/v1/catalogos?select=updated_at,data&clave=eq.registros');
    if(r&&r[0]&&r[0].data&&Number(r[0].updated_at)>(REG.ts||0)&&!REG.dirty){
      const d=r[0].data;remoteN++;REG.vendedores=d.vendedores||[];REG.conductores=d.conductores||[];REG.cajas=d.cajas||[];if(Array.isArray(d.transportistas))REG.transportistas=d.transportistas;if(Array.isArray(d.trailers))REG.trailers=d.trailers;if(Array.isArray(d.clientes))REG.clientes=d.clientes;REG.ts=Number(r[0].updated_at);saveReg(false);
    }
  }catch(e){}
}
let shOutT=0;
function renderSheet(){
  clearTimeout(shOutT);
  if(!sheet){const sc=$sh.querySelector('.scrim:not(.sout)');if(!sc||matchMedia('(prefers-reduced-motion: reduce)').matches){$sh.innerHTML='';return}
    /* v8.11: la ventana sale con ease-out y luego se quita */
    sc.classList.remove('sin');sc.classList.add('sout');const sh0=sc.querySelector('.sheet');if(sh0){sh0.removeAttribute('data-kind');sh0.setAttribute('aria-hidden','true')}
    shOutT=setTimeout(()=>{if(!sheet)$sh.innerHTML=''},230);return}
  let inner='';
  if(sheet.kind==='new')inner=newSheetHtml();
  else if(sheet.kind==='add'){inner=`<h3>${sheet.mode==='inv'?'Entrada de fruta · productor':'Agregar productor'}</h3><label class="fld" for="s-q"><span>Nombre o número</span><input class="in txt" id="s-q" type="text" autocomplete="off" data-search="1" value="${esc(sheet.q||'')}"></label><div id="results">${resultsHtml(sheet.q||'')}</div><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`}
  else if(sheet.kind==='prod'){inner=`<h3>Resumen del productor</h3><img src="${sheet.url}" alt="Resumen de ${esc(sheet.name)}"><p class="note" style="margin-top:8px">También puedes mantener presionada la imagen para guardarla.</p><div class="srow2"><button class="btn wa" data-act="wapng">${WA_SVG}<span>WhatsApp</span></button><button class="btn primary" data-act="savepng">Guardar imagen</button></div><div class="srow2"><button class="btn" data-act="savejpg">JPG</button><button class="btn" data-act="dx:pdfimg">PDF</button><button class="btn" data-act="copysum">Copiar texto</button><button class="btn" data-act="closesheet">Cerrar</button></div>`}
  else if(sheet.kind==='login'){inner=loginHtml()}
  else if(sheet.kind==='etq'){inner=etqHtml()}
  else if(sheet.kind==='usr'){inner=usrHtml()}
  else if(sheet.kind==='manre'){const x=orders.find(y=>y.id===sheet.oid);inner=`<h3>Reabrir manifiesto · ${esc(x?mainOf(x).cod:'')}</h3><p class="note">Al reabrirlo, las tarimas se pueden corregir otra vez y sus cajas vuelven a ofrecerse para reempaque. El motivo queda en el Registro de cambios.</p><label class="fld" for="mr-mot"><span>Motivo</span><textarea class="in txt" id="mr-mot" rows="3" placeholder="Por ejemplo: faltó una tarima de 150, error en el conteo"></textarea></label><div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="manreok">Reabrir</button></div>`}
  else if(sheet.kind==='out'){inner=outHtml()}
  else if(sheet.kind==='fin'){inner=finSetHtml()}
  else if(sheet.kind==='per'){inner=perHtml()}
  else if(sheet.kind==='wkc'){inner=wkcHtml()}
  else if(sheet.kind==='wkdone'){inner=wkdoneHtml()}
  else if(sheet.kind==='pesos'){inner=pesosHtml()}
  else if(sheet.kind==='kgemp'){inner=kgempHtml()}
  else if(sheet.kind==='pend'){inner=pendHtml()}
  else if(sheet.kind==='legal'){inner=legalHtml()}
  else if(sheet.kind==='saved'){inner=savedHtml()}
  else if(sheet.kind==='pentadd'){inner=pentAddHtml()}
  else if(sheet.kind==='dec'){inner=decHtml()}
  else if(sheet.kind==='seg2'){inner=seg2Html()}
  else if(sheet.kind==='pnext'){inner=pnextHtml()}
  else if(sheet.kind==='grandes'){inner=grandesHtml()}
  else if(sheet.kind==='recsem'){inner=recsemHtml()}
  else if(sheet.kind==='iwk'){inner=iwkHtml()}
  else if(sheet.kind==='pback'){inner=pbackHtml()}
  else if(sheet.kind==='pisomv'){inner=pisoMvHtml()}
  else if(sheet.kind==='sobim'){inner=sobimHtml()}
  else if(sheet.kind==='rmp'){inner=rmpHtml()}
  else if(sheet.kind==='syncinfo'){inner=syncInfoHtml()}
  else if(sheet.kind==='confirm'){inner=confirmHtml()}
  else if(sheet.kind==='log'){inner=logHtml()}
  else if(sheet.kind==='mov'){inner=movHtml()}
  else if(sheet.kind==='done'){inner=doneHtml()}
  else if(sheet.kind==='db'){inner=dbHtml()}
  else if(sheet.kind==='prods'){inner=prodsHtml()}
  else if(sheet.kind==='prodone'){inner=prodOneHtml()}
  else if(sheet.kind==='regs'){inner=regsHtml()}
  else if(sheet.kind==='users'){inner=usersHtml()}
  else if(sheet.kind==='acct'){inner=acctHtml()}
  else if(sheet.kind==='bio'){inner=bioHtml()}
  else if(sheet.kind==='copy'){inner=`<h3>Copiar ${esc(sheet.label||'texto')}</h3><p class="note" style="margin-bottom:8px">Tu navegador no dejó copiar solo. Selecciona el texto, cópialo y pégalo.</p><textarea id="copyta" readonly>${esc(sheet.text)}</textarea><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`}
  const old=$sh.querySelector('.scrim:not(.sout) .sheet'),keep=old&&old.dataset.kind===sheet.kind?old.scrollTop:0;
  $sh.innerHTML=`<div class="scrim${old?'':' sin'}"><div class="sheet${sheet.kind==='per'||sheet.kind==='grandes'?' wide':''}" data-kind="${sheet.kind}" role="dialog" aria-modal="true">${inner}</div></div>`;
  if(keep){const n=$sh.querySelector('.sheet');if(n)n.scrollTop=keep}
  if(sheet.kind==='fin'){const c=document.getElementById('fcar');if(c)fcarGo(c.dataset.start,false)}
  if(sheet.kind==='add'){const q=document.getElementById('s-q');if(q)q.focus()}
  if(sheet.kind==='copy'){const t=document.getElementById('copyta');if(t){t.focus();t.select()}}
  if(sheet.kind==='login'){const q=document.getElementById('lf-email');if(q&&!q.value)q.focus()}
}
function closeSheet(){if(sheet&&sheet.kind==='fin'&&history.state&&history.state.finSheet){history.back();return}sheet=null;renderSheet()}
/* el botón de regresar del teléfono cierra Precios y costos en lugar de salir de la pantalla */
window.addEventListener('popstate',()=>{if(sheet&&sheet.kind==='fin'){sheet=null;renderSheet()}});
async function copyText(text,label){
  try{await navigator.clipboard.writeText(text);toast((label||'Texto')+' copiado')}
  catch(e){sheet={kind:'copy',text:text,label:label};renderSheet()}
}

/* ---------- acciones ---------- */
function addProd(nombre,codigo,nota){
  const o=cur();if(!o||ro)return;const p=newProd(nombre,codigo,nota);const iv=invFill(p);o.productores.push(p);touch(o);if(iv)pesSync();logAdd({k:'add',ctx:ctxOf(o),lab:'Productor '+(nombre||'sin nombre')+(iv?' (cargado de Entrada de Fruta)':'')});
  if(iv)setTimeout(()=>toast('Se cargó la fruta de Entrada de Fruta; puedes ajustarla'),400);
  openP=p.id;tab='captura';scrollToP=p.id;sheet=null;renderSheet();render();
  setTimeout(()=>{const el=document.getElementById('f-p-'+p.id+'-k24');if(el)el.focus({preventScroll:true})},350);
}
function swap(pid,dir){
  const o=cur();if(!o)return;const i=o.productores.findIndex(p=>p.id===pid),j=i+dir;
  if(i<0||j<0||j>=o.productores.length)return;
  const t=o.productores[i];o.productores[i]=o.productores[j];o.productores[j]=t;touch(o);scrollToP=pid;render();
}
function armConfirm(key){confirmKey=key;setTimeout(()=>{if(confirmKey===key){confirmKey=null;if(!sheet)softRender()}},4000)}
/* ---------- varios tipos de empaque por productor: carrusel de conteos ---------- */
const pageOf={};
function prodOf(pid){const o=cur();return o&&o.productores.find(x=>x.id===pid)}
function addTipo(pid){
  const o=cur(),p=prodOf(pid);if(!o||!p||ro)return;const ts=tiposOf(p),nx=TIPOS.map(x=>x[0]).find(t=>ts.indexOf(t)<0);if(!nx)return;
  ts.push(nx);p.tipos=ts;p.tipo=ts[0];pageOf[pid]=ts.length-1;touch(o);render();toast('Se agregó '+TIPO_L[nx]+': elige el tipo y captura su conteo');
}
function setTipo(pid,i,val){
  const o=cur(),p=prodOf(pid);if(!o||!p||ro)return;const ts=tiposOf(p),old=ts[i];
  if(val===''){if(i>0){render();sheet={kind:'confirm',title:'Quitar tipo de empaque',msg:'¿Quitar '+TIPO_L[old]+' de '+(p.nombre||'este productor')+'?',extra:'Se borra el conteo de ese tipo para este productor.',ok:'Quitar',act:'dotrm',danger:true,pid:pid,ti:i};renderSheet()}return}
  if(val===old||ts.indexOf(val)>=0)return;
  logAdd({k:'note',ctx:ctxOf(o),lab:(p.nombre||'Productor')+' · tipo de empaque '+(i+1),o:TIPO_L[old],n:TIPO_L[val]});
  ts[i]=val;
  if(i>0&&p.accX&&p.accX[old]){p.accX[val]=p.accX[old];delete p.accX[old]}
  if(p.accx){const nx={};Object.keys(p.accx).forEach(k=>{nx[k.indexOf(old+':')===0?val+k.slice(old.length):k]=p.accx[k]});p.accx=nx}
  p.tipos=ts;p.tipo=ts[0];pageOf[pid]=i;touch(o);render();
}
function rmTipo(pid,i){
  const o=cur(),p=prodOf(pid);sheet=null;renderSheet();if(!o||!p||ro||!(i>0))return;const ts=tiposOf(p),old=ts[i];if(!old)return;
  logAdd({k:'note',ctx:ctxOf(o),lab:(p.nombre||'Productor')+' · quitó el tipo de empaque',o:TIPO_L[old],n:''});
  ts.splice(i,1);if(p.accX)delete p.accX[old];
  if(p.accx)Object.keys(p.accx).forEach(k=>{if(k.indexOf(old+':')===0)delete p.accx[k]});
  p.tipos=ts;p.tipo=ts[0];pageOf[pid]=Math.max(0,i-1);touch(o);render();toast('Se quitó '+TIPO_L[old]);
}
function cardPage(cs,i,smooth){
  const w=cs.clientWidth;if(!w)return;cs.scrollTo({left:i*(w+12),behavior:smooth?'smooth':'auto'});
}
function markPage(cs){
  const w=cs.clientWidth;if(!w)return;const n=cs.children.length,i=Math.max(0,Math.min(n-1,Math.round(cs.scrollLeft/(w+12)))),pid=cs.dataset.cs;
  pageOf[pid]=i;const pc=document.getElementById('pc-'+pid);if(!pc)return;
  pc.querySelectorAll('[data-dot]').forEach(d=>d.classList.toggle('on',+d.dataset.dot===i));
  pc.querySelectorAll('select[data-tipo]').forEach(s=>s.classList.toggle('on',+s.dataset.tipo.split(':')[1]===i));
}
function goto(v){view=v;curId=null;showHdr=false;sheet=null;renderSheet();render();window.scrollTo(0,0)}
function onClick(e){
  const t=e.target;
  if(t.classList&&t.classList.contains('scrim')){if(sheet&&(sheet.kind==='new'||sheet.kind==='fin'))return; /* Precios y costos: solo con Cerrar o regresar */ /* el nuevo pedido solo se cierra con Cancelar */closeSheet();return}
  const el=t.closest('[data-act]');if(!el||el.disabled)return;
  const parts=el.dataset.act.split(':'),act=parts[0],arg=parts[1];
  const o=cur();
  switch(act){
    case 'menu':goto('menu');break;
    case 'orders':case 'home':goto('orders');break;
    case 'traz':goto('traz');break;
    case 'inv':goto('inv');break;
    case 'fin':if(!canFin())break;if(!statsF.emp)statsF.emp=emp;goto('fin');break;
    case 'ftab':statsF.ftab=arg;saveStatsF();render();window.scrollTo(0,0);break;
    case 'rexgo':rexGo(arg);break;
    case 'xlv':xlvAct(arg,parts[2],parts[3]);break;
    case 'palopen':palOpen=palOpen===arg?null:arg;render();setTimeout(()=>{const el=document.getElementById('pal-'+arg);if(el)el.scrollIntoView({block:'nearest',behavior:'smooth'});const b=el&&el.querySelector('[data-act="palopen:'+arg+'"]');if(b)b.focus({preventScroll:true})},60);break;
    case 'rexall':REX.prods=arg==='1'?[]:['__ninguno__'];saveRex();render();break;
    case 'femp':statsF.emp=arg;invalidateStats();saveStatsF();render();break;
    case 'cxall':statsF.cxAll=!statsF.cxAll;render();break;
    case 'cxg':statsF.cxG=arg==='grp'?'grp':'cta';saveStatsF();render();break;
    case 'factsave':factSave();break;
    case 'realsave':realSave();break;
    case 'esort':statsF.esort=arg;saveStatsF();render();break;
    case 'embx':exportEmb();break;
    case 'csub':statsF.csub=arg;saveStatsF();render();break;
    case 'cate':statsF.cate=arg==='EC'?'EC':'VL';render();break;
    case 'prall':statsF.prAll=!statsF.prAll;render();break;
    case 'polmore':statsF.polN=(statsF.polN||40)+40;render();break;
    case 'ctbx':exportCtb(arg);break;
    case 'ctbreg':if(isAdmin()){ctbSet('reg|'+uid(),'nombre','Régimen nuevo','Régimen fiscal agregado');render()}break;
    case 'ctbregx':if(isAdmin()){ctbSet('reg|'+parts.slice(1).join(':'),'borrado',true,'Régimen fiscal quitado');render()}break;
    case 'pmode':statsF.pmode=arg==='M'?'M':'S';statsF.ppk='';saveStatsF();render();break;
    case 'cxpt':statsF.cxpT=arg;render();break;
    case 'logpar':confirmKey=null;sheet={kind:'log',scope:'par'};renderSheet();break;
    case 'cxx':exportCuentas();break;
    case 'movopen':{const q=parts.slice(1),S=q.shift();sheet={kind:'mov',S:S==='pag'?'pag':'cob',ref:q.join(':')};renderSheet();break}
    case 'movsave':movSave();break;
    case 'movanu':if(sheet&&sheet.kind==='mov'){sheet.anul=parts.slice(1).join(':');sheet.aErr='';renderSheet()}break;
    case 'movanuno':if(sheet){sheet.anul=null;renderSheet()}break;
    case 'movanugo':movAnular(parts.slice(1).join(':'));break;
    case 'stats':if(!canStats()){toast('Estadísticas no está disponible para el jefe de empaque');break}if(!statsF.emp)statsF.emp=emp;goto('stats');break;
    case 'emp':setEmp(arg);render();break;
    case 'skin':setSkin(arg);render();break;
    case 'legal':sheet={kind:'legal',doc:arg||'priv'};renderSheet();{const sc=document.querySelector('#sheetRoot .sheet');if(sc)sc.scrollTop=0}break;
    case 'lgacc':lg.acc=!!el.checked;if(lg.acc&&/acepta/.test(lg.err||'')){lg.err='';const al=$app.querySelector('[role="alert"]');if(al)al.remove()}break;
    case 'oemp':if(o&&!ro)changeEmp(o,o.emp==='EC'?'VL':'EC');break;
    case 'nemp':{if(!sheet||sheet.kind!=='new'||!sheet.d)break;const d=sheet.d,ne=(d.emp||emp)==='EC'?'VL':'EC',y=String(d.fecha||'').slice(0,4);d.emp=ne;d.nEC=nextCons(ne,y);d.nPed=nextPed(ne,y,d.semana);setEmp(ne);render();renderSheet();break}
    case 'logopen':confirmKey=null;sheet={kind:'log'};renderSheet();break;
    case 'lgsc':if(sheet){sheet.scope=arg;renderSheet()}break;
    case 'lgrv':revertLog(arg,false);break;
    case 'lgrvf':revertLog(arg,true);break;
    case 'lgno':confirmKey=null;renderSheet();break;
    case 'lgclean':if(confirmKey!=='lgclean'){confirmKey='lgclean';renderSheet()}else cleanLog();break;
    case 'listmore':listAll=!listAll;render();if(!listAll)window.scrollTo(0,0);break;
    case 'new':if(ro)break;sheet={kind:'new',d:newDefaults()};renderSheet();break;
    case 'example':loadExample();break;
    case 'open':{curId=arg;view='order';tab='captura';openP=null;showHdr=false;sheet=null;renderSheet();render();window.scrollTo(0,0);const x=cur();if(x&&x.variante==='1.5'&&x.estado!=='completo'&&!(x.productores||[]).length)openSeg2(x);else if(x&&x.variante==='1'&&x.estado!=='completo'&&!ro)openSobIm(x);break}
    /* v8.17: las tarimas ya no se arman solas: el jefe de empaque las arma en Código de Trazabilidad y Registro de Empaque las compara */
    case 'topal':case 'totraz':curId=arg;view='trazo';palOpen=null;sheet=null;renderSheet();render();window.scrollTo(0,0);break;
    case 'ordenpal':{const x=cur();if(!x||ro)break;sheet={kind:'confirm',title:'Acomodar tarimas como el empaque',msg:'Las cajas de primera ya registradas que todavía no están en tarimas se acomodan en el orden en que entraron los productores: primero completan las tarimas de su presentación y calibre, y si no caben se abren tarimas nuevas. Después se ordenan todas las tarimas. No se agrega ninguna caja que no esté en el Registro de empaque.',extra:'Las tarimas que ya armaste no pierden cajas. Si no quieres acomodarlas, toca Cancelar.',ok:'Acomodar y ordenar',act:'ordenpalok'};renderSheet()}break;
    case 'ordenpalok':{const x=cur();sheet=null;renderSheet();if(x){const n=autoPal(x,true);ordenarTarimas(x,true);toast(n?fmt(n)+' cajas acomodadas en tarimas y tarimas ordenadas como el empaque':'No había cajas de primera por acomodar; las tarimas quedaron ordenadas como el empaque');const t=ensureTraz(mainOf(x));if(t.ordLibre){delete t.ordLibre;touch(mainOf(x))}}render()}break;
    case 'ordlibre':{const x=cur();if(!x||ro)break;const m=mainOf(x),t=ensureTraz(m);if(arg==='1')t.ordLibre=1;else delete t.ordLibre;touch(m);render();if(arg==='1')toast('Listo: puedes ordenar las tarimas a tu manera')}break;
    case 'palseg':{const x=cur();if(x)palAddSeg(x,arg)}break;
    case 'tab':tab=arg;render();break;
    case 'mtipo':if(o){manSel[o.id]=arg;render();const f=$app.querySelector('[data-bind^="m.'+arg+'."]');if(f&&!ro)try{f.focus({preventScroll:true})}catch(x){}}break;
    case 'openr':curId=arg;view='order';tab='resumen';if(parts[2])manSel[arg]=parts[2];openP=null;sheet=null;renderSheet();render();break;
    case 'dx':docAct(arg,parts[2]);break;
    case 'docback':view=docFrom==='trazo'?'trazo':docFrom==='dvt'?'dvt':'order';render();window.scrollTo(0,0);break;
    case 'hdr':showHdr=!showHdr;render();break;
    case 'hdrz':trazHdr=!trazHdr;render();break;
    case 'p':openP=openP===arg?null:arg;scrollToP=openP;render();break;
    case 'addp':sheet={kind:'add',q:'',items:[]};renderSheet();break;
    case 'addleft':addLeftover();break;
    case 'palnext':palNextSheet(arg);break;
    case 'palgo':palOpen=arg;render();setTimeout(()=>{const el=document.getElementById('pal-'+arg);if(el)el.scrollIntoView({block:'center',behavior:'smooth'})},60);break;
    case 'pnextok':palNextDo();break;
    case 'grandes':sheet={kind:'grandes'};renderSheet();break;
    case 'recsem':{const ks=recSemKeys(),wk=ks.find(k=>recSemData(k).n>0)||ks[0];sheet={kind:'recsem',wk:wk,all:false};renderSheet();break}
    case 'recsemgo':if(sheet&&sheet.kind==='recsem')recSemOut();break;
    case 'palback':palBackSheet(arg);break;
    case 'pisomv':pisoMvSheet(trazOrder());break;
    case 'pisomvok':pisoMvDo();break;
    case 'pisoback':pisoBack(arg,parts[2]);break;
    case 'rmp':openRmp(o);break;
    case 'rmt':if(sheet&&sheet.kind==='rmp'&&TIPO_K.indexOf(arg)>=0){sheet.tipo=arg;sheet.nq={};renderSheet()}break;
    case 'rmpall':if(sheet&&sheet.kind==='rmp'){const x=orders.find(y=>y.id===sheet.oid);if(x)rmpAvail(x).forEach(a=>sheet.sel[a.id]=true);renderSheet()}break;
    case 'rmpnone':if(sheet&&sheet.kind==='rmp'){sheet.sel={};sheet.nq={};renderSheet()}break;
    case 'rmpok':if(sheet&&sheet.kind==='rmp')rmpDo();break;
    case 'rmback':rmpBack(arg,parts[2]);break;
    case 'dv':DV.e=DV.e||emp;goto('dv');break;
    case 'conteo':goto('conteo');break;
    case 'usersadm':usrOpen();break;
    case 'usrload':if(sheet&&sheet.kind==='usr'){sheet.list=null;renderSheet();usrLoad()}break;
    case 'usradd':if(sheet&&sheet.kind==='usr'){sheet.add=arg==='1';sheet.err='';renderSheet()}break;
    case 'usrnew':if(sheet&&sheet.kind==='usr'&&!sheet.busy)usrNew();break;
    case 'usrblk':if(sheet&&sheet.kind==='usr')usrBlk(arg,false);break;
    case 'usrok':if(sheet&&sheet.kind==='usr')usrBlk(arg,true);break;
    case 'ctq':CT.q=arg==='1.5'?'1.5':'1';render();break;
    case 'ctt':CT.tipo=TIPO_K.indexOf(arg)>=0?arg:'RPC';CT.n={};CT.pal='new';render();break;
    case 'ctsend':contSend();break;
    case 'ctok':contAuth(arg,true);break;
    case 'ctno':contAuth(arg,false);break;
    case 'dvt':dvOpen(arg);break;
    case 'dvback':view='dv';curId=null;render();window.scrollTo(0,0);break;
    case 'dvwk':DV.wk=arg;render();break;
    case 'dvord':DV.ord=arg==='asc'?'asc':'desc';render();break;
    case 'dvemp':DV.e=(DV.e||emp)==='VL'?'EC':'VL';DV.wk=null;setEmp(DV.e);render();break;
    case 'etq':etqOpen(arg);break;
    case 'etqall':if(sheet&&sheet.kind==='etq'){const m=orders.find(x=>x.id===sheet.oid);if(m)etqList(m).forEach(a=>{if(a.code)sheet.sel[a.id]=true});renderSheet()}break;
    case 'etqnone':if(sheet&&sheet.kind==='etq'){sheet.sel={};renderSheet()}break;
    case 'etqgo':if(sheet&&sheet.kind==='etq')etqGo();break;
    case 'mancl':{const x=orders.find(y=>y.id===arg);if(x)manClose(x);break}
    case 'manre':{const x=orders.find(y=>y.id===arg);if(x&&canManClose()){sheet={kind:'manre',oid:x.id,mot:''};renderSheet();const i=document.getElementById('mr-mot');if(i)i.focus()}break}
    case 'manreok':if(sheet&&sheet.kind==='manre'){const x=orders.find(y=>y.id===sheet.oid),v=(document.getElementById('mr-mot')||{}).value;if(x&&manReopen(x,v)){sheet=null;renderSheet();render()}}break;
    case 'pbackok':palBackDo();break;
    case 'sobim':if(!openSobIm(o))toast('No hay sobrantes por importar');break;
    case 'sobimok':{if(!sheet||sheet.kind!=='sobim')break;const x=orders.find(y=>y.id===sheet.oid);const sel=Object.keys(sheet.sel||{}).filter(k=>sheet.sel[k]);if(!sel.length){toast('Elige al menos una tarima');break}const c=sobImport(x,sel);sheet=null;renderSheet();if(x){const r=sobRow(mainOf(x));if(r){openP=r.id;scrollToP=r.id}}tab='captura';render();toast(fmt(c)+' cajas importadas a SOBRANTES');break}
    case 'tadd':addTipo(arg);break;
    case 'dotrm':if(sheet)rmTipo(sheet.pid,sheet.ti);break;
    case 'pick':{const x=sheet&&sheet.items&&sheet.items[+arg];if(x){if(sheet.mode==='inv')addEntrada(x.n,x.c||null);else addProd(x.n,x.c||null)}}break;
    case 'pickfree':{const q=(document.getElementById('s-q')||{}).value||'';if(q.trim()){if(sheet&&sheet.mode==='inv')addEntrada(q.trim().toUpperCase(),null);else addProd(q.trim().toUpperCase(),null)}}break;
    case 'eadd':case 'eopen':case 'edel':case 'etab':case 'isrtdir':case 'epes':case 'pwtab':case 'pwadd':case 'pwdel':case 'invx':case 'pinv':case 'iwk':case 'iwkset':case 'sjug':case 'segx':case 'jgan':invAct(act,arg,parts[2],parts[3]);break;
    case 'segll':case 'segllx':{if(!o||ro)break;const p=o.productores.find(x=>x.id===arg);if(!p)break;const old=p.segLlevo;
      if(act==='segll')p.segLlevo=n0(p.seg);else delete p.segLlevo;
      {const path='p.'+p.id+'.segLlevo';logAdd({k:'edit',ctx:ctxOf(o),path:path,num:true,lab:logLabel({t:'b',b:path},{o:o}),o:sv(old),n:sv(p.segLlevo)})}
      touch(o);render();if(act==='segll')setTimeout(()=>{const el=document.getElementById('f-p-'+p.id+'-segLlevo');if(el){el.focus();el.select&&el.select()}},60);toast(act==='segll'?'Se llevó sus segundas: ya no entran al inventario':'Las segundas vuelven al inventario de Citrilar');break}
    case 'up':swap(arg,-1);break;
    case 'down':swap(arg,1);break;
    case 'delp':{
      /* v8.25.3: un renglón del que ya salió fruta a reempaque, o un REEMPAQUE con operaciones, no se borra: el otro viaje seguiría descontando esas cajas */
      const o0=cur(),p0=o0&&o0.productores.find(p=>p.id===arg);
      if(p0){const out=rmpOutRow(o0.id,p0.id);if(out.length){toast('De este renglón ya se reempacaron cajas a '+[...new Set(out.map(a=>a.to.cod))].join(', ')+'. Primero regresa ese reempaque en su renglón REEMPAQUE');confirmKey=null;render();break}
        if(p0.rmp&&(p0.sobAp||[]).length){toast('Este REEMPAQUE tiene operaciones. Usa «Regresar» en cada una; al quedar vacío el renglón se quita solo');confirmKey=null;render();break}}
      if(confirmKey==='delp:'+arg){const oo=cur();if(oo){const pi=oo.productores.findIndex(p=>p.id===arg),pp=oo.productores[pi];if(pp)logAdd({k:'del',what:'p',ctx:ctxOf(oo),snap:clone(pp),idx:pi,lab:'Productor '+(pp.nombre||'sin nombre')});oo.productores=oo.productores.filter(p=>p.id!==arg);touch(oo);if(openP===arg)openP=null}confirmKey=null;render()}
      else{armConfirm('delp:'+arg);render()}
      break}
      break;
    case 'delsheet':{
      const x=visible().find(y=>y.id===arg);if(!x||ro)break;
      const sib=sheetsOf(x).filter(y=>y.id!==x.id);
      sheet={kind:'confirm',title:'Eliminar la hoja '+x.variante,msg:'¿Eliminar la hoja '+x.variante+' de '+x.cod+'?'+(sib.length?' La otra hoja del pedido se queda como está'+(x.traz&&(x.traz.tarimas||[]).length?' y las tarimas de Código de Trazabilidad pasan a ella.':'.'):' Es la única hoja del pedido.'),extra:'No se borra de la base de datos: queda marcada como eliminada.',ok:'Eliminar hoja',act:'dodelsheet',danger:true,sid:x.id};renderSheet();break}
    case 'dodelsheet':{
      const x=sheet&&visible().find(y=>y.id===sheet.sid);
      if(x&&!ro){logAdd({k:'del',what:'sheet',ids:[x.id],ctx:ctxOf(x),lab:'Hoja '+x.variante+' del pedido '+x.cod});removeSheet(x);invalidateStats();sheet=null;renderSheet();if(curId===x.id||view==='order'||view==='trazo'){curId=null;view='orders'}render();toast('Hoja '+x.variante+' eliminada')}
      break}
    case 'v1':{
      if(!o||ro||hasMain(o))break;
      const n=newOrder({emp:o.emp,anio:o.anio,cons:o.cons,cod:o.cod,emb:o.emb,po:o.po,fecha:o.fecha,semana:o.semana,customer:o.customer,domestic:o.domestic,factura:o.factura,variante:'1'});
      n.kgCaja=o.kgCaja;n.estado=o.estado;orders.push(n);touch(n);moveTraz(o,n);curId=n.id;view='order';tab='captura';openP=null;render();window.scrollTo(0,0);toast('Hoja 1 creada');
    }break;
    case 'plus':case 'minus':{
      const el=document.getElementById(arg);if(!el||ro)break;
      const op=act==='plus'?'+':'-';
      let v=String(el.value||'').trim();
      if(document.activeElement!==el){const ref=accRef(el),x=ref&&ref.pr.accx&&ref.pr.accx[ref.xk];if(x&&sumExpr(x)===sumExpr(v))v=x}
      v=/[+\-−–]$/.test(v)?v.slice(0,-1)+op:v+op;
      el.value=v;try{el.focus();el.setSelectionRange(v.length,v.length)}catch(x){}
    }break;
    case 'delorder':
      if(!o||ro)break;
      sheet={kind:'confirm',title:'Eliminar este pedido',msg:'¿Eliminar el pedido '+o.cod+'?'+(sheetsOf(o).length>1?' Se elimina también su hoja 1.5.':''),extra:'Esta acción no se puede deshacer desde la app.',ok:'Eliminar',act:'dodel',danger:true};renderSheet();break;
    case 'dodel':
      if(o&&!ro){const gone=sheetsOf(o);logAdd({k:'del',what:'sheet',ids:gone.map(x=>x.id),ctx:ctxOf(o),lab:'Pedido '+o.cod+(gone.length>1?' (hojas '+gone.map(x=>x.variante).join(' y ')+')':'')});gone.forEach(x=>{x.deleted=true;touch(x)});invalidateStats();sheet=null;renderSheet();curId=null;view='orders';render();toast('Pedido eliminado')}
      break;
    case 'complete':
      if(o&&canComplete(o)){sheet={kind:'confirm',title:'Completar registro',msg:'¿Completar el registro de '+o.cod+'? Pasará a Código de Trazabilidad para armar las tarimas.',extra:'Puedes reabrirlo si necesitas corregir algo.',ok:'Completar registro',act:'docomplete'};renderSheet()}
      break;
    case 'docomplete':completeOrder();break;
    case 'reopen':reopenOrder();break;
    case 'kgemp':sheet={kind:'kgemp'};renderSheet();break;
    case 'torient':{const x=cur();if(!x||ro)break;const m=mainOf(x),t=ensureTraz(m),v=arg==='h'?'h':'v';if((t.orient==='h'?'h':'v')===v)break;t.orient=v;touch(m);logAdd({k:'note',ctx:ctxOf(m),lab:'Orientación del Código de Trazabilidad',o:v==='h'?'Vertical':'Horizontal',n:v==='h'?'Horizontal':'Vertical'});render();toast('Hoja '+(v==='h'?'horizontal':'vertical'));break}
    case 'wktrips':openOutWkTrips();break;
    case 'pentadd':sheet={kind:'pentadd',pid:arg};renderSheet();break;
    case 'elink':{if(ro)break;const k=act+':'+arg+':'+parts[2]+':'+parts[3];if(confirmKey!==k){confirmKey=k;render();break}entLink(arg,parts[2],parts[3]);break}
    case 'epes1':{if(ro)break;const k=act+':'+arg+':'+parts[2];if(confirmKey!==k){confirmKey=k;render();break}entPes1(arg,parts[2]);break}
    case 'pentsel':pentAdd(arg,parts[2]);break;
    case 'pentrm':pentRm(arg,parts[2]);break;
    case 'savedopen':savedAct('open');break;
    case 'savedshare':savedAct('share');break;
    case 'pendopen':confirmKey=null;sheet={kind:'pend'};renderSheet();break;
    case 'decopen':sheet={kind:'dec',ed:''};renderSheet();break;
    case 'decedit':if(sheet&&sheet.kind==='dec'){sheet.ed=arg||'';renderSheet()}break;
    case 'decsave':decSave(arg);break;
    case 'exdel':if(!perAdmin())break;if(confirmKey!=='exdel'){confirmKey='exdel';renderSheet();break}exDel();break;
    case 'pent':{const e=INV.entradas.find(x=>x.id===arg);if(!e)break;invTab='ent';openE=e.id;goto('inv');break}
    case 'pgo':if(arg==='invproc'||arg==='inv'){invTab=arg==='invproc'?'proc':'ent';goto('inv')}else if(arg==='fin'){if(canFin()){if(!statsF.emp)statsF.emp=emp;goto('fin')}}else if(arg==='kg'){sheet={kind:'kgemp'};renderSheet()}break;
    case 'kgsave':kgempSave(false);break;
    case 'kgdef':kgempSave(true);break;
    case 'share':openShare(arg);break;
    case 'savejpg':if(sheet&&sheet.cv)sheet.cv.toBlob(b=>{if(b)saveFile('Empaque_'+(sheet.name||'productor').replace(/[^\w.-]+/g,'_')+'.jpg',b)},'image/jpeg',0.95);break;
    case 'savepng':if(sheet&&sheet.cv)sheet.cv.toBlob(b=>{if(b)saveFile('Empaque_'+(sheet.name||'productor').replace(/[^\w.-]+/g,'_')+'.png',b)},'image/png');break;
    case 'copysum':if(sheet)copyText(sheet.text,'Resumen');break;
    case 'wapng':if(sheet&&sheet.cv){const nm='Empaque_'+(sheet.name||'productor').replace(/[^\w.-]+/g,'_')+'.png',tx=sheet.text;sheet.cv.toBlob(b=>{if(b)shareWA(nm,b,tx,'Resumen del productor')},'image/png')}break;
    case 'copy':{if(!o)break;const b=blocks(o).find(x=>x.key===arg);if(b)copyText(b.text,b.title)}break;
    case 'copyv':{if(!o)break;const m={cod:o.cod,emb:o.emb,po:o.po,fecha:fmtUS(o.fecha),semana:String(o.semana),factura:o.factura};copyText(m[arg]||'',arg.toUpperCase())}break;
    case 'xlsx':exportRegistro(false);break;
    case 'mailx':exportRegistro(true);break;
    case 'xlsxz':exportTraz(false);break;
    case 'mailz':exportTraz(true);break;
    case 'addt':addTarima();break;
    case 'addl':addLine(arg);break;
    case 'addlc':addLineCal(arg,parts[2],parts.slice(3).join(':'));break;
    case 'dell':addDelLine(arg,parts[2]);break;
    case 'dupt':dupTarima(arg);break;
    case 'tmv':{const o2=trazOrder();if(!o2)break;const i=ensureTraz(o2).tarimas.findIndex(x=>x.id===arg);if(i>=0)moveTarima(arg,i+(+parts[2]||0));break}
    case 'delt':delTarima(arg);break;
    case 'dbopen':sheet={kind:'db'};renderSheet();break;
    case 'dbx':exportDb('xlsx');break;
    case 'dbc':exportDb('csv');break;
    case 'dbj':exportDb('json');break;
    case 'vw':statsF.view=arg;saveStatsF();render();break;
    case 'stab':statsF.tab=arg==='fin'||arg==='bi'?arg:'op';saveStatsF();render();break;
    case 'peropen':confirmKey=null;sheet={kind:'per',n:12};renderSheet();break;
    case 'permore':if(sheet){sheet.n=(sheet.n||12)+12;renderSheet()}break;
    case 'prc':case 'pro':{const k=parts.slice(1).join(':');if(!perAdmin())break;if(act==='pro'){if(sheet&&sheet.kind==='per'){sheet.reopen=k;sheet.reoErr='';sheet.reoTxt='';confirmKey=null;renderSheet();const m=document.getElementById('reo-m');if(m){m.scrollIntoView({block:'center'});m.focus()}}break}if(confirmKey!==act+':'+k){confirmKey=act+':'+k;renderSheet();break}closeWeek(k);if(sheet&&sheet.kind==='per')renderSheet();break}
    case 'reono':if(sheet&&sheet.kind==='per'){sheet.reopen=null;renderSheet()}break;
    case 'reogo':{const k=parts.slice(1).join(':'),m=gv('reo-m').trim();if(!sheet||sheet.kind!=='per')break;if(!m){sheet.reoErr='Escribe el motivo para reabrir.';renderSheet();break}if(openWeek(k,m)){sheet.reopen=null;sheet.reoTxt='';sheet.reoErr=''}renderSheet();break}
    case 'parmore':if(sheet&&sheet.kind==='fin'){sheet.hn=(sheet.hn||8)+20;renderSheet()}break;
    case 'wkclose':if(!perAdmin())break;confirmKey=null;sheet={kind:'wkc',k:wkcDefault()};renderSheet();break;
    case 'wkcgo':{const k=parts.slice(1).join(':');if(!perAdmin())break;const i=document.getElementById('wkc-conf'),wn=(/S(\d+)$/.exec(k)||['',''])[1];if(!i||String(+i.value)!==String(+wn)){toast('Escribe el número de la semana para confirmar');break}closeWeek(k);break}
    case 'wkcx':{const k=parts.slice(1).join(':'),f={emp:'ALL',cal:'ALL',year:'ALL',month:'ALL',week:k,desde:'',hasta:''},D=biCtx(f,{e:'Vera Limes y Citrilar',per:wkLab(k)+' ('+wkSpan(k)+')'});D.cierre=k;openOutBi(D);break}
    case 'biout':openOutBi(statsData());break;
    case 'biexample':loadBiExample();break;
    case 'kpi':statsF.kpi=arg;saveStatsF();render();break;
    case 'fsort':statsF.fsort=arg;saveStatsF();render();break;
    case 'finset':sheet={kind:'fin',e:statsF.emp==='EC'?'EC':'VL'};renderSheet();try{history.pushState({finSheet:1},'')}catch(x){}break;
    case 'finemp':if(sheet&&sheet.kind==='fin'){sheet.e=arg;renderSheet()}break;
    case 'fincal':if(sheet&&sheet.kind==='fin')fcarGo(arg,true);break;
    case 'dir':statsF.dir=statsF.dir==='desc'?'asc':'desc';saveStatsF();render();break;
    case 'per':statsF._per=!statsF._per;render();break;
    case 'clrd':statsF.desde='';invalidateStats();saveStatsF();render();break;
    case 'clrh':statsF.hasta='';invalidateStats();saveStatsF();render();break;
    case 'calo':openCal=openCal===arg?null:arg;render();break;
    case 'seg2':if(!openSeg2(o))toast('No hay segundas disponibles');break;
    case 's2all':case 's2none':case 's2p':{if(!sheet||sheet.kind!=='seg2')break;const gs=act==='s2p'?[sheet.G[+arg]].filter(Boolean):sheet.G;
      gs.forEach(x=>x.lots.forEach(l=>{if(act==='s2none')delete sheet.q[l.id];else sheet.q[l.id]=String(l.av)}));
      const sc=$sh.querySelector('.s2list'),top=sc?sc.scrollTop:0;renderSheet();const sc2=$sh.querySelector('.s2list');if(sc2)sc2.scrollTop=top;break}
    case 's2ok':seg2Ok();break;
    case 's2jug':seg2Jug();break;
    case 'apdel':{if(!o||ro)break;const p=o.productores.find(x=>x.id===arg);if(!p||!p.aportes)break;const a=p.aportes.find(x=>x.id===parts[2]);if(!a)break;p.aportes=p.aportes.filter(x=>x!==a);c23Sync(p);touch(o);logAdd({k:'note',ctx:ctxOf(o),lab:segName()+' · quitó a '+(a.nombre||'productor'),o:fmt(n0(a.n)),n:''});render();toast('Esas segundas vuelven a estar disponibles');break}
    case 'v15':{
      if(!o)break;
      const n=newOrder({emp:o.emp,anio:o.anio,cons:o.cons,cod:o.cod,emb:o.emb,po:o.po,fecha:o.fecha,semana:o.semana,customer:o.customer,domestic:o.domestic,factura:o.factura,variante:'1.5'});
      n.kgCaja=o.kgCaja;n.estado=o.estado;orders.push(n);touch(n);curId=n.id;view='order';tab='captura';openP=null;render();window.scrollTo(0,0);if(!openSeg2(n))toast('Hoja #1.5 creada');
    }break;
    case 'create':{
      const d=sheet&&sheet.d;if(!d)break;const c=codesFrom(d);
      {const wk=wkOf({anio:c.anio,semana:d.semana,fecha:d.fecha});if(wkClosed(wk)){toast(wkLab(wk)+' está cerrada. Un administrador puede reabrirla en Periodos.');break}}
      const base={emp:c.emp,anio:c.anio,cons:c.cons,cod:c.cod,emb:c.emb,po:d.po,fecha:d.fecha,semana:num(d.semana)==null?d.semana:num(d.semana),customer:d.customer,domestic:d.domestic,factura:d.factura};
      const hj=d.hojas||'1';let n=null;
      if(hj==='1'||hj==='ambas'){n=newOrder(Object.assign({variante:'1'},base));orders.push(n);touch(n)}
      if(hj==='1.5'||hj==='ambas'){const m=newOrder(Object.assign({variante:'1.5'},base));orders.push(m);touch(m);if(!n)n=m}
      if(d.customer)setCliente(mainOf(n),d.customer);
      curId=n.id;view='order';tab='captura';openP=null;sheet=null;renderSheet();render();window.scrollTo(0,0);
      const lo=prevLeftover(n);if(lo)toast('Hay sobrante de '+lo.from.cod+' para este pedido');
      if(hj==='1.5')openSeg2(n);
    }break;
    case 'sync':
      if(!cfgOK()){sheet={kind:'syncinfo'};renderSheet()}
      else if(!session){sheet={kind:'login',lf:{email:'',pw:''},err:''};renderSheet()}
      else doSync();
      break;
    case 'dologin':doSheetLogin();break;
    case 'logout':rtStop();session=null;ro=roRole=false;try{localStorage.removeItem(LS_SESSION)}catch(x){}setSync();render();toast('Sesión cerrada');break;
    case 'exportjson':exportBackup();break;
    case 'importjson':{const f=document.getElementById('impfile');if(f)f.click()}break;
    case 'closesheet':closeSheet();break;
    case 'regsopen':if(canCat()){sheet={kind:'regs',rt:'vendedores',q:'',edit:null,err:''};renderSheet()}break;
    case 'rtab':{const S=regS();if(S&&REGSPEC[arg]){S.rt=arg;S.q='';S.edit=null;S.err='';regRefresh(S)}break}
    case 'radd':{const S=regS();if(S&&canCat()){S.err=regSave(null,S);if(!S.err)toast('Guardado');regRefresh(S);const f=document.getElementById('rn-0');if(f&&!S.err)f.focus()}break}
    case 'redit':{const S=regS();if(S&&canCat()){S.edit=arg;S.err='';regRefresh(S)}break}
    case 'rcancel':{const S=regS();if(S){S.edit=null;regRefresh(S)}break}
    case 'rsave':{const S=regS();if(S&&canCat()){S.err=regSave(arg,S);if(!S.err){S.edit=null;toast('Guardado')}regRefresh(S)}break}
    case 'rdel':{const S=regS();if(S&&canCat()){if(confirmKey==='rdel:'+arg){confirmKey=null;REG[S.rt]=REG[S.rt].filter(x=>x.id!==arg);saveReg(true);toast('Eliminado')}else armConfirm('rdel:'+arg);regRefresh(S)}break}
    case 'prods':PV.q='';PV.only='all';goto('prods');break;
    case 'log':LG.rt=null;LG.q='';LG.edit=null;LG.err='';goto('log');break;
    case 'logsec':if(REGSPEC[arg]){LG.rt=arg;LG.q='';LG.edit=null;LG.err='';render();window.scrollTo(0,0)}break;
    case 'logmenu':LG.rt=null;LG.edit=null;LG.err='';render();window.scrollTo(0,0);break;
    case 'logimp':if(canCat()){let n=0;visible().forEach(o=>{const c=String(o.customer||'').trim().toUpperCase();if(c&&!regFind('clientes',c)){REG.clientes.push({id:uid(),n:c,destino:'',incoterm:'',diasPago:''});n++}});if(n){REG.clientes.sort((a,b)=>String(a.n).localeCompare(String(b.n),'es'));saveReg(true)}toast(n?n+' clientes agregados desde los pedidos':'Todos los clientes de los pedidos ya están');render()}break;
    case 'pvcls':PV.cls=arg;{const g=document.getElementById('pvgrid');if(g)g.innerHTML=prodCardsHtml();$app.querySelectorAll('[data-act^="pvcls:"]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.act==='pvcls:'+arg)))}break;
    case 'pvfil':PV.only=arg;{const g=document.getElementById('pvgrid');if(g)g.innerHTML=prodCardsHtml();$app.querySelectorAll('[data-act^="pvfil:"]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.act==='pvfil:'+arg)))}break;
    case 'pvopen':if(canCat()){sheet={kind:'prodone',c:+arg,err:''};renderSheet();const i=document.getElementById('pe-n');if(i){i.focus();i.select()}}break;
    case 'pvsave':if(sheet&&sheet.kind==='prodone'&&canCat()){const v=(document.getElementById('pe-n')||{}).value;const m=prodSet(+arg,v,(document.getElementById('pe-k')||{}).value);sheet.err=m;if(m){renderSheet()}else{if(isAdmin())acuSave(+arg);sheet=null;renderSheet();render();toast('Productor guardado')}}break;
    case 'pvdel':if(sheet&&sheet.kind==='prodone'&&canCat()){if(confirmKey==='pvdel:'+arg){confirmKey=null;prodDel(+arg);sheet=null;renderSheet();render();toast('Código '+arg+' liberado')}else{armConfirm('pvdel:'+arg);renderSheet()}}break;
    case 'pvadd':if(canCat()){const c=(document.getElementById('pv-c')||{}).value,n=(document.getElementById('pv-n')||{}).value;const ex=LISTA.find(x=>x.c===+c);const m=ex?'El código '+c+' ya tiene a '+ex.n+'. Toca su tarjeta para editarlo.':prodSet(c,n,(document.getElementById('pv-k')||{}).value);PV.err=m;if(!m){PV.q='';toast('Productor agregado')}render()}break;
    case 'lgtab':lg.tab=arg;lg.err='';lg.msg='';render();break;
    case 'lgin':doLogin();break;
    case 'lgreg':doRegister();break;
    case 'lgbio':bioLogin();break;
    case 'bioyes':bioYes();break;
    case 'biono':bioNo();break;
    case 'bioopen':bioOpen();break;
    case 'biodel':bioDel();break;
    case 'ulogout':case 'usersopen':case 'acctopen':case 'acsave':case 'uok':case 'urej':case 'ublk':case 'udel':userAct(act,arg,parts[2]);break;
    case 'ppick':pickProd(parts[1],parts[2],parts[3]);break;
    case 'prodsopen':if(canCat()){sheet={kind:'prods',q:'',only:'all',edit:null,err:''};renderSheet()}break;
    case 'pfil':if(sheet){sheet.only=arg;renderSheet()}break;
    case 'pedit':if(sheet&&canCat()){sheet.edit=+arg;sheet.err='';renderSheet();const i=document.getElementById('pe-n');if(i){i.focus();i.select()}}break;
    case 'pcancel':if(sheet){sheet.edit=null;renderSheet()}break;
    case 'psave':if(sheet&&canCat()){const v=(document.getElementById('pe-n')||{}).value;const m=prodSet(+arg,v,(document.getElementById('pe-k')||{}).value);sheet.err=m;if(!m){acuSave(+arg);sheet.edit=null;toast('Productor guardado')}renderSheet()}break;
    case 'padd':if(sheet&&canCat()){const c=(document.getElementById('pn-c')||{}).value,n=(document.getElementById('pn-n')||{}).value;const ex=LISTA.find(x=>x.c===+c);const m=ex?'El código '+c+' ya tiene a '+ex.n+'. Usa Editar para cambiarlo.':prodSet(c,n,(document.getElementById('pn-k')||{}).value);sheet.err=m;if(!m){sheet.q='';toast('Productor agregado')}renderSheet()}break;
    case 'pdel':if(sheet&&canCat()){if(confirmKey==='pdel:'+arg){confirmKey=null;prodDel(+arg);toast('Código '+arg+' liberado')}else armConfirm('pdel:'+arg);renderSheet()}break;
  }
}
function addDelLine(pid,lid){delLine(pid,lid)}
function setBind(b,val,isNum){
  const o=cur();if(!o||ro)return;const p=b.split('.');const v=isNum?num(val):val;
  if(p[0]==='o'){o[p[1]]=v;if(p[1]==='cod'){const m=String(val).match(/(\d+)\s*$/);if(m&&m[1].length<=4)o.cons=+m[1]}if(p[1]==='fecha'&&val){o.semana=isoWeek(val);const s=document.getElementById('f-o-semana');if(s)s.value=o.semana}}
  else if(p[0]==='m'){if(p.length===3){o.manT=o.manT||{};(o.manT[p[1]]=o.manT[p[1]]||{})[p[2]]=v;syncManSum(o)}else{o.manifiesto=o.manifiesto||{};o.manifiesto[p[1]]=v}}
  else if(p[0]==='p'){const pr=o.productores.find(x=>x.id===p[1]);if(!pr)return;if(p[2]==='acc'){accOf(pr,p[3],true)[p[4]]=v}else pr[p[2]]=v}
  else if(p[0]==='ob'){const m=mainOf(o);m.bi=m.bi||{};m.bi[p[1]]=v;if(m!==o)touch(m)}
  else if(p[0]==='z'){const m=mainOf(o);ensureTraz(m).hdr[p[1]]=val;hdrDocClear(m,p[1])}
  else if(p[0]==='t'){const pl=ensureTraz(mainOf(o)).tarimas.find(x=>x.id===p[1]);if(pl)pl[p[2]]=val}
  else if(p[0]==='tl'){const pl=ensureTraz(mainOf(o)).tarimas.find(x=>x.id===p[1]);const l=pl&&pl.lines.find(x=>x.id===p[2]);if(!l)return;
    if(l.de){if(p[3]!=='cal'&&p[3]!=='cant')return;const ock=PCAL_KEY[l.cal]||null,on=n0(l.cant);l[p[3]]=p[3]==='cant'?v:val;sobLineSync(mainOf(o),pl,l,ock,on);return}
    l[p[3]]=p[3]==='cant'?v:val}
}
$app.addEventListener('click',onClick);
$sh.addEventListener('click',onClick);
$app.addEventListener('input',e=>{
  const el=e.target;const b=el.dataset&&el.dataset.bind;if(!b)return;
  if(el.dataset.digits){const d=el.value.replace(/\D+/g,'');if(d!==el.value)el.value=d}
  if(el.dataset.sum&&OPS_RE.test(el.value))return;
  setBind(b,el.value,!!el.dataset.num);palCouple(b);const o=cur();if(o)touch(o);
  if(view==='trazo')updateTraz();else updateDerived();
});
$app.addEventListener('change',e=>{const el=e.target;if(el&&el.dataset&&el.dataset.tpos){moveTarima(el.dataset.tpos,+el.value);return}if(el&&el.dataset&&/^t\.[^.]+\.(marca|empaque)$/.test(el.dataset.bind||'')){render();return}if(el&&el.dataset&&/^tl\.[^.]+\.[^.]+\.q$/.test(el.dataset.bind||'')){const o=trazOrder(),pl=o&&ensureTraz(o).tarimas.find(x=>x.id===el.dataset.bind.split('.')[1]);if(pl){syncMarca(o,pl);touch(o)}render();return}if(el&&el.dataset&&el.dataset.learn)onHdrChange(el);if(el&&el.dataset&&el.dataset.tipo){const q=el.dataset.tipo.split(':');setTipo(q[0],+q[1],el.value)}});
$app.addEventListener('focusin',e=>{const el=e.target;if(el&&el.dataset&&el.dataset.tipo){const q=el.dataset.tipo.split(':'),pc=document.getElementById('pc-'+q[0]),cs=pc&&pc.querySelector('[data-cs]');if(cs)cardPage(cs,+q[1],true)}});
let csT=null;$app.addEventListener('scroll',e=>{const cs=e.target;if(!(cs&&cs.dataset&&cs.dataset.cs))return;clearTimeout(csT);csT=setTimeout(()=>markPage(cs),80)},true);
window.addEventListener('resize',()=>{$app.querySelectorAll('[data-cs]').forEach(cs=>cardPage(cs,pageOf[cs.dataset.cs]||0,false))});
$sh.addEventListener('input',e=>{
  const el=e.target;if(!sheet)return;
  if(el.dataset.lf&&sheet.lf){sheet.lf[el.dataset.lf]=el.value;return}
  if(el.dataset.search){sheet.q=el.value;const r=document.getElementById('results');if(r)r.innerHTML=resultsHtml(el.value);return}
  const k=el.dataset.sf;if(!k||!sheet.d)return;
  sheet.d[k]=el.value;
  if(k==='factura')sheet.d.facAuto=false;
  if(k==='customer'&&sheet.d.facAuto){sheet.d.factura=nextFactura(el.value);const i=document.getElementById('n-factura');if(i)i.value=sheet.d.factura}
  if(k==='fecha'&&el.value){const w=isoWeek(el.value),y=el.value.slice(0,4);sheet.d.semana=w;sheet.d.nEC=nextCons(sheet.d.emp,y);sheet.d.nPed=nextPed(sheet.d.emp,y,w);['semana','nEC','nPed'].forEach(f=>{const i=document.getElementById('n-'+f);if(i)i.value=sheet.d[f]})}
  if(k==='semana'){sheet.d.nPed=nextPed(sheet.d.emp,String(sheet.d.fecha).slice(0,4),el.value);const i=document.getElementById('n-nPed');if(i)i.value=sheet.d.nPed}
  const c=codesFrom(sheet.d),pv=document.getElementById('newprev');if(pv)pv.textContent=c.cod+' · '+c.emb;
});
$app.addEventListener('focusin',e=>{const t=e.target;if(t.dataset&&t.dataset.num)setTimeout(()=>{try{t.select()}catch(x){}},0)});
$app.addEventListener('keydown',e=>{
  if(e.key!=='Enter'||!e.target.matches||!e.target.matches('input.in')||e.target.dataset.psearch||e.target.dataset.lg)return;
  e.preventDefault();const scope=e.target.closest('.pf,.sumbox,.pal')||$app;
  const ins=[...scope.querySelectorAll('input.in')];const i=ins.indexOf(e.target);
  if(ins[i+1])ins[i+1].focus();else e.target.blur();
});

$sh.addEventListener('keydown',e=>{if(e.key==='Enter'&&sheet&&sheet.kind==='login'&&e.target.matches&&e.target.matches('input')){e.preventDefault();doSheetLogin()}});
document.addEventListener('change',e=>{if(e.target&&e.target.id==='impfile')importBackup(e.target)});

/* buscador de productor dentro de las tarimas */
$app.addEventListener('focusin',e=>{const t=e.target;if(t.dataset&&t.dataset.psearch){closePdds();openPdd(t);setTimeout(()=>{try{t.select()}catch(x){}},0)}});
$app.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.psearch){t.dataset.dirty='1';openPdd(t)}});
$app.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.tfind){trazQ=t.value;trazFindApply()}});
/* casillas del acumulado: funcionan como una mini hoja de cálculo que solo suma y resta (+50+50-10).
   Al salir de la casilla se guarda el total; al tocarla otra vez vuelve a mostrar la operación. */
const OPS_RE=/[+\-−–—＋－]/;
function normOps(s){return String(s==null?'':s).replace(/＋/g,'+').replace(/[−–—－]/g,'-').replace(/[,\s]/g,'')}
function sumExpr(s){
  let t=normOps(s).replace(/[+\-]+$/,'');
  if(!t)return null;
  const m=t.match(/[+-]?\d+(?:\.\d+)?/g);
  if(!m||m.join('')!==t)return NaN;
  let tot=0;m.forEach(x=>{tot+=parseFloat(x)});
  return Math.round(tot*100)/100;
}
function accRef(el){
  const bp=String((el&&el.dataset&&el.dataset.bind)||'').split('.');
  if(bp[0]!=='p'||bp[2]!=='acc')return null;
  const o=cur(),pr=o&&o.productores.find(x=>x.id===bp[1]);
  return pr?{o:o,pr:pr,t:bp[3],k:bp[4],xk:bp[3]+':'+bp[4]}:null;
}
function settleSum(el){
  if(!el||!el.dataset||!el.dataset.sum||ro)return;
  const ref=accRef(el);if(!ref)return;
  let t=normOps(el.value);const pr=ref.pr,k=ref.k,xk=ref.xk,acc=accOf(pr,ref.t);
  if(!/[+-]/.test(t)){
    if(pr.accx&&pr.accx[xk]!=null){delete pr.accx[xk];touch(ref.o)}
    return;
  }
  let tot=sumExpr(t);
  if(tot!==null&&isNaN(tot)){t=t.replace(/[^\d+\-.]/g,'');tot=sumExpr(t)}  /* si hay letras u otros signos, se descartan */
  if(tot==null||isNaN(tot)||tot<0){
    const prev=acc[k];
    el.value=prev==null?'':String(prev);
    toast(tot!=null&&!isNaN(tot)&&tot<0?'El total no puede ser menor que 0':'Operación no válida: solo sumas y restas');
    return;
  }
  const expr=t.replace(/[+\-]+$/,''),newX=/^\+?\d+(\.\d+)?$/.test(expr)?null:expr;
  const prevX=(pr.accx&&pr.accx[xk])||null,prevV=acc[k];
  el.value=String(tot);
  if(prevX===newX&&prevV!=null&&Number(prevV)===tot)return;  /* solo se tocó la casilla: no hay cambio que guardar */
  setBind(el.dataset.bind,el.value,true);
  pr.accx=pr.accx||{};
  if(newX==null)delete pr.accx[xk];else pr.accx[xk]=newX;
  touch(ref.o);
  if(view==='trazo')updateTraz();else updateDerived();
}
$app.addEventListener('focusout',e=>settleSum(e.target));
$app.addEventListener('focusin',e=>{
  const el=e.target;if(!(el&&el.dataset&&el.dataset.sum))return;
  const ref=accRef(el),x=ref&&ref.pr.accx&&ref.pr.accx[ref.xk];
  if(x&&sumExpr(x)===sumExpr(el.value)){el.value=x;setTimeout(()=>{try{el.setSelectionRange(x.length,x.length)}catch(e){}},0)}
});
$app.addEventListener('mousedown',e=>{if(e.target.closest&&e.target.closest('.plus'))e.preventDefault()});
$app.addEventListener('focusout',e=>{const t=e.target;if(t.dataset&&t.dataset.psearch)setTimeout(()=>{closePdds();settleProd(t)},220)});
$app.addEventListener('mousedown',e=>{if(e.target.closest&&e.target.closest('.pdd'))e.preventDefault()});
$app.addEventListener('keydown',e=>{
  const t=e.target;if(!(t.dataset&&t.dataset.psearch))return;
  if(e.key==='Escape'){closePdds();t.blur()}
  else if(e.key==='Enter'){e.preventDefault();const b=t.parentNode.querySelector('.pdi');if(b)b.click();else t.blur()}
});
$sh.addEventListener('input',e=>{
  const el=e.target;if(!sheet||(sheet.kind!=='prods'&&sheet.kind!=='regs'))return;
  if(el.dataset.digits){const d=el.value.replace(/\D+/g,'');if(d!==el.value)el.value=d}
  if(el.dataset.rsq){sheet.q=el.value;const r=document.getElementById('rlist');if(r)r.innerHTML=regsRowsHtml()}
  if(el.dataset.psq){sheet.q=el.value;const r=document.getElementById('plist');if(r)r.innerHTML=prodRowsHtml()}
});

$app.addEventListener('keydown',e=>{const t=e.target;if(t.dataset&&t.dataset.lg&&e.key==='Enter'){e.preventDefault();if(lg.tab==='reg')doRegister();else doLogin()}});
$sh.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.urol&&adminOnly()){const x=USERS.find(y=>y.id===t.dataset.urol);if(x){x.rol=t.value;if(!USERS.some(y=>y.rol==='admin'&&y.estado==='activo')){x.rol='admin';toast('Debe quedar al menos un administrador')}saveUsers();renderSheet()}}});

/* ---------- acceso de usuarios (candado local; con la base de datos se cambia por cuentas de Supabase) ---------- */
const LS_USERS='empaque-usuarios',LS_AUTH='empaque-auth';
const ROLES={admin:'Administrador',jefe:'Jefe de empaque',lector:'Solo lectura',contador:'Contador',tarima:'Personal de tarima'};
function canFin(){return !!authUser&&['admin','lector','contador'].indexOf(authUser.rol)>=0}
/* el contador consulta Finanzas, BI, precios y periodos; no ve la captura de empaque */
function isContador(){return !!authUser&&authUser.rol==='contador'}
let USERS=[],authUser=null,lg={tab:'in',err:'',msg:''},lgFails=0,lgLock=0;
const unorm=s=>norm(String(s||'')).replace(/\s+/g,' ').trim();
function loadUsers(){try{USERS=JSON.parse(localStorage.getItem(LS_USERS)||'[]')||[]}catch(e){USERS=[]}}
function saveUsers(){try{localStorage.setItem(LS_USERS,JSON.stringify(USERS))}catch(e){}}
async function hashPw(pw,salt){
  const s=salt+'|'+pw;
  try{if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return 'a'+Array.prototype.map.call(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}
  let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return 'b'+(h>>>0).toString(16);
}
const newSalt=()=>Math.random().toString(36).slice(2)+Date.now().toString(36);
async function ensureUsers(){
  if(USERS.length)return;
  const salt=newSalt();
  USERS=[{id:'u-1',user:'USUARIO 1',name:'USUARIO 1',salt:salt,hash:await hashPw('12345',salt),rol:'admin',estado:'activo',defPw:true,createdAt:Date.now()}];
  saveUsers();
}
function loadAuth(){
  if(cfgOK()){authUser=null;return}
  loadUsers();
  try{const a=JSON.parse(localStorage.getItem(LS_AUTH)||'null');authUser=(a&&USERS.find(x=>x.id===a.uid&&x.estado==='activo'))||null}catch(e){authUser=null}
}
loadAuth();
if(!cfgOK())ensureUsers().then(()=>{if(!authUser&&!document.getElementById('lg-u'))render()});
function authFromSession(){
  if(!cfgOK()||!session){return}
  const r=roleOf(session.access_token),r2=roleRaw(session.access_token),em=session.email||'';
  authUser={id:'sb:'+em,user:em,name:session.name||em,rol:(r==='admin'||r==='jefe'||r==='contador'||r==='tarima')?r:'lector',rol2:r2||'',sinRol:!(r==='admin'||r==='jefe'||r==='lector'||r==='contador'||r==='tarima'),estado:'activo',remote:true};
  applyRole();
}
function setAuth(u){authUser=u;try{if(u)localStorage.setItem(LS_AUTH,JSON.stringify({uid:u.id}));else localStorage.removeItem(LS_AUTH)}catch(e){}applyRole()}
const gv=id=>String((document.getElementById(id)||{}).value||'');
function loginView(){
  if(cfgOK())return `<main class="wrap lgw"><section class="hero"><img class="logo" src="${LOGO[emp]}" alt="Logotipo"><h1>${esc(APP_NAME)}</h1><div class="sub">Acceso para el personal autorizado</div></section>
<div class="panel" style="margin-top:12px"><label class="fld" for="lg-u"><span>Correo</span><input class="in txt" id="lg-u" data-lg="1" type="email" inputmode="email" autocomplete="username" autocapitalize="none" value="${esc(lg.u||'')}"></label>
<label class="fld" for="lg-p"><span>Contraseña</span>${PWI(`<input class="in txt" id="lg-p" data-lg="1" type="password" autocomplete="current-password">`)}</label>
${lg.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(lg.err)}</p>`:''}${lg.msg?`<div class="panel info" role="status">${esc(lg.msg)}</div>`:''}${lg.busy?'<p class="note">Entrando…</p>':''}
${legalBox()}<button class="btn primary" style="width:100%;margin-top:8px" data-act="lgin"${lg.busy?' disabled':''}>Entrar</button>${bioBtn()}<p class="note" style="margin-top:8px">Las cuentas las crea el administrador. Si no tienes una, pídesela.</p></div><p class="note vlab">Versión ${APP_VER}</p>${legalFoot()}</main>`;
  const reg=lg.tab==='reg';
  return `<main class="wrap lgw"><section class="hero"><img class="logo" src="${LOGO[emp]}" alt="Logotipo"><h1>${esc(APP_NAME)}</h1><div class="sub">Acceso para el personal autorizado</div></section>
<div class="seg" role="group" aria-label="Acceso" style="margin:12px 0"><button data-act="lgtab:in" aria-pressed="${!reg}">Entrar</button><button data-act="lgtab:reg" aria-pressed="${reg}">Solicitar acceso</button></div>
<div class="panel">${reg?`<label class="fld" for="lg-n"><span>Nombre completo</span><input class="in txt" id="lg-n" data-lg="1" type="text" autocomplete="name" value="${esc(lg.n||'')}"></label>`:''}
<label class="fld" for="lg-u"><span>Usuario</span><input class="in txt" id="lg-u" data-lg="1" type="text" autocomplete="username" autocapitalize="characters" value="${esc(lg.u||'')}"></label>
<label class="fld" for="lg-p"><span>Contraseña</span>${PWI(`<input class="in txt" id="lg-p" data-lg="1" type="password" autocomplete="${reg?'new-password':'current-password'}">`)}</label>
${reg?`<label class="fld" for="lg-p2"><span>Repite la contraseña</span>${PWI(`<input class="in txt" id="lg-p2" data-lg="1" type="password" autocomplete="new-password">`)}</label><p class="note">Mínimo 6 caracteres. Tu solicitud queda pendiente hasta que el administrador la autorice.</p>`:''}
${legalBox()}${lg.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(lg.err)}</p>`:''}${lg.msg?`<div class="panel info" role="status">${esc(lg.msg)}</div>`:''}
<button class="btn primary" style="width:100%;margin-top:8px" data-act="${reg?'lgreg':'lgin'}">${reg?'Enviar solicitud':'Entrar'}</button>${reg?'':bioBtn()}</div><p class="note vlab">Versión ${APP_VER}</p>${legalFoot()}</main>`;
}
async function doLogin(cred){
  if(!legalOK()){lg.err='Para entrar, acepta el aviso de privacidad y los términos con la casilla.';lg.msg='';render();return}
  if(cfgOK()){
    const em=(cred?cred.username:gv('lg-u')).trim().toLowerCase(),pw=cred?cred.password:gv('lg-p');lg.u=em;
    if(!em||!pw){lg.err='Escribe tu correo y tu contraseña.';render();return}
    lg.busy=true;lg.err='';render();
    try{await login(em,pw);legalRecord(em);lg={tab:'in',err:'',msg:'',busy:false};authFromSession();view='menu';curId=null;render();window.scrollTo(0,0);doSync();segStamp();if(!cred)bioOffer(em,pw)}
    catch(e){lg.busy=false;lg.err=(e&&e.status>=400&&e.status<500)?'Correo o contraseña incorrectos.':'No se pudo conectar. Revisa tu internet e inténtalo otra vez.';if(cred&&cred.bio&&e&&e.status>=400&&e.status<500){bioUnlink();lg.err='Tu contraseña cambió. Entra con la contraseña y vuelve a vincular la huella.'}render()}
    return;
  }
  if(Date.now()<lgLock){lg.err='Demasiados intentos. Espera unos segundos.';lg.msg='';render();return}
  const ru=cred?cred.username:gv('lg-u'),u=unorm(ru),p=cred?cred.password:gv('lg-p');lg.u=ru;
  await ensureUsers();
  const x=USERS.find(y=>unorm(y.user)===u);
  if(!x||x.hash!==await hashPw(p,x.salt)){if(++lgFails>=5){lgLock=Date.now()+30000;lgFails=0}lg.err=(cred&&cred.bio)?(bioUnlink(),'Tu contraseña cambió. Entra con la contraseña y vuelve a vincular la huella.'):'Usuario o contraseña incorrectos.';lg.msg='';render();return}
  lgFails=0;
  legalRecord(x.user);
  if(x.estado==='pendiente'){lg.err='Tu solicitud sigue pendiente. El administrador debe autorizarla.';lg.msg='';render();return}
  if(x.estado!=='activo'){lg.err='Tu acceso no está autorizado. Habla con el administrador.';lg.msg='';render();return}
  lg={tab:'in',err:'',msg:''};setAuth(x);view='menu';curId=null;render();window.scrollTo(0,0);segStamp();if(!cred)bioOffer(x.user,p);
}
async function doRegister(){
  if(!legalOK()){lg.err='Para enviar la solicitud, acepta el aviso de privacidad y los términos con la casilla.';lg.msg='';render();return}
  const n=gv('lg-n').trim().replace(/\s+/g,' '),u=gv('lg-u').trim().replace(/\s+/g,' '),p=gv('lg-p'),p2=gv('lg-p2');
  lg.n=n;lg.u=u;lg.msg='';
  if(n.length<3)lg.err='Escribe tu nombre completo.';
  else if(u.length<3)lg.err='El usuario necesita al menos 3 caracteres.';
  else if(p.length<6)lg.err='La contraseña necesita al menos 6 caracteres.';
  else if(p!==p2)lg.err='Las contraseñas no coinciden.';
  else if(USERS.some(y=>unorm(y.user)===unorm(u)))lg.err='Ese usuario ya existe. Elige otro.';
  else{
    const salt=newSalt();USERS.push({id:uid(),user:u.toUpperCase(),name:n.toUpperCase(),salt:salt,hash:await hashPw(p,salt),rol:'lector',estado:'pendiente',createdAt:Date.now()});saveUsers();
    lg={tab:'in',err:'',msg:'Solicitud enviada. Cuando el administrador la autorice podrás entrar con tu usuario y contraseña.',u:u};
  }
  if(lg.err&&lg.msg==='')lg.msg='';
  render();
}
function pendingUsers(){return USERS.filter(x=>x.estado==='pendiente').length}
function usersHtml(){
  const me=authUser,pend=USERS.filter(x=>x.estado==='pendiente'),rest=USERS.filter(x=>x.estado!=='pendiente');
  const roleBtns=(id)=>['jefe','lector','contador','admin'].map(r=>`<button class="btn sm" data-act="uok:${id}:${r}">${ROLES[r]}</button>`).join('');
  const p=pend.length?`<div class="sec">Pendientes de autorizar</div>`+pend.map(x=>`<div class="urow"><div class="rtx"><strong>${esc(x.name)}</strong><small>Usuario: ${esc(x.user)}</small></div><div class="ubt"><small>Autorizar como:</small><div class="rbt">${roleBtns(x.id)}</div><button class="btn sm danger" data-act="urej:${x.id}">Rechazar</button></div></div>`).join(''):'<p class="note">No hay solicitudes pendientes.</p>';
  const r=rest.map(x=>{
    const self=me&&x.id===me.id;
    return `<div class="urow"><div class="rtx"><strong>${esc(x.name)}${self?' (tú)':''}</strong><small>${esc(x.user)} · ${ROLES[x.rol]||x.rol} · ${x.estado==='activo'?'activo':x.estado}</small></div>${self?'':`<div class="ubt"><select class="in sel" data-urol="${x.id}" aria-label="Rol">${['admin','jefe','tarima','lector','contador'].map(k=>`<option value="${k}"${x.rol===k?' selected':''}>${ROLES[k]}</option>`).join('')}</select><div class="rbt"><button class="btn sm" data-act="ublk:${x.id}">${x.estado==='activo'?'Bloquear':'Activar'}</button><button class="btn sm danger" data-act="udel:${x.id}">${confirmKey==='udel:'+x.id?'Toca otra vez':'Eliminar'}</button></div></div>`}</div>`;
  }).join('');
  return `<h3>Usuarios</h3><p class="note" style="margin-bottom:8px">Aquí autorizas a quien pide acceso y eliges su rol. Jefe de empaque captura y edita; Solo lectura únicamente consulta y descarga; Administrador además configura.</p>${p}<div class="sec">Usuarios</div>${r}<div class="srow2"><button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
function acctHtml(){
  const u=authUser;if(!u)return '';
  if(u.remote)return `<h3>Mi cuenta</h3><p class="note" style="margin-bottom:8px">${esc(u.user)} · ${u.sinRol?'Sin rol asignado (solo lectura)':ROLES[u.rol]}</p><p class="note">La contraseña y las cuentas se administran en Supabase (Authentication → Users).</p>${bioAcctHtml()}<div class="srow2"><button class="btn primary" data-act="closesheet">Cerrar</button></div>`;
  return `<h3>Mi cuenta</h3><p class="note" style="margin-bottom:8px">${esc(u.name)} · ${esc(u.user)} · ${ROLES[u.rol]||u.rol}</p>${u.defPw?'<div class="warnbox" role="alert"><strong>Cambia la contraseña inicial</strong><div>Esta cuenta todavía usa la contraseña de prueba.</div></div>':''}
<label class="fld" for="ac-c"><span>Contraseña actual</span>${PWI(`<input class="in txt" id="ac-c" type="password" autocomplete="current-password">`)}</label><label class="fld" for="ac-n"><span>Contraseña nueva</span>${PWI(`<input class="in txt" id="ac-n" type="password" autocomplete="new-password">`)}</label><label class="fld" for="ac-n2"><span>Repite la nueva</span>${PWI(`<input class="in txt" id="ac-n2" type="password" autocomplete="new-password">`)}</label>${sheet.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.err)}</p>`:''}
${bioAcctHtml()}<div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button><button class="btn primary" data-act="acsave">Cambiar contraseña</button></div>`;
}
async function changePw(){
  const u=authUser;if(!u)return;
  const c=gv('ac-c'),n=gv('ac-n'),n2=gv('ac-n2');
  if(u.hash!==await hashPw(c,u.salt))sheet.err='La contraseña actual no es correcta.';
  else if(n.length<6)sheet.err='La nueva necesita al menos 6 caracteres.';
  else if(n!==n2)sheet.err='Las contraseñas nuevas no coinciden.';
  else{u.salt=newSalt();u.hash=await hashPw(n,u.salt);u.defPw=false;saveUsers();bioSync(u.user,n);sheet=null;renderSheet();render();toast('Contraseña actualizada');return}
  renderSheet();
}
function adminOnly(){return authUser&&authUser.rol==='admin'}
function rolReal(){return !authUser?'':(authUser.rol2||authUser.rol||'')}
function isTarima(){return !!authUser&&authUser.rol==='tarima'}
/* sin base de datos, el administrador local hace también lo del superadmin */
function isSuper(){if(!authUser)return false;if(!cfgOK())return authUser.rol==='admin';return rolReal()==='superadmin'&&!!session&&roleRaw(session.access_token)==='superadmin'}
function isInoc(){return !!authUser&&rolReal()==='inocuidad'&&!ro&&(!cfgOK()||(!!session&&roleRaw(session.access_token)==='inocuidad'))}
/* productores (nombre y clasificación) y catálogos de logística: administración e inocuidad */
function canCat(){return isAdmin()||isInoc()}
function userAct(act,arg,rol){
  if(act==='ulogout'){if(cfgOK()){rtStop();session=null;try{localStorage.removeItem(LS_SESSION)}catch(x){}}setAuth(null);view='menu';curId=null;sheet=null;renderSheet();lg={tab:'in',err:'',msg:''};render();return}
  if(act==='usersopen'){if(adminOnly()){sheet={kind:'users'};renderSheet()}return}
  if(act==='acctopen'){sheet={kind:'acct',err:''};renderSheet();return}
  if(act==='acsave'){changePw();return}
  if(!adminOnly())return;
  const x=USERS.find(y=>y.id===arg);if(!x)return;
  if(act==='uok'){x.estado='activo';x.rol=rol;toast(x.name+' autorizado')}
  else if(act==='urej'){USERS=USERS.filter(y=>y.id!==arg);toast('Solicitud rechazada')}
  else if(act==='ublk'){x.estado=x.estado==='activo'?'bloqueado':'activo'}
  else if(act==='udel'){if(confirmKey==='udel:'+arg){confirmKey=null;USERS=USERS.filter(y=>y.id!==arg)}else armConfirm('udel:'+arg)}
  if(!USERS.some(y=>y.rol==='admin'&&y.estado==='activo')){x.rol='admin';x.estado='activo';toast('Debe quedar al menos un administrador')}
  saveUsers();renderSheet();render();
}
/* ---------- documentos del embarque: Manifiesto y Packing List, PDF y PowerPoint (fusionado de la Fase 2) ---------- */
const DIR_US=['4900 W Expressway 83','Suite 226  +1 (956) 4585194'];
const DOC_EMP={EC:{prov:'CITRICOS J&C LLC',h:['Citricos J&C LLC'].concat(DIR_US)},VL:{prov:'VERA LIMES USA LLC',h:['Vera Limes USA LLC'].concat(DIR_US)}};
const CAL_ASC=['c110','c150','c175','c200','c230','c250','ctn','m28','m36','m42','m48','m54','m60','m63'];
const CAL_LAB={ctn:'230 CTN',c250:'250',c230:'230',c200:'200',c175:'175',c150:'150',c110:'110'};CAL_MM.forEach(c=>{CAL_LAB[c.k]=c.l.toUpperCase()});
let docTab='man',docFrom='order';
const DIAS_U=['DOMINGO','LUNES','MARTES','MIÉRCOLES','JUEVES','VIERNES','SÁBADO'],MESES_U=['ENERO','FEBRERO','MARZO','ABRIL','MAYO','JUNIO','JULIO','AGOSTO','SEPTIEMBRE','OCTUBRE','NOVIEMBRE','DICIEMBRE'];
function fechaLarga(iso){
  const p=String(iso||'').split('-');if(p.length!==3)return iso||'';
  const d=new Date(+p[0],+p[1]-1,+p[2]);if(isNaN(d))return iso;
  return DIAS_U[d.getDay()]+' '+(+p[2])+' DE '+MESES_U[+p[1]-1]+' DE '+p[0];
}
function docMain(o){return mainOf(o||cur())}
/* valores de los documentos: lo capturado en Código de Trazabilidad, corregible en la pantalla de documentos */
function docDef(m){
  const t=ensureTraz(m),h=t.hdr||{},E=DOC_EMP[m.emp]||DOC_EMP.EC,cli=h.cliente||m.customer||'';
  return {salida:h.salida||m.fecha||'',llegada:h.llegada||'',hora:h.hora||'',cliente:cli,factura:h.factura||m.factura||'',poCli:h.poCliente||m.po||'',
    poLinea:((cli?cli.split(/\s+/)[0]:'')+(h.pOrder?' '+h.pOrder:'')).trim(),cantTxt:'',
    linea:h.transporte||'',operador:h.conductor||'',placasT:h.placas||'',placasF:h.placasCaja||'',coment:'',
    alpha:h.alpha||'',caat:h.caat||'',eco:h.trailer||h.caja||'',cert:'',h1:E.h[0],h2:E.h[1],h3:E.h[2],
    viaje:m.cons!=null?String(m.cons):'',prov:h.plProv||PL_PROV[m.emp]||E.prov,vend:h.vendedor||'',pOrder:h.pOrder||'',tel:h.tel||'',sello:h.sello||'',manTipo:'ALL'};
}
function dv(m,k){const d=m.docs||{};return d[k]!==undefined&&d[k]!==null&&!(/^h[123]$/.test(k)&&String(d[k]).trim()==='')?d[k]:docDef(m)[k]}
/* ---------- v8.26 · varios manifiestos por viaje (uno por venta) ----------
   La venta 1 es la del viaje (encabezado de Trazabilidad). Las demás (m.ventas) llevan su propio cliente, P.O., factura y P. Order.
   Cada tarima es de una venta (p.venta; sin marca = venta 1). Cada venta tiene su manifiesto y su packing list con sus tarimas.
   El manifiesto interno y el Código de Trazabilidad siguen siendo del viaje completo. v = id de la venta ('' = venta 1; null = viaje completo). */
const VFIELDS=['cliente','factura','poCli','poLinea','pOrder','cantTxt'];
function ventas(m){return (m&&Array.isArray(m.ventas))?m.ventas:[]}
function multiV(m){return ventas(m).length>0}
function ventaOf(m,v){return v?ventas(m).find(x=>x.id===v)||null:null}
function palV(m,p){const v=p&&p.venta;return v&&ventaOf(m,v)?v:''}
function ventaN(m,v){return v?ventas(m).findIndex(x=>x.id===v)+2:1}
function palsOfV(m,v){return ensureTraz(m).tarimas.filter(p=>palV(m,p)===v)}
function dvv(m,k,v){
  if(v&&VFIELDS.indexOf(k)>=0){const V=ventaOf(m,v);if(V){const x=V[k];if(x!=null&&String(x).trim()!=='')return x;
    if(k==='poLinea'){const c=String(V.cliente||'').trim();return ((c?c.split(/\s+/)[0]:'')+(V.pOrder?' '+V.pOrder:'')).trim()}return ''}}
  return dv(m,k);
}
function ventaCli(m,v){return String(dvv(m,'cliente',v)||'').trim()}
function ventaLab(m,v){const c=ventaCli(m,v);return 'Manifiesto '+ventaN(m,v)+(c?' · '+c:'')}
let docVS={oid:null,v:''};
function docV(m){return m&&docVS.oid===m.id&&(docVS.v===''||!!ventaOf(m,docVS.v))?docVS.v:''}
function setDocV(m,v){docVS={oid:m.id,v:v||''}}
function ventaCan(m){return !ro&&!orderLocked(m)&&!manClosed(m)}
function ventaAdd(m){
  if(!ventaCan(m)){toast(manClosed(m)?'El manifiesto está cerrado':'No se puede cambiar');return}
  const n=ensureTraz(m).tarimas.length;if(n&&ventas(m).length+1>=n){toast('Ya hay un manifiesto por tarima');return}
  const V={id:uid(),cliente:'',factura:'',poCli:'',pOrder:''};m.ventas=ventas(m).concat([V]);setDocV(m,V.id);touch(m);
  logAdd({k:'add',ctx:ctxOf(m),lab:'Manifiesto '+ventaN(m,V.id)+' agregado',o:'',n:'venta a otro cliente'});
  render();toast('Manifiesto '+ventaN(m,V.id)+' agregado. Escribe su cliente y asígnale sus tarimas');
}
function ventaDel(m){
  const v=docV(m);if(!v||!ventaCan(m))return;const k='vdel:'+v;if(confirmKey!==k){armConfirm(k);render();return}confirmKey=null;
  const lab=ventaLab(m,v);let c=0;ensureTraz(m).tarimas.forEach(p=>{if(p.venta===v){delete p.venta;c++}});
  m.ventas=ventas(m).filter(x=>x.id!==v);if(!m.ventas.length)delete m.ventas;setDocV(m,'');touch(m);
  logAdd({k:'del',ctx:ctxOf(m),lab:'Manifiesto quitado',o:lab,n:c?c+(c===1?' tarima regresó':' tarimas regresaron')+' al manifiesto 1':''});
  render();toast(lab+' quitado'+(c?'. Sus tarimas regresaron al manifiesto 1':''));
}
function ventaSet(m,p,v){if(v)p.venta=v;else delete p.venta}
function ventaAsg(m,pid){
  if(!ventaCan(m)){toast(manClosed(m)?'El manifiesto está cerrado':'No se puede cambiar');return}
  const p=ensureTraz(m).tarimas.find(x=>x.id===pid);if(!p)return;const v=docV(m),cv=palV(m,p);
  ventaSet(m,p,cv===v&&v?'':v);touch(m);render();
}
function ventaRng(m){
  if(!ventaCan(m))return;const T=ensureTraz(m).tarimas,a=Math.floor(n0((document.getElementById('vr-a')||{}).value)),b0=(document.getElementById('vr-b')||{}).value,b=b0===''||b0==null?a:Math.floor(n0(b0));
  if(!(a>=1)||!(b>=a)||b>T.length){toast('Escribe las tarimas: de 1 a '+T.length);return}
  const v=docV(m);for(let i=a-1;i<b;i++)ventaSet(m,T[i],v);touch(m);
  logAdd({k:'edit',ctx:ctxOf(m),lab:'Tarimas asignadas',o:'',n:'Tarimas '+a+(b>a?' a '+b:'')+' al manifiesto '+ventaN(m,v)});
  render();toast('Tarimas '+a+(b>a?' a '+b:'')+' en el manifiesto '+ventaN(m,v));
}
function ventasHtml(m){
  const v=docV(m),T=ensureTraz(m).tarimas,can=ventaCan(m),ids=[''].concat(ventas(m).map(x=>x.id));
  const add=can?`<button class="btn sm" data-act="dx:vadd">+ Agregar manifiesto</button>`:'';
  if(!multiV(m))return `<div class="panel vbox"><div class="vhead"><strong>Manifiestos de este viaje</strong>${add}</div><p class="note">Un manifiesto por venta. Si parte de la carga se vende a otro cliente, agrega otro manifiesto y asígnale sus tarimas: cada uno sale con su cliente y su packing list. El manifiesto interno sigue siendo uno solo.</p></div>`;
  const chips=ids.map((id,k)=>{const n=palsOfV(m,id).length;return `<button class="vchip vc${k%6}" data-act="dx:vsel:${id||'0'}" aria-pressed="${id===v}"><b>Manifiesto ${k+1}</b><small>${esc(ventaCli(m,id)||'sin cliente')} · ${n} ${n===1?'tarima':'tarimas'}</small></button>`}).join('');
  const grid=T.length?`<div class="vgrid" role="group" aria-label="Tarimas del viaje por lugar">${T.map((p,i)=>{const pv=palV(m,p),k=ids.indexOf(pv);return `<button class="vpal vc${k%6}" data-act="dx:vasg:${p.id}" aria-pressed="${pv===v}"${can?'':' disabled'} aria-label="Tarima ${i+1}, ${esc(ventaLab(m,pv))}"><b>${i+1}</b><small>M${k+1}</small></button>`}).join('')}</div>`:'<p class="note">Todavía no hay tarimas en Código de Trazabilidad.</p>';
  const rng=can&&T.length?`<div class="vrng"><span>Tarimas de</span><input class="in" id="vr-a" type="text" inputmode="numeric" aria-label="Primera tarima"><span>a</span><input class="in" id="vr-b" type="text" inputmode="numeric" aria-label="Última tarima"><button class="btn sm" data-act="dx:vrng">Pasar al manifiesto ${ventaN(m,v)}</button></div>`:'';
  const del=can&&v?`<div class="pact"><button class="btn sm danger" data-act="dx:vdel">${confirmKey==='vdel:'+v?'Toca otra vez':'Quitar manifiesto '+ventaN(m,v)}</button></div>`:'';
  return `<div class="panel vbox"><div class="vhead"><strong>Manifiestos de este viaje</strong>${add}</div><div class="vchips" role="group" aria-label="Manifiesto que estás editando">${chips}</div><p class="note">Estás editando el <b>manifiesto ${ventaN(m,v)}</b>: los datos de abajo, su manifiesto y su packing list son solo de sus tarimas. ${can?'Toca una tarima para pasarla a este manifiesto'+(v?' (si ya es de este, regresa al manifiesto 1)':'')+', o pasa varias por número de lugar.':'Con el manifiesto cerrado las tarimas ya no cambian de manifiesto.'}</p>${grid}${rng}${del}</div>`;
}
/* v8.7: Manifiesto, Packing List y Código de Trazabilidad comparten los datos del embarque (por empaque).
   Lo que se escribe en un documento se guarda en el encabezado de Trazabilidad y aparece en los otros dos. */
const DOC2HDR={salida:'salida',llegada:'llegada',hora:'hora',cliente:'cliente',factura:'factura',poCli:'poCliente',linea:'transporte',operador:'conductor',placasT:'placas',placasF:'placasCaja',alpha:'alpha',caat:'caat',eco:'trailer',prov:'plProv',vend:'vendedor',pOrder:'pOrder',tel:'tel',sello:'sello'};
function setDocVal(k,v){
  const m=docMain(cur());if(!m||ro)return;
  {const vi=docV(m),V=vi&&VFIELDS.indexOf(k)>=0?ventaOf(m,vi):null;if(V){V[k]=v;touch(m);return}}
  const hk=DOC2HDR[k];
  if(hk){ensureTraz(m).hdr[hk]=v;if(m.docs&&k in m.docs)delete m.docs[k]}
  else{m.docs=m.docs||{};m.docs[k]=v}
  touch(m);
}
/* al cambiar el encabezado de Trazabilidad, deja de valer lo que se había corregido aparte en los documentos */
function hdrDocClear(m,hk){if(!m||!m.docs)return;Object.keys(DOC2HDR).forEach(k=>{if(DOC2HDR[k]===hk&&k in m.docs)delete m.docs[k]})}
/* pedidos anteriores: lo corregido solo en un documento pasa al encabezado si ahí está vacío (no se pierde ni se pisa nada) */
function docLink(m){
  if(!m||ro||!m.docs)return false;const h=ensureTraz(m).hdr;let ch=false;
  Object.keys(DOC2HDR).forEach(k=>{const hk=DOC2HDR[k],v=m.docs[k];if(v==null||String(v).trim()==='')return;
    if(!String(h[hk]||'').trim()){h[hk]=v;delete m.docs[k];ch=true}else if(String(h[hk]).trim()===String(v).trim()){delete m.docs[k];ch=true}});
  if(ch)touch(m);return ch;
}
/* cantidades por tipo de empaque y calidad: de las tarimas si ya hay, si no de lo empacado contra el manifiesto */
/* de dónde salen las cantidades de los documentos: las tarimas; si aún no hay, lo empacado; si tampoco, el manifiesto capturado en Resumen */
/* el manifiesto (y el manifiesto interno) salen del manifiesto capturado en Resumen, aunque todavía no haya tarimas ni código de trazabilidad */
function docSrc(m,pref,v){
  const z=trazCalc(m);
  if(v!=null&&multiV(m)){/* v8.26: con varios manifiestos, cada uno lleva solo las tarimas de su venta */
    const P=palsOfV(m,v),src={};P.forEach(p=>(p.lines||[]).forEach(l=>{const c=n0(l.cant),key=PCAL_KEY[l.cal];if(!(c>0)||!key)return;const L=lineOfCal(p,key,l);src[L]=src[L]||{};src[L][key]=(src[L][key]||0)+c}));
    return {src:src,z:Object.assign({},z,{nPal:P.length,t:Object.assign({},z.t,{tarimas:P})}),from:'pal'};
  }
  const sum=o=>Object.keys(o).reduce((a,L)=>a+CAL.reduce((s,c)=>s+((o[L]||{})[c.k]||0),0),0);
  const src={};
  sheetsOf(m).forEach(x=>{const q=x.variante==='1.5'?'1.5':'1';const mt=x.manT&&Object.keys(x.manT).length?x.manT:(x.manifiesto?{RPC:x.manifiesto}:{});Object.keys(mt).forEach(t=>{if(!TIPO_L[t])return;const v=mt[t]||{};CAL.forEach(c=>{const n=n0(v[c.k]);if(!n)return;const L=lineKey(q,lineType(t,c.k));src[L]=src[L]||{};src[L][c.k]=(src[L][c.k]||0)+n})})});
  if(pref==='man'&&sum(src)>0)return {src:src,z:z,from:'man'};
  if(z.nPal)return {src:z.palL,z:z,from:'pal'};
  if(sum(z.expL)>0)return {src:z.expL,z:z,from:'emp'};
  return sum(src)>0?{src:src,z:z,from:'man'}:{src:z.expL,z:z,from:'emp'};
}
function docQty(m,tp,v){
  const S=docSrc(m,undefined,v),z=S.z,src=S.src;
  const tot=(q,t)=>CAL.reduce((a,c)=>a+((src[lineKey(q,t)]||{})[c.k]||0),0);
  const all=TIPO_K.filter(t=>tot('1',t)||tot('1.5',t)),types=tp?[tp]:all,rows=[];
  const g=(q,k)=>types.reduce((a,t)=>a+((src[lineKey(q,t)]||{})[k]||0),0);
  CAL_ASC.forEach(k=>{const a=g('1',k),b=g('1.5',k);if(a||b)rows.push({k:k,l:CAL_LAB[k],a:a,b:b})});
  const ta=rows.reduce((s,r)=>s+r.a,0),tb=rows.reduce((s,r)=>s+r.b,0),byT={};
  all.forEach(t=>{byT[t]=tot('1',t)+tot('1.5',t)});
  return {rows:rows,ta:ta,tb:tb,t:ta+tb,types:all,byT:byT,tipo:tp||null,fromPal:!!z.nPal,nPal:z.nPal};
}
function cantAuto(q){
  const p=[];if(q.ta)p.push(fmt(q.ta)+' CALIDAD PRIMERA');if(q.tb)p.push(fmt(q.tb)+' CALIDAD UNO Y MEDIO');
  return p.join(' Y ');
}
/* tipos de empaque que salen en el manifiesto: todos (una hoja por tipo) o el elegido */
function manTypes(m){const q=docQty(m),s=dv(m,'manTipo');return q.types.indexOf(s)>=0?[s]:(q.types.length?q.types:['RPC'])}
/* tarimas agrupadas por empaque y calidad, para el pie del packing list */
/* resumen al final del Packing List: cajas por calibre de cada calidad, total de tarimas y de cajas */
function plCalRes(z){
  const Q={'PRIMERA':{},'UNO Y MEDIO':{}},STD=['110','150','175','200','230','250'];
  z.t.tarimas.forEach(p=>{(p.lines||[]).forEach(l=>{const q=lineQ(p,l)==='1.5'?'UNO Y MEDIO':'PRIMERA';const c=n0(l.cant);if(!(c>0))return;const k=String(l.cal||'').replace(/\s*[^\d\s].*$/,'').trim()||String(l.cal||'').trim()||'S/C';Q[q][k]=(Q[q][k]||0)+c})});
  return Object.keys(Q).filter(q=>q==='PRIMERA'||Object.keys(Q[q]).length).map(q=>{
    const ks=STD.concat(Object.keys(Q[q]).filter(k=>STD.indexOf(k)<0).sort((a,b)=>(parseFloat(a)||0)-(parseFloat(b)||0)));
    const rows=ks.map(k=>({cal:k,n:Q[q][k]||0}));return{q:q,label:'CALIDAD '+q,rows:rows,tot:rows.reduce((a,r)=>a+r.n,0)};
  });
}
/* si el contenido no cabe en la hoja, se reduce todo parejo para que salga en una sola página */
function fitOnePage(ops,W,H,top){
  let mx=0;ops.forEach(o=>{mx=Math.max(mx,(o.y||0)+(o.h||0))});
  const k=Math.min(1,(H-top)/mx);if(k>=1)return ops;
  const dx=(W-W*k)/2;
  return ops.map(o=>{const c=Object.assign({},o);c.x=o.x*k+dx;c.y=o.y*k;if(o.w!=null)c.w=o.w*k;if(o.h!=null)c.h=o.h*k;if(o.size)c.size=o.size*k;if(o.min)c.min=o.min*k;if(o.lw)c.lw=Math.max(1,o.lw*k);return c});
}
function plSummary(rows){const g={},out=[];rows.forEach(r=>{const k=r.tipo+' · '+r.cal;if(!g[k]){g[k]={l:k,n:0,cajas:0};out.push(g[k])}g[k].n++;g[k].cajas+=r.cajas});return out}

/* ===== lienzo / PDF / PPTX a partir de una lista de operaciones de dibujo (unidades a 150 ppp) ===== */
const DPI=150;
/* foto del tráiler (22 lugares en dos filas): c0 = centro de la primera fila de lugares y p = distancia entre filas, en pixeles de la foto */
const TRL={f:'img/trailer.jpg',w:305,h:933,c0:313.5,p:57.15,n:22};
async function trailerData(){try{return Object.assign({},await asset(TRL.f),{c0:TRL.c0,p:TRL.p,n:TRL.n})}catch(e){return null}}
/* v8.8: Packing List con la misma foto del tractor y la caja dibujada con un lugar por tarima (como Trazabilidad) */
async function plTrailer(m,v){
  const z=trazCalc(m),ph=await trailerComposite(z.nPal,v!=null&&multiV(m)?z.t.tarimas.map(p=>palV(m,p)===v):null);
  if(!ph)return trailerData();
  return Object.assign(ph,{c0:TRC.top+TRC.pad/2+TRC.pitch/2,p:TRC.pitch,n:z.nPal>0?z.nPal:TRC.std});
}
/* pone la foto a un costado de una tabla con una fila por tarima: cada fila de la foto (2 tarimas) mide lo mismo que 2 filas de la tabla */
function trailerOps(ops,tr,x,y0,rh){const k=2*rh/tr.p,w=tr.w*k,h=tr.h*k,y=y0+rh-tr.c0*k;ops.push({t:'i',b64:tr.b64,x:x,y:y,w:w,h:h});return{w:w,top:y,bottom:y+h}}
async function loadLogoData(e){try{return await asset(LOGO_F2[e])}catch(x){return null}}
function imgFromB64(b64){return new Promise(res=>{const im=new Image();im.onload=()=>res(im);im.onerror=()=>res(null);im.src='data:image/jpeg;base64,'+b64})}
function fitFont(x,s,w,size,bold,min){
  size=size||28;
  do{x.font=(bold?'bold ':'')+size+'px Arial,Helvetica,sans-serif'}while(x.measureText(s).width>w&&(size-=1)>(min||12));
  return size;
}
const _mc=document.createElement('canvas').getContext('2d');
function opSize(op){return op.wrap?op.size:fitFont(_mc,op.s,op.w-6,op.size,op.bold,op.min)}
function wrapLines(x,s,w){
  const out=[];String(s).split('\n').forEach(par=>{
    let line='';par.split(/\s+/).forEach(wd=>{const t=line?line+' '+wd:wd;if(x.measureText(t).width>w&&line){out.push(line);line=wd}else line=t});out.push(line);
  });return out;
}
async function renderPage(pg,dpi){
  dpi=dpi||200;const k=dpi/DPI,cv=document.createElement('canvas');cv.width=Math.round(pg.w*k);cv.height=Math.round(pg.h*k);
  const x=cv.getContext('2d');x.scale(k,k);x.fillStyle='#ffffff';x.fillRect(0,0,pg.w,pg.h);
  for(const op of pg.ops){
    if(op.t==='r'){
      if(op.rad){const r=op.rad;x.beginPath();x.moveTo(op.x+r,op.y);x.arcTo(op.x+op.w,op.y,op.x+op.w,op.y+op.h,r);x.arcTo(op.x+op.w,op.y+op.h,op.x,op.y+op.h,r);x.arcTo(op.x,op.y+op.h,op.x,op.y,r);x.arcTo(op.x,op.y,op.x+op.w,op.y,r);x.closePath();
        if(op.fill){x.fillStyle=op.fill;x.fill()}if(op.line){x.strokeStyle=op.line;x.lineWidth=op.lw||2;x.stroke()}}
      else{
      if(op.fill){x.fillStyle=op.fill;x.fillRect(op.x,op.y,op.w,op.h)}
      if(op.line){x.strokeStyle=op.line;x.lineWidth=op.lw||2;x.strokeRect(op.x,op.y,op.w,op.h)}}
    }else if(op.t==='l'){
      x.strokeStyle=op.line||'#000';x.lineWidth=op.lw||2;x.beginPath();x.moveTo(op.x,op.y);x.lineTo(op.x+op.w,op.y+op.h);x.stroke();
    }else if(op.t==='i'){
      if(op.b64){const im=await imgFromB64(op.b64);if(im)x.drawImage(im,op.x,op.y,op.w,op.h)}
    }else if(op.t==='t'&&op.s!==''){
      x.fillStyle=op.color||'#111';x.textBaseline='middle';
      const al=op.align||'left';x.textAlign=al==='center'?'center':al==='right'?'right':'left';
      const tx=al==='center'?op.x+op.w/2:al==='right'?op.x+op.w-4:op.x+4;
      if(op.wrap){
        x.font=(op.bold?'bold ':'')+op.size+'px Arial,Helvetica,sans-serif';
        const ls=wrapLines(x,op.s,op.w-8),lh=op.size*1.25;
        /* v8.18.4: si ni una línea cabe de alto (celda baja con letra grande, como la fecha del registro), se dibuja en una línea en vez de omitirla */
        if(lh>op.h+2&&ls.length<=1){const sz=Math.max(op.min||8,Math.min(opSize(op),(op.h+2)/1.05));x.font=(op.bold?'bold ':'')+sz+'px Arial,Helvetica,sans-serif';x.fillText(op.s,tx,op.y+op.h/2+1)}
        else if(lh>op.h+2){x.fillText(ls[0],tx,op.y+op.h/2+1)}
        else{
        const y0=op.vm?op.y+Math.max(0,(op.h-Math.min(ls.length,Math.floor((op.h+2)/lh))*lh)/2):op.y;
        ls.forEach((l,i)=>{if(i*lh+lh<=op.h+2)x.fillText(l,tx,y0+lh/2+i*lh)});}
      }else{const sz=opSize(op);x.font=(op.bold?'bold ':'')+sz+'px Arial,Helvetica,sans-serif';x.fillText(op.s,tx,op.y+op.h/2+1)}
    }
  }
  return cv;
}
function b64ToBytes(b64){const s=atob(b64),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u}
/* PDF mínimo: una imagen JPEG por página */
function pdfFromCanvases(items){
  const enc=new TextEncoder(),chunks=[],offs=[];let len=0;
  const push=b=>{const u=typeof b==='string'?enc.encode(b):b;chunks.push(u);len+=u.length};
  const obj=(n,fn)=>{offs[n]=len;push(n+' 0 obj\n');fn();push('\nendobj\n')};
  push('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  const n=items.length,imgs=items.map(it=>b64ToBytes(it.cv.toDataURL('image/jpeg',0.92).split(',')[1]));
  obj(1,()=>push('<< /Type /Catalog /Pages 2 0 R >>'));
  obj(2,()=>push('<< /Type /Pages /Count '+n+' /Kids ['+items.map((_,i)=>(3+i*3)+' 0 R').join(' ')+'] >>'));
  items.forEach((it,i)=>{
    const p=3+i*3,c=p+1,im=p+2,w=it.wpt,h=it.hpt;
    obj(p,()=>push('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+w.toFixed(2)+' '+h.toFixed(2)+'] /Resources << /XObject << /Im0 '+im+' 0 R >> >> /Contents '+c+' 0 R >>'));
    const cs='q '+w.toFixed(2)+' 0 0 '+h.toFixed(2)+' 0 0 cm /Im0 Do Q';
    obj(c,()=>push('<< /Length '+cs.length+' >>\nstream\n'+cs+'\nendstream'));
    obj(im,()=>{push('<< /Type /XObject /Subtype /Image /Width '+it.cv.width+' /Height '+it.cv.height+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+imgs[i].length+' >>\nstream\n');push(imgs[i]);push('\nendstream')});
  });
  const xr=len,tot=3+n*3;
  push('xref\n0 '+tot+'\n0000000000 65535 f \n');
  for(let i=1;i<tot;i++)push(String(offs[i]).padStart(10,'0')+' 00000 n \n');
  push('trailer\n<< /Size '+tot+' /Root 1 0 R >>\nstartxref\n'+xr+'\n%%EOF');
  return new Blob(chunks,{type:'application/pdf'});
}
/* v8.9.3: imagen JPG a partir de las mismas hojas del PDF, a la misma resolución (200 ppp) o más; varias hojas van una debajo de otra */
async function pagesToJpg(pages,dpi){
  dpi=dpi||200;const cvs=[];for(const pg of pages)cvs.push(await renderPage(pg,dpi));
  if(!cvs.length)throw new Error('sin hojas');
  const blobOf=c=>new Promise((res,rej)=>c.toBlob(b=>b?res(b):rej(new Error('jpg')),'image/jpeg',0.95));
  if(cvs.length===1)return blobOf(cvs[0]);
  const G=Math.round(dpi/6),W=Math.max(...cvs.map(c=>c.width)),H=cvs.reduce((s,c)=>s+c.height,0)+G*(cvs.length+1);
  /* límite de un lienzo del navegador: si no cabe, se reduce lo justo */
  const k=Math.min(1,16000/H,Math.sqrt(120e6/((W+2*G)*H)));
  const cv=document.createElement('canvas');cv.width=Math.round((W+2*G)*k);cv.height=Math.round(H*k);
  const x=cv.getContext('2d');x.fillStyle='#d9dde1';x.fillRect(0,0,cv.width,cv.height);x.imageSmoothingQuality='high';
  let y=G;cvs.forEach(c=>{x.drawImage(c,Math.round((G+(W-c.width)/2)*k),Math.round(y*k),Math.round(c.width*k),Math.round(c.height*k));y+=c.height+G});
  return blobOf(cv);
}
async function pagesToPdf(pages){
  const items=[];
  for(const pg of pages){const cv=await renderPage(pg,200);items.push({cv:cv,wpt:pg.w*72/DPI,hpt:pg.h*72/DPI})}
  return pdfFromCanvases(items);
}
/* PowerPoint editable: cada operación es una forma o un cuadro de texto que se puede corregir */
async function pagesToPptx(pages,title){
  if(typeof PptxGenJS==='undefined')throw new Error('pptx');
  const px=new PptxGenJS();px.defineLayout({name:'DOC',width:pages[0].w/DPI,height:pages[0].h/DPI});px.layout='DOC';
  px.author=APP_NAME;px.title=title||'Documento';
  const I=v=>v/DPI,hex=c=>String(c||'000000').replace('#','');
  for(const pg of pages){
    const s=px.addSlide();s.background={color:'FFFFFF'};
    for(const op of pg.ops){
      if(op.t==='r'){
        const o={x:I(op.x),y:I(op.y),w:I(op.w),h:I(op.h)};
        o.fill=op.fill?{color:hex(op.fill)}:{type:'none'};
        o.line=op.line?{color:hex(op.line),width:(op.lw||2)*72/DPI}:{type:'none'};
        if(op.rad){o.rectRadius=op.rad/DPI;s.addShape(px.ShapeType.roundRect,o)}else s.addShape(px.ShapeType.rect,o);
      }else if(op.t==='l'){
        s.addShape(px.ShapeType.line,{x:I(op.x),y:I(op.y),w:I(op.w),h:I(op.h),line:{color:hex(op.line),width:(op.lw||2)*72/DPI}});
      }else if(op.t==='i'){
        if(op.b64)s.addImage({data:'data:image/jpeg;base64,'+op.b64,x:I(op.x),y:I(op.y),w:I(op.w),h:I(op.h)});
      }else if(op.t==='t'&&op.s!==''){
        const sz=op.wrap?op.size:opSize(op);
        s.addText(String(op.s),{x:I(op.x),y:I(op.y),w:I(op.w),h:I(op.h),fontFace:'Arial',fontSize:Math.max(6,Math.round(sz*72/DPI*2)/2),bold:!!op.bold,color:hex(op.color||'#111111'),align:op.align||'left',valign:op.wrap?'top':'middle',margin:[0,3,0,3],wrap:!!op.wrap,fit:'none'});
      }
    }
  }
  try{return await px.write({outputType:'blob'})}catch(e){return await px.write('blob')}
}

/* ===== Manifiesto (formato Citrilar / JC Cítricos): una sola hoja; en Datos de la carga va una columna por calidad y tipo de empaque (hasta 8) ===== */
const Q_COL={'1':'1ERA','1.5':'1½'};
function manCols(m,v){
  const S=docSrc(m,'man',v),z=S.z,src=S.src;
  const tot=L=>CAL.reduce((a,c)=>a+((src[L]||{})[c.k]||0),0);
  const found=TIPO_K.filter(t=>tot(lineKey('1',t))||tot(lineKey('1.5',t))),ts=found.length?found:['RPC'],cols=[];
  ts.forEach(t=>['1','1.5'].forEach(q=>{const L=lineKey(q,t),n=tot(L);if(n)cols.push({t:t,q:q,v:src[L]||{},n:n})}));
  if(!cols.length)cols.push({t:ts[0],q:'1',v:{},n:0}); /* solo salen las calidades que llevan cajas */
  const rows=CAL_ASC.filter(k=>cols.some(c=>(c.v[k]||0)>0)),byT={};
  ts.forEach(t=>{byT[t]=cols.filter(c=>c.t===t).reduce((a,c)=>a+c.n,0)});
  const ta=cols.filter(c=>c.q==='1').reduce((a,c)=>a+c.n,0),tb=cols.filter(c=>c.q==='1.5').reduce((a,c)=>a+c.n,0);
  return {cols:cols,rows:rows,types:ts,byT:byT,ta:ta,tb:tb,t:ta+tb,fromPal:!!z.nPal,nPal:z.nPal,from:S.from};
}
function manCant(m,C,auto,v){
  const u=auto?'':String(dvv(m,'cantTxt',v)||'').trim();if(u)return u;
  const p=[];if(C.ta)p.push(fmt(C.ta)+' CALIDAD PRIMERA');if(C.tb)p.push(fmt(C.tb)+' CALIDAD UNO Y MEDIO');
  return p.join(' Y ')+(C.t&&C.types.length===1?' EN '+TIPO_L[C.types[0]].toUpperCase():'');
}
function manTypesTxt(C){return C.types.filter(t=>C.byT[t]).map(t=>TIPO_L[t].toUpperCase()+': '+fmt(C.byT[t])).join('   ')}
/* tabla de Datos de la carga: una columna por calidad y tipo de empaque (la usan el manifiesto y el manifiesto interno) */
function cargaOps(C,T,R,ops,x,y,w,h,tamW,yTot,G,o2){
  o2=o2||{};const n=C.cols.length,multi=C.types.length>1,LC=o2.ink||G;
  if(o2.box!==false)R(x,y,w,h,{line:G,lw:3});
  if(o2.bar!==false){R(x,y,w,56,{fill:G});T('DATOS DE LA CARGA',x,y,w,56,{size:30,bold:true,color:'#ffffff',align:'center'})}
  else T('DATOS DE LA CARGA',x,y+10,w,46,{size:30,bold:true,color:LC,align:'center'});
  const x0=x+20+tamW,cw=(x+w-20-x0)/n,cx=i=>x0+i*cw,hy=y+70;
  T('Tamaño',x+20,multi?hy+28:hy,tamW,44,{size:30,color:LC,bold:true,min:16});
  if(multi){C.types.forEach(t=>{const idx=C.cols.map((c,i)=>c.t===t?i:-1).filter(i=>i>=0);if(!idx.length)return;const a=idx[0],b=idx[idx.length-1];
    T(TIPO_L[t].toUpperCase(),cx(a),hy,cw*(b-a+1),30,{size:22,bold:true,color:LC,align:'center',min:12});
    ops.push({t:'l',x:cx(a)+8,y:hy+32,w:cw*(b-a+1)-16,h:0,line:G,lw:2})})}
  C.cols.forEach((c,i)=>T(Q_COL[c.q],cx(i),multi?hy+36:hy,cw,40,{size:n>4?24:28,color:LC,bold:true,align:'center',min:12}));
  const r0=hy+(multi?92:60),avail=yTot-6-r0,step=Math.min(80,Math.floor(avail/Math.max(1,C.rows.length))),fs=Math.max(18,Math.min(34,Math.round(step*0.5)));
  C.rows.forEach((k,j)=>{const ry=r0+j*step;
    T(CAL_LAB[k],x+20,ry,tamW,step-4,{size:Math.min(32,fs),color:LC,bold:true,min:14});
    C.cols.forEach((c,i)=>{const v=c.v[k]||0;T(v?fmt(v):'',cx(i),ry,cw,step-4,{size:fs,bold:true,align:'center',min:12})})});
  ops.push({t:'l',x:x+20,y:yTot-4,w:w-40,h:0,line:G,lw:3});
  T('TOTAL',x+20,yTot,tamW,50,{size:32,color:LC,bold:true,min:16});
  C.cols.forEach((c,i)=>T(c.n?fmt(c.n):'',cx(i),yTot,cw,50,{size:n>4?28:34,bold:true,align:'center',min:14}));
}
/* Comentarios y Certificado: si están vacíos, el renglón queda en blanco (sin el enunciado) */
function blankLab(k,V){return (k==='coment'||k==='cert')&&!String(V(k)||'').trim()}
async function manifestPages(o,v){
  if(v===undefined)v='';const m=docMain(o),V=k=>dvv(m,k,v),C=manCols(m,v),lg=await loadLogoData(m.emp),n=C.cols.length,G='#2f7d3a',INK='#111111',W='#ffffff',ops=[];
  const R=(x,y,w,h,p)=>ops.push(Object.assign({t:'r',x,y,w,h},p));
  const T=(s,x,y,w,h,p)=>ops.push(Object.assign({t:'t',s:s==null?'':String(s),x,y,w,h,size:28,color:INK},p));
  /* encabezado como la hoja impresa: logotipo grande a la izquierda y membrete centrado a la derecha */
  if(lg){const k=Math.min(520/lg.w,240/lg.h),lw=lg.w*k,lh=lg.h*k;ops.push({t:'i',b64:lg.b64,x:60,y:30+(240-lh)/2,w:lw,h:lh})}
  T(V('h1'),620,92,560,46,{size:34,bold:true,color:G,align:'center'});T(V('h2'),620,138,560,42,{size:32,color:G,bold:true,align:'center'});T(V('h3'),620,180,560,42,{size:32,color:G,bold:true,align:'center'});
  R(60,290,1155,56,{fill:G});T('MANIFIESTO',60,290,1155,56,{size:36,bold:true,color:W,align:'center'});
  R(60,350,1155,250,{line:G,lw:3});
  T('Fecha de salida',80,356,400,34,{size:28,color:G,bold:true});T(fechaLarga(V('salida')),80,390,540,40,{size:26,bold:true});
  T('Fecha de llegada',640,356,400,34,{size:28,color:G,bold:true});T(fechaLarga(V('llegada')),640,390,540,40,{size:26,bold:true});
  T('Compañía',80,442,240,44,{size:28,color:G,bold:true});T(V('cliente'),320,442,390,44,{size:28,bold:true,min:16});
  T('No. de Factura',80,498,240,44,{size:28,color:G,bold:true});T(V('factura'),320,498,390,44,{size:28,bold:true,min:16});
  T('Cantidad de Cajas',80,552,260,40,{size:28,color:G,bold:true});T(manCant(m,C,0,v),340,552,860,40,{size:24,bold:true,min:14});
  /* P.O.: la línea del cliente a la izquierda del recuadro; el recuadro con encabezado del color de la empresa y letras blancas */
  const PC=G; /* el naranja es solo del manifiesto interno de Citrilar */
  T(V('poLinea'),720,474,230,52,{size:26,bold:true,align:'right',min:14});
  R(965,430,235,112,{line:PC,lw:3});R(965,430,235,40,{fill:PC});T('P.O.',965,430,235,40,{size:26,bold:true,color:W,align:'center'});
  T(V('poCli'),965,472,235,66,{size:38,bold:true,align:'center',min:16});
  /* encabezado de columnas: el tipo de empaque arriba (si hay más de uno) y la calidad abajo */
  const multi=C.types.length>1;
  function carga(x,y,w,h,tamW,yTot){cargaOps(C,T,R,ops,x,y,w,h,tamW,yTot,G)}
  const field=(l,k,x,y,w)=>{T(l,x,y,w,36,{size:26,color:G,bold:true});T(V(k),x,y+38,w,50,{size:30,bold:true})};
  if(n<=3){
    /* como la hoja original: carga y transporte lado a lado */
    carga(60,630,560,730,n===3?150:190,1300);
    R(655,630,560,730,{line:G,lw:3});R(655,630,560,56,{fill:G});T('DATOS DEL TRANSPORTE',655,630,560,56,{size:30,bold:true,color:W,align:'center'});
    [['Línea Transportista','linea',704],['Nombre del Operador','operador',820],['Placas del Tractor','placasT',936],['Placas del Thermo','placasF',1052]].forEach(a=>field(a[0],a[1],675,a[2],520));
    if(String(V('coment')||'').trim())T('Comentarios',675,1168,520,36,{size:26,color:G,bold:true});T(V('coment'),675,1208,520,140,{size:26,bold:true,wrap:true});
    R(60,1390,1155,245,{line:G,lw:3});T('VARIOS',60,1396,1155,40,{size:30,bold:true,color:G,align:'center'});
    [['CÓDIGO ALPHA','alpha',1436],['CÓDIGO CAAT','caat',1482],['NÚMERO ECONÓMICO','eco',1528],['CERTIFICADO','cert',1574]].forEach(a=>{
      if(blankLab(a[1],V))return;T(a[0],80,a[2],330,44,{size:24,color:G,bold:true});T(V(a[1]),410,a[2],330,44,{size:28,bold:true});
    });
    /* v8.18: el total va pegado a su etiqueta (antes quedaba hasta el borde derecho) */
    T('TOTAL DE CAJAS:  '+(C.t?fmt(C.t):''),770,1450,430,50,{size:31,bold:true,min:18});
    T(manTypesTxt(C),770,1506,430,56,{size:multi?28:36,bold:true,min:16});
  }else{
    /* de 4 a 8 columnas: la carga ocupa todo el ancho; transporte y varios van abajo, lado a lado */
    carga(60,630,1155,600,170,1170);
    const y=1252;
    R(60,y,560,383,{line:G,lw:3});R(60,y,560,52,{fill:G});T('DATOS DEL TRANSPORTE',60,y,560,52,{size:28,bold:true,color:W,align:'center'});
    [['Línea Transportista','linea'],['Nombre del Operador','operador'],['Placas del Tractor','placasT'],['Placas del Thermo','placasF'],['Comentarios','coment']].forEach((a,i)=>{
      const ry=y+62+i*63;if(blankLab(a[1],V))return;T(a[0],80,ry,520,26,{size:21,color:G,bold:true});T(V(a[1]),80,ry+26,520,34,{size:26,bold:true,min:14});
    });
    R(655,y,560,383,{line:G,lw:3});R(655,y,560,52,{fill:G});T('VARIOS',655,y,560,52,{size:28,bold:true,color:W,align:'center'});
    [['CÓDIGO ALPHA','alpha'],['CÓDIGO CAAT','caat'],['NÚMERO ECONÓMICO','eco'],['CERTIFICADO','cert']].forEach((a,i)=>{
      const ry=y+64+i*46;if(blankLab(a[1],V))return;T(a[0],675,ry,260,42,{size:22,color:G,bold:true});T(V(a[1]),935,ry,260,42,{size:26,bold:true,min:14});
    });
    ops.push({t:'l',x:675,y:y+252,w:520,h:0,line:G,lw:2});
    T('TOTAL DE CAJAS:  '+(C.t?fmt(C.t):''),675,y+260,520,50,{size:31,bold:true,min:18});
    T(manTypesTxt(C),675,y+316,520,50,{size:24,bold:true,min:14});
  }
  return [{w:1275,h:1650,ops:ops}];
}

/* ===== Manifiesto interno de cada empresa en México: Vera Limes (verde) y Citrilar (naranja), con el limón de fondo ===== */
const DOC_MX={VL:{name:'EXPORTADORA DE CÍTRICOS VERA LIMES S.A. DE C.V.',rfc:'ECV170817C71',line:'#6aa636',ink:'#14304f'},EC:{name:'EXPORTADORA CITRILAR S.A. DE C.V.',rfc:'ECI061103G4A',line:'#e8692e',ink:'#4b5a1e'}};
const DIR_MX=['Carretera Federal Córdoba, Veracruz km. 56.6 S/N','Rancho Copalillo Cuitláhuac, Veracruz C.P. 94910'];
async function internoPages(o){
  const m=docMain(o),V=k=>dv(m,k),X=DOC_MX[m.emp]||DOC_MX.VL,G=X.line,K=X.ink,C=manCols(m),ops=[];
  const lg=await asset(LOGO[m.emp]).catch(()=>null),bg=await asset('img/lemon-bg.jpg').catch(()=>null);
  const R=(x,y,w,h,p)=>ops.push(Object.assign({t:'r',x,y,w,h},p));
  const T=(s,x,y,w,h,p)=>ops.push(Object.assign({t:'t',s:s==null?'':String(s),x,y,w,h,size:28,color:'#111111'},p));
  if(bg)ops.push({t:'i',b64:bg.b64,x:405,y:750,w:834,h:864});
  if(lg){const k=Math.min(440/lg.w,190/lg.h),w=lg.w*k,h=lg.h*k;ops.push({t:'i',b64:lg.b64,x:637-w/2,y:28+(190-h)/2,w:w,h:h})}
  T(X.name,37,228,1200,40,{size:30,bold:true,color:K,align:'center'});
  T('R.F.C. '+X.rfc+'  '+DIR_MX[0],37,270,1200,32,{size:24,color:K,align:'center'});
  T(DIR_MX[1],37,302,1200,32,{size:24,color:K,align:'center'});
  R(37,350,1200,52,{line:G,lw:3,rad:18});T('MANIFIESTO',37,350,1200,52,{size:34,bold:true,color:K,align:'center'});
  R(37,418,1200,232,{line:G,lw:3,rad:20});
  [['FECHA:',fechaLarga(V('salida'))],['COMPAÑÍA:',V('cliente')],['PO No.:',V('poCli')],['CANTIDAD DE CAJAS:',manCant(m,C)]].forEach((a,i)=>{
    const y=436+i*52;T(a[0],60,y,300,44,{size:26,bold:true,color:K});T(a[1],365,y,520,44,{size:i===3?22:26,bold:true,min:14});
  });
  R(915,434,295,124,{line:G,lw:3,rad:16});T('No. de Viaje',915,438,295,40,{size:28,bold:true,color:K,align:'center'});
  ops.push({t:'l',x:915,y:480,w:295,h:0,line:G,lw:3});T(V('viaje'),915,488,295,62,{size:36,bold:true,align:'center'});
  R(37,666,750,948,{line:G,lw:3,rad:20});
  cargaOps(C,T,R,ops,37,666,750,948,C.cols.length>4?120:150,1540,G,{box:false,bar:false,ink:K});
  T('DATOS DEL TRANSPORTE',805,676,420,46,{size:30,bold:true,color:K,align:'center'});
  [['LÍNEA TRANSPORTISTA','linea',760],['NOMBRE DEL OPERADOR','operador',894],['PLACAS DEL TRACTOR','placasT',1028],['PLACAS DEL THERMO','placasF',1162]].forEach(a=>{
    T(a[0],820,a[2],400,38,{size:26,bold:true,color:K});T(V(a[1]),820,a[2]+42,400,48,{size:28,bold:true,min:14});
  });
  R(800,1300,437,314,{line:G,lw:3,rad:20});
  [['COD. ALPHA:','alpha'],['COD. CAAT:','caat'],['NUM. ECON:','eco'],['NUM. DE SELLO:','sello']].forEach((a,i)=>{
    const y=1318+i*72;T(a[0],815,y,215,56,{size:24,bold:true,color:K});T(V(a[1]),1030,y,195,56,{size:26,bold:true,min:12});
  });
  return [{w:1275,h:1650,ops:ops}];
}
function openOutInt(){
  const o=cur();if(!o)return;const m=docMain(o),f={},E=EMPS[m.emp];
  f.pdf=async()=>pagesToPdf(await internoPages(o));
  f.pptx=async()=>pagesToPptx(await internoPages(o),'Manifiesto interno');
  openOut({pages:()=>internoPages(o),title:'Manifiesto interno '+E.name+' '+(dv(m,'poCli')||m.cod),base:'ManifiestoInterno_'+fileSafe(E.name)+'_'+fileSafe(dv(m,'poCli')||m.cod),fmts:f});
}

/* ===== Packing List en PDF (el Excel lleva el formato editable) ===== */
function plHeaderOps(m,lg,ops,narrow,v){
  const V=k=>dvv(m,k,v),G='#dce6f1';
  if(lg){const k=Math.min(300/lg.w,130/lg.h);ops.push({t:'i',b64:lg.b64,x:60,y:40,w:lg.w*k,h:lg.h*k})}
  ops.push({t:'t',s:'PACKING LIST',x:60,y:190,w:1120,h:56,size:38,bold:true,color:'#111',align:'center'});
  const rowsH=[['Fecha de salida:',fmtUS(V('salida')),'Hora de salida',V('hora')],['Fecha de llegada:',fmtUS(V('llegada')),'PO# CLIENTE:',V('poCli')],['Proveedor:',V('prov'),'Cliente:',V('cliente')],['Vendedor:',V('vend'),'P. Order:',V('pOrder')],['Tel:',V('tel'),'Num. de sello:',V('sello')]];
  rowsH.forEach((r,i)=>{
    const y=260+i*56;
    (narrow?[[60,170,'l'],[230,190,'v'],[420,150,'l'],[570,196,'v']]:[[60,230,'l'],[290,300,'v'],[590,220,'l'],[810,370,'v']]).forEach((c,j)=>{
      ops.push({t:'r',x:c[0],y:y,w:c[1],h:56,fill:c[2]==='l'?G:null,line:'#000',lw:2});
      ops.push({t:'t',s:r[j],x:c[0],y:y,w:c[1],h:56,size:c[2]==='l'?(narrow?20:24):(narrow?24:28),bold:true,color:'#111',align:c[2]==='l'?'left':'center',min:12});
    });
  });
  return 260+5*56+30;
}
/* v8.26: packing list de una venta: un renglón por lugar del thermo; sus tarimas llevan su número consecutivo del viaje y las de otras ventas van en gris, sin número */
function plRowsV(m,z,v){return plRows(z).map((r,i)=>palV(m,z.t.tarimas[i])===v?r:{n:'',empty:true,other:true})}
function plCtx(m,v){const z0=trazCalc(m),mv=v!=null&&multiV(m);return {z0:z0,mv:mv,z:mv?Object.assign({},z0,{t:Object.assign({},z0.t,{tarimas:palsOfV(m,v)})}):z0,rows:mv?plRowsV(m,z0,v):plRows(z0)}}
async function packingPages(o,v){
  if(v===undefined)v='';const m=docMain(o),X=plCtx(m,v),z=X.z,all=X.rows,rows=all.filter(r=>!r.empty),lg=await loadLogoData(m.emp),tr=await plTrailer(m,X.mv?v:null),pages=[];
  /* con la foto del tráiler la tabla va a la izquierda, una fila por tarima a la altura de su lugar en la caja */
  const COLS=tr?[[60,100,'No. Tarima'],[160,110,'Producto'],[270,200,'Tamaño'],[470,100,'RPC/CTN'],[570,110,'Calidad'],[680,86,'No. CAJAS']]
    :[[60,130,'No. Tarima'],[190,170,'Producto'],[360,380,'Tamaño'],[740,150,'RPC/CTN'],[890,170,'Calidad'],[1060,120,'No. CAJAS']];
  const RH=tr?36:54,TW=COLS[5][0]+COLS[5][1];
  let ops=[],y=plHeaderOps(m,lg,ops,!!tr,v);
  const head=()=>{COLS.forEach(c=>{ops.push({t:'r',x:c[0],y:y,w:c[1],h:56,fill:'#dce6f1',line:'#000',lw:2});ops.push({t:'t',s:c[2],x:c[0],y:y,w:c[1],h:56,size:tr?18:22,bold:true,color:'#111',align:'center',min:12})});y+=56};
  head();
  const ph=tr?trailerOps(ops,tr,1180-tr.w*2*RH/tr.p,y,RH):null;
  const list=(X.mv?all:rows).slice();if(tr)for(let i=list.length;i<tr.n;i++)list.push({n:X.mv?'':i+1,empty:true});
  list.forEach(r=>{
    (r.empty?[r.n,'','','','','']:[r.n,'LIMES',r.tam,r.tipo,r.cal,r.cajas]).forEach((v,j)=>{
      ops.push({t:'r',x:COLS[j][0],y:y,w:COLS[j][1],h:RH,line:'#000',lw:2,fill:r.other?'#d5d9df':null});
      ops.push({t:'t',s:v,x:COLS[j][0],y:y,w:COLS[j][1],h:RH,size:tr?(j===2&&String(v).length>10?18:24):(j===2&&String(v).length>16?22:28),bold:true,color:r.empty?'#888':'#111',align:'center',min:12});
    });y+=RH;
  });
  const totC=rows.reduce((a,r)=>a+r.cajas,0);
  ops.push({t:'r',x:60,y:y,w:TW-60-COLS[5][1],h:56,fill:'#dce6f1',line:'#000',lw:2});ops.push({t:'t',s:'TOTAL DE CAJAS',x:60,y:y,w:TW-70-COLS[5][1],h:56,size:26,bold:true,color:'#111',align:'right'});
  ops.push({t:'r',x:COLS[5][0],y:y,w:COLS[5][1],h:56,line:'#000',lw:2});ops.push({t:'t',s:fmt(totC),x:COLS[5][0],y:y,w:COLS[5][1],h:56,size:28,bold:true,color:'#111',align:'center'});y+=56+34;
  if(ph)y=Math.max(y,ph.bottom+24);
  /* resumen: una tabla por calidad (total, calibre, cajas) y a la derecha tarimas, cajas y pesos */
  const CR=plCalRes(z),rh=40,cx=[60,210,350],cw=[150,140,230],y0=y;
  CR.forEach(g=>{
    ops.push({t:'t',s:g.label,x:cx[0],y:y,w:cw[0]+cw[1]+cw[2],h:30,size:20,bold:true,color:'#111',align:'center'});y+=32;
    g.rows.forEach((r,i)=>{
      const last=i===g.rows.length-1;
      ops.push({t:'r',x:cx[0],y:y,w:cw[0],h:rh,line:'#000',lw:2,fill:last?'#8497b0':null});
      if(i===0)ops.push({t:'t',s:'TOTAL',x:cx[0]+8,y:y,w:cw[0]-16,h:rh,size:22,bold:true,color:'#111'});
      if(last)ops.push({t:'t',s:fmt(g.tot),x:cx[0]+8,y:y,w:cw[0]-16,h:rh,size:22,bold:true,color:'#111',align:'right'});
      ops.push({t:'r',x:cx[1],y:y,w:cw[1],h:rh,line:'#000',lw:2});ops.push({t:'t',s:r.cal,x:cx[1],y:y,w:cw[1],h:rh,size:22,color:'#111',align:'center'});
      ops.push({t:'r',x:cx[2],y:y,w:cw[2],h:rh,line:'#000',lw:2});ops.push({t:'t',s:fmt(r.n),x:cx[2]+8,y:y,w:cw[2]-16,h:rh,size:22,color:'#111',align:'right'});
      y+=rh;
    });
    y+=30;
  });
  [['Total tarimas:',String(rows.length)],['Total cajas:',fmt(totC)],['Peso Neto',''],['Peso Bruto:','']].forEach((a,i)=>{
    const yy=y0+32+i*rh;
    ops.push({t:'r',x:700,y:yy,w:240,h:rh,line:'#000',lw:2});ops.push({t:'t',s:a[0],x:700,y:yy,w:240,h:rh,size:22,bold:true,color:'#111',align:'center'});
    ops.push({t:'l',x:740,y:yy+rh-8,w:160,h:0,line:'#111',lw:1});
    ops.push({t:'r',x:940,y:yy,w:240,h:rh,line:'#000',lw:2});ops.push({t:'t',s:a[1],x:950,y:yy,w:220,h:rh,size:22,bold:true,color:'#111'});
  });
  pages.push({w:1240,h:1754,ops:fitOnePage(ops,1240,1754,40)});
  return pages;
}
async function buildPackingWb(o,v){
  TM=tipoMapFor(o);if(v===undefined)v='';
  const m=docMain(o),X=plCtx(m,v),z=X.z,V=k=>dvv(m,k,v),wb=newWb(),logo=await asset(LOGO_F2[m.emp]);
  const ph=await plTrailer(m,X.mv?v:null),rows=X.mv?X.rows.slice():X.rows;if(X.mv&&ph)for(let i=rows.length;i<ph.n;i++)rows.push({n:'',empty:true});
  XL.addPacking(wb,{o:m,logo:logo,trailer:ph,sheetName:V('poCli')||m.emb||m.cod,calRes:plCalRes(z),
    hdr:{salida:V('salida'),hora:V('hora'),llegada:V('llegada'),proveedor:V('prov'),cliente:V('cliente'),vendedor:V('vend'),tel:V('tel'),poCliente:V('poCli'),pOrder:V('pOrder'),sello:V('sello')},
    rows:rows});
  return wb;
}

/* ===== PDF del registro y de la trazabilidad (tablas completas y legibles) ===== */
function tablePages(sp){
  const land=sp.land,W=land?1754:1240,H=land?1240:1754,M=50,pages=[];
  let ops=[],y=M;
  const newPage=()=>{pages.push({w:W,h:H,ops:ops});ops=[];y=M};
  const TX=(s,x,yy,w,h,p)=>ops.push(Object.assign({t:'t',s:s==null?'':String(s),x,y:yy,w,h,size:24,color:'#111'},p));
  if(sp.logo){const k=Math.min(260/sp.logo.w,100/sp.logo.h);ops.push({t:'i',b64:sp.logo.b64,x:W-M-sp.logo.w*k,y:y,w:sp.logo.w*k,h:sp.logo.h*k})}
  TX(sp.title,M,y,W-M*2-280,52,{size:38,bold:true});y+=56;
  if(sp.sub){TX(sp.sub,M,y,W-M*2-280,36,{size:24,color:sp.subColor||'#444'});y+=40}
  y=Math.max(y,M+110);
  if(sp.pre)y=sp.pre(ops,y,W,M,TX);
  else if(sp.kv&&sp.kv.length){
    const cols=land?4:3,cw=(W-M*2)/cols;
    sp.kv.forEach((a,i)=>{const cx=M+(i%cols)*cw,cy=y+Math.floor(i/cols)*62;TX(a[0],cx,cy,cw-10,24,{size:18,color:'#666'});TX(a[1]||'—',cx,cy+22,cw-10,34,{size:24,bold:true})});
    y+=Math.ceil(sp.kv.length/cols)*62+16;
  }
  sp.tables.forEach(t=>{
    if(!t.rows.length)return;
    const tw=W-M*2,sum=t.w.reduce((a,b)=>a+b,0),xs=[];let ax=M;t.w.forEach(w=>{xs.push(ax);ax+=w/sum*tw});xs.push(M+tw);
    const rh=t.rh||44,fs=t.fs||22;
    const header=()=>{
      ops.push({t:'r',x:M,y:y,w:tw,h:rh+4,fill:'#1b2c46'});
      t.head.forEach((h,i)=>TX(h,xs[i],y,xs[i+1]-xs[i],rh+4,{size:fs-2,bold:true,color:'#ffffff',align:i===0?'left':'center',min:12}));y+=rh+4;
    };
    /* una tabla que cabe completa en una hoja no se parte: pasa entera a la siguiente */
    const need=(t.title?46:0)+rh+4+t.rows.length*rh;
    if(y+rh*3>H-M||(y+need>H-M&&need<=H-M*2-60&&y>M+200))newPage();
    if(t.title){TX(t.title,M,y,tw,40,{size:28,bold:true});y+=46}
    header();
    t.rows.forEach((r,ri)=>{
      if(y+rh>H-M){newPage();TX((t.title||sp.title)+' (continuación)',M,y,tw,36,{size:22,bold:true,color:'#555'});y+=42;header()}
      const bold=r.bold,cells=r.c||r;
      if(bold)ops.push({t:'r',x:M,y:y,w:tw,h:rh,fill:'#e9eef4'});
      else if(ri%2)ops.push({t:'r',x:M,y:y,w:tw,h:rh,fill:'#f6f8fa'});
      cells.forEach((c,i)=>TX(c,xs[i],y,xs[i+1]-xs[i],rh,{size:fs,bold:!!bold,align:i===0||(t.left&&t.left.indexOf(i)>=0)?'left':'center',min:12}));
      ops.push({t:'l',x:M,y:y+rh,w:tw,h:0,line:'#cfd6de',lw:1});y+=rh;
    });
    y+=34;
  });
  if(sp.foot)TX(sp.foot,M,Math.min(y,H-M-30),W-M*2,30,{size:20,color:'#666'});
  pages.push({w:W,h:H,ops:ops});
  return pages;
}
/* v8.8: el PDF del Registro de empaque es el mismo Excel impreso: cada hoja (primera, 1.5) completa en una página */
async function registroPages(o){const wb=await buildRegistroWb(o);return xlPages(wb,wb.worksheets)}
/* ---------- v8.7 · hoja de Excel → páginas de PDF ----------
   Dibuja una hoja de ExcelJS tal como se imprime (área de impresión, anchos, altos, celdas combinadas, rellenos, bordes,
   letra e imágenes), igual que «Exportar selección a PDF» en Excel. Así el PDF siempre sale igual al Excel. */
const XP={W:1240,H:1754,M:45};
function xpRange(ws){
  const a=String((ws.pageSetup&&ws.pageSetup.printArea)||'').split(',')[0].replace(/\$/g,'');
  const m=/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/.exec(a);
  const cn=s=>s.split('').reduce((n,ch)=>n*26+ch.charCodeAt(0)-64,0);
  if(m)return {c1:cn(m[1]),r1:+m[2],c2:cn(m[3]),r2:+m[4]};
  return {c1:1,r1:1,c2:Math.max(1,ws.columnCount),r2:Math.max(1,ws.rowCount)};
}
/* ancho de columna de Excel (caracteres) a puntos, como lo imprime Excel con Calibri 11 */
const xpColPt=w=>((w==null?8.43:w)*7+5)*0.75;
const xpRowPt=(ws,r)=>{const h=ws.getRow(r).height;return h==null?15:h};
function xpArgb(c,def){const a=c&&c.argb;return a&&a.length===8?'#'+a.slice(2):def}
function xpNum(v,f){
  if(typeof v!=='number'||!isFinite(v))return v==null?'':String(v);
  const sec=String(f||'General').split(';');let s=sec[0];
  if(sec.length>1&&sec.every(x=>x.trim()===''))return '';
  if(v<0&&sec[1])s=sec[1];else if(v===0&&sec[2])s=sec[2];
  const lit=/^"(.*)"$/.exec(s.trim());if(lit)return lit[1];
  if(/General/i.test(s))return String(Math.round(v*1e6)/1e6);
  const pct=/%/.test(s),d=(/0\.(0+)/.exec(s)||['',''])[1].length,neg=v<0&&!sec[1];
  const x=Math.abs(pct?v*100:v),cur=/\$/.test(s)?'$':'';
  let t=/#,##/.test(s)?x.toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d}):x.toFixed(d);
  return (neg||(v<0&&sec[1]&&/-/.test(s))?'-':'')+cur+t+(pct?'%':'');
}
function xpText(c){
  let v=c.value;
  if(v&&typeof v==='object'){
    if(v.richText)v=v.richText.map(x=>x.text).join('');
    else if('formula' in v||'sharedFormula' in v)v=v.result;
    else if(v instanceof Date)v=v.toISOString().slice(0,10);
    else if(v.text)v=v.text;
    else if(v.error)v=v.error;
  }
  if(v==null)return '';
  return typeof v==='number'?xpNum(v,c.numFmt):String(v);
}
function xpMerges(ws){
  const out=[];Object.keys(ws._merges||{}).forEach(k=>{const m=ws._merges[k];const d=m&&(m.model||m);if(d&&d.top)out.push({t:d.top,l:d.left,b:d.bottom,r:d.right})});return out;
}
/* sheets: hojas de un libro de ExcelJS; devuelve páginas para pagesToPdf (a 150 ppp, A4) */
function xlPages(wb,sheets,opt){
  opt=opt||{};const pages=[];
  (sheets||wb.worksheets).forEach(ws=>{
    const R=xpRange(ws),land=(ws.pageSetup&&ws.pageSetup.orientation)==='landscape',W=land?XP.H:XP.W,H=land?XP.W:XP.H,M=XP.M;
    const cx=[0];for(let c=R.c1;c<=R.c2;c++)cx.push(cx[cx.length-1]+xpColPt(ws.getColumn(c).width));
    const totW=cx[cx.length-1];let s=Math.min((W-2*M)/totW,DPI/72*1.6);
    const ry=[0];for(let r=R.r1;r<=R.r2;r++)ry.push(ry[ry.length-1]+xpRowPt(ws,r));
    /* una sola hoja (Ajustar a 1 página de alto): todo el contenido en la página, como una captura de la selección */
    const PS=ws.pageSetup||{};if(opt.onePage||(PS.fitToPage&&PS.fitToHeight===1))s=Math.min(s,(H-2*M)/ry[ry.length-1]);
    /* filas que repiten arriba de cada página (encabezados de tabla) */
    const rep=(()=>{const m=/^\$?(\d+):\$?(\d+)$/.exec(String((ws.pageSetup&&ws.pageSetup.printTitlesRow)||''));return m?{a:+m[1],b:+m[2]}:null})();
    const merges=xpMerges(ws).filter(m=>m.t>=R.r1&&m.l>=R.c1&&m.t<=R.r2&&m.l<=R.c2);
    const mOf={},skip={};merges.forEach(m=>{mOf[m.t+':'+m.l]=m;for(let r=m.t;r<=m.b;r++)for(let c=m.l;c<=m.r;c++)if(r!==m.t||c!==m.l)skip[r+':'+c]=1});
    const X=c=>M+cx[c-R.c1]*s;
    /* páginas: cortes en límites de fila sin partir celdas combinadas */
    const avail=(H-2*M)/s,breaks=[];let start=R.r1;
    const repH=rep?ry[rep.b-R.r1+1]-ry[rep.a-R.r1]:0;
    while(start<=R.r2){
      const lim=(breaks.length&&rep?avail-repH:avail);let r=start,acc=0;
      while(r<=R.r2&&acc+xpRowPt(ws,r)<=lim+0.01){acc+=xpRowPt(ws,r);r++}
      if(r===start)r++;
      /* no cortar una celda combinada: retrocede al inicio de la combinación */
      let end=r-1;const cut=merges.find(m=>m.t<=end&&m.b>end&&m.t>start);if(cut)end=cut.t-1;
      breaks.push([start,end]);start=end+1;
    }
    const imgs=(ws.getImages?ws.getImages():[]).map(im=>{const m=wb.getImage(+im.imageId);const tl=im.range.tl;
      const col=(tl.nativeCol!=null?tl.nativeCol:Math.floor(tl.col))+1,row=(tl.nativeRow!=null?tl.nativeRow:Math.floor(tl.row))+1;
      const ox=(tl.nativeColOff||0)/12700,oy=(tl.nativeRowOff||0)/12700,ext=im.range.ext||{width:0,height:0};
      return {b64:m&&(m.base64||'').replace(/^data:[^,]*,/,''),col:col,row:row,ox:ox,oy:oy,w:ext.width*0.75,h:ext.height*0.75}}).filter(x=>x.b64);
    breaks.forEach(([a,b],pi)=>{
      const ops=[];let off=0;
      const rows=[];if(pi>0&&rep){for(let r=rep.a;r<=rep.b;r++)rows.push(r)}for(let r=a;r<=b;r++)rows.push(r);
      const Y={};rows.forEach(r=>{Y[r]=M+off*s;off+=xpRowPt(ws,r)});
      const yEnd=M+off*s,rowIn=r=>Y[r]!=null;
      const cellBox=(r,c)=>{const m=mOf[r+':'+c];const r2=m?Math.min(m.b,b):r,c2=m?m.r:c;let h=0;for(let q=r;q<=r2;q++)if(rowIn(q))h+=xpRowPt(ws,q);return {x:X(c),y:Y[r],w:X(Math.min(c2,R.c2)+1)-X(c),h:h*s,r2:r2,c2:c2}};
      /* rellenos */
      rows.forEach(r=>{for(let c=R.c1;c<=R.c2;c++){if(skip[r+':'+c])continue;const cl=ws.getCell(r,c),f=cl.fill;if(f&&f.type==='pattern'&&f.pattern==='solid'){const bx=cellBox(r,c);ops.push({t:'r',x:bx.x,y:bx.y,w:bx.w,h:bx.h,fill:xpArgb(f.fgColor,'#ffffff')})}}});
      /* bordes */
      const lw=st=>st==='medium'?2.2:st==='thick'?3.2:st==='double'?2.4:1.1;
      const line=(x,y,w,h,b)=>{if(b&&b.style)ops.push({t:'l',x:x,y:y,w:w,h:h,line:xpArgb(b.color,'#000000'),lw:lw(b.style)*s/1.6})};
      rows.forEach(r=>{for(let c=R.c1;c<=R.c2;c++){if(skip[r+':'+c])continue;const m=mOf[r+':'+c],bx=cellBox(r,c),B=ws.getCell(r,c).border||{};
        const Bb=m?(ws.getCell(Math.min(m.b,b),m.l).border||{}):B,Br=m?(ws.getCell(m.t,m.r).border||{}):B;
        line(bx.x,bx.y,bx.w,0,B.top);line(bx.x,bx.y+bx.h,bx.w,0,Bb.bottom||B.bottom);line(bx.x,bx.y,0,bx.h,B.left);line(bx.x+bx.w,bx.y,0,bx.h,Br.right||B.right)}});
      /* textos */
      rows.forEach(r=>{for(let c=R.c1;c<=R.c2;c++){if(skip[r+':'+c])continue;const cl=ws.getCell(r,c),t=xpText(cl);if(t==='')continue;
        const bx=cellBox(r,c),fo=cl.font||{},al=cl.alignment||{},sz=(fo.size||11)*s,wrap=!!al.wrapText||t.indexOf('\n')>=0;
        let w=bx.w,align=al.horizontal||(typeof (cl.value&&cl.value.result!==undefined?cl.value.result:cl.value)==='number'?'right':'left');
        if(align==='centerContinuous')align='center';
        /* como en Excel: el texto a la izquierda sin ajuste se sale a las celdas vacías de la derecha */
        if(!wrap&&align==='left'&&!mOf[r+':'+c]){let c2=c+1;while(c2<=R.c2&&!skip[r+':'+c2]&&!mOf[r+':'+c2]&&xpText(ws.getCell(r,c2))===''){w+=X(c2+1)-X(c2);c2++}}
        ops.push({t:'t',s:t,x:bx.x,y:bx.y,w:w,h:bx.h,size:sz,bold:!!fo.bold,color:xpArgb(fo.color,'#000000'),align:align==='right'?'right':align==='center'?'center':'left',wrap:wrap,vm:al.vertical!=='top',min:Math.max(8,sz*0.7)})}});
      /* imágenes ancladas en la página */
      imgs.forEach(im=>{if(im.row<a||im.row>b||im.col<R.c1||im.col>R.c2+1)return;ops.push({t:'i',b64:im.b64,x:X(im.col)+im.ox*s,y:Y[im.row]+im.oy*s,w:im.w*s,h:im.h*s})});
      if(opt.foot)ops.push({t:'t',s:opt.foot,x:M,y:H-M+4,w:W-2*M,h:30,size:16,color:'#666',align:'right',pgfoot:1});
      pages.push({w:W,h:H,ops:ops,sheet:ws.name});
    });
  });
  /* numeración de todo el documento */
  if(opt.foot&&pages.length>1)pages.forEach((pg,i)=>pg.ops.forEach(o=>{if(o.pgfoot)o.s+=' · página '+(i+1)+' de '+pages.length}));
  return pages;
}
/* tráiler para Excel y PDF: la foto del tractor y, abajo, la caja dibujada con un lugar por tarima (dos por fila) */
const TRC={f:'img/tractor.jpg',W:380,bw:323,top:592,pitch:89.5,sw:125,sh:72,pad:22,std:22};
async function trailerComposite(nPal,mine){
  let tr=null;try{tr=await asset(TRC.f)}catch(e){}
  if(!tr)return null;
  const n=nPal>0?nPal:TRC.std,rows=Math.ceil(n/2),bx=Math.round((TRC.W-TRC.bw)/2),bh=TRC.pad+rows*TRC.pitch;
  const cv=document.createElement('canvas');cv.width=TRC.W;cv.height=Math.round(TRC.top+bh+8);
  const x=cv.getContext('2d');x.fillStyle='#ffffff';x.fillRect(0,0,cv.width,cv.height);
  const im=await imgFromB64(tr.b64);
  /* la caja va primero para que el tractor (quinta rueda) quede encima de su borde */
  const g=x.createLinearGradient(bx,0,bx+TRC.bw,0);g.addColorStop(0,'#8e97a8');g.addColorStop(.06,'#d9dde6');g.addColorStop(.94,'#d9dde6');g.addColorStop(1,'#8e97a8');
  x.fillStyle=g;x.fillRect(bx,TRC.top,TRC.bw,bh);x.strokeStyle='#7d8698';x.lineWidth=3;x.strokeRect(bx+1.5,TRC.top+1.5,TRC.bw-3,bh-3);
  const gap=(TRC.bw-2*TRC.sw)/3;
  for(let i=0;i<rows*2;i++){
    if(mine&&i<n){/* v8.26: packing list de una venta: sus tarimas en azul con su número consecutivo del viaje; las de otras ventas en gris */
      const col=i%2,row=Math.floor(i/2),sx=bx+gap+col*(TRC.sw+gap),sy=TRC.top+TRC.pad/2+row*TRC.pitch+(TRC.pitch-TRC.sh)/2,me=!!mine[i];
      x.fillStyle=me?'#1a5f82':'#c3c9d3';x.fillRect(sx,sy,TRC.sw,TRC.sh);x.strokeStyle=me?'#062236':'#8e97a8';x.lineWidth=2.5;x.strokeRect(sx,sy,TRC.sw,TRC.sh);
      if(me){x.fillStyle='#ffffff';x.font='bold 30px Arial,Helvetica,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(String(i+1),sx+TRC.sw/2,sy+TRC.sh/2+1)}
      continue;
    }
    const col=i%2,row=Math.floor(i/2),sx=bx+gap+col*(TRC.sw+gap),sy=TRC.top+TRC.pad/2+row*TRC.pitch+(TRC.pitch-TRC.sh)/2;
    const used=i<n&&nPal>0;
    x.fillStyle=used?'#1a5f82':(i<n?'#1a5f82':'#e4e8ee');x.fillRect(sx,sy,TRC.sw,TRC.sh);
    x.strokeStyle=used||i<n?'#062236':'#b7bfcc';x.lineWidth=2.5;x.strokeRect(sx,sy,TRC.sw,TRC.sh);
    if(i<n){x.fillStyle='#ffffff';x.font='30px Arial,Helvetica,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(String(i+1),sx+TRC.sw/2,sy+TRC.sh/2+1)}
  }
  if(im)x.drawImage(im,(TRC.W-tr.w*TRC.W/tr.w)/2,0,TRC.W,tr.h*TRC.W/tr.w);
  return {b64:cv.toDataURL('image/jpeg',0.92).split(',')[1],w:cv.width,h:cv.height,boxTop:TRC.top,boxBot:Math.round(TRC.top+bh),photo:true,slots:rows*2};
}
/* v8.7: el PDF del Código de Trazabilidad es la hoja de Excel impresa (misma selección, mismas coordenadas) */
async function trazPdfPages(o){
  const m=docMain(o),wb=await buildTrazWb(m);
  return xlPages(wb,[wb.worksheets[0]]);
}
function resolveName(sh,pk){
  try{const k=resolveProd(sh,pk);if(!k)return pk||'';
    for(const s of sh){const r=compute(s).rows.find(r=>prodKey(s,r.p)===k);if(r)return r.p.nombre||k}
    return k;}catch(e){return pk||''}
}

/* ===== elegir formato y sacar el archivo (WhatsApp o guardar) ===== */
const FMT_LABEL={xlsx:'Excel',pdf:'PDF',jpg:'Imagen JPG',png:'Imagen PNG',pptx:'PowerPoint (editable)'};
function openOut(spec){sheet=Object.assign({kind:'out',busy:null},spec);renderSheet()}
/* vista previa: dibuja las hojas tal como saldrán en el PDF, para revisarlas antes de descargar o enviar */
async function outPrev(){
  const s=sheet;if(!s||s.kind!=='out'||s.busy||!s.pages)return;
  s.busy='prev';renderSheet();
  try{
    const pg=await s.pages(),imgs=[];
    for(const p of pg){const cv=await renderPage(p,110);imgs.push({src:cv.toDataURL('image/jpeg',.85),land:p.w>p.h})}
    if(sheet!==s)return;s.busy=null;s.prev=imgs;renderSheet();
    const el=document.querySelector('.pvw');if(el)el.scrollTop=0;
  }catch(e){if(sheet===s){s.busy=null;renderSheet()}toast('No se pudo preparar la vista previa')}
}
function prevHtml(s){
  const n=s.prev.length,k=s.fmts.pdf?'pdf':Object.keys(s.fmts)[0];
  return `<h3>Vista previa · ${esc(s.title)}</h3><p class="note" style="margin-bottom:8px">${n} ${n===1?'hoja':'hojas'}. Así sale el PDF; si algo no está bien, regresa y corrígelo antes de enviarlo.</p>
<div class="pvw">${s.prev.map((p,i)=>`<figure class="pvp${p.land?' land':''}"><img src="${p.src}" alt="Hoja ${i+1} de ${n}"><figcaption>Hoja ${i+1} de ${n}</figcaption></figure>`).join('')}</div>
<div class="srow2 pvact"><button class="btn" data-act="dx:pvback">Volver</button><button class="btn wa" data-act="dx:wa:${k}" ${s.busy?'disabled':''}>${WA_SVG}<span>WhatsApp</span></button><button class="btn primary" data-act="dx:save:${k}" ${s.busy?'disabled':''}>Descargar ${FMT_LABEL[k]||k}</button></div>`;
}
function outHtml(){
  const s=sheet;if(s.prev)return prevHtml(s);
  const rows=Object.keys(s.fmts).map(k=>`<div class="oline"><div class="ol"><strong>${FMT_LABEL[k]||k}</strong><small>${esc(s.base)}.${k}</small></div><div class="oa"><button class="btn sm wa" data-act="dx:wa:${k}" ${s.busy?'disabled':''}>${WA_SVG}<span>WhatsApp</span></button><button class="btn sm primary" data-act="dx:save:${k}" ${s.busy?'disabled':''}>Descargar</button></div></div>`).join('');
  const pv=s.pages?`<button class="btn pvbtn" data-act="dx:prev" ${s.busy?'disabled':''}>${s.busy==='prev'?'Preparando la vista previa…':'Vista previa'}</button>`:'';
  return `<h3>${esc(s.title)}</h3>${pv}<p class="note" style="margin-bottom:8px">${s.busy&&s.busy!=='prev'?'Preparando el archivo…':(s.note||'Elige el formato y cómo quieres sacarlo.')+' «Descargar» guarda el archivo en el dispositivo'+(isNative()?' (Documentos › '+SAVE_DIR+')':'')+'; WhatsApp abre el menú de compartir.'}</p>${rows}<div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
async function outDo(mode,k){
  const s=sheet;if(!s||s.kind!=='out'||s.busy||!s.fmts[k])return;
  s.busy=k;renderSheet();
  try{
    const blob=await s.fmts[k]();const name=s.base+'.'+k;
    s.busy=null;renderSheet();
    if(mode==='wa')await shareWA(name,blob,s.title,s.title);else await saveFile(name,blob,s.title);
  }catch(e){if(sheet===s){s.busy=null;renderSheet()}toast(k==='pptx'&&typeof PptxGenJS==='undefined'?'PowerPoint no está disponible en esta vista':'No se pudo generar el archivo')}
}
function openOutReg(){
  const o=cur();if(!o)return;const f={};
  if(typeof ExcelJS!=='undefined')f.xlsx=async()=>wbBlob(await buildRegistroWb(o));
  f.pdf=async()=>pagesToPdf(await registroPages(o));
  f.jpg=async()=>pagesToJpg(await registroPages(o),200);
  f.pptx=async()=>pagesToPptx(await registroPages(o),'Registro '+o.cod);
  openOut({pages:()=>registroPages(o),title:'Registro '+o.cod+' · '+(o.emb||''),base:'Registro_'+fileSafe(o.cod),fmts:f});
}
function openOutTraz(){
  const o=cur();if(!o)return;const m=mainOf(o),f={};
  if(typeof ExcelJS!=='undefined')f.xlsx=async()=>wbBlob(await buildTrazWb(m));
  f.pdf=async()=>pagesToPdf(await trazPdfPages(m));
  f.pptx=async()=>pagesToPptx(await trazPdfPages(m),'Trazabilidad '+m.cod);
  openOut({pages:()=>trazPdfPages(m),title:'Código de Trazabilidad '+m.cod,base:'Trazabilidad_'+fileSafe(m.emb||m.cod)+(trazCalc(m).borrador?'_BORRADOR':''),fmts:f});
}
function ventaTit(m,v){return multiV(m)?' · '+ventaLab(m,v):''}
function ventaBase(m,v){return multiV(m)?'_M'+ventaN(m,v)+(ventaCli(m,v)?'_'+fileSafe(ventaCli(m,v).split(/\s+/)[0]):''):''}
function openOutMan(){
  const o=cur();if(!o)return;const m=docMain(o),v=docV(m),C=manCols(m,v),f={},po=dvv(m,'poCli',v)||m.cod;
  f.pdf=async()=>pagesToPdf(await manifestPages(o,v));
  f.pptx=async()=>pagesToPptx(await manifestPages(o,v),'Manifiesto');
  openOut({pages:()=>manifestPages(o,v),title:'Manifiesto '+po+ventaTit(m,v),base:'Manifiesto_'+fileSafe(po)+ventaBase(m,v),fmts:f,
    note:'Una sola hoja. Datos de la carga lleva '+C.cols.length+(C.cols.length===1?' columna':' columnas')+': '+C.cols.map(c=>TIPO_L[c.t]+' '+Q_COL[c.q]).join(', ')+'.'});
}
function openOutPl(){
  const o=cur();if(!o)return;const m=docMain(o),v=docV(m),f={};
  if(typeof ExcelJS!=='undefined')f.xlsx=async()=>wbBlob(await buildPackingWb(o,v));
  f.pdf=async()=>pagesToPdf(await packingPages(o,v));
  f.pptx=async()=>pagesToPptx(await packingPages(o,v),'Packing List');
  openOut({pages:()=>packingPages(o,v),title:'Packing List '+(dvv(m,'poCli',v)||m.cod)+ventaTit(m,v),base:'PackingList_'+fileSafe(dvv(m,'poCli',v)||m.emb||m.cod)+ventaBase(m,v),fmts:f});
}
async function prodImgPdf(){
  if(!sheet||!sheet.cv)return;
  const cv=sheet.cv,w=595,h=w*cv.height/cv.width;
  await saveFile('Empaque_'+fileSafe(sheet.name||'productor')+'.pdf',pdfFromCanvases([{cv:cv,wpt:w,hpt:h}]),'Resumen '+(sheet.name||''));
}

/* ===== pantalla de documentos ===== */
/* campos de documentos que se llenan desde Control Logístico */
const DOC_LIST={cliente:'cliente',linea:'transporte',operador:'conductor',eco:'trailer',vend:'vendedor'};
function docLists(m){
  const h=ensureTraz(m).hdr;
  return Object.keys(DOC_LIST).map(k=>{const f=DOC_LIST[k];return `<datalist id="dg-${f}">${catList(f,dv(m,'linea')||h.transporte).map(v=>`<option value="${esc(v)}"></option>`).join('')}</datalist>`}).join('');
}
/* al elegir un dato del catálogo en el documento se completan los que dependen de él */
document.addEventListener('change',e=>{
  const el=e.target;if(!el||!el.dataset||!el.dataset.doc||ro)return;const m=docMain(cur());if(!m)return;
  const k=el.dataset.doc,v=String(el.value||'').trim();if(!v)return;let ch=false;
  const put=(kk,val)=>{val=String(val==null?'':val).trim();if(!val||String(dv(m,kk)||'')===val)return;const hk=DOC2HDR[kk];if(hk){ensureTraz(m).hdr[hk]=val;if(m.docs)delete m.docs[kk]}else{m.docs=m.docs||{};m.docs[kk]=val}ch=true};
  if(k==='linea'){const t=regFind('transportistas',v);if(t){put('caat',t.caat);put('alpha',t.alpha)}}
  if(k==='operador'){const x=regFind('conductores',v);if(x){if(!String(dv(m,'eco')||'').trim()||!regFind('trailers',dv(m,'eco')))put('placasT',x.placas);if(x.transporte&&!String(dv(m,'linea')||'').trim())put('linea',x.transporte)}}
  if(k==='eco'){const x=regFind('trailers',v);if(x){put('placasT',x.placas);if(x.transporte&&!String(dv(m,'linea')||'').trim())put('linea',x.transporte)}}
  if(k==='vend'){const x=regFind('vendedores',v);if(x)put('tel',x.tel)}
  /* el cliente del documento es el del pedido: Registro, Trazabilidad y las hojas 1 y 1.5 */
  if(k==='cliente'&&!docV(m)){setCliente(m,v);ch=true}
  if(ch){touch(m);render()}
});
function docF(m,k,l,type,wide){
  const ls=DOC_LIST[k];return `<label class="fld${wide?' wide':''}" for="d-${k}"><span>${esc(l)}</span><input class="in txt" id="d-${k}" type="${type||'text'}" autocomplete="off" data-doc="${k}"${ls?` list="dg-${ls}"`:''} value="${esc(dvv(m,k,docV(m)))}"${ro?' readonly':''}></label>`;
}
function qtyTable(m,v){
  const C=manCols(m,v);if(!C.rows.length)return '<p class="note">Aún no hay cantidades. Captura el manifiesto en Resumen o las tarimas en Código de Trazabilidad y aquí aparecen solas.</p>';
  const gc=`grid-template-columns:64px repeat(${C.cols.length},minmax(0,1fr))`,multi=C.types.length>1;
  const th=C.cols.map(c=>`<span style="text-align:right">${multi?esc(TIPO_L[c.t])+'<br>':''}${Q_COL[c.q]}</span>`).join('');
  return `<div class="sumbox qtyb mtab"><div class="shead" style="${gc}"><span>Tamaño</span>${th}</div>${C.rows.map(k=>`<div class="srow" style="${gc}"><span class="cl">${esc(CAL_LAB[k])}</span>${C.cols.map(c=>`<span class="mono" style="text-align:right">${c.v[k]?fmt(c.v[k]):'–'}</span>`).join('')}</div>`).join('')}<div class="srow mtot" style="${gc}"><span class="k">Total</span>${C.cols.map(c=>`<span class="mono" style="text-align:right">${fmt(c.n)}</span>`).join('')}</div><div class="totline"><span class="k">Total de cajas</span><b>${fmt(C.t)}</b></div><p class="note" style="margin-top:6px">${esc(manTypesTxt(C))}</p></div>`;
}
function docsView(o){
  docLink(docMain(o));
  const m=docMain(o),v=docV(m),mv=multiV(m),q=docQty(m,null,v),C=manCols(m,v);
  const tabs=`<div class="tabs" role="tablist">${[['man','Manifiesto'],['pl','Packing List']].map(t=>`<button class="tab" role="tab" data-act="dx:tab:${t[0]}" aria-selected="${docTab===t[0]}">${t[1]}</button>`).join('')}</div>`;
  const head=`<section class="label"><div class="lrow"><div><div class="k">Pedido ${esc(m.emp)} · ${esc(m.emb)}</div><div class="big">${esc(m.cod)}</div></div><div style="text-align:right"><span class="chip">${q.fromPal?q.nPal+(q.nPal===1?' tarima':' tarimas'):'Sin tarimas'}</span></div></div></section>`;
  const note=C.from==='man'?`<div class="panel info"><p class="note">Las cantidades salen del manifiesto capturado en Resumen. Puedes ver y generar el manifiesto aunque todavía no esté el código de trazabilidad.</p></div>`:C.from==='pal'?'':`<div class="panel warn"><p class="note">Todavía no hay manifiesto capturado en Resumen ni tarimas. Las cantidades salen de lo empacado; captura el manifiesto en Resumen para que salga completo.</p></div>`;
  let body='';
  if(docTab==='man'){
    const ch=`<div class="panel info"><p class="note">El manifiesto sale en una sola hoja. Datos de la carga lleva una columna por cada calidad y tipo de empaque del embarque (hasta 8): ${esc(C.cols.map(c=>TIPO_L[c.t]+' '+Q_COL[c.q]).join(', '))}.</p></div>`;
    body=`<div class="dsk ddoc"><div class="dcol">${ch}<div class="sec">Datos de la carga${mv?' · manifiesto '+ventaN(m,v):''}</div><div class="panel">${qtyTable(m,v)}</div>${note}${liveHtml()}</div><div class="dcol">
<div class="sec">Encabezado</div><div class="panel"><div class="grid2 hdrgrid">${docF(m,'h1','Membrete: empresa',0,1)}${docF(m,'h2','Membrete: línea 2',0,1)}${docF(m,'h3','Membrete: línea 3',0,1)}${docF(m,'salida','Fecha de salida','date')}${docF(m,'llegada','Fecha de llegada','date')}${docF(m,'cliente','Compañía',0,1)}${docF(m,'factura','No. de factura')}${docF(m,'poCli','P.O. (recuadro)')}${docF(m,'poLinea','P.O. línea (cliente y número)')}${docF(m,'cantTxt','Cantidad de cajas (vacío = automático)',0,1)}</div><p class="note" style="margin-top:8px">Cantidad automática: ${esc(manCant(m,C,1)||'—')}</p></div>
<div class="sec">Datos del transporte</div><div class="panel"><div class="grid2 hdrgrid">${docF(m,'linea','Transportista',0,1)}${docF(m,'operador','Conductor',0,1)}${docF(m,'placasT','Placas del tractor')}${docF(m,'placasF','Placas del termo')}${docF(m,'coment','Comentarios',0,1)}</div></div>
<div class="sec">Varios</div><div class="panel"><div class="grid2 hdrgrid">${docF(m,'alpha','Código ALPHA')}${docF(m,'caat','Código CAAT')}${docF(m,'eco','Trailer (núm. económico)')}${docF(m,'cert','Certificado')}</div></div>
<div class="panel"><p class="note">Encabezado, transporte y varios se llenan solos con lo capturado en Código de Trazabilidad, que a su vez toma los datos de Control Logístico. Al elegir un transportista, conductor, trailer o vendedor del catálogo se completan sus teléfonos, placas y códigos. Aquí los puedes corregir y se guardan con el pedido.</p><div class="pact">${genMenu('man','Generar manifiesto')}</div></div>
${v?'':`<div class="sec">Manifiesto interno · ${esc(EMPS[m.emp].name)}</div><div class="panel"><p class="note">Formato interno de ${esc((DOC_MX[m.emp]||DOC_MX.VL).name)}, con su logotipo, R.F.C. y dirección en México. ${mv?'Es uno solo para todo el viaje: lleva la carga de todas las tarimas, aunque vayan en varios manifiestos.':'Lleva la misma carga y el mismo transporte que el manifiesto.'}</p><div class="grid2 hdrgrid" style="margin-top:8px">${docF(m,'viaje','No. de viaje')}${docF(m,'sello','Num. de sello')}</div><div class="pact">${genMenu('int','Generar manifiesto interno')}</div></div>`}</div></div>`;
  }else{
    TM=tipoMapFor(m);
    const sm=plSummary(plCtx(m,v).rows.filter(r=>!r.empty));
    body=`<div class="dsk ddoc"><div class="dcol"><div class="sec">Encabezado del packing list</div><div class="panel"><div class="grid2 hdrgrid">${docF(m,'salida','Fecha de salida','date')}${docF(m,'hora','Hora de salida','time')}${docF(m,'llegada','Fecha de llegada','date')}${docF(m,'poCli','PO# cliente')}${docF(m,'prov','Proveedor',0,1)}${docF(m,'cliente','Cliente',0,1)}${docF(m,'vend','Vendedor')}${docF(m,'pOrder','P. Order')}${docF(m,'tel','Teléfono del vendedor')}${docF(m,'sello','Num. de sello')}</div></div></div><div class="dcol">
<div class="sec">Tarimas por empaque y calidad</div><div class="panel">${sm.length?sm.map(g=>`<div class="kv"><span>${esc(g.l)}</span><b>${g.n} ${g.n===1?'tarima':'tarimas'} · ${fmt(g.cajas)} cajas</b></div>`).join(''):'<p class="note">Captura las tarimas en Código de Trazabilidad para que aparezcan aquí.</p>'}<div class="pact"><button class="btn" data-act="dx:pv:pl" ${q.nPal?'':'disabled'}>Vista previa</button><button class="btn primary" data-act="dx:outpl" ${q.nPal?'':'disabled'}>Generar packing list</button></div></div>${q.nPal?liveHtml():''}</div></div>`;
  }
  return topbar(m.cod+' · Documentos','docback')+`<main class="wrap">${lockBan(m)}${head}${ventasHtml(m)}${tabs}${body}</main>${docLists(m)}`;
}
/* botón Generar con sus opciones desplegadas: Vista previa, PDF y PowerPoint editable */
let genOpen=null;
function genMenu(k,label){
  const op=genOpen===k;
  return `<div class="gmenu"><button class="btn primary" data-act="dx:gm:${k}" aria-expanded="${op}" aria-haspopup="menu">${esc(label)} <span aria-hidden="true">${op?'▴':'▾'}</span></button>${op?`<div class="gmlist" role="menu"><button role="menuitem" data-act="dx:pv:${k}">Vista previa</button><button role="menuitem" data-act="dx:dl:${k}.pdf">PDF</button><button role="menuitem" data-act="dx:dl:${k}.pptx">PowerPoint editable</button></div>`:''}</div>`;
}
/* vista en vivo: el manifiesto se vuelve a dibujar mientras se llenan las casillas */
let liveK='man',liveSrc='',liveSrcK='',liveT=null,liveN=0;
function liveKind(){return docTab==='pl'?'pl':liveK}
function liveHtml(){
  const b=(k,l)=>`<button class="btn sm" data-act="dx:lv:${k}" aria-pressed="${liveK===k}">${l}</button>`,k=liveKind();
  const nm={man:'manifiesto',int:'manifiesto interno',pl:'packing list'}[k];
  return `<div class="sec">Vista en vivo</div><div class="panel lvbox">${k==='pl'?'':`<div class="lvsw" role="group" aria-label="Documento">${b('man','Manifiesto')}${b('int','Manifiesto interno')}</div>`}<div class="lvpg">${liveSrc&&liveSrcK===k?`<img id="lvimg" src="${liveSrc}" alt="Vista en vivo del ${nm}">`:'<img id="lvimg" alt="" hidden><p class="note" id="lvwait">Preparando la vista…</p>'}</div><p class="note">Se actualiza sola al escribir. Así sale el ${nm}${k==='pl'?' (primera hoja)':''}.</p></div>`;
}
function liveSched(ms){
  clearTimeout(liveT);liveT=setTimeout(async()=>{
    const o=cur();if(!o||view!=='docs')return;const n=++liveN,k=liveKind();
    try{const v=docV(docMain(o));const pg=await (k==='pl'?packingPages(o,v):k==='int'?internoPages(o):manifestPages(o,v));const cv=await renderPage(pg[0],72);if(n!==liveN)return;
      liveSrc=cv.toDataURL('image/jpeg',.8);liveSrcK=k;const im=document.getElementById('lvimg');if(im){im.src=liveSrc;im.hidden=false}const w=document.getElementById('lvwait');if(w)w.remove()}catch(e){}
  },ms==null?350:ms);
}
function docAct(verb,arg){
  const o=cur();
  if(arg&&String(arg).indexOf('@')>=0){const q=String(arg).split('@'),m=o&&docMain(o);arg=q[0];if(m)setDocV(m,q[1]==='0'?'':q[1])}
  switch(verb){
    case 'vsel':{const m=o&&docMain(o);if(m){setDocV(m,arg==='0'?'':arg);liveSrc='';render();liveSched(0)}break}
    case 'vadd':{const m=o&&docMain(o);if(m){ventaAdd(m);liveSrc='';liveSched(0)}break}
    case 'vdel':{const m=o&&docMain(o);if(m){ventaDel(m);liveSched(0)}break}
    case 'vasg':{const m=o&&docMain(o);if(m){ventaAsg(m,arg);liveSched(0)}break}
    case 'vrng':{const m=o&&docMain(o);if(m){ventaRng(m);liveSched(0)}break}
    case 'gm':genOpen=genOpen===arg?null:arg;render();break;
    case 'dl':{const q=String(arg||'').split('.'),F={man:openOutMan,int:openOutInt}[q[0]];genOpen=null;if(F&&(q[1]==='pdf'||q[1]==='pptx')){render();F();outDo('save',q[1])}break}
    case 'lv':liveK=arg==='int'?'int':'man';liveSrc='';render();break;
    case 'open':if(!o)return;liveSrc='';genOpen=null;docFrom=view==='trazo'?'trazo':view==='dvt'?'dvt':'order';view='docs';docTab=arg==='pl'?'pl':'man';sheet=null;renderSheet();render();window.scrollTo(0,0);break;
    case 'tab':docTab=arg==='pl'?'pl':'man';render();break;
    case 'mt':if(ro)return;setDocVal('manTipo',arg);render();break;
    case 'outman':openOutMan();break;
    case 'outint':openOutInt();break;
    case 'outpl':openOutPl();break;
    case 'outreg':openOutReg();break;
    case 'outtraz':openOutTraz();break;
    case 'wa':outDo('wa',arg);break;
    case 'prev':outPrev();break;
    case 'pv':{const F={reg:openOutReg,traz:openOutTraz,man:openOutMan,int:openOutInt,pl:openOutPl}[arg];genOpen=null;if(F){F();outPrev()}break}
    case 'pvback':if(sheet&&sheet.kind==='out'){sheet.prev=null;renderSheet()}break;
    case 'save':outDo('save',arg);break;
    case 'pdfimg':prodImgPdf();break;
  }
}
$app.addEventListener('input',e=>{const el=e.target;if(el&&el.dataset&&el.dataset.doc){setDocVal(el.dataset.doc,el.value);liveSched()}});
$app.addEventListener('change',e=>{const el=e.target;if(!el||!el.dataset||!el.dataset.pvsel)return;const m=trazOrder();if(!m||!ventaCan(m))return;const p=ensureTraz(m).tarimas.find(x=>x.id===el.dataset.pvsel);if(!p)return;
  ventaSet(m,p,el.value);touch(m);render();toast('Tarima en el '+ventaLab(m,el.value))});

/* ---------- Entrada de Fruta: fruta recibida en almacén (para ambas empresas) e inventario disponible para empaque ---------- */
const LS_INV='empaque-entradas';
let INV={entradas:[],dirty:[],noTable:false};
(function(){try{const j=JSON.parse(localStorage.getItem(LS_INV)||'null');if(j&&Array.isArray(j.entradas))INV={entradas:j.entradas,dirty:Array.isArray(j.dirty)?j.dirty:[],noTable:false}}catch(e){}})();
let invTab='ent',openE=null;
const INV_F=['k24','k18','kilos','seg','tor','jug'];
const INV_L={k24:'Cajas grandes',k18:'Cajas pequeñas',kilos:'Kilos',seg:'Segunda',tor:'Torreón',jug:'Juguera'};
function saveInv(){try{localStorage.setItem(LS_INV,JSON.stringify({entradas:INV.entradas,dirty:INV.dirty}))}catch(e){}setSync()}
function touchE(e){e.updatedAt=Date.now();if(INV.dirty.indexOf(e.id)<0)INV.dirty.push(e.id);saveInv()}
const invKey=(codigo,nombre)=>codigo?'c'+(+codigo):'n'+norm(nombre||'').trim().replace(/\s+/g,' ');
function entradas(){return INV.entradas.filter(e=>!e.deleted)}
function newEntrada(nombre,codigo){return{id:uid(),fecha:todayISO(),nombre:nombre||'',codigo:codigo==null?null:codigo,k24:null,k18:null,kilos:null,seg:null,tor:null,jug:null,nota:'',pesos:{ch:[],gr:[]},createdAt:Date.now(),updatedAt:Date.now(),deleted:false}}
/* promedio de las cajas pesadas (muestra): pequeña = caja pequeña, grande = caja grande */
function pesoProm(a){const v=(a||[]).map(num).filter(x=>x!=null&&x>0);return v.length?{n:v.length,sum:v.reduce((s,x)=>s+x,0),avg:v.reduce((s,x)=>s+x,0)/v.length}:null}
function pesoEst(e){const ch=pesoProm(e.pesos&&e.pesos.ch),gr=pesoProm(e.pesos&&e.pesos.gr);if(!ch&&!gr)return null;return{ch:ch,gr:gr,kg:(ch?n0(e.k18)*ch.avg:0)+(gr?n0(e.k24)*gr.avg:0)}}
/* inventario por productor: todo lo que entró menos lo que ya se pasó a empaque (productores cargados desde aquí) */
/* inventario por productor y por entrega (cada entrada es una entrega):
   - lo que entra al empaque se descuenta de su entrega (o de la más antigua, en registros de versiones anteriores);
   - el torreón y la juguera ya catalogados se cargan al renglón; lo que el empaque agrega no sale del inventario;
   - las segundas que se anotan en Registro de Empaque son «segundas resultantes»: se suman al inventario del productor */
const FRUTA_F=['k24','k18','kilos','tor','jug'];
let TOOK=new Map();
function invData(){
  const map=new Map();
  const get=(k,nombre,codigo)=>{let a=map.get(k);if(!a){a={key:k,nombre:nombre||'Sin nombre',codigo:codigo||null,ent:[],in:{},out:{},av:{},eav:new Map(),uses:[],ch:[],gr:[],res:{prod:0,llevo:0,tot:0,av:0,a15:0,lots:[]}};INV_F.forEach(f=>{a.in[f]=0;a.out[f]=0});map.set(k,a)}else if(!a.codigo&&codigo)a.codigo=codigo;return a};
  entradas().slice().sort((x,y)=>(x.fecha||'').localeCompare(y.fecha||'')||((x.createdAt||0)-(y.createdAt||0))).forEach(e=>{
    const a=get(invKey(e.codigo,e.nombre),e.nombre,e.codigo),v={};a.ent.push(e);INV_F.forEach(f=>{a.in[f]+=n0(e[f]);v[f]=n0(e[f])});a.eav.set(e.id,v);
    if(e.pesos){a.ch=a.ch.concat(e.pesos.ch||[]);a.gr=a.gr.concat(e.pesos.gr||[])}
  });
  TOOK=new Map();
  const take=(a,ids,f,n,cap,rec)=>{
    if(!(n>0))return;const L=a.ent.filter(e=>!ids||ids.indexOf(e.id)>=0);if(!L.length)return;
    const note=(e,t)=>{if(rec&&t){const r=rec[e.id]=rec[e.id]||{k24:0,k18:0};r[f]+=t}};
    for(const e of L){const v=a.eav.get(e.id),t=Math.min(Math.max(0,v[f]),n);v[f]-=t;n-=t;note(e,t);if(n<=0)return}
    if(!cap){a.eav.get(L[L.length-1].id)[f]-=n;note(L[L.length-1],n)} /* se empacó más de lo que entró: queda en negativo para revisarlo */
  };
  const ord=visible().slice().sort((x,y)=>(x.fecha||'').localeCompare(y.fecha||'')||((x.createdAt||0)-(y.createdAt||0)));
  ord.forEach(o=>(o.productores||[]).forEach(p=>{
    if(!p.inv)return;const a=map.get(invKey(p.codigo,p.nombre));if(!a)return;a.uses.push({o:o,p:p});
    const ids=p.invEnt&&p.invEnt.length?p.invEnt:null,rec={};
    ['k24','k18'].forEach(f=>take(a,ids,f,n0(p[f]),false,rec));TOOK.set(p.id,rec);
    /* v8.20: con pesadas por entrega, cada entrega descuenta sus propios kilos; lo demás, como antes */
    if(p.pesE&&ids){let rest=n0(p.kilos);ids.forEach(id=>{const v=a.eav.get(id),k=n0(p.pesE[id]);if(v&&k){v.kilos-=k;rest-=k}});if(rest>0.01)take(a,ids,'kilos',rest,false)}
    else take(a,ids,'kilos',n0(p.kilos),false);
    ['tor','jug'].forEach(f=>take(a,ids,f,p.invL?Math.min(n0(p[f]),n0(p.invL[f])):n0(p[f]),true));
    if(!p.invV)take(a,ids,'seg',n0(p.seg),true);
  }));
  /* segunda catalogada que pasó a la hoja 1.5 */
  ord.forEach(o=>(o.productores||[]).forEach(p=>{
    const one=(lot,n)=>{if(!lot||lot[0]!=='e')return;const e=INV.entradas.find(x=>'e.'+x.id===lot);const a=e&&map.get(invKey(e.codigo,e.nombre));const v=a&&a.eav.get(e.id);if(!v)return;v.seg-=n;a.uses.push({o:o,p:p})};
    if(p.segLot)one(p.segLot,n0(p.k18));(p.aportes||[]).forEach(x=>one(x.lot,n0(x.n)));
  }));
  const jugE=(lot,n)=>{if(!lot||lot[0]!=='e')return;const e=INV.entradas.find(y=>'e.'+y.id===lot);const a=e&&map.get(invKey(e.codigo,e.nombre));const v=a&&a.eav.get(e.id);if(!v)return;v.seg-=n;a.jugE=(a.jugE||0)+n;a.jugById=a.jugById||{};a.jugById[e.id]=(a.jugById[e.id]||0)+n};
  Object.keys(PER.list).forEach(k=>{const w=PER.list[k];if(w&&w.closed&&w.jug)(w.jug.lots||[]).forEach(x=>jugE(x.lot,n0(x.n)))});
  jugManAll().forEach(z=>{if(z.src==='e')jugE(z.lot,n0(z.n))});
  /* segundas resultantes del Registro de Empaque, por entrega */
  seg2Lots().forEach(l=>{if(l.src!=='o')return;const a=get(l.key,l.nombre,l.codigo);a.res.tot+=l.tot;a.res.av+=l.av;a.res.a15+=l.usado-l.jug;a.res.jug=(a.res.jug||0)+l.jug;a.res.lots.push(l)});
  ord.forEach(o=>(o.productores||[]).forEach(p=>{if(p.segLot||p.sob||+p.codigo===SEG_COD||!(segC(p)>0))return;const a=map.get(invKey(p.codigo,p.nombre));if(!a)return;a.res.cera=(a.res.cera||0)+n0(p.cera);const ll=Math.min(n0(p.seg),Math.max(0,n0(p.segLlevo)));a.res.prod+=n0(p.seg);a.res.llevo+=ll;(a.res.rows=a.res.rows||[]).push({wk:wkOf(o),prod:n0(p.seg),llevo:ll,cera:n0(p.cera)})}));
  map.forEach(a=>{
    INV_F.forEach(f=>{let t=0;a.eav.forEach(v=>t+=v[f]);a.av[f]=Math.round(t*100)/100;a.out[f]=Math.round((a.in[f]-a.av[f])*100)/100});
    a.res.lots.sort((x,y)=>(x.fecha||'').localeCompare(y.fecha||''));
    a.segDisp=Math.max(0,a.av.seg)+a.res.av;
    a.hasFruta=FRUTA_F.some(f=>a.av[f]>0);
    a.has=a.hasFruta||a.segDisp>0;
  });
  return map;
}
const SEG_COD=23;
/* v8.13: las segundas con cera cuentan y se pagan igual que una segunda */
function segC(p){return n0(p&&p.seg)+n0(p&&p.cera)}
function segName(){return 'CITRILAR SEGUNDAS'}
/* ---------- segundas por productor: cada entrega que dejó segundas queda disponible, por separado, para la hoja 1.5 ---------- */
const DIAS_C=['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'],MES_C=['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
function diaTxt(s){if(!s)return 'Sin fecha';const p=String(s).split('-');if(p.length!==3)return String(s);const d=new Date(+p[0],+p[1]-1,+p[2]);return DIAS_C[d.getDay()]+' '+(+p[2])+' '+MES_C[+p[1]-1]+(+p[0]!==new Date().getFullYear()?' '+p[0]:'')}
/* v8.13 · envíos a Juguera hechos a mano: viven en el renglón (o la entrada) de donde salieron las segundas, uno por envío */
function jugManOf(x){const m=x&&x.jugEnv;if(!m||typeof m!=='object')return [];return Object.keys(m).map(id=>Object.assign({id:id},m[id])).filter(z=>z&&!z.anul&&n0(z.n)>0)}
function jugManAll(){
  const out=[];
  visible().forEach(o=>(o.productores||[]).forEach(p=>jugManOf(p).forEach(z=>out.push(Object.assign({src:'o',oid:o.id,pid:p.id,emp:o.emp},z,{wk:z.wk||wkOfDate(z.f)})))));
  entradas().forEach(e=>jugManOf(e).forEach(z=>out.push(Object.assign({src:'e',eid:e.id,emp:null},z,{wk:z.wk||wkOfDate(z.f)}))));
  return out;
}
/* lote de segunda: 'o.<pedido>.<renglón>' (segundas) u 'o.<pedido>.<renglón>.c' (con cera) o 'e.<entrada>' */
function lotRow(id){const q=String(id||'').split('.');return q[0]==='o'?'o.'+q[1]+'.'+q[2]:String(id||'')}
function seg2Lots(){
  const lots=new Map(),used={},legacy={},man={};
  visible().forEach(o=>(o.productores||[]).forEach(p=>{
    if(p.segLot)used[p.segLot]=(used[p.segLot]||0)+n0(p.k18);
    (p.aportes||[]).forEach(a=>{if(a.lot)used[a.lot]=(used[a.lot]||0)+n0(a.n)});
    if(p.inv&&!p.invV&&n0(p.seg)>0){const k=invKey(p.codigo,p.nombre);legacy[k]=(legacy[k]||0)+n0(p.seg)}
  }));
  /* lo que se mandó a Juguera al cerrar una semana */
  const jug={};Object.keys(PER.list).forEach(k=>{const w=PER.list[k];if(w&&w.closed&&w.jug)(w.jug.lots||[]).forEach(x=>{used[x.lot]=(used[x.lot]||0)+n0(x.n);jug[x.lot]=(jug[x.lot]||0)+n0(x.n)})});
  /* lo que se mandó a Juguera a mano (botón «Enviar a Juguera») */
  jugManAll().forEach(z=>{if(!z.lot)return;used[z.lot]=(used[z.lot]||0)+n0(z.n);man[z.lot]=(man[z.lot]||0)+n0(z.n)});
  /* segundas (y segundas con cera) que salieron de cada empaque, menos las que el productor se llevó; cuentan en la semana del empaque */
  visible().forEach(o=>(o.productores||[]).forEach(p=>{
    if(p.segLot||p.sob||+p.codigo===SEG_COD)return;
    const ent=p.invEnt&&INV.entradas.find(x=>x.id===p.invEnt[0]),fe=(ent&&ent.fecha)||p.invFecha||'',wk=wkOf(o);
    const base={src:'o',oid:o.id,pid:p.id,emp:o.emp,cod:o.cod,key:invKey(p.codigo,p.nombre),nombre:p.nombre||'Sin nombre',codigo:p.codigo||null,fecha:fe||o.fecha||'',fEmp:o.fecha||'',wk:wk,semana:fe?isoWeek(fe):o.semana};
    const ll=Math.min(n0(p.seg),Math.max(0,n0(p.segLlevo))),n=n0(p.seg)-ll;
    const de='Empaque '+o.cod+(o.variante==='1.5'?' (1.5)':'')+(fe&&o.fecha&&fe!==o.fecha?' ('+diaTxt(o.fecha)+')':'');
    if(n>0){const id='o.'+o.id+'.'+p.id;lots.set(id,Object.assign({id:id,cera:false,de:'Segundas resultantes · '+de,tot:n,usado:used[id]||0},base))}
    const c=n0(p.cera);
    if(c>0){const id='o.'+o.id+'.'+p.id+'.c';lots.set(id,Object.assign({id:id,cera:true,de:'Segundas con cera · '+de,tot:c,usado:used[id]||0},base))}
  }));
  /* segunda que llegó ya separada al almacén (Entrada de Fruta); lo que versiones anteriores ya habían cargado a un empaque se descuenta */
  entradas().slice().sort((a,b)=>(a.fecha||'').localeCompare(b.fecha||'')).forEach(e=>{
    let n=n0(e.seg);if(n<=0)return;const k=invKey(e.codigo,e.nombre);
    const lg=Math.min(n,legacy[k]||0);if(lg){legacy[k]-=lg;n-=lg}if(n<=0)return;
    const id='e.'+e.id;
    lots.set(id,{id:id,src:'e',eid:e.id,emp:null,cod:'',cera:false,key:k,nombre:e.nombre||'Sin nombre',codigo:e.codigo||null,fecha:e.fecha||'',fEmp:'',wk:wkOfDate(e.fecha),semana:e.fecha?isoWeek(e.fecha):null,de:'Llegaron catalogadas · Entrada de fruta',tot:n,usado:used[id]||0});
  });
  lots.forEach(l=>{l.jugC=jug[l.id]||0;l.jugM=man[l.id]||0;l.jug=l.jugC+l.jugM;l.proc=Math.max(0,l.usado-l.jug);l.av=Math.max(0,l.tot-l.usado)});
  return lots;
}
/* por productor (no un solo total): cada uno con sus entregas ordenadas por fecha */
function seg2Groups(all){
  const g=new Map();
  seg2Lots().forEach(l=>{if(!all&&l.av<=0)return;let x=g.get(l.key);if(!x){x={key:l.key,nombre:l.nombre,codigo:l.codigo,lots:[],av:0};g.set(l.key,x)}x.lots.push(l);x.av+=l.av;if(!x.codigo&&l.codigo)x.codigo=l.codigo});
  const out=[...g.values()];out.forEach(x=>x.lots.sort((a,b)=>(a.fecha||'').localeCompare(b.fecha||'')||a.de.localeCompare(b.de)));
  return out.sort((a,b)=>a.nombre.localeCompare(b.nombre));
}
function seg2Avail(){let n=0,c=0;seg2Groups().forEach(x=>{if(x.av>0){n+=x.av;c++}});return{cajas:n,prods:c}}
function openSegJug(wk){if(ro)return false;if(wkClosed(wk)){toast(wkLab(wk)+' está cerrada');return true}const G=seg2Groups().map(x=>Object.assign({},x,{lots:x.lots.filter(l=>!l.wk||l.wk<=wk)})).filter(x=>x.lots.length).map(x=>Object.assign(x,{av:x.lots.reduce((s,l)=>s+l.av,0)}));if(!G.length)return false;sheet={kind:'seg2',oid:null,wk:wk,q:{},G:G};renderSheet();return true}
function openSeg2(o){if(!o||ro||o.variante!=='1.5')return false;const G=seg2Groups();if(!G.length)return false;sheet={kind:'seg2',oid:o.id,q:{},G:G};renderSheet();return true}
function seg2Lot(l,q){
  return `<label class="s2r" for="s2-${esc(l.id)}"><span class="s2d"><b>${esc(diaTxt(l.fecha))}${l.cera?' <span class="chip cera">Con cera</span>':''}</b><small>${esc(l.de)}${l.wk?' · '+esc(wkLab(l.wk,true)):''}</small></span><span class="s2a"><b>${fmt(l.av)}</b><small>de ${fmt(l.tot)}</small></span><input class="in" id="s2-${esc(l.id)}" inputmode="numeric" autocomplete="off" data-s2="${esc(l.id)}" value="${q[l.id]?esc(q[l.id]):''}" placeholder="0" aria-label="Cajas de ${esc(l.nombre)} del ${esc(diaTxt(l.fecha))}"></label>`;
}
function seg2Tot(){let c=0;const q=(sheet&&sheet.q)||{};Object.keys(q).forEach(k=>c+=n0(q[k]));return 'Seleccionadas: '+fmt(c)+' cajas · '+fmt(c*SEG_KG)+' kg'}
function seg2Html(){
  const G=sheet.G||[],q=sheet.q||{},jo=!sheet.oid,o=jo?null:orders.find(x=>x.id===sheet.oid),wk=o?wkOf(o):sheet.wk;
  return `<h3>${jo?'Enviar segundas a Juguera':'Segundas disponibles'}</h3><p class="note">${jo?`Elige cuántas cajas de cada productor y entrega van a Juguera. Cuentan como venta a Juguera de ${esc(wkLab(wk))}; lo que no mandes se queda disponible y, si sigue ahí al cerrar la semana, se va solo.`:`Segundas que dejó cada productor en empaques anteriores y en Entrada de Fruta, separadas por entrega. Escribe cuántas cajas pasan a esta hoja 1.5: entran juntas en el renglón ${segName()} (023), con el resumen de lo que aporta cada productor. También puedes mandarlas directo a Juguera (${esc(wkLab(wk))}). Las demás se quedan disponibles para otro empaque.`} Peso: cajas × ${SEG_KG} kg.</p>
<div class="srow2"><button class="btn sm" data-act="s2all">Seleccionar todo</button><button class="btn sm" data-act="s2none">Limpiar</button></div>
<div class="s2list">${G.map((x,i)=>`<div class="s2g"><div class="s2h"><div><strong>${esc(x.nombre)}</strong><small>${x.codigo?'Código '+pad(x.codigo,3)+' · ':''}${x.lots.length} ${x.lots.length===1?'entrega':'entregas'} · ${fmt(x.av)} cajas</small></div><button class="btn sm" data-act="s2p:${i}">Todo</button></div>${x.lots.map(l=>seg2Lot(l,q)).join('')}</div>`).join('')}</div>
<p class="s2tot" id="s2tot">${esc(seg2Tot())}</p>
<div class="srow2 s2acts"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn${jo?' primary':''} jugb" data-act="s2jug">Enviar a Juguera</button>${jo?'':`<button class="btn primary" data-act="s2ok">Agregar a ${segName()}</button>`}</div>`;
}
/* las segundas elegidas entran juntas en el renglón especial 023 CITRILAR SEGUNDAS; el renglón guarda lo que aporta cada productor y entrega */
function c23Of(o){return (o.productores||[]).find(p=>p.c23)}
function c23Sync(p){const t=(p.aportes||[]).reduce((a,x)=>a+n0(x.n),0);p.k18=t||null;p.kilos=t?t*SEG_KG:null}
function seg2Ok(){
  const o=orders.find(x=>x.id===(sheet&&sheet.oid));if(!o||ro)return;
  const q=sheet.q||{},L=seg2Lots();let n=0,c=0,over=false;
  let p=c23Of(o);const nuevo=!p;
  if(!p){p=newProd(segName(),SEG_COD,'');p.c23=true;p.aportes=[]}
  (sheet.G||[]).forEach(x=>x.lots.forEach(l0=>{
    const l=L.get(l0.id);let k=Math.round(n0(q[l0.id]));if(!l||k<=0)return;if(k>l.av){k=l.av;over=true}if(k<=0)return;
    const a=p.aportes.find(y=>y.lot===l.id);
    if(a)a.n=n0(a.n)+k;else p.aportes.push({id:uid(),lot:l.id,nombre:l.nombre,codigo:l.codigo,fecha:l.fecha||'',de:l.de,n:k});
    n++;c+=k;
  }));
  if(!n){toast('Escribe cuántas cajas pasan, o toca «Seleccionar todo»');return}
  p.aportes.sort((a,b)=>(a.nombre||'').localeCompare(b.nombre||'')||(a.fecha||'').localeCompare(b.fecha||''));
  c23Sync(p);if(nuevo)o.productores.unshift(p);
  touch(o);logAdd({k:'add',ctx:ctxOf(o),lab:fmt(c)+' cajas de segunda a '+segName()+' ('+n+(n===1?' entrega':' entregas')+')'});
  sheet=null;renderSheet();openP=p.id;tab='captura';scrollToP=p.id;render();
  toast('Se agregaron '+fmt(c)+' cajas a '+segName()+(over?'. Algunas cantidades se ajustaron a lo disponible':''));
}
/* ---------- v8.13 · envío a Juguera con el botón (desde la ventana de segundas o la pestaña SEGUNDAS) ----------
   cada envío se guarda en el renglón del empaque (o en la entrada) de donde salieron las segundas: p.jugEnv / e.jugEnv,
   un registro por envío con su lote, cajas, semana de venta, quién y cuándo; anularlo lo marca, no lo borra */
function jugHost(l){
  if(!l)return null;
  if(l.src==='o'){const o=orders.find(x=>x.id===l.oid&&!x.deleted);const p=o&&(o.productores||[]).find(x=>x.id===l.pid);return p?{o:o,x:p}:null}
  const e=INV.entradas.find(x=>x.id===l.eid&&!x.deleted);return e?{e:e,x:e}:null;
}
function seg2Jug(){
  if(!sheet||sheet.kind!=='seg2'||ro)return;
  const o=sheet.oid?orders.find(x=>x.id===sheet.oid):null,wk=o?wkOf(o):sheet.wk;
  if(!wk){toast('Elige la semana del envío');return}
  if(wkClosed(wk)){toast(wkLab(wk)+' está cerrada. Para mandar más a Juguera un administrador la reabre en Periodos');return}
  const q=sheet.q||{},L=seg2Lots(),f=todayISO(),by=authUser.name||authUser.user||'—',at=Date.now(),tO=new Set(),tE=new Set();let n=0,c=0,over=false;
  Object.keys(q).forEach(id=>{
    const l=L.get(id);let k=Math.round(n0(q[id]));if(!l||k<=0)return;if(k>l.av){k=l.av;over=true}if(k<=0)return;
    const h=jugHost(l);if(!h)return;
    h.x.jugEnv=Object.assign({},h.x.jugEnv||{});
    h.x.jugEnv[uid()]={lot:l.id,n:k,wk:wk,f:f,by:by,at:at,nombre:l.nombre,codigo:l.codigo||null,cera:l.cera?true:undefined};
    if(h.o)tO.add(h.o);else tE.add(h.e);n++;c+=k;
  });
  if(!n){toast('Escribe cuántas cajas van a Juguera, o toca «Seleccionar todo»');return}
  tO.forEach(touch);tE.forEach(touchE);
  logAdd({k:'note',ctx:o?ctxOf(o):{t:'s',id:wk,cod:wkLab(wk)},where:'Segundas',lab:fmt(c)+' cajas de segunda a Juguera ('+n+(n===1?' entrega':' entregas')+')',o:'',n:wkLab(wk)});
  sheet=null;renderSheet();render();
  toast('Se mandaron '+fmt(c)+' cajas a Juguera ('+wkLab(wk,true)+')'+(over?'. Algunas cantidades se ajustaron a lo disponible':''));
}
/* anular un envío: las cajas regresan a disponibles; queda la marca de quién lo anuló */
function jugAnular(src,hid,sid){
  if(ro)return;let host=null,o=null;
  if(src==='o'){orders.forEach(x=>{if(host||x.deleted)return;const p=(x.productores||[]).find(y=>y.id===hid&&y.jugEnv&&y.jugEnv[sid]);if(p){host=p;o=x}})}
  else host=INV.entradas.find(x=>x.id===hid&&x.jugEnv&&x.jugEnv[sid]);
  const z=host&&host.jugEnv[sid];if(!z||z.anul)return;
  if(wkClosed(z.wk)){toast(wkLab(z.wk)+' está cerrada; no se puede anular');return}
  const k='jgan:'+src+':'+hid+':'+sid;if(confirmKey!==k){armConfirm(k);render();return}confirmKey=null;
  host.jugEnv=Object.assign({},host.jugEnv);host.jugEnv[sid]=Object.assign({},z,{anul:true,anulBy:authUser.name||authUser.user||'—',anulAt:Date.now()});
  if(o)touch(o);else touchE(host);
  logAdd({k:'note',ctx:o?ctxOf(o):{t:'s',id:z.wk,cod:wkLab(z.wk)},where:'Segundas',lab:'Envío a Juguera anulado · '+(z.nombre||''),o:fmt(z.n)+' cajas',n:'regresan a disponibles'});
  render();toast(fmt(z.n)+' cajas regresan a disponibles');
}
/* ---------- v8.13 · pestaña SEGUNDAS: todo lo de una semana (la del empaque donde salió cada segunda) ---------- */
function isSegRow(p){return !!(p&&(p.c23||p.segLot||+p.codigo===SEG_COD))}
function segSemKeys(){
  const s=new Set();seg2Lots().forEach(l=>{if(l.wk)s.add(l.wk)});
  visible().forEach(o=>{if((o.productores||[]).some(p=>isSegRow(p)||segC(p)>0))s.add(wkOf(o))});
  jugManAll().forEach(z=>{if(z.wk)s.add(z.wk)});s.add(wkOfDate(todayISO()));
  return [...s].filter(Boolean).sort().reverse();
}
function segSemData(wk){
  const L=seg2Lots(),V=visible().filter(o=>wkOf(o)===wk),m=/^(\d{4})-S(\d+)$/.exec(wk||''),cl=wkClosed(wk);
  const lots=[...L.values()].filter(l=>l.wk===wk);
  const T={tot:0,av:0,proc:0,jug:0,cera:0,ceraAv:0,llevo:0,prev:0};
  lots.forEach(l=>{T.tot+=l.tot;T.av+=l.av;T.proc+=l.proc;T.jug+=l.jug;if(l.cera){T.cera+=l.tot;T.ceraAv+=l.av}});
  L.forEach(l=>{if(l.wk&&l.wk<wk&&l.av>0)T.prev+=l.av});
  /* primera corrida: un renglón por pedido (viaje), con lo que salió de sus hojas; Calidad 1.5 = cajas empacadas en su hoja 1.5 sin contar renglones de segunda */
  const fm=new Map();
  V.slice().sort((a,b)=>String(a.fecha||'').localeCompare(String(b.fecha||''))||String(a.cod).localeCompare(String(b.cod),'es',{numeric:true})).forEach(o=>{
    const k=o.emp+'|'+o.cod;let r=fm.get(k);if(!r){r={emp:o.emp,cod:o.cod,po:'',emb:'',fecha:o.fecha||'',seg:0,llevo:0,cera:0,tor:0,des:0,c15:0,jug:0};fm.set(k,r)}
    if(o.variante!=='1.5'||!r.po){r.po=o.po||r.po;r.emb=o.emb||r.emb}
    const M=compute(o);
    M.rows.forEach(x=>{const p=x.p;if(isSob(p)||isSegRow(p))return;const ll=Math.min(n0(p.seg),Math.max(0,n0(p.segLlevo)));
      r.seg+=n0(p.seg)-ll;r.llevo+=ll;r.cera+=n0(p.cera);r.tor+=n0(p.tor);r.des+=n0(p.des);r.jug+=n0(p.jug);if(o.variante==='1.5')r.c15+=x.t});
  });
  const first=[...fm.values()].filter(r=>r.seg||r.llevo||r.cera||r.tor||r.des||r.c15);
  T.llevo=first.reduce((s,r)=>s+r.llevo,0);
  /* segundas maquiladas: cada renglón de segunda corrido en una hoja 1.5 de la semana */
  const maq=[];
  V.filter(o=>o.variante==='1.5').forEach(o=>{const M=compute(o),mn=sheetsOf(o).find(x=>x.variante==='1')||o;M.rows.forEach(x=>{const p=x.p;if(!isSegRow(p))return;
    const ap=(p.aportes||[]).filter(a=>n0(a.n)>0),cer=ap.filter(a=>/\.c$/.test(a.lot||'')).reduce((s,a)=>s+n0(a.n),0);
    maq.push({nombre:p.c23?'2 DAS PROD':(p.nombre||'Sin nombre'),po:mn.po||o.po||'',emb:mn.emb||o.emb||'',cod:o.cod,emp:o.emp,ent:n0(p.k18),c15:x.t,tor:n0(p.tor),des:n0(p.des),jug:n0(p.jug),cera:cer,ap:ap.length})})});
  /* a Juguera sin correr: con el botón (en esta semana) y al cierre (lo que mandó el cierre de esta semana) */
  const man=jugManAll().filter(z=>z.wk===wk),P=PER.list[wk],cie=cl&&P&&P.jug?(P.jug.lots||[]).filter(x=>n0(x.n)>0):[];
  const isC=x=>!!x.cera||/\.c$/.test(x.lot||'');
  const S={manS:0,manC:0,cieS:0,cieC:0,penS:0,penC:0};
  man.forEach(z=>{S[isC(z)?'manC':'manS']+=n0(z.n)});cie.forEach(x=>{S[isC(x)?'cieC':'cieS']+=n0(x.n)});
  if(!cl)jugCandidates(wk).forEach(l=>{S[l.cera?'penC':'penS']+=l.av});
  /* lista de envíos para la pantalla, con lo necesario para anular */
  const env=[];
  visible().forEach(o=>(o.productores||[]).forEach(p=>{const mm=p.jugEnv;if(!mm)return;Object.keys(mm).forEach(id=>{const z=mm[id];if(z&&z.wk===wk&&n0(z.n)>0)env.push(Object.assign({sid:id,src:'o',hid:p.id},z))})}));
  entradas().forEach(e=>{const mm=e.jugEnv;if(!mm)return;Object.keys(mm).forEach(id=>{const z=mm[id];if(z&&z.wk===wk&&n0(z.n)>0)env.push(Object.assign({sid:id,src:'e',hid:e.id},z))})});
  env.sort((a,b)=>(b.at||0)-(a.at||0));
  return {wk:wk,num:m?+m[2]:0,anio:m?+m[1]:0,yy:m?String(m[1]).slice(2):'',span:wkSpan(wk),closed:cl,T:T,lots:lots,first:first,maq:maq,S:S,env:env,cie:cie,
    noCorS:S.manS+S.cieS+S.penS,noCorC:S.manC+S.cieC+S.penC,pend:S.penS+S.penC};
}
let segWk=null;
function segWkCur(){const ks=segSemKeys();return segWk&&ks.indexOf(segWk)>=0?segWk:wkOfDate(todayISO())}
function segTabHtml(){
  const wk=segWkCur(),D=segSemData(wk),T=D.T,cl=D.closed,ok=Math.abs(T.av+T.proc+T.jug-T.tot)<0.01;
  const tile=(l,v,s)=>`<div><span>${l}</span><b>${fmt(v)}</b>${s?`<small>${s}</small>`:''}</div>`;
  const tb=(h,rows,foot)=>`<div class="tblx"><table class="stbl"><thead><tr>${h.map((x,i)=>`<th${i>1?' class="r"':''}>${x}</th>`).join('')}</tr></thead><tbody>${rows}</tbody>${foot?`<tfoot>${foot}</tfoot>`:''}</table></div>`;
  const sum=(a,k)=>a.reduce((s,r)=>s+n0(r[k]),0);
  const fH=['Viaje','PO · Embarque','2das','Con cera','Torreón','Desecho','Calidad 1.5'];
  const fR=D.first.map(r=>`<tr><th scope="row" class="mono">${esc(r.cod)}</th><td><small>${esc(r.po||'—')} · ${esc(r.emb||'—')}</small></td>${['seg','cera','tor','des','c15'].map(k=>`<td class="r">${fmt(r[k])}</td>`).join('')}</tr>`).join('');
  const fF=D.first.length?`<tr><th scope="row">Total cajas</th><td></td>${['seg','cera','tor','des','c15'].map(k=>`<td class="r"><b>${fmt(sum(D.first,k))}</b></td>`).join('')}</tr>`:'';
  const mH=['Renglón','Viaje','Entraron','Calidad 1.5','Torreón','Desecho','Juguera','Diferencia'];
  const mR=D.maq.map(r=>{const d=r.ent-r.c15-r.tor-r.des-r.jug;return `<tr><th scope="row">${esc(r.nombre)}${r.cera?`<small> · ${fmt(r.cera)} con cera</small>`:''}</th><td class="mono"><small>${esc(r.cod)}</small></td>${['ent','c15','tor','des','jug'].map(k=>`<td class="r">${fmt(r[k])}</td>`).join('')}<td class="r${Math.abs(d)>0.01?' neg':''}">${fmt(d)}</td></tr>`}).join('');
  const mF=D.maq.length?(()=>{const d=sum(D.maq,'ent')-sum(D.maq,'c15')-sum(D.maq,'tor')-sum(D.maq,'des')-sum(D.maq,'jug');return `<tr><th scope="row">Total cajas</th><td></td>${['ent','c15','tor','des','jug'].map(k=>`<td class="r"><b>${fmt(sum(D.maq,k))}</b></td>`).join('')}<td class="r"><b>${fmt(d)}</b></td></tr>`})():'';
  const G=new Map();D.lots.forEach(l=>{let x=G.get(l.key);if(!x){x={nombre:l.nombre,codigo:l.codigo,lots:[]};G.set(l.key,x)}x.lots.push(l)});
  const lotH=[...G.values()].sort((a,b)=>a.nombre.localeCompare(b.nombre)).map(x=>`<article class="invc"><div class="ih"><div><strong>${esc(x.nombre)}</strong><small>${x.codigo?'Código '+pad(x.codigo,3)+' · ':''}${x.lots.length} ${x.lots.length===1?'entrega':'entregas'}</small></div><span class="chip ${x.lots.some(l=>l.av>0)?'good':''}">${fmt(x.lots.reduce((s,l)=>s+l.av,0))} disponibles</span></div>${x.lots.map(l=>`<div class="s2st"><div><b>${esc(diaTxt(l.fecha))}</b>${l.cera?' <span class="chip cera">Con cera</span>':''}<small>${esc(l.de)}</small></div><div class="s2n"><span>Salieron <b>${fmt(l.tot)}</b></span><span>Procesadas <b>${fmt(l.proc)}</b></span><span>Juguera <b>${fmt(l.jug)}</b></span><span>Disponibles <b class="${l.av>0?'pos':''}">${fmt(l.av)}</b></span></div></div>`).join('')}</article>`).join('');
  const envH=D.env.length?D.env.map(z=>{const k='jgan:'+z.src+':'+z.hid+':'+z.sid;return `<div class="kv${z.anul?' anul':''}"><span><b>${esc(z.nombre||'Sin nombre')}</b>${z.cera?' · con cera':''}<small> · ${esc(fmtTs(z.at))} · ${esc(z.by||'—')}${z.anul?' · anulado por '+esc(z.anulBy||'—'):''}</small></span><b>${fmt(z.n)}${!z.anul&&!cl&&!ro?` <button class="btn sm" data-act="${k}">${confirmKey===k?'Toca otra vez':'Anular'}</button>`:''}</b></div>`}).join(''):'<p class="note">Todavía no se manda nada a Juguera con el botón en esta semana.</p>';
  const cieH=cl?`<div class="kv"><span>Al cerrar la semana (sobrantes)</span><b>${fmt(D.S.cieS+D.S.cieC)}</b></div>`:(D.S.penS+D.S.penC?`<p class="note">Al cerrar ${esc(wkLab(wk))} se irán solas a Juguera ${fmt(D.S.penS+D.S.penC)} cajas que sigan disponibles (de esta semana y anteriores).</p>`:'');
  const wkBtn=`<div class="srtbar"><button class="btn sm wkpick" data-act="iwk:seg" aria-haspopup="dialog">Semana: <b>${esc(wkLab(wk))}</b> · ${esc(D.span)} ▾</button><span class="chip ${cl?'crit':'good'}">${cl?LOCK_SVG+' Cerrada':'Abierta'}</span></div>`;
  return `${wkBtn}
<div class="panel"><div class="k">Segundas de ${esc(wkLab(wk))} (por la semana del empaque donde salieron)</div><div class="ig tot tot4">${tile('Disponibles',T.av,T.ceraAv?fmt(T.ceraAv)+' con cera':'')}${tile('Con cera',T.cera,'salieron')}${tile('Procesadas',T.proc,'pasaron a hoja 1.5')}${tile('Enviadas a Juguera',T.jug,'')}</div>
<p class="note" style="margin-top:8px">${ok?'Cuadra: ':'<b class="neg">Revisar:</b> '}salieron ${fmt(T.tot)} = ${fmt(T.av)} disponibles + ${fmt(T.proc)} procesadas + ${fmt(T.jug)} a Juguera.${T.llevo?' Aparte, los productores se llevaron '+fmt(T.llevo)+'.':''}${T.prev?' De semanas anteriores siguen disponibles '+fmt(T.prev)+'.':''}</p>
<div class="pact">${ro||cl?'':'<button class="btn sm primary" data-act="sjug">Enviar a Juguera</button>'}<button class="btn sm" data-act="segx"${typeof ExcelJS==='undefined'?' disabled':''}>Descargar Excel de la semana</button></div></div>
<div class="sec">Concentrado de segundas · primer corrida</div>${D.first.length?tb(fH,fR,fF):'<p class="note">Sin empaques con segundas en esta semana.</p>'}
<div class="sec">Segundas maquiladas · hoja 1.5</div>${D.maq.length?tb(mH,mR,mF):'<p class="note">Todavía no se corren segundas en una hoja 1.5 esta semana.</p>'}
<div class="sec">Envíos a Juguera · ${esc(wkLab(wk))}</div><div class="panel">${envH}${cieH}</div>
<div class="sec">Por productor y entrega</div>${lotH?'<div class="cgrid">'+lotH+'</div>':'<p class="note">Ninguna segunda salió de los empaques de esta semana.</p>'}`;
}
/* ventana para elegir la semana (inventario y segundas) */
function iwkHtml(){
  const t=sheet.t,cur=t==='seg'?segWkCur():invWk;
  const ks=t==='seg'?segSemKeys():invWkKeys();
  const cnt=k=>{if(t==='seg'){const L=[...seg2Lots().values()].filter(l=>l.wk===k);return L.length?fmt(L.reduce((s,l)=>s+l.tot,0))+' cajas de segunda':'sin segundas'}const n=entradas().filter(e=>wkOfDate(e.fecha)===k).length;return n+(n===1?' entrada':' entradas')};
  const opt=(k,l,s)=>`<button class="wkopt${k===cur?' on':''}" data-act="iwkset:${k}" aria-pressed="${k===cur}"><b>${esc(l)}</b><small>${esc(s)}</small></button>`;
  return `<h3>${t==='seg'?'Segundas por semana':'Inventario por semana'}</h3><p class="note">${t==='seg'?'Cada segunda cuenta en la semana del empaque donde salió.':'Cada productor aparece una vez por semana de entrega, sin juntar semanas. Los totales de arriba siguen siendo lo disponible hoy.'}</p>
<div class="wklist">${t==='seg'?'':opt('ALL','Todas las semanas','agrupadas por semana, la más reciente primero')}${ks.map(k=>opt(k,wkLab(k),wkSpan(k)+' · '+cnt(k)+(wkClosed(k)?' · cerrada':''))).join('')}</div>
<div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
let invWk='ALL';
function invWkKeys(){const s=new Set();entradas().forEach(e=>{const k=wkOfDate(e.fecha);if(k)s.add(k)});seg2Lots().forEach(l=>{if(l.src==='o'&&l.wk)s.add(l.wk)});return [...s].sort().reverse()}
/* un productor partido por semana: sus entregas de esa semana y las segundas resultantes de los empaques de esa semana */
function invSplit(a){
  const W=new Map(),get=k=>{let x=W.get(k);if(!x){x={wk:k,key:a.key+'|'+k,nombre:a.nombre,codigo:a.codigo,ent:[],in:{},out:{},av:{},eav:a.eav,uses:[],ch:[],gr:[],jugE:0,res:{prod:0,llevo:0,tot:0,av:0,a15:0,jug:0,lots:[]}};INV_F.forEach(f=>{x.in[f]=0;x.av[f]=0});W.set(k,x)}return x};
  a.ent.forEach(e=>{const x=get(wkOfDate(e.fecha)||''),v=a.eav.get(e.id);x.ent.push(e);INV_F.forEach(f=>{x.in[f]+=n0(e[f]);x.av[f]+=v[f]});x.jugE+=(a.jugById&&a.jugById[e.id])||0;if(e.pesos){x.ch=x.ch.concat(e.pesos.ch||[]);x.gr=x.gr.concat(e.pesos.gr||[])}});
  a.res.lots.forEach(l=>{const x=get(l.wk||'');x.res.tot+=l.tot;x.res.av+=l.av;x.res.a15+=l.usado-l.jug;x.res.jug+=l.jug;x.res.lots.push(l)});
  (a.res.rows||[]).forEach(r=>{const x=get(r.wk||'');x.res.prod+=r.prod;x.res.llevo+=r.llevo;x.res.cera=(x.res.cera||0)+n0(r.cera)});
  a.uses.forEach(u=>{const ids=u.p.invEnt||[],e=a.ent.find(z=>ids.indexOf(z.id)>=0),k=e?wkOfDate(e.fecha):wkOf(u.o);if(W.has(k))W.get(k).uses.push(u)});
  W.forEach(x=>{INV_F.forEach(f=>{x.av[f]=Math.round(x.av[f]*100)/100;x.out[f]=Math.round((x.in[f]-x.av[f])*100)/100});x.segDisp=Math.max(0,x.av.seg)+x.res.av;x.hasFruta=FRUTA_F.some(f=>x.av[f]>0);x.has=x.hasFruta||x.segDisp>0});
  return [...W.values()];
}
/* ---------- v8.13 · Excel de la semana, calcado de la hoja SEMANA42 de «2 das 2026.xlsx» ---------- */
async function segSemOut(){
  const wk=segWkCur(),D=segSemData(wk),base=fileSafe('Segundas_Semana_'+D.num+'_'+D.anio);
  D.mkg=[SEG_KG,PESOS.kg.RPC,SEG_KG,SEG_KG,SEG_KG];D.tara=TARA_KG;
  const mk=()=>{const wb=newWb();XL.addSegSem(wb,D);return wb};
  openOut({pages:()=>{const wb=mk();return xlPages(wb,wb.worksheets,{foot:'Generado '+fmtTs(Date.now())})},title:'Segundas · Semana '+D.num+' · '+D.anio,base:base,
    fmts:{xlsx:async()=>wbBlob(mk()),pdf:async()=>{const wb=mk();return pagesToPdf(await xlPages(wb,wb.worksheets,{foot:'Generado '+fmtTs(Date.now())}))}},
    note:'Las cajas salen de la app. Las casillas amarillas (tickets de Juguera, kilos del ticket, precio y Torreón no corrido) se llenan a mano. «2das no corridas» son las segundas que se fueron a Juguera sin correr'+(D.closed?'':', incluidas las que se irán solas al cerrar la semana')+'.'});
}
function seg2Note(p){
  const l=seg2Lots().get(p.segLot);
  return 'Segundas de '+(p.segDe||(l&&l.de)||'otra entrega')+' · '+diaTxt(p.segFecha)+'. '+(l?(l.av?'Quedan '+fmt(l.av)+' disponibles de esa entrega.':'Ya no quedan disponibles de esa entrega.'):'');
}
/* resumen dentro del renglón 023: cada productor con las cajas que aporta (editable) */
function c23Html(o,p){
  const ap=p.aportes||[],t=ap.reduce((a,x)=>a+n0(x.n),0);
  return `<div class="apbox"><div class="sec">Resumen · lo que aporta cada productor</div>${ap.length?ap.map(a=>`<div class="apr"><span class="apn"><b>${esc(a.nombre||'Sin nombre')}</b><small>${a.codigo?esc(codeLabel(a.codigo,o.emp))+' · ':''}${esc(diaTxt(a.fecha))} · ${esc(a.de||'')}</small></span><input class="in" inputmode="numeric" autocomplete="off" aria-label="Cajas que aporta ${esc(a.nombre||'')}" data-ap="${p.id}:${a.id}" value="${a.n==null?'':esc(a.n)}"${ro?' readonly':''}>${ro?'':`<button class="btn sm" data-act="apdel:${p.id}:${a.id}" aria-label="Quitar ${esc(a.nombre||'')}">×</button>`}</div>`).join(''):'<p class="note">Todavía no hay productores en este renglón.</p>'}<div class="kv" style="border-bottom:0"><span>Total de segundas</span><b>${fmt(t)} cajas · ${fmt(t*SEG_KG)} kg</b></div>${ro?'':'<div class="pact"><button class="btn sm" data-act="seg2" data-edit>+ Agregar segundas</button></div>'}</div>`;
}
function seg2InvHtml(){
  const G=seg2Groups();
  if(!G.length)return '<div class="sec">Segundas para hoja 1.5</div><p class="note">No hay segundas disponibles. Aparecen aquí, por productor y por entrega, cuando se capturan en un empaque o en Entrada de Fruta.</p>';
  return `<div class="sec">Segundas para hoja 1.5 · por productor y entrega</div><div class="cgrid">${G.map(x=>`<article class="invc s15"><div class="ih"><div><strong><span class="t15">1.5</span>${esc(x.nombre)}</strong><small>${x.codigo?'Código '+pad(x.codigo,3)+' · ':''}${x.lots.length} ${x.lots.length===1?'entrega':'entregas'}</small></div><span class="chip good">${fmt(x.av)} cajas</span></div>${x.lots.map(l=>`<div class="kv"><span>${esc(diaTxt(l.fecha))} · ${esc(l.de)}</span><b>${fmt(l.av)}</b></div>`).join('')}</article>`).join('')}</div>`;
}
function invTxt(av){const p=[];if(av.k24)p.push(fmt(av.k24)+' grandes');if(av.k18)p.push(fmt(av.k18)+' pequeñas');if(av.kilos)p.push(fmt(av.kilos,av.kilos%1?1:0)+' kg');if(av.seg)p.push(fmt(av.seg)+' segunda');if(av.tor)p.push(fmt(av.tor)+' torreón');if(av.jug)p.push(fmt(av.jug)+' juguera');return p.join(' · ')||'sin fruta'}
function invFirst(){return [...invData().values()].filter(a=>a.hasFruta).sort((a,b)=>a.nombre.localeCompare(b.nombre)).map(a=>({c:a.codigo,n:a.nombre,inv:a}))}
/* al agregar un productor a un empaque se carga lo que tiene disponible; se puede ajustar y lo demás se queda en inventario */
/* al agregar un productor a un empaque se carga su entrega más antigua con fruta (una entrega por renglón, para no perder la trazabilidad); se puede ajustar y lo demás se queda en inventario */
function invFill(p){
  const a=invData().get(invKey(p.codigo,p.nombre));if(!a||!a.hasFruta)return null;
  const e=a.ent.find(x=>{const v=a.eav.get(x.id);return FRUTA_F.some(f=>v[f]>0)});if(!e)return null;
  const v=a.eav.get(e.id);FRUTA_F.forEach(f=>{if(v[f]>0)p[f]=Math.round(v[f]*100)/100});
  p.inv=true;p.invV=3;p.invEnt=[e.id];p.invFecha=e.fecha||'';p.invL={tor:Math.max(0,v.tor),jug:Math.max(0,v.jug)};
  p.pesE={}; /* v8.20: los kilos del renglón salen de las pesadas de báscula de sus entregas */
  return a;
}
/* ---------- v8.20 · entregas combinadas en una corrida y pesadas de báscula compartidas con Entrada de Fruta ----------
   Un renglón puede juntar varias entregas del mismo productor (p.invEnt). El peso de báscula vive en la entrega (e.kilos) y se puede
   capturar en Entrada de Fruta o en el renglón: es el mismo dato. A cada renglón le toca de cada entrega una parte proporcional a las
   cajas que tomó de ella (p.pesE[id]); los kilos del renglón son la suma. Así el inventario de kilos siempre cuadra.
   Los renglones viejos con kilos escritos a mano (sin p.pesE) no se tocan. Las semanas cerradas no cambian. */
const cajEq=x=>n0(x&&x.k18)+1.5*n0(x&&x.k24);
function pesShares(){
  invData();const by=new Map();
  visible().forEach(o=>(o.productores||[]).forEach(p=>{if(!p.inv||!p.invEnt||!p.invEnt.length)return;p.invEnt.forEach(id=>{if(!by.has(id))by.set(id,[]);by.get(id).push({o:o,p:p})})}));
  const out=new Map();
  by.forEach((R,id)=>{const e=INV.entradas.find(x=>x.id===id);if(!e)return;const C=cajEq(e),t=R.map(x=>cajEq((TOOK.get(x.p.id)||{})[id]));const T=t.reduce((a,b)=>a+b,0);
    const sh=R.map((x,i)=>C>0?(T>C?t[i]/T:t[i]/C):(T>0?t[i]/T:1/R.length));out.set(id,{e:e,R:R,sh:sh,t:t,C:C})});
  return out;
}
function pesSync(){
  const S=pesShares(),ch=new Set();
  S.forEach((x,id)=>{const K=num(x.e.kilos);
    x.R.forEach((r,i)=>{const p=r.p;if(wkClosed(wkOf(r.o)))return;if(!p.pesE){if(n0(p.kilos)>0)return;p.pesE={}}
      if(!(K>0)){if(p.pesE[id]!=null){delete p.pesE[id];ch.add(r.o)}return}
      const v=Math.round(K*x.sh[i]*100)/100;if(p.pesE[id]!==v){p.pesE[id]=v;ch.add(r.o)}})});
  visible().forEach(o=>{if(wkClosed(wkOf(o)))return;(o.productores||[]).forEach(p=>{if(!p.pesE||!p.invEnt)return;
    Object.keys(p.pesE).forEach(k=>{if(p.invEnt.indexOf(k)<0){delete p.pesE[k];ch.add(o)}});
    const ks=Object.keys(p.pesE),v=ks.length?Math.round(ks.reduce((a,k)=>a+n0(p.pesE[k]),0)*100)/100:null;
    if((v==null?null:v)!==(num(p.kilos)==null?null:num(p.kilos))){p.kilos=v;ch.add(o)}})});
  ch.forEach(o=>touch(o));return ch.size;
}
function pseTxt(p,id,S){
  const x=(S||pesShares()).get(id);if(!x)return '';const i=x.R.findIndex(r=>r.p===p),sh=i>=0?x.sh[i]:1,K=num(x.e.kilos);
  const part=sh<0.999?'A esta corrida: '+(K>0?fmt(K*sh,0)+' kg':'—')+' ('+fmt(x.t[i],x.t[i]%1?1:0)+' de '+fmt(x.C,x.C%1?1:0)+' cajas de campo)'+(x.R.length>1?' · el resto va en '+x.R.filter(r=>r.p!==p).map(r=>r.o.cod).join(', '):''):'Entra completa en esta corrida'+(K>0?' · '+fmt(K,K%1?1:0)+' kg':'');
  return part+(K>0?'':' · Falta el peso de báscula');
}
/* bloque «Entregas en esta corrida» de la tarjeta del productor */
function pentHtml(o,p){
  if(!p.inv||!p.invEnt||!p.invEnt.length)return '';
  const S=pesShares(),lock=ro||wkClosed(wkOf(o)),a=invData().get(invKey(p.codigo,p.nombre));
  const rows=p.invEnt.map(id=>{const e=INV.entradas.find(x=>x.id===id);if(!e)return '';const x=S.get(id),i=x?x.R.findIndex(r=>r.p===p):-1,sh=i>=0?x.sh[i]:1,K=num(e.kilos);
    const lk=lock||(x&&x.R.some(r=>wkClosed(wkOf(r.o))));
    return `<div class="pentr"><div class="pentl"><b>Entrega ${esc(diaTxt(e.fecha))}</b><small>${esc([n0(e.k24)?fmt(n0(e.k24))+' grandes':'',n0(e.k18)?fmt(n0(e.k18))+' pequeñas':''].filter(Boolean).join(' · ')||'sin cajas')}</small></div>
<label class="fld pentk" for="pk-${p.id}-${id}"><span>Báscula de la entrega (kg)</span><input class="in" id="pk-${p.id}-${id}" inputmode="decimal" autocomplete="off" data-ebind="${id}.kilos" data-enum="1" value="${K==null?'':esc(K)}" placeholder="sin peso"${lk?' readonly':''}></label>
<small class="note pents" data-base="note pents" data-out="pse.${p.id}.${id}">${esc(pseTxt(p,id,S))}</small>${!lock&&p.invEnt.length>1?`<button class="btn sm pentx" data-act="pentrm:${p.id}:${id}" aria-label="Quitar la entrega del ${esc(diaTxt(e.fecha))} de esta corrida">Quitar</button>`:''}</div>`}).join('');
  const cand=a?a.ent.filter(e=>p.invEnt.indexOf(e.id)<0&&FRUTA_F.some(f=>a.eav.get(e.id)[f]>0)):[];
  return `<div class="pentw"><div class="sec">Entregas en esta corrida</div>${rows}${!lock&&cand.length?`<button class="btn sm" data-act="pentadd:${p.id}">+ Agregar otra entrega (${cand.length})</button>`:''}<p class="note">El peso de báscula es el mismo dato que en Entrada de Fruta: captúralo aquí o allá cuando llegue el ticket. Los kilos del lote son la suma de lo que le toca a esta corrida de cada entrega.</p></div>`;
}
function pentAddHtml(){
  const o=cur(),p=o&&o.productores.find(x=>x.id===sheet.pid);if(!p)return '<p class="note">El productor ya no está.</p>';
  const a=invData().get(invKey(p.codigo,p.nombre)),cand=a?a.ent.filter(e=>(p.invEnt||[]).indexOf(e.id)<0&&FRUTA_F.some(f=>a.eav.get(e.id)[f]>0)):[];
  return `<h3>Agregar otra entrega</h3><p class="note" style="margin-bottom:8px">Entregas de ${esc(p.nombre||'este productor')} con fruta en inventario. La que elijas se suma a esta corrida: sus cajas y su peso de báscula.</p>${cand.length?cand.map(e=>{const v=a.eav.get(e.id);return `<button class="pendr" data-act="pentsel:${p.id}:${e.id}">Entrega ${esc(diaTxt(e.fecha))} · ${esc(invTxt({k24:Math.max(0,v.k24),k18:Math.max(0,v.k18),kilos:Math.max(0,v.kilos)}))}${num(e.kilos)>0?'':' · sin peso de báscula'}<span aria-hidden="true">›</span></button>`}).join(''):'<p class="note">No hay más entregas con fruta de este productor.</p>'}<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button></div>`;
}
function pentAdd(pid,eid){
  const o=cur();if(!o||ro)return;const p=o.productores.find(x=>x.id===pid);if(!p)return;const a=invData().get(invKey(p.codigo,p.nombre)),v=a&&a.eav.get(eid),e=INV.entradas.find(x=>x.id===eid);if(!v||!e)return;
  p.invEnt=(p.invEnt||[]).concat([eid]);p.inv=true;p.invV=p.invV||3;if(!p.pesE&&!(n0(p.kilos)>0))p.pesE={};
  if(Math.max(0,v.k24))p.k24=n0(p.k24)+Math.max(0,v.k24);if(Math.max(0,v.k18))p.k18=n0(p.k18)+Math.max(0,v.k18);
  if(!p.pesE&&Math.max(0,v.kilos))p.kilos=Math.round((n0(p.kilos)+Math.max(0,v.kilos))*100)/100; /* renglón viejo con kilos a mano: se suman */
  p.invL=p.invL||{tor:0,jug:0};p.invL.tor=n0(p.invL.tor)+Math.max(0,v.tor);p.invL.jug=n0(p.invL.jug)+Math.max(0,v.jug);
  touch(o);pesSync();logAdd({k:'note',ctx:ctxOf(o),lab:(p.nombre||'Productor')+' · juntó la entrega del '+diaTxt(e.fecha),o:'',n:invTxt({k24:Math.max(0,v.k24),k18:Math.max(0,v.k18),kilos:Math.max(0,v.kilos)})});
  sheet=null;renderSheet();render();toast('Entrega del '+diaTxt(e.fecha)+' agregada a la corrida');
}
function pentRm(pid,eid){
  const o=cur();if(!o||ro)return;const p=o.productores.find(x=>x.id===pid);if(!p||!p.invEnt||p.invEnt.length<2)return;
  invData();const t=(TOOK.get(p.id)||{})[eid]||{k24:0,k18:0},e=INV.entradas.find(x=>x.id===eid);
  p.k24=Math.max(0,n0(p.k24)-t.k24)||null;p.k18=Math.max(0,n0(p.k18)-t.k18)||null;p.invEnt=p.invEnt.filter(x=>x!==eid);if(p.pesE)delete p.pesE[eid];
  touch(o);pesSync();logAdd({k:'note',ctx:ctxOf(o),lab:(p.nombre||'Productor')+' · quitó la entrega del '+(e?diaTxt(e.fecha):''),o:'',n:''});render();toast('Entrega quitada: vuelve al inventario');
}
function invNote(p){
  const a=invData().get(invKey(p.codigo,p.nombre));if(!a)return '';
  const e=p.invEnt&&INV.entradas.find(x=>x.id===p.invEnt[0]);
  const rest=a.ent.filter(x=>(p.invEnt||[]).indexOf(x.id)<0&&FRUTA_F.some(f=>a.eav.get(x.id)[f]>0));
  const es=(p.invEnt||[]).map(id=>INV.entradas.find(x=>x.id===id)).filter(Boolean);
  return (p.inv?(es.length>1?'Cargado de las entregas del '+es.map(x=>diaTxt(x.fecha)).join(' y ')+'. ':e?'Cargado de la entrega del '+diaTxt(e.fecha)+'. ':'Cargado de Entrada de Fruta. '):'')+'Queda en inventario: '+invTxt(a.av)+'.'+(rest.length?' '+(rest.length===1?'Otra entrega pendiente':'Otras '+rest.length+' entregas pendientes')+': '+rest.map(x=>diaTxt(x.fecha)).join(', ')+'.':'');
}
function invCardHtml(p){
  const a=invData().get(invKey(p.codigo,p.nombre));if(!a)return '';
  const o=cur(),hasCaj=n0(p.k24)>0||n0(p.k18)>0;
  /* v8.20.2: si el renglón ya tiene cajas capturadas, se liga con una entrega sin sobrescribir lo capturado */
  const ents=!p.inv&&hasCaj&&o?a.ent.filter(e=>FRUTA_F.some(f=>a.eav.get(e.id)[f]>0)):[];
  return `<div class="invnote"><span data-out="pinv.${p.id}"></span>${!p.inv&&a.hasFruta&&!ro?(hasCaj?`<div class="pact">${ents.map(e=>{const k='elink:'+e.id+':'+o.id+':'+p.id;return `<button class="btn sm${confirmKey===k?' primary':''}" data-act="${k}">${confirmKey===k?'Toca otra vez: ligar con la entrega del '+esc(diaTxt(e.fecha)):'Ligar con la entrega del '+esc(diaTxt(e.fecha))+' ('+esc(invTxt({k24:Math.max(0,a.eav.get(e.id).k24),k18:Math.max(0,a.eav.get(e.id).k18),kilos:Math.max(0,a.eav.get(e.id).kilos)}))+')'}</button>`}).join('')}</div><p class="note">Este renglón no está ligado a Entrada de Fruta: la entrega sigue pendiente allá. Ligarlo no cambia las cajas que ya capturaste.</p>`:`<button class="btn sm" data-act="pinv:${p.id}">Cargar de Entrada de Fruta</button>`):''}</div>`;
}
function invMenuSub(){
  const D=[...invData().values()].filter(a=>a.has),c=D.reduce((s,a)=>s+Math.max(0,a.av.k24)+Math.max(0,a.av.k18),0);
  return D.length?`${D.length} ${D.length===1?'productor':'productores'} con fruta · ${fmt(c)} cajas disponibles`:'Registra la fruta que llega al almacén';
}
function addEntrada(nombre,codigo){
  if(ro)return;const e=newEntrada(nombre,codigo);INV.entradas.push(e);touchE(e);logAdd({k:'add',ctx:{t:'e',id:e.id,cod:nombre||''},lab:'Entrada de '+(nombre||'productor')});
  invTab='ent';openE=e.id;sheet=null;renderSheet();render();
  setTimeout(()=>{const el=document.getElementById('f-e-'+e.id+'-k24');if(el){el.scrollIntoView({block:'center'});el.focus({preventScroll:true})}},300);
}
/* ---------- pantalla ---------- */
function eFld(e,k,l,o2){
  o2=o2||{};const id='f-e-'+e.id+'-'+k,v=e[k];
  return `<label class="fld" for="${id}"><span>${esc(l)}</span><input class="in${o2.txt?' txt':''}" id="${id}" type="${o2.date?'date':'text'}"${o2.num?' inputmode="numeric"':o2.dec?' inputmode="decimal"':''} autocomplete="off" data-ebind="${e.id}.${k}"${o2.num||o2.dec?' data-enum="1"':''} value="${v==null?'':esc(v)}"${ro?' readonly':''}></label>`;
}
function entHead(e){const t=[];if(n0(e.k24))t.push(fmt(n0(e.k24))+' grandes');if(n0(e.k18))t.push(fmt(n0(e.k18))+' pequeñas');if(n0(e.kilos))t.push(fmt(n0(e.kilos),1)+' kg');return fmtDate(e.fecha)+(t.length?' · '+t.join(' · '):' · sin cantidades')}
function pesoTxt(e){
  const x=pesoEst(e);if(!x)return 'Sin pesos de muestra.';
  const p=[];if(x.ch)p.push('Pequeña: '+x.ch.n+' pesadas, promedio '+fmt(x.ch.avg,2)+' kg');if(x.gr)p.push('Grande: '+x.gr.n+' pesadas, promedio '+fmt(x.gr.avg,2)+' kg');
  return p.join(' · ')+(x.kg?' · Peso estimado del lote ≈ '+fmt(x.kg,0)+' kg':'');
}
/* lo que salió de esta entrega en Registro de Empaque: dónde se empacó y cuántas segundas resultaron */
function entResHtml(e){
  const u=[];let sg=0;
  visible().forEach(o=>(o.productores||[]).forEach(p=>{if(!p.invEnt||p.invEnt.indexOf(e.id)<0)return;u.push(o.cod+(o.variante==='1.5'?' (1.5)':''));sg+=Math.max(0,n0(p.seg)-Math.min(n0(p.seg),n0(p.segLlevo)))}));
  if(!u.length)return '';
  const S=pesShares().get(e.id),rep=S&&S.R.length?`<div class="sec">Corridas de esta entrega</div><div class="panel">${S.R.map((r,i)=>`<div class="kv"><span>${esc(r.o.cod)}${r.o.variante==='1.5'?' (1.5)':''} · ${fmt(S.t[i],S.t[i]%1?1:0)} cajas de campo</span><b>${num(e.kilos)>0?fmt(num(e.kilos)*S.sh[i],0)+' kg':'sin peso'}</b></div>`).join('')}${S.R.length>1?'<p class="note">El peso de báscula se reparte entre las corridas según las cajas que tomó cada una.</p>':''}</div>`:'';
  return rep+`<div class="sec">Segundas resultantes</div><div class="panel"><div class="kv"><span>Empacada en</span><b>${esc([...new Set(u)].join(', '))}</b></div><div class="kv" style="border-bottom:0"><span>Segundas resultantes (Registro de Empaque)</span><b>${fmt(sg)}</b></div></div>`;
}
function entCard(e,proc,sa){
  const open=openE===e.id;
  const head=`<button class="prow" data-act="eopen:${e.id}" aria-expanded="${open}"><span class="idx">${e.codigo?pad(e.codigo,3):'—'}</span><span class="pn"><span>${esc(e.nombre||'Sin nombre')}</span><small data-out="eh.${e.id}">${esc(entHead(e))}</small>${!proc&&invTab==='ent'?(()=>{const W=entWhy(e),t=!INV_F.some(f=>n0(e[f])>0)?'Sin cantidades':/No está ligada/.test(W.msg[0]||'')?'Sin ligar a un empaque':/quedan sin pasar/.test(W.msg.join(' '))?'En empaque · le queda fruta':'';return t?`<span class="pchips"><span class="chip ${t==='En empaque · le queda fruta'?'info':'unas'} pchip">${t}</span></span>`:''})():''}${proc?`<span class="pchips"><span class="chip good pchip">Procesado</span>${sa?'<span class="chip unas pchip" title="Los kilos ya están en un empaque, pero todavía no cuadran con lo capturado en calibres y casillas de clasificación">Sin asignar</span>':''}</span>`:''}${e.nota?`<span class="pnote">${esc(e.nota)}</span>`:''}</span></button>`;
  if(!open)return `<article class="pc" id="ec-${e.id}">${head}</article>`;
  return `<article class="pc open" id="ec-${e.id}">${head}<div class="pf">${proc?'':entWhyHtml(e)}
<div class="grid2">${eFld(e,'fecha','Fecha de llegada',{date:1})}${eFld(e,'codigo','Código del productor',{num:1})}</div>${eFld(e,'nombre','Productor',{txt:1})}<p class="note">Puedes corregir el código y el nombre aunque ya esté registrado: el código trae el nombre de la lista y el cambio pasa también a los pedidos donde se empacó.</p>
<div class="sec">Cajas y peso</div>
<div class="grid3">${eFld(e,'k24','Cajas grandes',{num:1})}${eFld(e,'k18','Cajas pequeñas',{num:1})}${eFld(e,'kilos','Peso (kg)',{dec:1})}</div>
<p class="note kgw" data-out="ekw.${e.id}">${esc(kgCajaTxt(kgCajaChk(e.kilos,e.k18,e.k24)))}</p>
<div class="pesobox"><p class="note" data-out="ep.${e.id}">${esc(pesoTxt(e))}</p>${ro?'':`<button class="btn sm" data-act="epes:${e.id}">+ Agregar pesos</button>`}</div>
<div class="grid2">${eFld(e,'zona','Zona o huerta de origen',{txt:1})}</div>
<div class="sec">Muestreo de recepción (%)</div><div class="grid3">${eFld(e,'mPri','Primera',{dec:1})}${eFld(e,'mSeg','Segunda',{dec:1})}${eFld(e,'mDes','Desecho',{dec:1})}</div>
<div class="sec">Ya catalogada</div>
<div class="grid3">${eFld(e,'seg','Segunda',{num:1})}${eFld(e,'tor','Torreón',{num:1})}${eFld(e,'jug','Juguera',{num:1})}</div>
${entResHtml(e)}
<label class="fld" for="f-e-${e.id}-nota" style="margin-top:10px"><span>Notas</span><textarea class="in txt ta" id="f-e-${e.id}-nota" rows="2" data-ebind="${e.id}.nota"${ro?' readonly':''}>${esc(e.nota||'')}</textarea></label>
${ro?'':`<div class="pact"><button class="btn sm danger" data-act="edel:${e.id}">${confirmKey==='edel:'+e.id?'Toca otra vez':'Eliminar entrada'}</button></div>`}
</div></article>`;
}
function segBoxHtml(a){
  const cIn=a.in.seg,cAv=Math.max(0,a.av.seg),jg=(a.jugE||0)+(a.res.jug||0),cOut=Math.max(0,cIn-cAv-(a.jugE||0)),R=a.res;
  if(!cIn&&!R.prod&&!R.cera&&!R.lots.length)return '';
  const kv=(l,v,c)=>`<div class="kv${c?' '+c:''}"><span>${l}</span><b>${v}</b></div>`;
  return `<div class="segbox"><div class="k">Segundas</div>
${cIn?kv('Llegaron catalogadas',fmt(cIn)):''}${R.prod?kv('Segundas resultantes (Registro de Empaque)',fmt(R.prod)):''}${R.cera?kv('Segundas con cera (Registro de Empaque)',fmt(R.cera)):''}${R.llevo?kv('− Se las llevó el productor',fmt(R.llevo)):''}${cOut+R.a15?kv('− Pasaron a hoja 1.5',fmt(cOut+R.a15)):''}${jg?kv('− Enviadas a Juguera',fmt(jg)):''}${kv('Disponibles para hoja 1.5',fmt(a.segDisp),'tot')}
${R.lots.length?`<div class="seglots">${R.lots.map(l=>`<div><span>${esc(diaTxt(l.fecha))} · ${esc(l.de)}${l.cera?' <span class="chip cera">Con cera</span>':''}</span><b>${fmt(l.av)}<small> de ${fmt(l.tot)}</small></b></div>`).join('')}</div>`:''}</div>`;
}
function invCard(a){
  const used=a.uses.map(u=>u.o.cod+(u.o.variante==='1.5'?' (1.5)':'')).filter((v,i,s)=>s.indexOf(v)===i);
  const ch=pesoProm(a.ch),gr=pesoProm(a.gr);
  return `<article class="invc${a.has?'':' off'}"><div class="ih"><div><strong>${esc(a.nombre)}</strong><small>${a.codigo?'Código '+pad(a.codigo,3):'sin código'} · ${a.ent.length?a.ent.length+' '+(a.ent.length===1?'entrega':'entregas'):'segundas de los empaques de esta semana'}</small></div><span class="chip ${a.has?'good':''}">${a.has?'Disponible':a.ent.length?'Sin fruta':'Sin segundas'}</span></div>
${a.ent.length?`<div class="ig">${FRUTA_F.map(f=>`<div><span>${INV_L[f]}</span><b class="${a.av[f]>0?'pos':a.av[f]<0?'neg':''}">${fmt(a.av[f],f==='kilos'&&a.av[f]%1?1:0)}</b><small>entró ${fmt(a.in[f],f==='kilos'&&a.in[f]%1?1:0)}</small></div>`).join('')}</div>`:''}
${a.ent.length>1?`<div class="entl">${a.ent.map(e=>{const v=a.eav.get(e.id),q={};FRUTA_F.forEach(f=>q[f]=Math.max(0,v[f]));const t=invTxt(q);return `<div><span>Entrega ${esc(diaTxt(e.fecha))}</span><b>${esc(t==='sin fruta'?'ya pasó a empaque':t)}</b></div>`}).join('')}</div>`:''}
${segBoxHtml(a)}
${ch||gr?`<p class="note" style="margin-top:6px">Peso promedio de muestra: ${ch?'pequeña '+fmt(ch.avg,2)+' kg ('+ch.n+')':''}${ch&&gr?' · ':''}${gr?'grande '+fmt(gr.avg,2)+' kg ('+gr.n+')':''}</p>`:''}
${used.length?`<p class="note">Pasó a empaque en: ${esc(used.join(', '))}</p>`:''}</article>`;
}
/* orden de cada pestaña de Entrada de Fruta (A-Z, fecha o cantidad, invertible) */
const LS_ISRT='empaque-inv-orden';
let INVSRT=(()=>{try{return JSON.parse(localStorage.getItem(LS_ISRT)||'{}')||{}}catch(e){return {}}})();
function invSortOf(t){const d={ent:{k:'fecha',dir:'desc'},inv:{k:'az',dir:'asc'},proc:{k:'fecha',dir:'desc'}}[t]||{k:'fecha',dir:'desc'};const s=INVSRT[t]||{};return {k:['az','fecha','cant'].indexOf(s.k)>=0?s.k:d.k,dir:s.dir==='asc'||s.dir==='desc'?s.dir:d.dir}}
function invSortSet(t,s){INVSRT[t]=s;try{localStorage.setItem(LS_ISRT,JSON.stringify(INVSRT))}catch(e){}}
/* v8.15 · entradas cuya fruta ya está en un empaque pero sus kilos todavía no cuadran con lo capturado en calibres y casillas de clasificación
   (segundas, cera, Torreón, desecho, Juguera). En Procesado salen con «Sin asignar» hasta que la etiqueta «Dif» de ese productor quede en verde. */
function entSinAsignar(){
  const out=new Set();
  visible().forEach(o=>{
    if(!(o.productores||[]).some(p=>p.invEnt&&p.invEnt.length))return;
    compute(o).rows.forEach(r=>{const p=r.p;if(!p.invEnt||!p.invEnt.length)return;
      if(difChip(r).cls!=='good')p.invEnt.forEach(id=>out.add(id));});
  });
  return out;
}
/* v8.20.1 · por qué una entrada sigue en Entradas y cómo arreglarlo */
function entWhy(e){
  const out={msg:[],fix:[]},F=x=>fmt(x,x%1?1:0);
  if(!INV_F.some(f=>n0(e[f])>0)){out.msg.push('No tiene cajas ni kilos capturados: sin cantidades no puede pasar a Procesado.');return out}
  const k=invKey(e.codigo,e.nombre),a=invData().get(k),v=a&&a.eav.get(e.id),lk=[],cand=[];
  visible().forEach(o=>(o.productores||[]).forEach(p=>{if(p.sob||p.sob2||isSob(p)||+p.codigo===SEG_COD||p.segLot)return;if(invKey(p.codigo,p.nombre)!==k)return;
    if(p.inv&&(p.invEnt||[]).indexOf(e.id)>=0)lk.push({o:o,p:p});else if(!wkClosed(wkOf(o)))cand.push({o:o,p:p})}));
  if(!lk.length){
    out.msg.push('No está ligada a ningún renglón de Registro de Empaque.');
    if(cand.length){out.msg.push('Hay '+(cand.length===1?'un renglón':cand.length+' renglones')+' de este productor sin ligar: si su fruta es esta entrega, lígalo.');cand.slice(0,6).forEach(c=>out.fix.push({act:'elink:'+e.id+':'+c.o.id+':'+c.p.id,t:'Ligar con '+c.o.cod+(c.o.variante==='1.5'?' (1.5)':'')+' · '+(n0(c.p.k24)?F(n0(c.p.k24))+' grandes ':'')+(n0(c.p.k18)?F(n0(c.p.k18))+' pequeñas ':'')+(n0(c.p.kilos)?'· '+F(n0(c.p.kilos))+' kg':'')}))}
    else out.msg.push('Cuando se empaque, agrega al productor en Registro de Empaque y se carga de aquí.');
    return out;
  }
  if(v){const q=[];['k24','k18'].forEach(f=>{if(v[f]>0)q.push(F(v[f])+' '+(f==='k24'?'grandes':'pequeñas'))});if(v.kilos>0.01)q.push(F(Math.round(v.kilos*100)/100)+' kg');['tor','jug'].forEach(f=>{if(v[f]>0)q.push(F(v[f])+' '+(f==='tor'?'Torreón':'Juguera'))});
    if(q.length)out.msg.push('Está en '+[...new Set(lk.map(x=>x.o.cod))].join(', ')+', pero quedan sin pasar al empaque: '+q.join(' · ')+'.');
    if(v.kilos>0.01&&!(v.k24>0)&&!(v.k18>0)){const old=lk.filter(x=>!x.p.pesE&&!wkClosed(wkOf(x.o)));if(old.length){out.msg.push('Las cajas ya pasaron completas; la diferencia es de kilos: el renglón tiene kilos escritos a mano distintos a la báscula.');old.forEach(x=>out.fix.push({act:'epes1:'+x.o.id+':'+x.p.id,t:'Usar el peso de báscula en '+x.o.cod+' · '+(x.p.nombre||'')+' (ahora '+F(n0(x.p.kilos))+' kg)'}))}}
    if((v.k24>0||v.k18>0)&&cand.length)cand.slice(0,4).forEach(c=>out.fix.push({act:'elink:'+e.id+':'+c.o.id+':'+c.p.id,t:'Ligar también con '+c.o.cod+' · '+(c.p.nombre||'')}));
  }
  return out;
}
function entWhyHtml(e){
  const W=entWhy(e);if(!W.msg.length)return '';
  return `<div class="panel warn ewhy"><strong>Por qué sigue en Entradas</strong>${W.msg.map(m=>`<p class="note">${esc(m)}</p>`).join('')}${!ro&&W.fix.length?`<div class="pendrows">${W.fix.map(f=>`<button class="pendr" data-act="${esc(f.act)}">${esc(f.t)}${confirmKey===f.act?' · toca otra vez para confirmar':''}<span aria-hidden="true">›</span></button>`).join('')}</div>`:''}</div>`;
}
function entLink(eid,oid,pid){
  const o=orders.find(x=>x.id===oid&&!x.deleted),p=o&&(o.productores||[]).find(x=>x.id===pid),e=INV.entradas.find(x=>x.id===eid);if(!p||!e||ro||wkClosed(wkOf(o)))return;
  p.inv=true;p.invV=p.invV||3;p.invEnt=(p.invEnt||[]).filter(x=>x!==eid).concat([eid]);if(!p.invFecha)p.invFecha=e.fecha||'';
  if(!(n0(p.k24)>0)&&!(n0(p.k18)>0)){p.k24=num(e.k24);p.k18=num(e.k18)}
  if(!(n0(p.kilos)>0))p.pesE=p.pesE||{};
  touch(o);pesSync();logAdd({k:'note',ctx:ctxOf(o),lab:(p.nombre||'Productor')+' · ligado a la entrega del '+diaTxt(e.fecha),o:'',n:''});confirmKey=null;render();toast('Entrega ligada con '+o.cod);
}
function entPes1(oid,pid){
  const o=orders.find(x=>x.id===oid&&!x.deleted),p=o&&(o.productores||[]).find(x=>x.id===pid);if(!p||ro||wkClosed(wkOf(o)))return;
  const old=p.kilos;p.pesE={};touch(o);pesSync();logAdd({k:'edit',ctx:ctxOf(o),path:'p.'+p.id+'.kilos',num:true,lab:(p.nombre||'Productor')+' · kilos del lote (ahora siguen la báscula)',o:sv(old),n:sv(p.kilos)});confirmKey=null;render();toast('Kilos del renglón: '+fmt(n0(p.kilos),n0(p.kilos)%1?1:0)+' kg (báscula)');
}
/* entradas procesadas: tenían fruta y ya no les queda nada en inventario (ni segunda catalogada) */
function entProc(){
  const D=invData(),L=seg2Lots(),out=new Set();
  entradas().forEach(e=>{
    if(!INV_F.some(f=>n0(e[f])>0))return;
    const a=D.get(invKey(e.codigo,e.nombre)),v=a&&a.eav.get(e.id);if(!v)return;
    const lot=L.get('e.'+e.id);
    if(!FRUTA_F.some(f=>v[f]>0)&&!(lot&&lot.av>0)&&!(n0(e.seg)>0&&!lot&&v.seg>0))out.add(e.id);
  });
  return out;
}
/* ---------- v8.12 · hoja semanal de Entrada de fruta en Excel (calca de «Entrada de limón») y PDF ---------- */
function recSemKeys(){const s=new Set();entradas().forEach(e=>{const k=wkOfDate(e.fecha);if(k)s.add(k)});s.add(wkOfDate(todayISO()));return [...s].filter(Boolean).sort().reverse()}
function recNom(e){const li=e.codigo?LISTA.find(x=>x.c===e.codigo):null;let n=String((li&&li.n)||e.nombre||'SIN NOMBRE').toUpperCase();const z=String(e.zona||'').trim();if(z&&clsOf(e.codigo)==='interno')n+=' ('+z.toUpperCase()+')';return n}
function recSemData(wk){
  const r=wkRange(wk);if(!r)return null;const days=[];
  for(let i=0;i<7;i++){const f=dayAdd(r.a,i),d=new Date(f+'T12:00:00Z');days.push({f:f,lab:DIAS_U[d.getUTCDay()]+' '+fmtDate(f),rows:[]})}
  const isI=e=>clsOf(e.codigo)==='interno'?1:0;
  entradas().filter(e=>wkOfDate(e.fecha)===wk).sort((a,b)=>isI(b)-isI(a)||(a.createdAt||0)-(b.createdAt||0)).forEach(e=>{const d=days.find(x=>x.f===e.fecha);if(d)d.rows.push({n:recNom(e),kilos:num(e.kilos),ch:num(e.k18),gr:num(e.k24),int:!!isI(e)})});
  const pm=new Map();days.forEach(d=>d.rows.forEach(x=>{if(!pm.has(x.n))pm.set(x.n,{n:x.n,int:x.int})}));
  const prods=[...pm.values()].filter(x=>x.int).concat([...pm.values()].filter(x=>!x.int));
  const peds=new Map();orders.filter(o=>!o.deleted&&wkOf(o)===wk).forEach(o=>{const k=o.emp+'|'+o.cod;let t=peds.get(k);if(!t){t={cod:o.cod,emp:o.emp,fecha:o.fecha||'',cajas:0};peds.set(k,t)}(o.productores||[]).forEach(p=>{if(isSob(p)||+p.codigo===SEG_COD||p.segLot)return;t.cajas+=n0(p.k18)+n0(p.k24)*1.5})});
  const trips=[...peds.values()].sort((a,b)=>String(a.fecha).localeCompare(String(b.fecha))||String(a.cod).localeCompare(String(b.cod),'es',{numeric:true}));
  const m=/^(\d{4})-S(\d+)$/.exec(wk);
  return {wk:wk,num:m?+m[2]:0,anio:m?+m[1]:0,span:wkSpan(wk),days:days,prods:prods,trips:trips,n:days.reduce((s,d)=>s+d.rows.length,0)};
}
async function recSemWb(wk,all){
  const wb=newWb(),ks=all?recSemKeys().filter(k=>k.slice(0,4)===wk.slice(0,4)&&recSemData(k).n>0).sort():[wk];
  if(all&&ks.indexOf(wk)<0){ks.push(wk);ks.sort()}
  ks.forEach(k=>XL.addRecSem(wb,recSemData(k)));return wb;
}
async function recSemPages(wk){const wb=newWb();XL.addRecSemPdf(wb,recSemData(wk));return xlPages(wb,wb.worksheets,{foot:'Generado '+fmtTs(Date.now())})}
function recsemHtml(){
  const ks=recSemKeys(),wk=sheet.wk||ks[0];
  const opts=ks.map(k=>{const n=entradas().filter(e=>wkOfDate(e.fecha)===k).length;return `<option value="${k}"${k===wk?' selected':''}>${esc(wkLab(k))} · ${esc(wkSpan(k))} · ${n} ${n===1?'entrada':'entradas'}</option>`}).join('');
  const W=recSemData(wk);
  return `<h3>Hoja semanal de entrada de fruta</h3><p class="note">Sale igual que tu Excel «Entrada de limón»: un bloque por día de lunes a domingo con productor, kilos, cajas chicas, cajas grandes y total (chicas + grandes × 1.5), lo que ya está en piso, los estimados para capturar a mano, las entradas reales por día y las cajas de cada viaje de la semana. El PDF trae lo mismo, un día debajo de otro, para compartir.</p>
<label class="fld" for="rs-wk"><span>Semana</span><select class="in sel" id="rs-wk" data-rswk="1">${opts}</select></label>
<label class="rchk" for="rs-all"><input type="checkbox" id="rs-all" data-rsall="1"${sheet.all?' checked':''}> <span>Excel con todas las semanas de ${esc(wk.slice(0,4))} (una hoja por semana)</span></label>
<p class="note" style="margin-top:8px">${W&&W.n?fmt(W.n)+(W.n===1?' entrada':' entradas')+' en la semana · '+W.trips.length+(W.trips.length===1?' viaje':' viajes'):'Esta semana todavía no tiene entradas; la hoja sale vacía para llenarla.'}</p>
<div class="srow2"><button class="btn" data-act="closesheet">Cancelar</button><button class="btn primary" data-act="recsemgo">Continuar</button></div>`;
}
function recSemOut(){
  const wk=sheet.wk||recSemKeys()[0],all=!!sheet.all,W=recSemData(wk),base=fileSafe('Entrada_de_fruta_Semana_'+W.num+'_'+W.anio);
  openOut({pages:()=>recSemPages(wk),title:'Entrada de fruta · Semana '+W.num+' · '+W.anio,base:base,
    fmts:{xlsx:async()=>wbBlob(await recSemWb(wk,all)),pdf:async()=>pagesToPdf(await recSemPages(wk))},
    note:(all?'El Excel trae una hoja por cada semana de '+W.anio+' con entradas. ':'')+'Las casillas amarillas del Excel (estimados, % y pendiente por traer) se llenan a mano.'});
}
function invView(){
  const D=[...invData().values()].sort((a,b)=>(b.has-a.has)||a.nombre.localeCompare(b.nombre)),tot={};
  FRUTA_F.forEach(f=>tot[f]=D.reduce((s,a)=>s+Math.max(0,a.av[f]),0));tot.seg=D.reduce((s,a)=>s+a.segDisp,0);
  const S=invSortOf(invTab),dir=S.dir==='asc'?1:-1,P=entProc();
  const tabs=`<div class="tabs" role="tablist">${[['ent','Entradas'],['inv','Inventario'],['proc','Procesado'],['seg','Segundas']].map(t=>`<button class="tab" role="tab" data-act="etab:${t[0]}" aria-selected="${invTab===t[0]}">${t[1]}${t[0]==='proc'&&P.size?' <small class="tcnt">'+P.size+'</small>':''}</button>`).join('')}</div>`;
  const srt=`<div class="srtbar"><label class="fld srtsel" for="inv-srt"><span>Ordenar</span><select class="in sel" id="inv-srt" data-isrt="1">${[['az','A-Z'],['fecha','Fecha'],['cant','Cantidad']].map(x=>`<option value="${x[0]}"${S.k===x[0]?' selected':''}>${x[1]}</option>`).join('')}</select></label><button class="btn sm srtdir" data-act="isrtdir" aria-label="Invertir orden" title="Invertir orden">${S.dir==='asc'?'↑':'↓'} ${S.k==='az'?(S.dir==='asc'?'A → Z':'Z → A'):S.k==='fecha'?(S.dir==='asc'?'Más antiguas':'Más recientes'):(S.dir==='asc'?'Menor primero':'Mayor primero')}</button></div>`;
  const eCant=e=>n0(e.kilos)||(n0(e.k24)+n0(e.k18)),aCant=a=>Math.max(0,a.av.k24)+Math.max(0,a.av.k18)+a.segDisp,aFecha=a=>a.ent.map(e=>e.fecha||'').sort().pop()||'';
  const cmpE=(x,y)=>S.k==='az'?(x.nombre||'').localeCompare(y.nombre||'')*dir:S.k==='cant'?(eCant(x)-eCant(y))*dir||(x.nombre||'').localeCompare(y.nombre||''):((x.fecha||'').localeCompare(y.fecha||'')||((x.createdAt||0)-(y.createdAt||0)))*dir;
  if(invTab==='inv')D.sort((x,y)=>S.k==='az'?x.nombre.localeCompare(y.nombre)*dir:S.k==='cant'?(aCant(x)-aCant(y))*dir||x.nombre.localeCompare(y.nombre):aFecha(x).localeCompare(aFecha(y))*dir||x.nombre.localeCompare(y.nombre));
  let body;
  if(invTab==='inv'){
    /* v8.13: cada productor una vez por semana de entrega (sin juntar semanas); la ventana «Semana» elige cuál ver */
    let C=[];D.forEach(a=>invSplit(a).forEach(x=>C.push(x)));
    const wks=[...new Set(C.map(x=>x.wk))].sort().reverse(),sw=invWk!=='ALL'&&wks.indexOf(invWk)>=0?invWk:'ALL';
    if(sw!=='ALL')C=C.filter(x=>x.wk===sw);
    const cmpA=(x,y)=>S.k==='az'?x.nombre.localeCompare(y.nombre)*dir:S.k==='cant'?(aCant(x)-aCant(y))*dir||x.nombre.localeCompare(y.nombre):aFecha(x).localeCompare(aFecha(y))*dir||x.nombre.localeCompare(y.nombre);
    const grp=(sw==='ALL'?wks:[sw]).map(k=>{const L=C.filter(x=>x.wk===k).sort((x,y)=>(y.has-x.has)||cmpA(x,y));return L.length?`<div class="wkhd">${k?esc(wkLab(k))+' · '+esc(wkSpan(k)):'Sin fecha'}</div><div class="cgrid">${L.map(invCard).join('')}</div>`:''}).join('');
    const wkb=`<button class="btn sm wkpick srtdir" data-act="iwk:inv" aria-haspopup="dialog">Semana: <b>${sw==='ALL'?'Todas':esc(wkLab(sw))}</b> ▾</button>`;
    body=`<div class="panel"><div class="k">Disponible para empaque (ambas empresas)</div><div class="ig tot">${FRUTA_F.concat(['seg']).map(f=>`<div><span>${f==='seg'?'Segundas disponibles':INV_L[f]}</span><b>${fmt(tot[f],f==='kilos'&&tot[f]%1?1:0)}</b></div>`).join('')}</div><p class="note" style="margin-top:8px">Al agregar un productor en Registro de Empaque se carga lo que tiene aquí. Si en ese pedido solo pasas una parte, el resto se queda en inventario.</p><div class="pact"><button class="btn sm" data-act="invx"${typeof ExcelJS==='undefined'?' disabled':''}>Descargar inventario (Excel)</button></div></div>
<div class="sec">Por productor y semana</div>${srt.replace('<div class="srtbar">','<div class="srtbar">'+wkb)}${C.length?grp:'<div class="empty"><h2>Sin fruta registrada</h2><p>Toca «+ Agregar productor» para registrar la primera entrada.</p></div>'}`;
  }else if(invTab==='seg'){
    body=segTabHtml();
  }else if(invTab==='proc'){
    const E=entradas().filter(e=>P.has(e.id)).sort(cmpE),SA=entSinAsignar(),nSA=E.filter(e=>SA.has(e.id)).length;
    body=`<p class="note" style="margin-top:10px">Fruta que ya se recibió y pasó completa a empaque: ya no está disponible en inventario. Ábrela para ver en qué pedido se empacó.${nSA?` <b class="unastx">${nSA} ${nSA===1?'entrada sigue':'entradas siguen'} sin asignar</b>: sus kilos ya están en un empaque, pero todavía no cuadran con los calibres y las casillas de clasificación de Registro de Empaque. La etiqueta se quita cuando la «Dif» del productor queda en verde.`:''}</p>${srt}`+(E.length?'<div class="pgrid">'+E.map(e=>entCard(e,true,SA.has(e.id))).join('')+'</div>':'<div class="empty"><h2>Nada procesado todavía</h2><p>Cuando toda la fruta de una entrada pase a Registro de Empaque, la entrada se mueve aquí.</p></div>');
  }else{
    const E=entradas().filter(e=>!P.has(e.id)).sort(cmpE);
    body=srt+(E.length?'<div class="pgrid">'+E.map(e=>entCard(e)).join('')+'</div>':'<div class="empty"><h2>Sin entradas pendientes</h2><p>Cada entrada es la fruta que trae un productor: cajas, peso, lo que ya viene para segunda, Torreón o juguera y notas.'+(P.size?' Las que ya se empacaron están en Procesado.':'')+'</p></div>');
  }
  return topbar('Entrada de Fruta','menu')+`<main class="wrap"><div class="finacts recacts"><button class="btn sm" data-act="recsem">Hoja semanal · Excel o PDF</button></div>${tabs}${body}</main>${ro?'':`<div class="dock"><div class="dockin"><button class="btn primary" data-act="eadd">+ Agregar productor</button></div></div>`}`;
}
function pesosHtml(){
  const e=INV.entradas.find(x=>x.id===sheet.eid);if(!e)return '';
  const t=sheet.tab==='gr'?'gr':'ch',arr=(e.pesos&&e.pesos[t])||[],pp=pesoProm(arr);
  return `<h3>Pesos de muestra · ${esc(e.nombre||'')}</h3><div class="seg" role="group" aria-label="Tipo de caja" style="margin:8px 0"><button data-act="pwtab:ch" aria-pressed="${t==='ch'}">Pequeña</button><button data-act="pwtab:gr" aria-pressed="${t==='gr'}">Grande</button></div>
<div class="pwrow"><input class="in" id="pw-in" inputmode="decimal" autocomplete="off" placeholder="Peso en kg, por ejemplo 18.6" aria-label="Peso de una caja ${t==='gr'?'grande':'pequeña'}"><button class="btn primary" data-act="pwadd">Agregar</button></div>
<div class="pwlist">${arr.length?arr.map((w,i)=>`<button class="pwc" data-act="pwdel:${i}" aria-label="Quitar ${esc(w)} kg">${esc(fmt(num(w),2))} kg <span aria-hidden="true">×</span></button>`).join(''):'<p class="note">Todavía no hay pesos de cajas '+(t==='gr'?'grandes':'pequeñas')+'.</p>'}</div>
<div class="panel" style="margin-top:10px"><div class="kv"><span>Cajas pesadas</span><b>${pp?pp.n:0}</b></div><div class="kv"><span>Peso total pesado</span><b>${pp?fmt(pp.sum,2):'0'} kg</b></div><div class="kv" style="border-bottom:0"><span>Promedio por caja</span><b>${pp?fmt(pp.avg,2)+' kg':'–'}</b></div></div>
<p class="note" style="margin-top:8px">${esc(pesoTxt(e))}. Es una estimación de referencia con las cajas que se pesaron.</p><div class="srow2"><button class="btn" data-act="closesheet">Listo</button></div>`;
}
function pwAdd(){
  const e=sheet&&INV.entradas.find(x=>x.id===sheet.eid);if(!e||ro)return;const i=document.getElementById('pw-in');
  const v=num(i&&i.value);if(v==null||v<=0){toast('Escribe un peso mayor que cero');return}
  e.pesos=e.pesos||{ch:[],gr:[]};const t=sheet.tab==='gr'?'gr':'ch';(e.pesos[t]=e.pesos[t]||[]).push(v);touchE(e);renderSheet();render();
  const n=document.getElementById('pw-in');if(n)n.focus();
}
function invAct(act,arg,a2,a3){
  switch(act){
    case 'eadd':if(ro)return;sheet={kind:'add',mode:'inv',q:'',items:[]};renderSheet();break;
    case 'eopen':openE=openE===arg?null:arg;render();break;
    case 'etab':invTab=['ent','inv','proc','seg'].indexOf(arg)>=0?arg:'ent';render();break;
    case 'iwk':sheet={kind:'iwk',t:arg==='seg'?'seg':'inv'};renderSheet();break;
    case 'iwkset':if(sheet&&sheet.kind==='iwk'){if(sheet.t==='seg')segWk=arg;else invWk=arg;sheet=null;renderSheet();render();window.scrollTo(0,0)}break;
    case 'sjug':if(!openSegJug(segWkCur()))toast('No hay segundas disponibles');break;
    case 'segx':if(typeof ExcelJS==='undefined'){toast('La descarga en Excel no está disponible aquí');break}segSemOut();break;
    case 'jgan':jugAnular(arg,a2,a3);break;
    case 'isrtdir':{const s=invSortOf(invTab);s.dir=s.dir==='asc'?'desc':'asc';invSortSet(invTab,s);render();break}
    case 'edel':{if(ro)return;if(confirmKey!=='edel:'+arg){armConfirm('edel:'+arg);render();return}const e=INV.entradas.find(x=>x.id===arg);if(e){logAdd({k:'del',what:'ent',ids:[e.id],ctx:{t:'e',id:e.id,cod:e.nombre||''},lab:'Entrada de '+(e.nombre||'productor')+' del '+fmtDate(e.fecha)});e.deleted=true;touchE(e)}confirmKey=null;render();toast('Entrada eliminada');break}
    case 'epes':sheet={kind:'pesos',eid:arg,tab:'ch'};renderSheet();setTimeout(()=>{const i=document.getElementById('pw-in');if(i)i.focus()},200);break;
    case 'pwtab':if(sheet){sheet.tab=arg;renderSheet()}break;
    case 'pwadd':pwAdd();break;
    case 'pwdel':{const e=sheet&&INV.entradas.find(x=>x.id===sheet.eid);if(!e||ro)return;const t=sheet.tab==='gr'?'gr':'ch';e.pesos[t].splice(+arg,1);touchE(e);renderSheet();render();break}
    case 'invx':exportInv();break;
    case 'pinv':{const o=cur();if(!o||ro)return;const p=o.productores.find(x=>x.id===arg);if(p&&invFill(p)){touch(o);pesSync();render();toast('Se cargó la fruta de Entrada de Fruta')}break}
  }
}
$app.addEventListener('input',e=>{
  const el=e.target,b=el&&el.dataset&&el.dataset.ebind;if(!b||ro)return;
  const q=b.split('.'),en=INV.entradas.find(x=>x.id===q[0]);if(!en)return;
  let v=el.value;if(el.dataset.enum)v=num(v);if(q[1]==='codigo')v=v==null?null:Math.round(v);
  const prevC=en.codigo;en[q[1]]=v;
  /* código y nombre se corrigen en cualquier momento: el código trae el nombre de la lista y el nombre exacto de la lista trae su código */
  if(q[1]==='codigo'&&v){const li=LISTA.find(x=>x.c===v),pl=LISTA.find(x=>x.c===prevC),nm=String(en.nombre||'').trim();
    if(li&&(!nm||(pl&&norm(pl.n)===norm(nm))||LISTA.some(x=>norm(x.n)===norm(nm)))){en.nombre=li.n;const n=document.getElementById('f-e-'+en.id+'-nombre');if(n)n.value=li.n}}
  if(q[1]==='nombre'){const li=LISTA.find(x=>norm(x.n)===norm(String(v||'').trim()));if(li&&en.codigo!==li.c){en.codigo=li.c;const c=document.getElementById('f-e-'+en.id+'-codigo');if(c)c.value=li.c}}
  touchE(en);
  const h=$app.querySelector('[data-out="eh.'+en.id+'"]');if(h)h.textContent=entHead(en);
  const p=$app.querySelector('[data-out="ep.'+en.id+'"]');if(p)p.textContent=pesoTxt(en);
  const kw=$app.querySelector('[data-out="ekw.'+en.id+'"]');if(kw)kw.textContent=kgCajaTxt(kgCajaChk(en.kilos,en.k18,en.k24));
  if(q[1]==='kilos'||q[1]==='k24'||q[1]==='k18'){pesSync();if(view==='order')updateDerived()}
});
/* al terminar de corregir el código o el nombre, se actualiza también en los pedidos donde se empacó esa entrada */
$app.addEventListener('change',e=>{const el=e.target,b=el&&el.dataset&&el.dataset.ebind;if(!b||ro)return;const q=b.split('.');if(q[1]!=='codigo'&&q[1]!=='nombre')return;
  const en=INV.entradas.find(x=>x.id===q[0]);if(!en)return;let n=0;
  visible().forEach(o=>{let ch=false;(o.productores||[]).forEach(p=>{if(!p.invEnt||p.invEnt.indexOf(en.id)<0)return;if(p.codigo!==en.codigo||p.nombre!==en.nombre){p.codigo=en.codigo;p.nombre=en.nombre;ch=true;n++}});if(ch)touch(o)});
  logAdd({k:'note',ctx:{t:'e',id:en.id,cod:en.nombre||''},lab:'Productor corregido en Entrada de Fruta',o:'',n:(en.codigo?pad(en.codigo,3)+' · ':'')+(en.nombre||'')});
  if(n)toast('También se corrigió en '+n+(n===1?' renglón':' renglones')+' del Registro de Empaque')});
$sh.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='pw-in'){e.preventDefault();pwAdd()}});
$app.addEventListener('change',e=>{const el=e.target;if(!el.dataset||!el.dataset.ap||ro)return;const o=cur(),ids=el.dataset.ap.split(':');const p=o&&o.productores.find(x=>x.id===ids[0]),a=p&&(p.aportes||[]).find(x=>x.id===ids[1]);if(!a)return;
  const l=seg2Lots().get(a.lot),max=n0(a.n)+(l?l.av:0);let v=Math.round(n0(String(el.value).replace(/\D+/g,'')));if(v>max){v=max;toast('Solo hay '+fmt(max)+' disponibles de esa entrega')}
  const old=a.n;a.n=v;c23Sync(p);touch(o);logAdd({k:'note',ctx:ctxOf(o),lab:segName()+' · '+(a.nombre||'productor'),o:fmt(n0(old)),n:fmt(v)});render()});
$sh.addEventListener('input',e=>{const el=e.target;if(!sheet||sheet.kind!=='seg2'||!el.dataset||!el.dataset.s2)return;const d=el.value.replace(/\D+/g,'');if(d!==el.value)el.value=d;if(d)sheet.q[el.dataset.s2]=d;else delete sheet.q[el.dataset.s2];const t=document.getElementById('s2tot');if(t)t.textContent=seg2Tot()});
/* v8.21 · ventana de reempaque: casillas, cajas que salen y cajas que salieron */
function rmpLive(id){const o=orders.find(x=>x.id===sheet.oid);if(!o)return;const A=rmpAvail(o),C=A.filter(a=>sheet.sel[a.id]).map(rmpLineCalc),x=C.find(y=>y.a.id===id);
  if(x){const m=$sh.querySelector('[data-rmm="'+id+'"]');if(m)m.textContent=x.merma>0.005?'merma '+fmt(x.merma,1)+' kg':x.merma<-0.005?'+'+fmt(-x.merma,1)+' kg':'sin merma'}
  const t=document.getElementById('rmtot');if(t)t.textContent=rmpTot(C)}
$sh.addEventListener('input',e=>{const el=e.target;if(!sheet||sheet.kind!=='rmp'||!el.dataset)return;const id=el.dataset.rmq||el.dataset.rmn;if(!id)return;
  const d=el.value.replace(/\D+/g,'');if(d!==el.value)el.value=d;
  if(el.dataset.rmq){sheet.q[id]=d;delete sheet.nq[id];delete sheet.nq[id+'#48']}else{sheet.nq[id]=d;rmpLive(id.replace(/#48$/,''))}});
$sh.addEventListener('change',e=>{const el=e.target;if(sheet&&sheet.kind==='usr'&&el.dataset&&el.dataset.usrol){usrRol(el.dataset.usrol,el.value);return}if(sheet&&sheet.kind==='etq'&&el.dataset&&el.dataset.etqsel){if(el.checked)sheet.sel[el.dataset.etqsel]=true;else delete sheet.sel[el.dataset.etqsel];renderSheet()}});
$sh.addEventListener('change',e=>{const el=e.target;if(!sheet||sheet.kind!=='rmp'||!el.dataset)return;
  if(el.dataset.rmsel){if(el.checked)sheet.sel[el.dataset.rmsel]=true;else{delete sheet.sel[el.dataset.rmsel];delete sheet.nq[el.dataset.rmsel];delete sheet.nq[el.dataset.rmsel+'#48']}renderSheet()}
  else if(el.dataset.rmq){setTimeout(()=>{if(sheet&&sheet.kind==='rmp')renderSheet()},0)} /* el change llega al salir de la casilla: se redibuja después */
  else if(el.dataset.rmmm){sheet.mm[el.dataset.rmmm]=el.value;renderSheet()}
  else if(el.dataset.rmdest){sheet.dest=el.value;renderSheet()} /* las cajas corregidas se conservan al cambiar de viaje */});
/* ---------- Excel e inventario en la base de datos ---------- */
function invSheetSpec(){
  return{name:'Entrada de fruta',cols:[{k:'fecha',h:'Fecha',w:12,al:'center'},{k:'productor',h:'Productor',w:30},{k:'codigo',h:'Código',w:9,al:'center'},{k:'k24',h:'Cajas grandes',w:10,fmt:'#,##0'},{k:'k18',h:'Cajas pequeñas',w:10,fmt:'#,##0'},{k:'kilos',h:'Peso (kg)',w:11,fmt:'#,##0.0'},{k:'seg',h:'Segunda',w:10,fmt:'#,##0'},{k:'tor',h:'Torreón',w:10,fmt:'#,##0'},{k:'jug',h:'Juguera',w:10,fmt:'#,##0'},{k:'pch',h:'Prom. pequeña (kg)',w:12,fmt:'0.00'},{k:'pgr',h:'Prom. grande (kg)',w:12,fmt:'0.00'},{k:'est',h:'Peso estimado (kg)',w:13,fmt:'#,##0'},{k:'nota',h:'Notas',w:34}],
    rows:entradas().sort((a,b)=>(a.fecha||'').localeCompare(b.fecha||'')).map(e=>{const x=pesoEst(e);return{fecha:fmtDate(e.fecha),productor:e.nombre||'',codigo:e.codigo?pad(e.codigo,3):'',k24:num(e.k24),k18:num(e.k18),kilos:num(e.kilos),seg:num(e.seg),tor:num(e.tor),jug:num(e.jug),pch:x&&x.ch?Math.round(x.ch.avg*100)/100:null,pgr:x&&x.gr?Math.round(x.gr.avg*100)/100:null,est:x&&x.kg?Math.round(x.kg):null,nota:e.nota||''}})};
}
async function exportInv(){
  if(typeof ExcelJS==='undefined'){toast('La descarga en Excel no está disponible aquí');return}
  try{
    const D=[...invData().values()].sort((a,b)=>a.nombre.localeCompare(b.nombre)),stamp=todayISO(),wb=newWb();
    const cols=[{k:'productor',h:'Productor',w:30},{k:'codigo',h:'Código',w:9,al:'center'}].concat(INV_F.map(f=>({k:'av_'+f,h:INV_L[f]+' disponible',w:13,fmt:f==='kilos'?'#,##0.0':'#,##0'})),INV_F.map(f=>({k:'in_'+f,h:INV_L[f]+' entró',w:12,fmt:f==='kilos'?'#,##0.0':'#,##0'})),[{k:'ped',h:'Pasó a empaque en',w:30}]);
    cols.push({k:'sres',h:'Segundas resultantes',w:13,fmt:'#,##0'},{k:'sdisp',h:'Segundas disponibles 1.5',w:14,fmt:'#,##0'});
    const rows=D.map(a=>{const r={productor:a.nombre,codigo:a.codigo?pad(a.codigo,3):'',sres:a.res.prod-a.res.llevo,sdisp:a.segDisp,ped:a.uses.map(u=>u.o.cod).filter((v,i,s)=>s.indexOf(v)===i).join(', ')};INV_F.forEach(f=>{r['av_'+f]=a.av[f];r['in_'+f]=a.in[f]});return r});
    XL.addBase(wb,{titulo:'Entrada de Fruta · Inventario',sub:'Exportado el '+fmtDate(stamp)+' · '+D.length+' productores · '+entradas().length+' entradas',cols:cols,rows:rows,extra:[invSheetSpec()]});
    await saveFile('Inventario_fruta_'+stamp+'.xlsx',await wbBlob(wb),'Inventario de fruta');
  }catch(e){toast('No se pudo generar el Excel')}
}
/* ---------- sincronización (tabla entradas en Supabase) ---------- */
async function syncInv(){
  try{
    const idx=(await sb('/rest/v1/entradas?select=id,updated_at&order=updated_at.desc&limit=5000'))||[];
    INV.noTable=false;
    const need=idx.filter(r=>{const l=INV.entradas.find(x=>x.id===r.id),t=Number(r.updated_at)||0;return !l||(SYNCB.se[r.id]!=null?t!==SYNCB.se[r.id]:t>(l.updatedAt||0)||INV.dirty.indexOf(r.id)>=0)});
    for(let i=0;i<need.length;i+=50){
      const rows=(await sb('/rest/v1/entradas?select=id,updated_at,data&id=in.('+need.slice(i,i+50).map(r=>r.id).join(',')+')'))||[];
      rows.forEach(r=>{if(!r.data)return;remoteN++;const d=JSON.parse(JSON.stringify(r.data));d.id=r.id;d.updatedAt=Number(r.updated_at)||0;const k=INV.entradas.findIndex(x=>x.id===r.id);
        if(k>=0&&INV.dirty.indexOf(r.id)>=0){const m=merge3(SYNCB.e[r.id],INV.entradas[k],d);m.id=r.id;m.updatedAt=Math.max(Date.now(),d.updatedAt+1);INV.entradas[k]=m}
        else{if(k<0)INV.entradas.push(d);else INV.entradas[k]=d;INV.dirty=INV.dirty.filter(x=>x!==r.id)}
        SYNCB.se[r.id]=d.updatedAt;setBase('e',r.id,d)});
    }
    if(!ro){
      const send=INV.dirty.map(id=>INV.entradas.find(e=>e.id===id)).filter(Boolean).map(e=>({e:e,t:e.updatedAt}));
      const eDone=x=>{SYNCB.se[x.e.id]=x.t;setBase('e',x.e.id,x.e);if(x.e.updatedAt===x.t)INV.dirty=INV.dirty.filter(id=>id!==x.e.id)};
      const conf=await pushCas('entradas',send.map(x=>({x:x,id:x.e.id,t:x.t,d:x.e,base:SYNCB.se[x.e.id]})),eDone);
      for(const id of conf){for(let n=0;n<3;n++){
        const r=((await sb('/rest/v1/entradas?select=id,updated_at,data&id=eq.'+encodeURIComponent(id)))||[])[0],k=INV.entradas.findIndex(x=>x.id===id);if(!r||!r.data||k<0)break;
        const d=JSON.parse(JSON.stringify(r.data));d.id=id;d.updatedAt=Number(r.updated_at)||0;const m=merge3(SYNCB.e[id],INV.entradas[k],d);m.id=id;m.updatedAt=Math.max(Date.now(),d.updatedAt+1);INV.entradas[k]=m;SYNCB.se[id]=d.updatedAt;setBase('e',id,d);remoteN++;
        if(await pushOne('entradas',{id:id,t:m.updatedAt,d:m,base:d.updatedAt})){eDone({e:m,t:m.updatedAt});break}
      }}
    }
    saveInv();
  }catch(e){if(e&&(e.status===404||e.status===400))INV.noTable=true}
}

/* ---------- registro de cambios (bitácora): quién cambió qué, cuándo y el valor anterior; revertir un cambio puntual ---------- */
const LS_LOG='empaque-bitacora';
/* entradas contables: no se revierten ni se borran con la limpieza */
const LOG_KEEP=['param','period','cobro','pago'];
let LOG={list:[],dirty:[],noTable:false};
(function(){try{const j=JSON.parse(localStorage.getItem(LS_LOG)||'null');if(j&&Array.isArray(j.list))LOG={list:j.list,dirty:Array.isArray(j.dirty)?j.dirty:[],noTable:false}}catch(e){}})();
function saveLog(){try{localStorage.setItem(LS_LOG,JSON.stringify({list:LOG.list,dirty:LOG.dirty}))}catch(e){}}
function canRevert(){return !ro&&!!authUser&&(authUser.rol==='admin'||authUser.rol==='jefe')}
const sv=v=>v==null?'':String(v);
const O_LAB={cod:'Pedido',emb:'Código de embarque',po:'PO',fecha:'Fecha',semana:'Semana',factura:'Factura',customer:'Cliente',domestic:'Cliente doméstico',kgCaja:'Kg por caja de campo'};
const OB_LAB={destino:'Destino',incoterm:'INCOTERM',diasPago:'Días de pago',rech:'Cajas rechazadas',reclamo:'Motivo del reclamo',naviera:'Naviera o transportista',contenedor:'Contenedor',eta:'ETA',llegada:'Llegada real',demora:'Demoras (USD)',personas:'Personas en el turno',horas:'Horas del turno',paro:'Minutos de paro'};
const P_LAB={precioKg:'Acuerdo de compra · precio (MXN por kg)',modal:'Acuerdo de compra · modalidad',nombre:'Nombre',codigo:'Código',k24:'Cajas grandes',k18:'Cajas pequeñas',kilos:'Kilos',seg:'Segundas',cera:'Segundas con cera',segLlevo:'Se llevó sus segundas',tor:'Torreón',des:'Desecho',jug:'Juguera',nota:'Notas'};
const D_LAB={h1:'Membrete empresa',h2:'Membrete línea 2',h3:'Membrete línea 3',salida:'Fecha de salida',llegada:'Fecha de llegada',hora:'Hora de salida',cliente:'Compañía',factura:'Factura',poCli:'P.O.',poLinea:'P.O. línea',cantTxt:'Cantidad de cajas',linea:'Transportista',operador:'Conductor',placasT:'Placas del tractor',placasF:'Placas del termo',coment:'Comentarios',alpha:'Código ALPHA',caat:'Código CAAT',eco:'Trailer (núm. económico)',cert:'Certificado',viaje:'No. de viaje',sello:'Sello',prov:'Proveedor',vend:'Vendedor',pOrder:'P. Order',tel:'Teléfono del vendedor'};
const E_LAB={zona:'Zona o huerta',mPri:'Muestreo primera %',mSeg:'Muestreo segunda %',mDes:'Muestreo desecho %',fecha:'Fecha de llegada',codigo:'Código',nombre:'Productor',nota:'Notas'};
const VIEW_L={order:'Registro de Empaque',trazo:'Código de Trazabilidad',docs:'Documentos',inv:'Entrada de Fruta'};
function ctxOf(o){return {t:'o',id:o.id,cod:o.cod,emp:o.emp,v:o.variante}}
function logAdd(x){
  if(ro||!authUser)return null;
  const now=Date.now(),me=authUser.id||'';
  if(x.k==='edit'){
    /* ediciones seguidas del mismo campo por la misma persona se juntan en una sola entrada */
    const L=LOG.list.find(e=>e.path===x.path&&e.ctx&&x.ctx&&e.ctx.id===x.ctx.id);
    if(L&&L.k==='edit'&&L.uid===me&&now-L.ts<180000&&!LOG.list.some(r=>r.rev===L.id)){
      L.n=x.n;L.ts=now;L.gone=sv(L.n)===sv(L.o);if(LOG.dirty.indexOf(L.id)<0)LOG.dirty.push(L.id);saveLog();setSync();return L;
    }
  }
  const e=Object.assign({id:uid(),ts:now,u:authUser.name||authUser.user||'—',uid:me,where:VIEW_L[view]||''},x);
  LOG.list.unshift(e);LOG.dirty.push(e.id);saveLog();setSync();return e;
}
/* lee y escribe un campo del pedido a partir de su ruta (la misma que usan las casillas) */
function bindRef(o,b){
  const p=b.split('.');
  if(p[0]==='o')return {get:()=>o[p[1]],set:v=>{o[p[1]]=v},o:o};
  if(p[0]==='m'){
    if(p.length===3)return {get:()=>((o.manT||{})[p[1]]||{})[p[2]],set:v=>{o.manT=o.manT||{};(o.manT[p[1]]=o.manT[p[1]]||{})[p[2]]=v;syncManSum(o)},o:o};
    return {get:()=>(o.manifiesto||{})[p[1]],set:v=>{o.manifiesto=o.manifiesto||{};o.manifiesto[p[1]]=v},o:o};
  }
  if(p[0]==='p'){
    const pr=()=>o.productores.find(x=>x.id===p[1]);
    if(p[2]==='acc')return {get:()=>{const r=pr();return r?accOf(r,p[3])[p[4]]:undefined},set:v=>{const r=pr();if(!r)throw new Error('gone');accOf(r,p[3],true)[p[4]]=v;if(r.accx)delete r.accx[p[3]+':'+p[4]]},o:o};
    return {get:()=>{const r=pr();return r?r[p[2]]:undefined},set:v=>{const r=pr();if(!r)throw new Error('gone');r[p[2]]=v},o:o};
  }
  if(p[0]==='ob'){const m=mainOf(o);return {get:()=>(m.bi||{})[p[1]],set:v=>{m.bi=m.bi||{};m.bi[p[1]]=v},o:m}}
  if(p[0]==='z'){const m=mainOf(o);return {get:()=>ensureTraz(m).hdr[p[1]],set:v=>{ensureTraz(m).hdr[p[1]]=v},o:m}}
  if(p[0]==='t'||p[0]==='tl'){
    const m=mainOf(o),pl=()=>ensureTraz(m).tarimas.find(x=>x.id===p[1]);
    if(p[0]==='t')return {get:()=>{const x=pl();return x?x[p[2]]:undefined},set:v=>{const x=pl();if(!x)throw new Error('gone');x[p[2]]=v},o:m};
    const ln=()=>{const x=pl();return x&&x.lines.find(l=>l.id===p[2])};
    return {get:()=>{const l=ln();return l?l[p[3]]:undefined},set:v=>{const l=ln();if(!l)throw new Error('gone');l[p[3]]=v},o:m};
  }
  if(p[0]==='d'){const m=docMain(o);return {get:()=>dv(m,p[1]),set:v=>{m.docs=m.docs||{};m.docs[p[1]]=v},o:m}}
  return null;
}
function logKey(el){const d=el.dataset||{};if(d.bind)return {t:'b',b:d.bind,num:!!d.num};if(d.doc)return {t:'b',b:'d.'+d.doc};if(d.ebind)return {t:'e',b:d.ebind,num:!!d.enum};return null}
function logResolve(k){
  if(k.t==='e'){const q=k.b.split('.'),e=INV.entradas.find(x=>x.id===q[0]);return e?{ctx:{t:'e',id:e.id,cod:e.nombre||''},ref:{get:()=>e[q[1]]},e:e,f:q[1]}:null}
  const o=cur();if(!o)return null;const r=bindRef(o,k.b);if(!r)return null;return {ctx:ctxOf(r.o||o),ref:r,o:o};
}
function logLabel(k,R){
  if(k.t==='e')return (R.e.nombre||'Entrada')+' · '+(INV_L[R.f]||E_LAB[R.f]||R.f);
  const p=k.b.split('.'),o=R.o;
  if(p[0]==='o')return 'Encabezado · '+(O_LAB[p[1]]||p[1]);
  if(p[0]==='ob')return 'Encabezado · '+(OB_LAB[p[1]]||p[1]);
  if(p[0]==='m')return 'Manifiesto '+(p.length===3?TIPO_L[p[1]]+' · ':'')+'calibre '+(CAL_LAB[p[p.length-1]]||p[p.length-1]);
  if(p[0]==='p'){const pr=o.productores.find(x=>x.id===p[1]),nm=pr?(pr.nombre||'Productor'):'Productor';return p[2]==='acc'?nm+' · '+(TIPO_L[p[3]]||p[3])+' calibre '+(CAL_LAB[p[4]]||p[4]):nm+' · '+(P_LAB[p[2]]||p[2])}
  if(p[0]==='z'){const f=HDR_FIELDS.find(x=>x[0]===p[1]);return 'Encabezado del embarque · '+(f?f[1]:p[1])}
  if(p[0]==='t'||p[0]==='tl'){
    const ts=ensureTraz(mainOf(o)).tarimas,i=ts.findIndex(x=>x.id===p[1]),n='Tarima '+(i+1);
    if(p[0]==='t')return n+' · '+(p[2]==='marca'?'Calidad':'Presentación');
    const li=ts[i]?ts[i].lines.findIndex(l=>l.id===p[2]):-1;return n+' · línea '+(li+1)+' · '+({cal:'Calibre',cant:'Cajas',prod:'Productor'}[p[3]]||p[3]);
  }
  if(p[0]==='d')return 'Documentos · '+(D_LAB[p[1]]||p[1]);
  return k.b;
}
const logPend=new WeakMap();
document.addEventListener('focusin',e=>{const el=e.target;if(!el||!el.dataset||ro||!authUser)return;const k=logKey(el);if(!k)return;const R=logResolve(k);if(R)logPend.set(el,{k:k,before:sv(R.ref.get())})});
function logCommit(el){
  const P=logPend.get(el);if(!P)return;const R=logResolve(P.k);if(!R)return;
  const after=sv(R.ref.get());if(after===P.before)return;
  logAdd({k:'edit',ctx:R.ctx,path:P.k.t==='e'?'e.'+P.k.b:P.k.b,num:P.k.num,lab:logLabel(P.k,R),o:P.before,n:after});P.before=after;
}
document.addEventListener('focusout',e=>{const el=e.target;setTimeout(()=>logCommit(el),30)});
document.addEventListener('change',e=>{const el=e.target;if(el&&el.tagName==='SELECT')logCommit(el)},true);
function fmtTs(ts){try{return new Date(ts).toLocaleString('es-MX',{dateStyle:'short',timeStyle:'short'})}catch(e){return ''}}
/* revertir: no borra nada, deja un cambio nuevo en el registro */
function revertLog(id,force){
  const e=LOG.list.find(x=>x.id===id);if(!e||!canRevert())return;
  if(e.k==='del')return restoreLog(e);
  if(e.k!=='edit')return;
  let ref,done;
  if(e.ctx.t==='e'){
    const q=e.path.split('.'),en=INV.entradas.find(x=>x.id===q[1]);if(!en||en.deleted){toast('Esa entrada ya no existe');return}
    ref={get:()=>en[q[2]],set:v=>{en[q[2]]=v}};done=()=>touchE(en);
  }else{
    const o=orders.find(x=>x.id===e.ctx.id);if(!o||o.deleted){toast('Esa hoja ya no existe o está eliminada');return}
    ref=bindRef(o,e.path);done=()=>touch(ref.o||o);
  }
  if(!ref){toast('Este cambio no se puede revertir');return}
  const now=sv(ref.get());
  if(now!==sv(e.n)&&!force){confirmKey='rv:'+id;renderSheet();return}
  try{ref.set(e.o===''?(e.num?null:''):(e.num?num(e.o):e.o))}catch(x){toast('El productor o la tarima de este cambio ya no existe');return}
  done();confirmKey=null;
  logAdd({k:'revert',rev:e.id,ctx:e.ctx,path:e.path,num:e.num,lab:e.lab,where:e.where,o:now,n:e.o});
  invalidateStats();render();renderSheet();toast('Cambio revertido');
}
function restoreLog(e){
  if(!canRevert())return;
  if(e.what==='p'){
    const o=orders.find(x=>x.id===e.ctx.id);if(!o||o.deleted){toast('La hoja de ese productor ya no existe');return}
    if(!o.productores.some(p=>p.id===e.snap.id))o.productores.splice(Math.min(e.idx||0,o.productores.length),0,clone(e.snap));touch(o);
  }else if(e.what==='t'){
    const o=orders.find(x=>x.id===e.ctx.id);if(!o||o.deleted){toast('Ese pedido ya no existe');return}
    const t=ensureTraz(o);if(!t.tarimas.some(p=>p.id===e.snap.id))t.tarimas.splice(Math.min(e.idx||0,t.tarimas.length),0,clone(e.snap));touch(o);
  }else if(e.what==='sheet'){
    const xs=(e.ids||[]).map(id=>orders.find(x=>x.id===id)).filter(Boolean);
    if(xs.some(x=>visible().some(y=>y.id!==x.id&&y.emp===x.emp&&y.cod===x.cod&&y.variante===x.variante))){toast('Ya existe otra hoja con ese pedido; no se puede restaurar encima');return}
    xs.forEach(x=>{x.deleted=false;touch(x)});
  }else if(e.what==='ent'){
    const en=INV.entradas.find(x=>x.id===(e.ids||[])[0]);if(en){en.deleted=false;touchE(en)}
  }else return;
  logAdd({k:'restore',rev:e.id,ctx:e.ctx,lab:e.lab,where:e.where});
  invalidateStats();render();renderSheet();toast('Restaurado');
}
function logScope(){
  if((view==='order'||view==='trazo'||view==='docs')&&cur()){const o=cur(),ids=sheetsOf(o).map(x=>x.id);return {label:'Pedido '+o.cod,f:e=>e.ctx&&e.ctx.t==='o'&&(ids.indexOf(e.ctx.id)>=0||(e.ctx.emp===o.emp&&e.ctx.cod===o.cod))}}
  if(view==='inv')return {label:'Entrada de Fruta',f:e=>e.ctx&&e.ctx.t==='e'};
  return null;
}
function logHtml(){
  const sc=logScope(),here=sc&&sheet.scope!=='all'&&sheet.scope!=='par';
  let L=LOG.list.filter(e=>!e.gone);if(here)L=L.filter(sc.f);
  /* el contador solo ve los cambios de precios, costos y periodos */
  if(isContador()||sheet.scope==='par')L=L.filter(e=>LOG_KEEP.indexOf(e.k)>=0);
  const n=L.length;L=L.slice(0,150);
  const by=id=>LOG.list.find(r=>r.rev===id);
  const TAG={revert:'<span class="chip info">Revertido</span>',del:'<span class="chip crit">Eliminado</span>',restore:'<span class="chip good">Restaurado</span>',add:'<span class="chip">Agregado</span>',note:'<span class="chip warn">Cambio de tipo</span>',param:'<span class="chip info">Precios y costos</span>',period:'<span class="chip warn">Periodo</span>',cobro:'<span class="chip good">Cobro</span>',pago:'<span class="chip good">Pago</span>'};
  const rows=L.map(e=>{
    const rb=by(e.id),hasV=e.k==='edit'||e.k==='revert'||e.k==='note'||LOG_KEEP.indexOf(e.k)>=0;
    let act='';
    if(rb)act=`<p class="lgrb">${rb.k==='restore'?'Restaurado':'Revertido'} por ${esc(rb.u)} · ${fmtTs(rb.ts)}</p>`;
    else if(canRevert()&&e.k==='edit'){
      if(confirmKey==='rv:'+e.id){const o=e.ctx.t==='o'&&orders.find(x=>x.id===e.ctx.id),r=o&&bindRef(o,e.path),en=e.ctx.t==='e'&&INV.entradas.find(x=>x.id===e.path.split('.')[1]);const nowV=r?sv(r.get()):en?sv(en[e.path.split('.')[2]]):'';
        act=`<div class="warnbox">Este campo cambió después: ahora vale «${esc(nowV||'vacío')}». Si lo reviertes a «${esc(e.o||'vacío')}» se pierde ese cambio.<div class="pact"><button class="btn sm" data-act="lgno">Cancelar</button><button class="btn sm danger" data-act="lgrvf:${e.id}">Revertir de todos modos</button></div></div>`}
      else act=`<button class="btn sm" data-act="lgrv:${e.id}">Revertir este cambio</button>`;
    }else if(canRevert()&&e.k==='del'&&e.what)act=`<button class="btn sm" data-act="lgrv:${e.id}">Restaurar</button>`;
    else if(e.k==='note')act='<p class="lgrb">Este cambio se corrige a mano en la hoja.</p>';
    else if(e.k==='param'&&String(e.path||'').indexOf('dec.')===0)act='<p class="lgrb">Para corregirla, usa «Corregir» en Decisiones de dirección (Pendientes).</p>';
    else if(e.k==='param'&&e.path==='pesos')act='<p class="lgrb">Para corregirlo, cambia el valor en Pesos y equivalencias (engrane de Registro de Empaque).</p>';
    else if(e.k==='param'&&e.path!=='fin')act='<p class="lgrb">No se revierte: para corregirlo se guarda una versión nueva en Precios y costos.</p>';
    return `<div class="lgr">${TAG[e.k]||''}<b class="lgl">${esc(e.lab||'')}</b>${hasV?`<div class="lgv"><span>${esc(e.o===''||e.o==null?'vacío':e.o)}</span> → <b>${esc(e.n===''||e.n==null?'vacío':e.n)}</b></div>`:''}<small class="lgm">${esc([e.where,e.ctx&&e.ctx.cod?(e.ctx.cod+(e.ctx.v?' · hoja '+e.ctx.v:'')):''].filter(Boolean).join(' · '))}<br>${esc(e.u)} · ${fmtTs(e.ts)}</small>${act}</div>`;
  }).join('');
  const tabs=isContador()?'':`<div class="sib" style="margin:8px 0">${sc?`<button class="btn sm" data-act="lgsc:here" aria-pressed="${!!here&&sheet.scope!=='par'}">${esc(sc.label)}</button>`:''}<button class="btn sm" data-act="lgsc:all" aria-pressed="${!here&&sheet.scope!=='par'}">Todo</button><button class="btn sm" data-act="lgsc:par" aria-pressed="${sheet.scope==='par'}">Contable</button></div>`;
  const keepK=e=>LOG_KEEP.indexOf(e.k)>=0,old=LOG.list.filter(e=>Date.now()-e.ts>365*864e5&&!keepK(e)).length;
  const clean=isAdmin()?`<div class="panel" style="margin-top:12px"><p class="note">Limpieza (solo administrador): borra del registro los cambios de más de 12 meses. Hay ${fmt(old)}. Los cambios de precios, costos, periodos, cobros y pagos no se borran nunca.</p><div class="pact"><button class="btn sm danger" data-act="lgclean" ${old?'':'disabled'}>${confirmKey==='lgclean'?'Toca otra vez para borrar':'Borrar más de 12 meses'}</button></div></div>`:'';
  return `<h3>Registro de cambios</h3><p class="note">Cada cambio guarda dónde fue, quién lo hizo, la fecha y hora, y el valor anterior. Revertir no borra nada: deja un cambio nuevo en el registro.${canRevert()?'':' Solo el administrador y el jefe de empaque pueden revertir.'}</p>${tabs}${rows||'<p class="note" style="margin-top:12px">Todavía no hay cambios registrados aquí.</p>'}${n>150?`<p class="note">Se muestran los 150 más recientes de ${fmt(n)}.</p>`:''}${clean}<div class="pact"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
async function cleanLog(){
  if(!isAdmin())return;const cut=Date.now()-365*864e5;
  LOG.list=LOG.list.filter(e=>e.ts>=cut||LOG_KEEP.indexOf(e.k)>=0);LOG.dirty=LOG.dirty.filter(id=>LOG.list.some(e=>e.id===id));saveLog();confirmKey=null;renderSheet();toast('Registro limpio');
  if(cfgOK()&&session)try{await sb('/rest/v1/bitacora?ts=lt.'+cut+'&data->>k=not.in.(param,period,cobro,pago)',{method:'DELETE'})}catch(e){}
}
/* sincronización (tabla bitacora en Supabase): solo se agregan y actualizan entradas */
async function syncLog(){
  try{
    if(!ro||canMov()){
      const send=LOG.dirty.map(id=>LOG.list.find(e=>e.id===id)).filter(Boolean);
      for(let i=0;i<send.length;i+=100){
        const part=send.slice(i,i+100);
        await sb('/rest/v1/bitacora?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:part.map(e=>({id:e.id,ts:e.ts,data:e}))});
        LOG.dirty=LOG.dirty.filter(id=>!part.some(e=>e.id===id));
      }
    }
    const rows=((await sb('/rest/v1/bitacora?select=id,ts,data&order=ts.desc&limit=3000'))||[]).concat((await sb('/rest/v1/bitacora?select=id,ts,data&data->>k=in.(param,period,cobro,pago)&order=ts.desc&limit=20000'))||[]);LOG.noTable=false;
    rows.forEach(r=>{if(!r.data)return;const k=LOG.list.findIndex(x=>x.id===r.id);if(k<0)LOG.list.push(r.data);else if((r.data.ts||0)>(LOG.list[k].ts||0)&&LOG.dirty.indexOf(r.id)<0)LOG.list[k]=r.data});
    LOG.list.sort((a,b)=>b.ts-a.ts);saveLog();
  }catch(e){if(e&&(e.status===404||e.status===400))LOG.noTable=true}
}

/* ---------- v8.1 · Finanzas: sección propia con el panel del contador, cuentas por cobrar y por pagar (Fase 1) ----------
   Ventas en USD, costos y pagos en MXN. Los cobros y pagos se guardan en sus propias tablas («cobros» y «pagos»):
   solo se agregan o se anulan con motivo, nunca se borran. */
const LS_COB='empaque-cobros',LS_PAG='empaque-pagos';
let COB={list:[],dirty:[],noTable:false},PAG={list:[],dirty:[],noTable:false};
(function(){[[LS_COB,COB],[LS_PAG,PAG]].forEach(q=>{try{const j=JSON.parse(localStorage.getItem(q[0])||'null');if(j&&Array.isArray(j.list)){q[1].list=j.list;q[1].dirty=Array.isArray(j.dirty)?j.dirty:[]}}catch(e){}})})();
function saveMov(){_frm=null;try{localStorage.setItem(LS_COB,JSON.stringify({list:COB.list,dirty:COB.dirty}));localStorage.setItem(LS_PAG,JSON.stringify({list:PAG.list,dirty:PAG.dirty}))}catch(e){}invalidateStats();setSync()}
/* registran cobros y pagos: administrador y contador */
function canMov(){if(!authUser||['admin','contador'].indexOf(authUser.rol)<0)return false;if(!cfgOK())return true;return !!session&&['admin','contador'].indexOf(roleOf(session.access_token))>=0}
const r2=v=>Math.round((+v||0)*100)/100;
const movSum=(S,ref,tipo)=>S.list.reduce((s,x)=>s+(x.ref===ref&&!x.anulado&&(!tipo||x.tipo===tipo)?(+x.monto||0):0),0);
/* antigüedad por días de atraso: 0 a 30 verde, 31 a 60 amarillo, más de 60 rojo */
const BUCKETS=[['cur','Por vencer'],['b30','0 a 30 días'],['b60','31 a 60 días'],['b60p','Más de 60 días']];
const bucketOf=d=>d<0?'cur':d<=30?'b30':d<=60?'b60':'b60p';
const BK_CLS={cur:'n',b30:'ok',b60:'w',b60p:'c'},BK_CHIP={cur:'info',b30:'good',b60:'warn',b60p:'crit'};
const MOV_T={cobro:'Cobro',nota:'Nota de crédito o descuento',pago:'Pago',ajuste:'Ajuste o descuento',fact:'Factura',real:'Flete real del embarque'};
const RECLAMO={'':'Sin reclamo',abierto:'En reclamo',nota:'Resuelto con nota de crédito',cerrado:'Resuelto sin nota'};
/* el registro vigente (el más reciente sin anular) de la factura de un pedido o del flete real de un embarque */
function lastMov(S,ref,tipo){let b=null;S.list.forEach(x=>{if(x.ref===ref&&x.tipo===tipo&&!x.anulado&&(!b||(x.at||0)>(b.at||0)))b=x});return b}
var _frm=null;
function fleteReal(e,cod){if(!_frm){_frm=new Map();PAG.list.forEach(x=>{if(x.tipo!=='real'||x.anulado)return;const b=_frm.get(x.ref);if(!b||(x.at||0)>(b.at||0))_frm.set(x.ref,x)})}const x=_frm.get('cxp|flete|'+e+'|'+cod);return x&&+x.monto>=0?+x.monto:null}
const paidSum=ref=>movSum(PAG,ref,'pago')+movSum(PAG,ref,'ajuste');
const estOf=(saldo,hecho)=>saldo<=0.005?'ok':hecho>0.005?'par':'pen';
const FORMAS=['Transferencia','Cheque','Efectivo','Otro'];
/* cuentas por cobrar (una por pedido, en USD) y por pagar (fruta por productor y semana, flete por pedido, en MXN) */
function accData(e0){
  const f=statsF,E=e0||f.emp||'ALL',hoy=todayISO(),key=E+'|'+hoy;if(!f._acc||f._acc.hoy!==hoy)f._acc={hoy:hoy};if(f._acc[key])return f._acc[key];
  const L=visible().filter(o=>E==='ALL'||o.emp===E),FA=finAgg(L),pm=new Map(),cxc=[],cxp=[];
  FA.ords.forEach(x=>{const o=x.o,k=o.emp+'|'+o.cod;let a=pm.get(k);if(!a){a={emp:o.emp,cod:o.cod,usd:0,flete:0,fr:false,sheets:[]};pm.set(k,a)}a.usd+=x.usd;a.flete+=x.flete;a.fr=a.fr||x.fr;a.sheets.push(o)});
  pm.forEach((a,k)=>{
    const m=mainOf(a.sheets[0]),bi=m.bi||{},done=a.sheets.every(o=>o.estado==='completo'),fe=m.fecha||'',wk=wkOf(m);
    /* la factura registrada en Finanzas (fecha y monto) manda sobre lo calculado; vence en la fecha de factura (o del pedido) más los días de pago */
    const ref='cxc|'+k,cob=movSum(COB,ref,'cobro'),nc=movSum(COB,ref,'nota'),fa=lastMov(COB,ref,'fact');
    if(a.usd>0&&(done||m.factura||cob||nc||fa)){const dias=num(bi.diasPago),calc=r2(a.usd),monto=fa&&+fa.monto>0?r2(fa.monto):calc,ff=(fa&&fa.fecha)||'',base=ff||fe,venc=base?dayAdd(base,dias||0):'',hecho=r2(cob+nc),saldo=r2(monto-hecho),atr=venc?dayDiff(venc,hoy):0,nf=(fa&&fa.num)||m.factura||'';
      cxc.push({ref:ref,emp:a.emp,cod:a.cod,lab:(nf?'Factura '+nf:'Pedido '+a.cod),nombre:String(m.customer||'').trim()||'Sin cliente',factura:nf,po:m.po||'',fecha:fe,fFact:ff,dias:dias,venc:venc,calc:calc,fact:fa?monto:null,reclamo:(fa&&fa.reclamo)||'',monto:monto,cob:r2(cob),nc:r2(nc),hecho:hecho,saldo:saldo,dif:r2(cob-calc),est:estOf(saldo,hecho),atr:atr,b:saldo>0.005?bucketOf(atr):null,proc:!done,div:'USD',wk:wk})}
    if(a.flete>0){const ref2='cxp|flete|'+k,pg=paidSum(ref2),pl=num(parsDe(a.emp,wk).plazoFlete),venc=fe?dayAdd(fe,pl||0):'',saldo=r2(a.flete-pg),atr=venc?dayDiff(venc,hoy):0,tr=(m.traz&&m.traz.hdr&&m.traz.hdr.transporte)||'';
      cxp.push({ref:ref2,emp:a.emp,cod:a.cod,tipo:'flete',lab:'Flete y cruce · pedido '+a.cod,nombre:tr||'Flete y cruce',det:'Flete y cruce · pedido '+a.cod+(a.fr?' · flete real':''),fecha:fe,venc:venc,calc:r2(a.flete),real:a.fr,monto:r2(a.flete),hecho:r2(pg),saldo:saldo,dif:r2(pg-a.flete),est:estOf(saldo,pg),atr:atr,b:saldo>0.005?bucketOf(atr):null,div:'MXN',sinPlazo:pl==null})}
  });
  const wg=new Map();L.forEach(o=>{const w=wkOf(o);if(!w)return;const k=o.emp+'|'+w;if(!wg.has(k))wg.set(k,[]);wg.get(k).push(o)});
  wg.forEach((os,k)=>{const q=k.split('|'),e=q[0],wk=q[1],A=finAgg(os),rg=wkRange(wk),pl=num(parsDe(e,wk).plazoProd);
    A.rows.forEach(a=>{if(!(a.pago>0.005))return;const ref='cxp|prod|'+e+'|'+wk+'|'+a.key,pg=paidSum(ref),venc=rg?dayAdd(rg.b,pl||0):'',saldo=r2(a.pago-pg),atr=venc?dayDiff(venc,hoy):0;
      cxp.push({ref:ref,emp:e,tipo:'prod',lab:a.nombre+' · '+wkLab(wk),nombre:a.nombre,codigo:a.codigo,det:'Fruta de '+wkLab(wk)+(a.consig?' · consignación':'')+' · '+fmt(a.kilos)+' kg',wk:wk,fecha:rg?rg.b:'',venc:venc,calc:r2(a.pago),monto:r2(a.pago),hecho:r2(pg),saldo:saldo,dif:r2(pg-a.pago),est:estOf(saldo,pg),atr:atr,b:saldo>0.005?bucketOf(atr):null,div:'MXN',sinPlazo:pl==null})})});
  /* Juguera: una cuenta por cobrar por empresa y semana (MXN) y una por pagar por productor y semana */
  const cxj=[];jugData().W.forEach(w=>{if(E!=='ALL'&&w.emp!==E)return;const rg=wkRange(w.wk),fe=rg?rg.b:'',ref=w.ref,cob=movSum(COB,ref,'cobro'),nc=movSum(COB,ref,'nota'),lq=lastMov(COB,ref,'fact'),hecho=r2(cob+nc);
    if(w.base>0.005||cob||nc||lq){const saldo=r2(w.base-hecho),atr=fe?dayDiff(fe,hoy):0;
      cxj.push({ref:ref,emp:w.emp,jug:true,lab:'Juguera · '+wkLab(w.wk),nombre:'Juguera',det:fmt(w.caj)+' cajas · '+w.prods.size+(w.prods.size===1?' productor':' productores'),po:'',factura:(lq&&lq.num)||'',fecha:fe,fFact:lq?lq.fecha:'',dias:0,venc:fe,calc:w.calc==null?0:w.calc,sinPrecio:w.calc==null,fact:w.liq,reclamo:'',monto:r2(w.base),cob:r2(cob),nc:r2(nc),hecho:hecho,saldo:saldo,dif:r2(cob-(w.calc||0)),est:estOf(saldo,hecho),atr:atr,b:saldo>0.005?bucketOf(atr):null,div:'MXN',wk:w.wk,caj:w.caj})}
    const pl=num(parsDe(w.emp,w.wk).plazoProd),venc=fe?dayAdd(fe,pl||0):'';
    w.prods.forEach(a=>{const r='cxp|jug|'+w.emp+'|'+w.wk+'|'+a.key,pg=paidSum(r);if(!(a.pago>0.005)&&!pg)return;const saldo=r2(a.pago-pg),atr=venc?dayDiff(venc,hoy):0;
      cxp.push({ref:r,emp:w.emp,tipo:'jug',lab:a.nombre+' · Juguera '+wkLab(w.wk),nombre:a.nombre,codigo:a.codigo,det:'Juguera de '+wkLab(w.wk)+' · '+fmt(a.caj,a.caj%1?1:0)+' cajas'+(w.par.modo==='fijo'?' a precio fijo':w.liq!=null?' · liquidada':' · estimada'),wk:w.wk,fecha:fe,venc:venc,calc:r2(a.pago),monto:r2(a.pago),hecho:r2(pg),saldo:saldo,dif:r2(pg-a.pago),est:estOf(saldo,pg),atr:atr,b:saldo>0.005?bucketOf(atr):null,div:'MXN',sinPlazo:pl==null})})});
  const ag=rows=>{const g={n:0,nv:0};BUCKETS.forEach(b=>g[b[0]]=0);rows.forEach(x=>{if(!x.b)return;g[x.b]+=x.saldo;g.n++;if(x.b!=='cur')g.nv++});g.tot=BUCKETS.reduce((s,b)=>s+g[b[0]],0);g.venc=g.tot-g.cur;return g};
  /* el saldo a favor (pagado de más) no resta en la antigüedad: queda en su cuenta */
  const srt=(a,b)=>(b.b?1:0)-(a.b?1:0)||b.atr-a.atr||String(a.venc).localeCompare(String(b.venc));
  cxc.sort(srt);cxp.sort(srt);cxj.sort(srt);
  const d={cxc:cxc,cxp:cxp,cxj:cxj,agc:ag(cxc),agp:ag(cxp),agj:ag(cxj)};f._acc[key]=d;return d;
}
function accRow(ref){const A=accData();return A.cxc.concat(A.cxj,A.cxp).find(x=>x.ref===ref)||null}
const amt=(v,div,d)=>money(v,d==null?2:d)+' '+div;
function atrChip(x){
  if(!x.b)return '';
  if(x.atr>=0)return `<span class="chip ${BK_CHIP[x.b]}">${x.atr===0?'Vence hoy':'Vencida hace '+fmt(x.atr)+(x.atr===1?' día':' días')}</span>`;
  return `<span class="chip info">Vence en ${fmt(-x.atr)}${x.atr===-1?' día':' días'}</span>`;
}
/* conciliación: cobrado o pagado, parcial o pendiente */
function estChip(x,S){const c={ok:['good','Cobrado','Pagado'],par:['warn','Cobro parcial','Pago parcial'],pen:['','Pendiente','Pendiente']}[x.est]||['','Pendiente','Pendiente'];return `<span class="chip ${c[0]}">${S==='cob'?c[1]:c[2]}</span>`}
const sgnAmt=(v,div)=>(v>0.005?'+':'')+amt(v,div);
function agingHtml(g,div,title){
  const mx=Math.max(1,...BUCKETS.map(b=>g[b[0]]));
  return `<div class="panel aging"><div class="agh"><strong>${title}</strong><b>${amt(g.tot,div,0)}</b></div>${BUCKETS.map(b=>`<div class="agr"><span>${b[1]}</span><span class="agbar" aria-hidden="true"><i class="${BK_CLS[b[0]]}" style="width:${(g[b[0]]/mx*100).toFixed(1)}%"></i></span><b>${money(g[b[0]],0)}</b></div>`).join('')}<p class="note">${g.venc>0.005?'Vencido: '+amt(g.venc,div,0)+' en '+g.nv+(g.nv===1?' cuenta':' cuentas'):'Nada vencido.'}</p></div>`;
}
function accCardHtml(x,S){
  const mv=(S==='cob'?COB:PAG).list.filter(y=>y.ref===x.ref).length,can=canMov()&&!ro;
  return `<div class="prd acc${x.b&&x.atr>0?' late':''}"><div class="r1"><div class="pnm">${esc(x.nombre)}<small>${esc(S==='cob'?x.lab+(x.po?' · PO '+x.po:'')+' · '+x.emp:x.det+' · '+x.emp)}</small></div><div class="rend">${money(x.saldo,2)}<em class="cur">${x.div}</em><small>saldo</small></div></div>
<div class="r2">${x.fecha?(S==='cob'?(x.jug?'Semana al ':'Pedido del '):'Desde el ')+fmtDate(x.fecha)+' · ':''}${x.fFact?(x.jug?'liquidación del ':'factura del ')+fmtDate(x.fFact)+' · ':''}${x.venc?'vence '+fmtDate(x.venc):'sin fecha'}</div>
<div class="r2 conc">${x.sinPrecio?'Sin precio de Juguera en Precios y costos':'Calculado '+amt(x.calc,x.div)}${S==='cob'&&x.fact!=null?(x.jug?' · liquidado ':' · facturado ')+amt(x.fact,x.div)+(Math.abs(x.fact-x.calc)>0.005?' ('+sgnAmt(r2(x.fact-x.calc),x.div)+')':''):''}${S==='pag'&&x.real?' (flete real)':''} · ${S==='cob'?'cobrado '+amt(x.cob,x.div)+(x.nc?' · notas de crédito '+amt(x.nc,x.div):''):'pagado '+amt(x.hecho,x.div)}${x.hecho>0.005?' · diferencia contra lo calculado '+sgnAmt(x.dif,x.div):''}</div>
<div class="r3">${estChip(x,S)}${atrChip(x)}${x.reclamo==='abierto'?'<span class="chip warn">En reclamo</span>':x.reclamo==='nota'?'<span class="chip info">Reclamo con nota de crédito</span>':''}${x.proc?'<span class="chip warn">Pedido en proceso</span>':''}${S==='cob'&&x.dias==null?'<span class="chip">Sin días de pago</span>':''}${S==='pag'&&x.sinPlazo?'<span class="chip">Sin plazo capturado</span>':''}<span class="acb">${can&&x.b?`<button class="btn sm primary" data-act="movopen:${S}:${esc(x.ref)}">${S==='cob'?'Registrar cobro':'Registrar pago'}</button>`:''}${mv||!can||!x.b?`<button class="btn sm" data-act="movopen:${S}:${esc(x.ref)}">${mv?'Movimientos ('+mv+')':'Detalle'}</button>`:''}</span></div></div>`;
}
function empSegHtml(){const f=statsF,v=f.emp||'ALL';return `<div class="seg fseg" role="group" aria-label="Empresa">${[['VL','Vera Limes'],['EC','Citrilar'],['ALL','Ambas']].map(o=>`<button data-act="femp:${o[0]}" aria-pressed="${v===o[0]}">${o[1]}</button>`).join('')}</div>`}
function cxListHtml(S){
  const A=accData(),f=statsF,cob=S==='cob';let L=cob?A.cxc:A.cxp;
  if(!cob&&(f.cxpT==='prod'||f.cxpT==='flete'||f.cxpT==='jug'))L=L.filter(x=>x.tipo===f.cxpT);
  const n0=L.length;if(!f.cxAll)L=L.filter(x=>x.b);
  const fl=cob?'':`<div class="srt">${[['all','Todo'],['prod','Productores'],['flete','Fletes']].concat(L.some(x=>x.tipo==='jug')?[['jug','Juguera']]:[]).map(o=>`<button class="btn sm" data-act="cxpt:${o[0]}" aria-pressed="${(f.cxpT||'all')===o[0]}">${o[1]}</button>`).join('')}</div>`;
  const grp=f.cxG==='grp',gb=`<div class="srt">${[['cta','Por cuenta'],['grp',cob?'Por cliente':'Por productor o proveedor']].map(o=>`<button class="btn sm" data-act="cxg:${o[0]}" aria-pressed="${(grp?'grp':'cta')===o[0]}">${o[1]}</button>`).join('')}</div>`;
  if(grp)return agingHtml(cob?A.agc:A.agp,cob?'USD':'MXN',cob?'Por cobrar a clientes':'Por pagar')+fl+gb+agingGroupHtml(L,cob?'USD':'MXN',cob?'Cliente':'Productor o proveedor')+`<p class="note" style="margin-top:8px">Saldos pendientes agrupados por ${cob?'cliente':'productor o proveedor'} y antigüedad: 0 a 30 días (verde), 31 a 60 (amarillo), más de 60 (rojo).</p>`;
  return agingHtml(cob?A.agc:A.agp,cob?'USD':'MXN',cob?'Por cobrar a clientes':'Por pagar')+fl+gb+`<div class="srt"><button class="btn sm" data-act="cxall" aria-pressed="${!!f.cxAll}">${f.cxAll?'Ocultar saldadas':'Ver también las saldadas'}</button><span class="note">${L.length} de ${n0}</span></div>`+
   (L.length?`<div class="cgrid">${L.slice(0,f.cxN||60).map(x=>accCardHtml(x,S)).join('')}</div>`:`<p class="note" style="margin-top:8px">${n0?'Todo está saldado.':cob?'Aún no hay pedidos completos o facturados con venta.':'Aún no hay pagos de fruta ni fletes por registrar.'}</p>`)+
   (cob?jugCxHtml(A):'')+
   `<p class="note" style="margin-top:10px">${cob?'Cada pedido completo o con factura es una cuenta por cobrar en dólares. Si se registra la factura (fecha y monto), manda sobre lo calculado con los precios de su semana. Vence en la fecha de factura (o del pedido, si no hay) más sus días de pago.':'Fruta: lo que se paga a cada productor por semana, con su acuerdo y los precios de esa semana. Juguera: lo de cada productor por sus cajas de Juguera de corridas de primera (la de segundas y corridas 1.5 es del empaque). Flete y cruce: por pedido; si se registra el flete real, ese manda sobre el parámetro. Los días de crédito se ponen en Precios y costos.'}</p>`;
}
function jugCxHtml(A){
  if(!A.cxj.length)return '';const f=statsF,L=f.cxAll?A.cxj:A.cxj.filter(x=>x.b);
  return `<div class="sec" style="margin-top:14px">Juguera</div>`+agingHtml(A.agj,'MXN','Por cobrar a la Juguera')+(L.length?`<div class="cgrid" style="margin-top:8px">${L.slice(0,f.cxN||60).map(x=>accCardHtml(x,'cob')).join('')}</div>`:'<p class="note" style="margin-top:8px">Todo está cobrado.</p>')
   +`<p class="note" style="margin-top:8px">Una cuenta por semana y empresa, en pesos. Manda la liquidación de la Juguera si se registra; sin ella se estima con cajas × precio de venta. Vence al terminar la semana.</p>`;
}
function resHtml(){
  const A=accData(),f=statsF,hoy=todayISO(),d30=dayAdd(hoy,-30),inE=x=>f.emp==='ALL'||!f.emp||x.emp===f.emp;
  const s30=(S,t,j)=>S.list.reduce((s,x)=>s+(!x.anulado&&x.tipo===t&&inE(x)&&x.fecha>=d30&&x.fecha<=hoy&&(S!==COB||(String(x.ref).indexOf('cxj|')===0)===!!j)?+x.monto||0:0),0);
  const tiles=tileHtml('Por cobrar',money(A.agc.tot,0)+'<em class="cur">USD</em>',A.agc.venc>0.005?'vencido '+amt(A.agc.venc,'USD',0):'nada vencido',null,A.agc.venc>0.005?'warnt':'')
   +tileHtml('Por pagar',money(A.agp.tot,0)+'<em class="cur">MXN</em>',A.agp.venc>0.005?'vencido '+amt(A.agp.venc,'MXN',0):'nada vencido',null,A.agp.venc>0.005?'warnt':'')
   +tileHtml('Cobrado en 30 días',money(s30(COB,'cobro'),0)+'<em class="cur">USD</em>','cobros registrados')
   +tileHtml('Pagado en 30 días',money(s30(PAG,'pago'),0)+'<em class="cur">MXN</em>','pagos registrados');
  const lc=A.cxc.filter(x=>x.b&&x.atr>0).slice(0,5),lp=A.cxp.filter(x=>x.b&&x.atr>0).slice(0,5);
  const todo=[];
  const mains=visible().filter(o=>isLeader(o)&&inE(o));
  const sinF=mains.filter(o=>o.estado==='completo'&&!String(o.factura||'').trim()).length,sinD=A.cxc.filter(x=>x.b&&x.dias==null).length;
  const abiertas=weekKeys(false).filter(k=>k<curWk()&&!wkClosed(k)&&wkStats(k).L.length).length;
  const ej=FIN.ejemplo||PAR.list.some(v=>v.origen==='migrado'&&v.nota==='valores de ejemplo'&&parVer(v.emp,curWk())===v);
  const sinPl=['VL','EC'].some(e=>parsDe(e,curWk()).plazoProd==null);
  if(ej)todo.push(['crit','Precios de ejemplo','Las cifras usan precios y costos de muestra.','finset','Precios y costos']);
  if(abiertas)todo.push(['warn',abiertas+(abiertas===1?' semana pasada sigue abierta':' semanas pasadas siguen abiertas'),'Al cerrarlas se congelan sus precios y costos.','peropen','Periodos']);
  if(sinF)todo.push(['warn',sinF+(sinF===1?' pedido completo sin factura':' pedidos completos sin factura'),'Se ven en Por cobrar como «Pedido» en lugar de factura.','ftab:cxc','Por cobrar']);
  if(sinD)todo.push(['info',sinD+(sinD===1?' cuenta sin días de pago':' cuentas sin días de pago'),'Vencen el día del pedido hasta que se capturen los días de pago en el pedido (BI).','ftab:cxc','Por cobrar']);
  if(sinPl)todo.push(['info','Sin días de crédito con productores','Los pagos de fruta vencen al terminar la semana.','finset','Precios y costos']);
  const lst=(L,S,t)=>`<div class="panel"><div class="agh"><strong>${t}</strong><b>${L.length?L.length:''}</b></div>${L.length?L.map(x=>`<div class="kv"><span>${esc(x.nombre)}<br><small class="note">${esc(S==='cob'?x.lab:x.det)} · vencida hace ${fmt(x.atr)} días</small></span><span class="kvb"><b>${amt(x.saldo,x.div,0)}</b>${canMov()&&!ro?`<button class="btn sm" data-act="movopen:${S}:${esc(x.ref)}">${S==='cob'?'Cobrar':'Pagar'}</button>`:''}</span></div>`).join(''):'<p class="note">Nada vencido.</p>'}</div>`;
  const K=cashKpi();if(K.umbral==null&&isAdmin())todo.push(['info','Sin umbral de capital de trabajo','Sin él no hay alerta cuando el hueco entre lo que falta por cobrar y por pagar crece.','finset','Precios y costos']);
  return `<div class="tiles">${tiles}</div>
<div class="sec">Capital de trabajo · al día de hoy</div>${cashTilesHtml(K)}
<div class="sec">Pendientes</div>${todo.length?`<div class="todo">${todo.map(t=>`<div class="tdi ${t[0]}"><div><strong>${esc(t[1])}</strong><small>${esc(t[2])}</small></div><button class="btn sm" data-act="${t[3]}">${esc(t[4])}</button></div>`).join('')}</div>`:'<p class="note">No hay pendientes de datos.</p>'}
<div class="g2c">${lst(lc,'cob','Cobros vencidos')}${lst(lp,'pag','Pagos vencidos')}</div>
<div class="sec">Antigüedad de saldos</div><div class="g2c">${agingHtml(A.agc,'USD','Por cobrar a clientes')}${agingHtml(A.agp,'MXN','Por pagar')}</div>`;
}
function cmpTxtOf(D){return D.ref?`Comparado con ${esc(D.ref.label)}.`:(D.hasRef?'Sin datos comparables en el periodo anterior.':'Sin datos comparables: elige un año, un mes o un periodo para comparar.')}
/* ---------- v8.8 · vista previa en vivo (Registro de empaque, Código de Trazabilidad y Finanzas › Exportar) ----------
   Dibuja las hojas del mismo Excel que se descarga (xlPages) y las vuelve a dibujar cuando cambian los datos o los filtros.
   Se acerca con + y − (o pellizcando con dos dedos, o Ctrl + rueda) y se desliza dentro del cuadro. */
const XLV={};
const XLV_SRC={
  reg:{t:'Registro de empaque',pages:async()=>{const o=cur();return o?registroPages(o):[]},sig:()=>{const o=cur();return o?o.id:''}},
  traz:{t:'Código de Trazabilidad',pages:async()=>{const o=cur();return o?trazPdfPages(mainOf(o)):[]},sig:()=>{const o=cur();return o?mainOf(o).id:''}},
  rex:{t:'Excel de resultados',pages:async()=>{const R=rexData();if(!R.prods.length)return [];const wb=await rexBuild(R);return xlPages(wb,wb.worksheets,{foot:'Generado '+R.generado})},
    sig:()=>JSON.stringify([REX.ped,REX.prods,REX.cal,REX.cls,REX.res,statsF.emp,statsF.cal,statsF.year,statsF.month,statsF.week,statsF.desde,statsF.hasta])},
  /* v8.9.2: el Cierre semanal (formato viajes) de Finanzas también se ve en vivo; los precios de clasificación y los datos fijos cambian dataVer */
  cierre:{t:'Cierre semanal',pages:async()=>{const C=cvData();if(!C.nTrips)return [];const wb=await cvBuild(C);return xlPages(wb,wb.worksheets,{foot:'Generado '+C.gen})},
    sig:()=>JSON.stringify([REX.ped,statsF.emp,statsF.cal,statsF.year,statsF.month,statsF.week,statsF.desde,statsF.hasta])}
};
const xlvS=k=>XLV[k]||(XLV[k]={sig:null,imgs:null,z:1,n:0,t:null,busy:false,err:false});
function xlvTabs(k){
  const S=xlvS(k);if(!S.imgs||!S.imgs.length)return '';
  const seen=[];S.imgs.forEach((im,i)=>{if(!seen.some(x=>x.n===im.sheet))seen.push({n:im.sheet,i:i})});
  return seen.length>1?seen.map(x=>`<button class="btn sm" data-act="xlv:${k}:go:${x.i}">${esc(x.n||'Hoja')}</button>`).join(''):'';
}
function xlvImgs(k){
  const S=xlvS(k);
  if(!S.imgs)return `<p class="note xlvw">${typeof ExcelJS==='undefined'?'La vista previa necesita el módulo de Excel, que no está disponible aquí.':'Preparando la vista previa…'}</p>`;
  if(!S.imgs.length)return '<p class="note xlvw">Sin datos para mostrar con esta selección.</p>';
  const n=S.imgs.length;
  return S.imgs.map((im,i)=>`<figure class="xlvpg${im.land?' land':''}" id="xlv-${k}-${i}"><img src="${im.src}" alt="Hoja ${i+1} de ${n}${im.sheet?' · '+esc(im.sheet):''}" draggable="false"><figcaption>${i+1} de ${n}${im.sheet?' · '+esc(im.sheet):''}</figcaption></figure>`).join('');
}
function xlvHtml(k){
  const S=xlvS(k),src=XLV_SRC[k];
  return `<div class="xlv" data-xlv="${k}"><div class="xlvbar"><span class="xlvst" id="xlvst-${k}" role="status">${S.busy?'Actualizando…':S.imgs?'Al día':''}</span><div class="xlvz" role="group" aria-label="Acercar o alejar la vista previa del ${esc(src.t)}"><button class="btn sm" data-act="xlv:${k}:out" aria-label="Alejar">−</button><output id="xlvz-${k}">${Math.round(S.z*100)}%</output><button class="btn sm" data-act="xlv:${k}:in" aria-label="Acercar">+</button><button class="btn sm" data-act="xlv:${k}:fit">Ajustar</button></div></div><div class="xlvtabs" id="xlvtabs-${k}">${xlvTabs(k)}</div><div class="xlvp" id="xlvp-${k}" style="--z:${S.z}" tabindex="0" aria-label="Vista previa del ${esc(src.t)}: desliza para recorrer las hojas">${xlvImgs(k)}</div></div>`;
}
function xlvPaint(k){
  const S=xlvS(k),vp=document.getElementById('xlvp-'+k);if(!vp)return;
  vp.innerHTML=xlvImgs(k);const tb=document.getElementById('xlvtabs-'+k);if(tb)tb.innerHTML=xlvTabs(k);
  const st=document.getElementById('xlvst-'+k);if(st)st.textContent=S.err?'No se pudo dibujar la vista previa':S.busy?'Actualizando…':'Al día';
}
function xlvZoom(k,z,cx,cy){
  const S=xlvS(k),vp=document.getElementById('xlvp-'+k);z=Math.max(0.5,Math.min(4,Math.round(z*100)/100));
  if(!vp){S.z=z;return}
  const r=vp.getBoundingClientRect(),px=cx==null?r.width/2:cx-r.left,py=cy==null?r.height/2:cy-r.top;
  const fx=(vp.scrollLeft+px)/Math.max(1,vp.scrollWidth),fy=(vp.scrollTop+py)/Math.max(1,vp.scrollHeight);
  S.z=z;vp.style.setProperty('--z',z);
  vp.scrollLeft=fx*vp.scrollWidth-px;vp.scrollTop=fy*vp.scrollHeight-py;
  const o=document.getElementById('xlvz-'+k);if(o)o.textContent=Math.round(z*100)+'%';
}
function xlvSched(k,ms){
  const S=xlvS(k),src=XLV_SRC[k];if(!src)return;
  clearTimeout(S.t);S.t=setTimeout(async()=>{
    if(!document.getElementById('xlvp-'+k))return;
    const sig=src.sig()+'#'+dataVer;if(S.sig===sig&&S.imgs){xlvPaint(k);return}
    if(typeof ExcelJS==='undefined'){S.imgs=null;xlvPaint(k);return}
    const n=++S.n;S.busy=true;S.err=false;const st=document.getElementById('xlvst-'+k);if(st)st.textContent='Actualizando…';
    try{
      const pg=await src.pages(),imgs=[];
      for(const p of pg){if(n!==S.n)return;const cv=await renderPage(p,p.w>p.h?84:96);imgs.push({src:cv.toDataURL('image/jpeg',.85),land:p.w>p.h,sheet:p.sheet||''})}
      if(n!==S.n)return;S.imgs=imgs;S.sig=sig;
    }catch(e){if(n!==S.n)return;S.err=true}
    S.busy=false;xlvPaint(k);
  },ms==null?450:ms);
}
function xlvAll(ms){document.querySelectorAll('.xlv[data-xlv]').forEach(el=>xlvSched(el.dataset.xlv,ms))}
function xlvAct(k,op,a){
  const S=xlvS(k);
  if(op==='in')xlvZoom(k,S.z*1.25);else if(op==='out')xlvZoom(k,S.z/1.25);else if(op==='fit')xlvZoom(k,1);
  else if(op==='go'){const f=document.getElementById('xlv-'+k+'-'+a),vp=document.getElementById('xlvp-'+k);if(f&&vp)vp.scrollTop=f.offsetTop-vp.offsetTop}
}
/* pellizcar con dos dedos y Ctrl + rueda para acercar */
(()=>{
  const P=new Map();let d0=0,z0=1,k0=null;
  const dist=()=>{const a=[...P.values()];return Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)};
  document.addEventListener('pointerdown',e=>{const vp=e.target.closest&&e.target.closest('.xlvp');if(!vp||e.pointerType!=='touch')return;P.set(e.pointerId,{x:e.clientX,y:e.clientY});if(P.size===2){k0=vp.id.slice(5);d0=dist();z0=xlvS(k0).z}},{passive:true});
  document.addEventListener('pointermove',e=>{if(!P.has(e.pointerId))return;P.set(e.pointerId,{x:e.clientX,y:e.clientY});if(P.size===2&&k0&&d0>0){const a=[...P.values()];xlvZoom(k0,z0*dist()/d0,(a[0].x+a[1].x)/2,(a[0].y+a[1].y)/2)}},{passive:true});
  const up=e=>{P.delete(e.pointerId);if(P.size<2){k0=null;d0=0}};
  document.addEventListener('pointerup',up,{passive:true});document.addEventListener('pointercancel',up,{passive:true});
  document.addEventListener('wheel',e=>{const vp=e.target.closest&&e.target.closest('.xlvp');if(!vp||!(e.ctrlKey||e.metaKey))return;e.preventDefault();const k=vp.id.slice(5);xlvZoom(k,xlvS(k).z*(e.deltaY<0?1.1:1/1.1),e.clientX,e.clientY)},{passive:false});
})();
/* lo que se escribe sin volver a dibujar la pantalla (encabezado y tarimas de Trazabilidad) también actualiza la vista */
document.addEventListener('input',e=>{if(e.target&&e.target.closest&&e.target.closest('#app'))xlvAll(700)});
document.addEventListener('change',e=>{if(e.target&&e.target.closest&&e.target.closest('#app'))xlvAll(450)});
/* ---------- v8.7 · Finanzas › Exportar: resultados de productores, tamaños, segundas, Torreón y desecho ----------
   Usa los mismos filtros de Finanzas (empresa, calidad, año, mes, semana o periodo) y las mismas funciones que la pantalla
   (compute, aggregate y finAgg). El Excel lleva fórmulas vivas; el PDF es ese mismo Excel impreso; Compartir manda el archivo. */
const LS_REX='empaque-exportar';
const REX_CLS=[['exp','Primera'],['seg','Segundas'],['tor','Torreón'],['des','Desecho'],['jug','Juguera']];
const REX_RES=[['caj','Cajas'],['kg','Kilos'],['imp','Importes'],['rend','Rendimientos']];
let REX=(()=>{let r=null;try{r=JSON.parse(localStorage.getItem(LS_REX)||'null')}catch(e){}r=r&&typeof r==='object'?r:{};
  return {ped:r.ped||'ALL',prods:Array.isArray(r.prods)?r.prods:[],cal:Array.isArray(r.cal)?r.cal:[],cls:Object.assign({exp:1,c15:1,seg:1,tor:1,des:1,jug:1},r.cls||{}),res:Object.assign({caj:1,kg:1,imp:1,rend:1},r.res||{}),q:'',busy:null}})();
function saveRex(){try{localStorage.setItem(LS_REX,JSON.stringify({ped:REX.ped,prods:REX.prods,cal:REX.cal,cls:REX.cls,res:REX.res}))}catch(e){}}
const rexKey=p=>pKey(p);
const rexSob=p=>!!p.sob2||!p.codigo&&/^(ec|vl)-?(\d{4}-)?\d+$/.test(norm(p.nombre).trim());
function rexCalAll(){return CAL.filter(c=>c.k!=='ctn'||visible().some(o=>(o.productores||[]).some(p=>{const a=p.acc||{};return Object.keys(a).some(t=>n0((a[t]||{}).ctn)>0)})))}
function rexPedidos(list){const m=new Map();list.forEach(o=>{const k=o.emp+'|'+o.cod;if(!m.has(k))m.set(k,{k:k,emp:o.emp,cod:o.cod,emb:o.emb,fecha:o.fecha||''})});return [...m.values()].sort((a,b)=>String(a.fecha).localeCompare(String(b.fecha))||String(a.cod).localeCompare(String(b.cod)))}
/* periodo de los filtros de Finanzas, en palabras y para el nombre del archivo */
function rexPeriodo(list){
  const f=statsF,P=periodOf(f);
  if(P.week&&P.week!=='ALL'){const m=/^(\d{4})-S(\d+)$/.exec(P.week);return m?{t:'Semana '+(+m[2])+' de '+m[1],f:'Semana_'+(+m[2])+'_'+m[1]}:{t:P.week,f:P.week}}
  if(P.custom)return {t:(P.desde?'del '+fmtDate(P.desde):'desde el inicio')+(P.hasta?' al '+fmtDate(P.hasta):' a hoy'),f:(P.desde||'inicio')+'_a_'+(P.hasta||'hoy')};
  if(P.year!=='ALL'&&P.month!=='ALL'){const n=MESES[+P.month-1];return {t:n+' de '+P.year,f:n+'_'+P.year}}
  if(P.year!=='ALL')return {t:'Año '+P.year,f:String(P.year)};
  const ds=list.map(o=>o.fecha).filter(Boolean).sort();return {t:ds.length?'del '+fmtDate(ds[0])+' al '+fmtDate(ds[ds.length-1]):'todo el historial',f:'Historial'};
}
/* datos del reporte: una sola fuente para pantalla, Excel y PDF */
function rexData(){
  const D=statsData(),base=rexTripFill(D.cur.list),peds=rexPedidos(base);
  if(REX.ped!=='ALL'&&!peds.some(p=>p.k===REX.ped))REX.ped='ALL';
  const list=base.filter(o=>REX.ped==='ALL'||o.emp+'|'+o.cod===REX.ped);
  const calAll=rexCalAll(),cal=calAll.filter(c=>!REX.cal.length||REX.cal.indexOf(c.k)>=0),cls=REX.cls,res=REX.res,sel=REX.prods;
  const F=finAgg(list),impOK=F.T.ing>0||F.T.fruta>0;
  const newAcc=(p)=>{const pc=pCode(p),li=pc?LISTA.find(x=>x.c===pc):null;const a={key:rexKey(p),cod0:pc||null,cls:clsOf(pc),clsX:!!clsExp(pc),codigo:pc?codeLabel(pc,null).replace(/^.*?-/,''):'',nombre:(li&&li.n)||p.nombre||'Sin nombre',ped:new Set(),kilos:0,cal:{},pri:0,c15:0,seg:0,tor:0,des:0,jug:0,eqv:0,campoR:0,ctn:false,kExp:0,pago:null,pagoJug:null,ing:null};CAL.forEach(c=>a.cal[c.k]=0);return a};
  const addRow=(a,o,r,kg)=>{const p=r.p,q15=o.variante==='1.5';a.ped.add(o.emp+'|'+o.cod);a.kilos+=n0(p.kilos);
    CAL.forEach(c=>{const d=Math.max(0,r.delta[c.k]||0);if(!d)return;if(c.k==='ctn')a.ctn=true;if(q15){a.seg+=d;return}if(cal.some(x=>x.k===c.k)){a.cal[c.k]+=d;a.pri+=d;a.kExp+=d*kg}});
    a.seg+=segC(p);a.tor+=n0(p.tor);a.des+=n0(p.des);a.jug+=n0(p.jug);if(r.rend!=null&&!q15){a.eqv+=r.eqv;a.campoR+=r.campo}};
  const fin=(a,FF)=>{const x=FF.map.get(a.key);if(x){a.pago=x.pago||0;a.pagoJug=x.pagoJug||0;a.ing=x.ing||0}else{a.pago=0;a.pagoJug=0;a.ing=0}
    a.rend=a.campoR>0?a.eqv/a.campoR:null;a.kcl=(cls.exp?a.pri*KG_DEF:0)+['seg','tor','des','jug'].reduce((s,k)=>s+(cls[k]?a[k]*SEG_KG:0),0);a.ped=a.ped.size;return a};
  const prods=new Map(),viajes=[];
  rexPedidos(list).forEach(pd=>{
    const sh=list.filter(o=>o.emp+'|'+o.cod===pd.k),m=sh.find(o=>o.variante!=='1.5')||sh[0],FV=finAgg(sh),vp=new Map();
    const tam=cal.map(c=>({k:c.k,l:c.l,a:0,b:0})),v={cod:pd.cod,emb:m.emb||'',po:m.po||'',fecha:m.fecha||'',fechaTxt:m.fecha?fechaLarga(m.fecha):'sin fecha',cliente:m.customer||'',empresa:EMPS[m.emp].name,kg:pesosOf(m).campo,seg:0,tor:0,des:0,jug:0};
    sh.forEach(o=>{const M=compute(o),kg=M.kg;M.rows.forEach(r=>{const p=r.p;if(rexSob(p))return;const k=rexKey(p),inn=+p.codigo===SEG_COD||!!p.segLot;if(sel.length&&(inn||sel.indexOf(k)<0))return;
      if(inn){tam.forEach(t=>{t.b+=Math.max(0,r.delta[t.k]||0)});return}
      let a=prods.get(k);if(!a){a=newAcc(p);prods.set(k,a)}addRow(a,o,r,kg);
      let b=vp.get(k);if(!b){b=newAcc(p);vp.set(k,b)}addRow(b,o,r,kg);
      tam.forEach(t=>{const d=Math.max(0,r.delta[t.k]||0);if(o.variante==='1.5')t.b+=d;else t.a+=d});
      v.seg+=segC(p);v.tor+=n0(p.tor);v.des+=n0(p.des);v.jug+=n0(p.jug)})});
    if(!vp.size)return;
    tam.forEach(t=>{if(!cls.exp)t.a=0;if(!cls.seg)t.b=0});
    v.tam=tam.filter(t=>t.a||t.b);if(!v.tam.length)v.tam=tam.slice(0,1);
    const od=FV.ords,sum=k=>od.reduce((s,x)=>s+(x[k]||0),0);
    v.tc=+parsDe(m.emp,wkOf(m)).tc||null;v.usd=sum('usd');v.nac=sum('nac');v.ing=sum('ing');v.fruta=sum('fruta');v.mat=sum('mat');v.mo=sum('mo');v.flete=sum('flete');v.cost=sum('cost');
    v.prods=[...vp.values()].map(a=>fin(a,FV)).sort((x,y)=>y.pri-x.pri||x.nombre.localeCompare(y.nombre));
    const vc=v.prods.reduce((s,a)=>s+a.campoR,0),ve=v.prods.reduce((s,a)=>s+a.eqv,0);v.T={rend:vc>0?ve/vc:null,ctn:v.prods.some(a=>a.ctn)};
    viajes.push(v);
  });
  const rows=[...prods.values()].map(a=>fin(a,F)).sort((x,y)=>x.nombre.localeCompare(y.nombre));
  const T={kilos:0,pri:0,c15:0,seg:0,tor:0,des:0,jug:0,kcl:0,pago:0,pagoJug:0,cal:{},eqv:0,campoR:0,ctn:false};CAL.forEach(c=>T.cal[c.k]=0);
  rows.forEach(a=>{['kilos','pri','seg','tor','des','jug','kcl','pago','pagoJug','eqv','campoR'].forEach(k=>T[k]+=a[k]||0);CAL.forEach(c=>T.cal[c.k]+=a.cal[c.k]);if(a.ctn)T.ctn=true});
  T.rend=T.campoR>0?T.eqv/T.campoR:null;
  /* sin calibres elegidos, el reporte solo lleva los calibres que tienen cajas (como FORMATO VIAJES) */
  const calR=REX.cal.length?cal:cal.filter(c=>T.cal[c.k]>0||viajes.some(v=>v.tam.some(t=>t.k===c.k&&(t.a||t.b))));
  /* importes del conjunto: con todos los productores, los de finAgg; con algunos, lo de esos productores */
  const all=!sel.length;T.usd=all?F.T.ingUSD:null;T.ing=all?F.T.ing:rows.reduce((s,a)=>s+(a.ing||0),0);T.cost=all?F.T.cost:null;
  const tam=calR.map(c=>{let a=0,b=0;viajes.forEach(v=>v.tam.forEach(t=>{if(t.k===c.k){a+=t.a;b+=t.b}}));return {k:c.k,l:c.l,a:a,b:b}}).filter(t=>t.a||t.b);
  const emps=[...new Set(list.map(o=>o.emp))],per=rexPeriodo(list);
  const empresa=statsF.emp==='ALL'||emps.length>1?'Vera Limes y Citrilar':EMPS[statsF.emp==='ALL'?emps[0]||emp:statsF.emp].name;
  const filtros=['Empresa: '+(statsF.emp==='ALL'?'ambas':EMPS[statsF.emp].name),'Calidad del empaque: '+(statsF.cal==='ALL'?'todas':statsF.cal==='1'?'primera':'segundas'),'Pedido: '+(REX.ped==='ALL'?'todos':REX.ped.split('|')[1]),'Productores: '+(all?'todos':rows.length+' elegidos'),'Calibres: '+(cal.length===calAll.length?'todos':cal.map(c=>c.l).join(', ')),'Clasificación: '+REX_CLS.filter(x=>cls[x[0]]).map(x=>x[1].toLowerCase()).join(', ')];
  const notas=[];
  if(!impOK)notas.push('Importes: No disponible. Faltan precios en Finanzas › Precios y costos para el periodo elegido.');
  if(!all)notas.push('Con productores elegidos, la venta de exportación, los costos y la utilidad del conjunto no se reparten por productor: se ven completos sin filtrar productores.');
  if(fvPend().length)notas.push('FORMATO VIAJES tiene '+fvPend().length+' de 3 puntos sin confirmar en Decisiones de dirección (celdas G18, columna F y L33): la utilidad de tu Excel manual no es comparable con la de esta exportación hasta resolverlos.');
  notas.push('Rendimiento de primeras = cajas de primera ÷ cajas campo (kilos ÷ '+KG_DEF+'), como en Estadísticas. Kilos clasificados = cajas de exportación × '+KG_DEF+' + cajas de segunda, Torreón, desecho y Juguera × '+SEG_KG+', como en FORMATO VIAJES.');
  return {titulo:'Resultados financieros · '+empresa,empresa:empresa,periodo:per.t,perF:per.f,generado:fmtTs(Date.now()),filtros:filtros,unidades:'Unidades: cajas, kilogramos (kg), pesos mexicanos (MXN) y dólares (USD). Ventas en USD, costos y pagos en MXN.',
    cal:calR.length?calR:cal.slice(0,1),calAll:REX.cal.length?calAll.length:(calR.length||1),cls:cls,res:res,kgCampo:KG_DEF,kgExp:KG_DEF,kgSeg:SEG_KG,prods:rows,viajes:viajes,nViajes:viajes.length,tam:tam,T:T,impOK:impOK,notas:notas,emps:emps,peds:peds,list:list};
}
function rexName(R,ext){
  const e=R.emps.length===1&&statsF.emp!=='ALL'?EMPS[R.emps[0]].name.replace(/\s+/g,''):'Consolidado';
  return fileSafe(e+'_Finanzas_'+(REX.ped!=='ALL'?REX.ped.split('|')[1]+'_':'')+R.perF)+'.'+ext;
}
async function rexBuild(R){if(typeof ExcelJS==='undefined')throw new Error('sin ExcelJS');const wb=newWb();XL.addRex(wb,R);return wb}
async function rexFile(kind,R){
  const wb=await rexBuild(R);
  if(kind==='xlsx')return {blob:await wbBlob(wb),name:rexName(R,'xlsx')};
  const pages=xlPages(wb,wb.worksheets,{foot:'Generado '+R.generado});
  return {blob:await pagesToPdf(pages),name:rexName(R,'pdf')};
}
/* Compartir: hoja para compartir del teléfono; si el navegador no comparte archivos, se descarga para adjuntarlo */
async function rexShare(f,title){
  const C=window.Capacitor;if(C&&C.isNativePlatform&&C.isNativePlatform()){await saveFile(f.name,f.blob,title);return 'ok'}
  try{const file=new File([f.blob],f.name,{type:f.blob.type});
    if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],title:title,text:title});return 'ok'}}catch(e){if(e&&e.name==='AbortError')return 'cancel'}
  await saveFile(f.name,f.blob);return 'fallback';
}
async function rexGo(kind){
  if(REX.busy)return;
  if(kind==='cierre'){
    const C=cvData();if(!C.nTrips){toast('No hay viajes con esta selección');return}
    REX.busy=kind;rexBtns();
    try{const wb=await cvBuild(C),nm=cvName(C);await saveFile(nm,await wbBlob(wb));toast('Cierre semanal listo: '+nm)}catch(e){toast('No se pudo generar el cierre semanal')}
    REX.busy=null;rexBtns();return;
  }
  const R=rexData();
  if(!R.prods.length){toast('No hay resultados con esta selección');return}
  REX.busy=kind;rexBtns();
  try{
    if(kind==='share'){const f=await rexFile('pdf',R),r=await rexShare(f,R.titulo+' · '+R.periodo);toast(r==='ok'?'Listo para compartir':r==='cancel'?'No se compartió':'Este dispositivo no comparte archivos: se descargó el PDF para que lo adjuntes')}
    else{const f=await rexFile(kind,R);await saveFile(f.name,f.blob);toast((kind==='xlsx'?'Excel':'PDF')+' listo: '+f.name)}
  }catch(e){toast('No se pudo generar el archivo')}
  REX.busy=null;rexBtns();
}
function rexBtnsHtml(n){
  const b=REX.busy,dis=b||!n?' disabled':'';
  return `<button class="btn primary" data-act="rexgo:xlsx"${dis}>${b==='xlsx'?'Generando…':'Descargar Excel'}</button><button class="btn" data-act="rexgo:pdf"${dis}>${b==='pdf'?'Generando…':'Descargar PDF'}</button><button class="btn" data-act="rexgo:share"${dis}>${b==='share'?'Preparando…':'Compartir'}</button><button class="btn primary" data-act="rexgo:cierre"${dis}>${b==='cierre'?'Generando…':'Cierre semanal (formato viajes)'}</button>`;
}
function rexBtns(){const el=document.getElementById('rexbtns');if(el)el.innerHTML=rexBtnsHtml(rexData().prods.length)}
function rexChk(grp,k,l,on){return `<label class="rchk"><input type="checkbox" data-rex="${grp}:${esc(k)}"${on?' checked':''}><span>${esc(l)}</span></label>`}
function rexView(D){
  const R=rexData(),base=rexTripFill(D.cur.list),calAll=rexCalAll(),A=aggregate(base.filter(o=>REX.ped==='ALL'||o.emp+'|'+o.cod===REX.ped));
  const plist=A.rows.filter(a=>!/^n(ec|vl)/.test(a.key)).sort((a,b)=>a.nombre.localeCompare(b.nombre)),q=norm(REX.q||'').trim();
  const prodsH=plist.filter(a=>!q||norm(a.nombre+' '+(a.codigo||'')).includes(q)).map(a=>rexChk('p',a.key,a.nombre+(a.codigo?' · '+pad(a.codigo,3):''),!REX.prods.length||REX.prods.indexOf(a.key)>=0)).join('');
  const f1=v=>v==null?'No disponible':fmt(v);
  const prev=R.prods.length?`<div class="tblx"><table class="ptbl rexp"><thead><tr><th>Productor</th>${REX.res.kg?'<th>Kilos</th>':''}${REX.res.caj&&REX.cls.exp?'<th>Primera</th>':''}${REX.res.caj?['seg','tor','des','jug'].filter(k=>REX.cls[k]).map(k=>'<th>'+{seg:'Segundas',tor:'Torreón',des:'Desecho',jug:'Juguera'}[k]+'</th>').join(''):''}${REX.res.rend&&REX.cls.exp?'<th>Rend.</th>':''}${REX.res.imp?'<th>Pago (MXN)</th>':''}</tr></thead><tbody>${R.prods.map(a=>`<tr><th scope="row">${esc(a.nombre)}<small>${a.codigo?'#'+esc(a.codigo):'sin código'} · ${a.ped} ${a.ped===1?'pedido':'pedidos'}</small></th>${REX.res.kg?`<td class="m r">${fmt(a.kilos)}</td>`:''}${REX.res.caj&&REX.cls.exp?`<td class="m r">${fmt(a.pri)}</td>`:''}${REX.res.caj?['seg','tor','des','jug'].filter(k=>REX.cls[k]).map(k=>`<td class="m r">${fmt(a[k])}</td>`).join(''):''}${REX.res.rend&&REX.cls.exp?`<td class="m r">${a.rend==null?'–':pctTxt(a.rend)}</td>`:''}${REX.res.imp?`<td class="m r">${R.impOK?money(a.pago||0):'No disponible'}</td>`:''}</tr>`).join('')}<tr class="tot"><th scope="row">Total</th>${REX.res.kg?`<td class="m r">${fmt(R.T.kilos)}</td>`:''}${REX.res.caj&&REX.cls.exp?`<td class="m r">${fmt(R.T.pri)}</td>`:''}${REX.res.caj?['seg','tor','des','jug'].filter(k=>REX.cls[k]).map(k=>`<td class="m r">${fmt(R.T[k])}</td>`).join(''):''}${REX.res.rend&&REX.cls.exp?`<td class="m r">${R.T.rend==null?'–':pctTxt(R.T.rend)}</td>`:''}${REX.res.imp?`<td class="m r"><b>${R.impOK?money(R.T.pago):'No disponible'}</b></td>`:''}</tr></tbody></table></div>`:`<section class="empty"><h2>Sin resultados con esta selección</h2><p>Cambia los filtros, el pedido o los productores elegidos. No se genera un archivo vacío.</p></section>`;
  return filtersHtml(D)+`<p class="statline" role="status">${infoLine(D)}</p>
<div class="sec">Exportación de resultados financieros</div>
<div class="panel rexp"><p class="note">Se exporta lo que ves abajo, con los filtros de arriba (los mismos de Utilidad y BI). Excel con fórmulas, PDF igual al Excel, o Compartir el PDF. Montos en MXN, ventas en USD.</p>
<label class="fld" for="rex-ped"><span>Pedido (viaje)</span><select class="in sel" id="rex-ped" data-rexsel="ped"><option value="ALL">Todos los pedidos del periodo (${R.peds.length})</option>${R.peds.map(p=>`<option value="${esc(p.k)}"${REX.ped===p.k?' selected':''}>${esc(p.cod)} · ${esc(p.emb||'')}${p.fecha?' · '+fmtDate(p.fecha):''}</option>`).join('')}</select></label>
<div class="rgrp"><span class="rgl">Clasificación de la fruta</span>${REX_CLS.map(x=>rexChk('c',x[0],x[1],!!REX.cls[x[0]])).join('')}</div>
<div class="rgrp"><span class="rgl">Tipo de resultado</span>${REX_RES.map(x=>rexChk('r',x[0],x[1],!!REX.res[x[0]])).join('')}</div>
<div class="rgrp"><span class="rgl">Calibres</span>${calAll.map(c=>rexChk('k',c.k,c.l,!REX.cal.length||REX.cal.indexOf(c.k)>=0)).join('')}</div>
<details class="rgrp rprod"${REX.prods.length||REX.po?' open':''}><summary><span class="rgl">Productores</span> ${REX.prods.length?REX.prods.filter(k=>k!=='__ninguno__').length+' de '+plist.length+' elegidos':'todos ('+plist.length+')'}</summary><div class="pact"><button class="btn sm" data-act="rexall:1">Todos</button><button class="btn sm" data-act="rexall:0">Ninguno</button></div><label class="fld" for="rex-q"><span>Buscar productor</span><input class="in txt" id="rex-q" type="text" autocomplete="off" data-rexq="1" value="${esc(REX.q||'')}"></label><div class="rchks" id="rexprods">${prodsH||'<p class="note">Sin productores en el periodo.</p>'}</div></details>
${rexClasHtml(A)}
<div class="pact rexbtns" id="rexbtns">${rexBtnsHtml(R.prods.length)}</div></div>
<div class="sec">Vista previa · ${esc(R.periodo)} · ${fmt(R.nViajes)} ${R.nViajes===1?'pedido':'pedidos'} · ${fmt(R.prods.length)} productores</div>${prev}${R.notas.map(t=>`<p class="note">${esc(t)}</p>`).join('')}
<div class="sec">Vista previa en vivo del Excel</div><div class="panel"><p class="note" style="margin-bottom:8px">Cambia los filtros y las casillas de arriba: la vista se actualiza sola. Así salen el Excel y el PDF.</p>${xlvHtml('rex')}</div>
<div class="sec">Vista previa en vivo · Cierre semanal (formato viajes)</div><div class="panel"><p class="note" style="margin-bottom:8px">Así sale el Excel del Cierre semanal: hojas PRECIOS, una por semana con sus viajes, Resumen semanal y Pagos a productores. Se actualiza solo con los filtros, el pedido, los precios de clasificación y los datos fijos del viaje.</p>${xlvHtml('cierre')}</div>`;
}
/* casillas y listas de la exportación */
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset)return;
  if(t.dataset.rexsel==='ped'){REX.ped=t.value;saveRex();render();return}
  const r=t.dataset.rex;if(!r)return;const i=r.indexOf(':'),g=r.slice(0,i),k=r.slice(i+1);
  if(g==='c')REX.cls[k]=t.checked?1:0;
  else if(g==='r')REX.res[k]=t.checked?1:0;
  else if(g==='k'){const all=rexCalAll().map(c=>c.k);let s=REX.cal.length?REX.cal.slice():all.slice();s=t.checked?[...new Set(s.concat(k))]:s.filter(x=>x!==k);REX.cal=s.length===all.length?[]:s;if(!s.length){REX.cal=[];toast('Debe quedar al menos un calibre')}}
  else if(g==='p'){const all=[...document.querySelectorAll('[data-rex^="p:"]')].map(x=>x.dataset.rex.slice(2));let s=REX.prods.length?REX.prods.filter(x=>x!=='__ninguno__'):all.slice();s=t.checked?[...new Set(s.concat(k))]:s.filter(x=>x!==k);REX.prods=s.length>=all.length&&!REX.q?[]:s;if(!s.length)REX.prods=['__ninguno__']}
  saveRex();render();
});
document.addEventListener('toggle',e=>{const t=e.target;if(t&&t.classList&&t.classList.contains('rprod'))REX.po=t.open},true);
/* v8.11: lo que se despliega entra suave */
document.addEventListener('toggle',e=>{const t=e.target;if(!t||t.tagName!=='DETAILS'||!t.open)return;t.classList.add('dan');setTimeout(()=>t.classList.remove('dan'),320)},true);
document.addEventListener('input',e=>{const t=e.target;if(!t||!t.dataset||!t.dataset.rexq)return;REX.q=t.value;const q=norm(t.value||'').trim();document.querySelectorAll('#rexprods .rchk').forEach(l=>{l.hidden=!!q&&!norm(l.textContent).includes(q)})});


/* ---------- v8.9 · clasificación de productores y Cierre semanal (calca de FORMATO VIAJES) ----------
   Los precios por clasificación y los datos fijos del viaje viven en Precios y costos (versión por semana), igual que lo demás.
   El Cierre semanal lee los mismos pedidos y productores que el Excel de resultados; cada viaje lleva el bloque completo de FORMATO VIAJES
   con fórmulas vivas y casillas amarillas editables. */
const CLAS_F=[['p250','Calibre 250','MXN por caja'],['p230','Calibre 230','MXN por caja'],['p200','Calibre 200','MXN por caja'],['p175','Calibre 175','MXN por caja'],['p150','Calibre 150','MXN por caja'],['p110','Calibre 110','MXN por caja'],['seg','Segundas','MXN por caja'],['tor',"Torreón (275')",'MXN por caja'],['des','Desecho','MXN por caja'],['pkg','Pago por kilo de báscula','MXN por kg']];
const CLAS_BOX={chico:['p250','p230','p200','p175','p150','p110','seg','tor','des'],interno:['p250','p230','p200','p175','p150','p110','seg','tor','des'],grande:['seg','tor','des','pkg']};
const CLAS_DEF={chico:{p250:150,p230:165,p200:180,p175:180,p150:180,p110:180,pmen:180,c15:0,seg:50,tor:50,des:0},interno:{p250:150,p230:165,p200:180,p175:180,p150:180,p110:180,pmen:180,c15:0,seg:50,tor:50,des:0},grande:{pkg:9,c15:0,seg:50,tor:50,des:0}};
const CIERRE_F=[['aduAm','Aduana americana','USD por viaje'],['aduMx','Aduana mexicana','MXN por viaje'],['aduCaja','Aduana por caja','USD por caja'],['factPri','Factura primeras','MXN por caja'],['fact15','Factura segundas','MXN por caja'],['retorno','Plástico / retorno','MXN por caja'],['gastos','Gastos (maquila y seguro)','MXN por caja'],['seguro','Seguro de carga','MXN por caja'],['dscFlete','Descuento fletes','USD por caja']];
const CIERRE_DEF={aduAm:174.75,aduMx:1200,aduCaja:0.35,factPri:850,fact15:310,retorno:5,gastos:45,seguro:0,dscFlete:0.4};
/* v8.10: 175, 150 y 110 tienen precio propio; si aún no se captura, toman el que se guardó para «Calibres 175, 150 y 110» (pmen) */
const clasRaw=(F,c,f)=>{const v=F&&F.clas&&F.clas[c]&&F.clas[c][f];return v!=null&&v!==''&&isFinite(+v)?+v:null};
const CLAS_MEN={p175:1,p150:1,p110:1};
const clasVal=(F,c,f)=>{const v=clasRaw(F,c,f);if(v!=null)return v;if(CLAS_MEN[f]){const m=clasRaw(F,c,'pmen');if(m!=null)return m}if(c==='grande'&&f==='pkg'&&F&&+F.kg>0)return +F.kg;return (CLAS_DEF[c]||{})[f]};
const clasPh=(F,c,f)=>{if(CLAS_MEN[f]&&clasRaw(F,c,'pmen')!=null)return clasRaw(F,c,'pmen');if(c==='grande'&&f==='pkg'&&F&&+F.kg>0)return +F.kg;return CLAS_DEF[c][f]};
/* ---------- v8.11 · productores grandes: pago por entrega ----------
   A los Grandes se les paga por kilo de báscula de cada entrega. El precio y el anticipo de cada entrega se guardan en Precios y costos
   de la semana en que llegó la fruta (gpag, por pedido y renglón del productor). Utilidad, Por pagar, Merma y el Cierre semanal leen
   el mismo precio: el de la entrega, o el acuerdo de compra, o Clasificación · Grandes, o el pago general por kilo. */
const GR_SRC={entrega:'precio de esta entrega',hoja:'acuerdo guardado en la hoja',acuerdo:'acuerdo de compra',clas:'Clasificación · Grandes',general:'pago general por kilo',sug:'valor sugerido',sin:'sin precio'};
function grSrcTxt(e){return e.set?'Precio propio de esta entrega.':e.base.src==='sin'?'Sin precio: escribe el precio por kilo de esta entrega, o captura Clasificación › Grandes o el pago general en Precios y costos. Mientras no haya precio, el pago sale en 0.':'Sin precio propio: usa '+GR_SRC[e.base.src]+' ('+money(e.base.v,2)+' MXN por kg).'}
function isGrande(p){return !!p&&!(+p.codigo===SEG_COD||p.segLot)&&!isSob(p)&&clsOf(pCode(p))==='grande'}
function grEnt(p){return p&&p.invEnt&&INV.entradas.find(x=>x.id===p.invEnt[0])||null}
function grFecha(o,p){const e=grEnt(p);return (e&&e.fecha)||p.invFecha||o.fecha||''}
function grWk(o,p){return wkOfDate(grFecha(o,p))||wkOf(o)}
const grId=(o,p)=>o.id+'~'+p.id;
function grPkg(o,p,base){
  const wk=grWk(o,p),F=parsDe(o.emp,wk),g=((F&&F.gpag)||{})[grId(o,p)]||{};
  let v=base?NaN:+g.pkg,src='entrega';
  if(!(v>0)){v=+p.precioKg;src='hoja'}
  if(!(v>0)){const ac=(F.acu&&p.codigo&&F.acu[p.codigo])||{};v=+ac.precioKg;src='acuerdo'}
  if(!(v>0)){v=clasRaw(F,'grande','pkg');src='clas'}
  if(!(v>0)){v=+F.kg;src='general'}
  /* v8.16: sin ningún precio capturado ya no se usa un valor fijo escondido: queda «Sin precio» y el pago sale en 0 hasta capturarlo */
  if(!(v>0)){v=0;src='sin'}
  return {v:+v,src:src,wk:wk,ant:num(g.ant)||0,F:F};
}
/* ventana «Grandes»: cada entrega de fruta de los productores grandes del periodo, con su precio por kilo y anticipo */
let grSel='';
function grInPer(fe){const g=Object.assign({},statsF,periodOf(statsF));if(!fe)return false;if(g.week&&g.week!=='ALL')return wkOfDate(fe)===g.week;return (g.year==='ALL'||fe.slice(0,4)===String(g.year))&&(g.month==='ALL'||fe.slice(5,7)===g.month)&&(!g.desde||fe>=g.desde)&&(!g.hasta||fe<=g.hasta)}
function grData(){
  const D=statsData(),list=rexTripFill(D.cur.list).filter(o=>REX.ped==='ALL'||o.emp+'|'+o.cod===REX.ped),pm=new Map(),used=new Set();
  const es=statsF.emp==='ALL'?['VL','EC']:[statsF.emp];
  orders.forEach(o=>{if(!o.deleted)(o.productores||[]).forEach(p=>(p.invEnt||[]).forEach(id=>used.add(id)))});
  const get=(key,pc,nm)=>{let a=pm.get(key);if(!a){a={key:key,cod:pc||null,nombre:nm,E:[],pend:[],kilos:0,pago:0,ant:0};pm.set(key,a)}return a};
  list.forEach(o=>compute(o).rows.forEach(r=>{const p=r.p;if(!isGrande(p))return;
    const pc=pCode(p),li=pc?LISTA.find(x=>x.c===pc):null,a=get(pKey(p),pc,(li&&li.n)||p.nombre||'Sin nombre');
    const g=grPkg(o,p),b=grPkg(o,p,1),kilos=n0(p.kilos),e={o:o,p:p,id:grId(o,p),fecha:grFecha(o,p),wk:g.wk,kilos:kilos,k24:n0(p.k24),k18:n0(p.k18),campo:r.campo,exp:r.t,rend:r.rend,seg:segC(p),tor:n0(p.tor),des:n0(p.des),pkg:g.v,src:g.src,base:b,ant:g.ant,set:+(((g.F.gpag||{})[grId(o,p)]||{}).pkg)>0,pago:kilos*g.v,closed:wkClosed(g.wk)};
    a.E.push(e);a.kilos+=kilos;a.pago+=e.pago;a.ant+=e.ant}));
  LISTA.filter(x=>clsExp(x.c)==='grande').forEach(x=>get('c'+x.c,x.c,x.n));
  entradas().forEach(e=>{if(used.has(e.id)||!grInPer(e.fecha))return;const pc=e.codigo||null;if(clsOf(pc)!=='grande')return;const a=pm.get('c'+pc);if(a)a.pend.push(e)});
  const P=[...pm.values()].sort((x,y)=>(y.E.length?1:0)-(x.E.length?1:0)||x.nombre.localeCompare(y.nombre));
  P.forEach(a=>a.E.sort((x,y)=>String(x.fecha).localeCompare(String(y.fecha))||String(x.o.cod).localeCompare(String(y.o.cod),'es',{numeric:true})));
  return {P:P,es:es,per:rexPeriodo(list)};
}
function grEntHtml(e,ed){
  const o=e.o,ro2=!ed||e.closed,fid=e.id.replace(/[^\w-]/g,'_');
  const dat=[['Kilos de báscula',fmt(e.kilos,e.kilos%1?1:0)+' kg'],['Cajas campo',e.campo==null?'–':fmt(e.campo,1)],['Cajas de exportación',fmt(e.exp)],['Rendimiento',pctTxt(e.rend)],['Segundas · Torreón · Desecho',fmt(e.seg)+' · '+fmt(e.tor)+' · '+fmt(e.des)]];
  return `<div class="gre${e.set?' gset':''}" data-gre="${esc(e.id)}"><div class="grt"><b>${esc(fmtDate(e.fecha)||'sin fecha')}</b><span>${esc(wkLab(e.wk))}</span><span class="mono">${esc(o.cod)}</span>${o.variante==='1.5'?'<span class="chip">segundas</span>':''}${e.closed?'<span class="chip">semana cerrada</span>':''}</div>
<div class="grk">${dat.map(x=>`<div><span>${x[0]}</span><b>${x[1]}</b></div>`).join('')}</div>
<div class="grin"><label class="fld" for="gp-${fid}"><span>Precio por kilo (MXN)</span><input class="in" id="gp-${fid}" inputmode="decimal" data-fin="${o.emp}.gpag.${e.id}.pkg" data-fk="${e.wk}" data-grp="${esc(e.id)}" value="${e.set?esc(e.pkg):''}" placeholder="${esc(e.base.v)}"${ro2?' readonly':''}></label><label class="fld" for="ga-${fid}"><span>Anticipo (MXN)</span><input class="in" id="ga-${fid}" inputmode="decimal" data-fin="${o.emp}.gpag.${e.id}.ant" data-fk="${e.wk}" data-grp="${esc(e.id)}" value="${e.ant?esc(e.ant):''}" placeholder="0"${ro2?' readonly':''}></label><div class="grpay"><span>Pago (MXN)</span><b data-out="gr.pago.${esc(e.id)}">${money(e.pago,2)}</b><small data-out="gr.neto.${esc(e.id)}">${e.ant?'menos anticipo: '+money(e.pago-e.ant,2):''}</small></div></div>
<p class="note${!e.set&&e.base.src==='sin'?' unastx':''}" data-out="gr.src.${esc(e.id)}">${esc(grSrcTxt(e))}</p></div>`;
}
function grandesHtml(){
  const G=grData(),ed=isAdmin(),A=G.P.filter(a=>!grSel||a.key===grSel),nE=G.P.reduce((s,a)=>s+a.E.length,0);
  const opt=`<label class="fld" for="gr-sel"><span>Productor</span><select class="in sel" id="gr-sel" data-grsel="1"><option value="">Todos los grandes (${G.P.length})</option>${G.P.map(a=>`<option value="${esc(a.key)}"${a.key===grSel?' selected':''}>${esc((a.cod?codeLabel(a.cod,G.es[0])+' · ':'')+a.nombre)} · ${a.E.length} ${a.E.length===1?'entrega':'entregas'}</option>`).join('')}</select></label>`;
  const body=!G.P.length?`<p class="note">No hay productores clasificados como Grandes. Clasifícalos en el menú Productores.</p>`:A.map(a=>`<section class="grp"><div class="grh"><b>${esc(a.nombre)}</b><small>${a.cod?esc(codeLabel(a.cod,G.es[0]))+' · ':''}${a.E.length} ${a.E.length===1?'entrega':'entregas'} · ${fmt(a.kilos,a.kilos%1?1:0)} kg · ${mxn(a.pago,2)}${a.ant?' · anticipos '+mxn(a.ant,2):''}</small></div>${a.E.length?a.E.map(e=>grEntHtml(e,ed)).join(''):'<p class="note">Sin entregas en pedidos de este periodo.</p>'}${a.pend.length?`<p class="note grpend">Recibido en Entrada de fruta, todavía sin pedido: ${a.pend.map(e=>esc(fmtDate(e.fecha))+' · '+fmt(n0(e.kilos),1)+' kg').join('; ')}. Se paga cuando entre a un pedido.</p>`:''}</section>`).join('');
  return `<h3>Productores grandes</h3><p class="note">Pago por kilo de báscula de cada entrega del periodo (${esc(G.per.t||'')}). El precio y el anticipo se guardan en Precios y costos de la semana en que llegó la fruta; los usan el Cierre semanal, Utilidad y Por pagar. Vacío usa el acuerdo de compra, el precio de Clasificación · Grandes o el pago general por kilo.${ed?'':' Solo el administrador puede cambiarlos.'}</p>${opt}<p class="note">${nE} ${nE===1?'entrega':'entregas'} en el periodo.</p>${body}<div class="srow2"><button class="btn primary" data-act="closesheet">Listo</button></div>`;
}
/* después de guardar un precio o anticipo, la entrega se recalcula en su lugar (sin volver a dibujar la ventana) */
function grUpdate(id){
  const G=grData();let e=null;G.P.forEach(a=>a.E.forEach(x=>{if(x.id===id)e=x}));if(!e)return;
  const set=(k,v)=>{const n=$sh.querySelector('[data-out="'+k+id+'"]');if(n)n.textContent=v};
  set('gr.pago.',money(e.pago,2));set('gr.neto.',e.ant?'menos anticipo: '+money(e.pago-e.ant,2):'');
  set('gr.src.',grSrcTxt(e));
  const c=$sh.querySelector('[data-gre="'+id+'"]');if(c)c.classList.toggle('gset',e.set);
  const a=G.P.find(x=>x.E.indexOf(e)>=0),h=c&&c.closest('.grp')&&c.closest('.grp').querySelector('.grh small');
  if(a&&h)h.textContent=(a.cod?codeLabel(a.cod,G.es[0])+' · ':'')+a.E.length+(a.E.length===1?' entrega':' entregas')+' · '+fmt(a.kilos,a.kilos%1?1:0)+' kg · '+mxn(a.pago,2)+(a.ant?' · anticipos '+mxn(a.ant,2):'');
}
/* precio por kilo de un renglón: Grandes por entrega; los demás como siempre (acuerdo o pago general) */
function pkgOf(F,o,p){if(isGrande(p))return grPkg(o,p).v;const ac=(F.acu&&p.codigo&&F.acu[p.codigo])||{};return +p.precioKg>0?+p.precioKg:+ac.precioKg>0?+ac.precioKg:(+F.kg||0)}
const cierreVal=(F,f)=>{const v=F&&F.cierre&&F.cierre[f];if(v!=null&&v!==''&&isFinite(+v))return +v;if(f==='aduMx'&&+F.cruce>0)return +F.cruce;return CIERRE_DEF[f]};
/* un viaje es de todas sus hojas (1 y 1.5): si el periodo o la semana dejó fuera una hoja hermana, se vuelve a sumar (respetando el filtro de calidad) */
function rexTripFill(list){
  const ks=new Set(list.map(o=>o.emp+'|'+o.cod)),have=new Set(list.map(o=>o.id)),f=statsF;
  const ex=orders.filter(o=>!o.deleted&&!have.has(o.id)&&ks.has(o.emp+'|'+o.cod)&&(!f.cal||f.cal==='ALL'||o.variante===f.cal));
  return ex.length?list.concat(ex):list;
}
function rexClasHtml(A){
  const f=statsF,es=f.emp==='ALL'?['VL','EC']:[f.emp],ed=isAdmin();
  const wk=f.week&&f.week!=='ALL'?f.week:null,k=wk&&!wkClosed(wk)?wk:finDesdeDef();
  const cnt={chico:0,grande:0,interno:0};let sin=0;
  A.rows.forEach(a=>{if(!a.codigo)return;cnt[clsOf(a.codigo)]++;if(!clsExp(a.codigo))sin++});
  const gv=(F,c,r)=>{const v=((F.clas||{})[c]||{})[r];return v==null?'':esc(v)};
  const head=`<span></span>${PCLS.map(x=>x[0]==='grande'?`<button class="fh pcls k-grande pclsb" data-act="grandes" aria-haspopup="dialog" title="Pago de los productores grandes por entrega">${x[1]} ›</button>`:`<span class="fh pcls k-${x[0]}">${x[1]}</span>`).join('')}`;
  const grid=e=>{
    const F=parVerVals(e,k);
    const rows=CLAS_F.map(r=>`<span class="fl">${esc(r[1])}<small>${esc(r[2])}</small></span>`+PCLS.map(c=>CLAS_BOX[c[0]].indexOf(r[0])<0?'<span class="fna">—</span>':`<input class="in" inputmode="decimal" aria-label="${esc(r[1]+' · '+c[1]+' · '+EMPS[e].name)}" data-fin="${e}.clas.${c[0]}.${r[0]}" data-fk="${k}" value="${gv(F,c[0],r[0])}" placeholder="${clasPh(F,c[0],r[0])}"${ed?'':' readonly'}>`).join('')).join('');
    const fix=CIERRE_F.map(r=>{const v=(F.cierre||{})[r[0]];return `<label class="fld" for="cv-${e}-${r[0]}"><span>${esc(r[1])} (${esc(r[2])})</span><input class="in" id="cv-${e}-${r[0]}" inputmode="decimal" data-fin="${e}.cierre.${r[0]}" data-fk="${k}" value="${v==null?'':esc(v)}" placeholder="${CIERRE_DEF[r[0]]}"${ed?'':' readonly'}></label>`}).join('');
    return `<div class="rclasemp">${es.length>1?`<b class="rcemp">${esc(EMPS[e].name)}</b>`:''}<div class="clasgrid">${head}${rows}</div><details class="cfijos"><summary>Datos fijos del viaje (los fija el contador)</summary><div class="grid2">${fix}</div></details></div>`;
  };
  return `<div class="rgrp rclas"><span class="rgl">Clasificación de productores</span></div>
<p class="note">Precio que se le paga a cada clasificación; lo usa el Cierre semanal. Vacío usa el valor sugerido (en gris). Se guardan desde ${esc(wkLab(k))} y quedan en el historial de Precios y costos.${ed?'':' Solo el administrador puede cambiarlos.'}</p>
<p class="note">En este periodo: ${cnt.chico} Chicos · ${cnt.grande} Grandes · ${cnt.interno} Internos.${sin?' '+sin+(sin===1?' productor no tiene':' productores no tienen')+' clasificación guardada (cuentan como Chicos, y los de Jesús Lagunes como Internos): clasifícalos en Productores.':''}</p>${es.map(grid).join('')}`;
}
function cvData(){
  const D=statsData(),list=rexTripFill(D.cur.list).filter(o=>REX.ped==='ALL'||o.emp+'|'+o.cod===REX.ped);
  const CK=['c250','c230','c200','c175','c150','c110'],trips=[],sinC=new Map();let mm=0;
  rexPedidos(list).forEach(pd=>{
    const sh=list.filter(o=>o.emp+'|'+o.cod===pd.k),m=sh.find(o=>o.variante!=='1.5')||sh[0],wk=wkOf(m),F=parsDe(m.emp,wk);
    const t={k:pd.k,emp:m.emp,empName:EMPS[m.emp].name,cod:pd.cod,emb:m.emb||'',po:m.po||'',fecha:m.fecha||'',cliente:m.customer||'',wk:wk,sizes:{},c15:{n:0,usd:0},tipos:new Set(),prods:[]};
    CK.forEach(k=>t.sizes[k]={n:0,usd:0});
    const pm=new Map();
    sh.forEach(o=>{
      const M=compute(o),q=o.variante==='1.5'?'1.5':'1';
      M.rows.forEach(r=>{
        const p=r.p;if(rexSob(p)&&!p.rmp)return;const key=pKey(p),inn=+p.codigo===SEG_COD||!!p.segLot||!!p.rmp,om=rmpOutAll(o,p); /* v8.21: lo reempacado se vende en el viaje que lo recibe; el productor conserva sus calibres */
        let a=inn?null:pm.get(key);
        if(!a&&!inn){const pc=pCode(p),li=pc?LISTA.find(x=>x.c===pc):null;a={key:key,cod:pc||null,nombre:(li&&li.n)||p.nombre||'Sin nombre',cls:clsOf(pc),clsX:!!clsExp(pc),kilos:0,k24:0,k18:0,cal:{},c15:0,seg:0,tor:0,des:0,jug:0};CK.forEach(k=>a.cal[k]=0);pm.set(key,a)}
        r.tipos.forEach(t0=>{const d=r.byT[t0].delta;CAL.forEach(c=>{
          const n=Math.max(0,d[c.k]||0);if(!n)return;
          const tp=lineType(t0,c.k),pr=precioUSD(F,tp,q,c.k),ck=c.k==='ctn'?'c230':c.k;
          const ok=tp+'|'+c.k,out=Math.min(n,om[ok]||0),ns=n-out;if(out)om[ok]-=out;
          if(CK.indexOf(ck)<0){mm+=ns;return}
          if(ns)t.tipos.add(tp);
          if(q==='1.5'){if(a)a.seg+=n;t.c15.n+=ns;t.c15.usd+=ns*pr}else{if(a)a.cal[ck]+=n;t.sizes[ck].n+=ns;t.sizes[ck].usd+=ns*pr}
        })});
        if(a&&a.cls==='grande'&&!inn&&(n0(p.kilos)>0)){const g=grPkg(o,p);(a.ents=a.ents||[]).push({fecha:grFecha(o,p),kilos:n0(p.kilos),pkg:g.v,src:g.src,ant:g.ant,wk:g.wk,same:g.wk===wk,q:q})}
        if(a){a.kilos+=n0(p.kilos);a.k24+=n0(p.k24);a.k18+=n0(p.k18);a.seg+=segC(p);a.tor+=n0(p.tor);a.des+=n0(p.des);a.jug+=n0(p.jug)}
      });
    });
    if(!pm.size&&!t.c15.n)return;
    const FV=finAgg(sh),fr=fleteReal(m.emp,m.cod);
    t.nac=Math.round(FV.ords.reduce((s,x)=>s+(x.nac||0),0)*100)/100;
    t.flete=fr!=null?fr:(+F.flete||0);
    CK.forEach(k=>{const s=t.sizes[k];s.p=s.n>0?s.usd/s.n:precioUSD(F,'RPC','1',k)});
    t.c15.p=t.c15.n>0?t.c15.usd/t.c15.n:precioUSD(F,'RPC','1.5','c230');
    const ts=[...t.tipos];t.pack=!ts.length||ts.every(x=>x==='RPC')?'PLASTICO':ts.every(x=>x==='CTN'||x==='CTN10')?'CARTON':'MIXTO';
    const ord={chico:0,grande:1,interno:2};
    t.prods=[...pm.values()].sort((x,y)=>ord[x.cls]-ord[y.cls]||x.nombre.localeCompare(y.nombre));
    t.prods.forEach(a=>{if(!a.clsX)sinC.set(a.key,a.nombre)});
    trips.push(t);
  });
  trips.sort((a,b)=>String(a.fecha).localeCompare(String(b.fecha))||String(a.cod).localeCompare(String(b.cod),'es',{numeric:true}));
  const groups=new Map();
  trips.forEach(t=>{
    const g=t.wk+'|'+t.emp;let G=groups.get(g);
    if(!G){const F=parsDe(t.emp,t.wk),P={clas:{},cierre:{},kgC:KG_DEF,kgE:KG_DEF,kgS:SEG_KG,tc:+F.tc||0};
      PCLS.forEach(c=>{P.clas[c[0]]={};CLAS_BOX[c[0]].forEach(f=>P.clas[c[0]][f]=clasVal(F,c[0],f))});
      CIERRE_F.forEach(r=>P.cierre[r[0]]=cierreVal(F,r[0]));
      const wn=/^\d{4}-S(\d+)$/.exec(t.wk||'');
      G={wk:t.wk,emp:t.emp,empName:t.empName,P:P,trips:[],name:(wn?'SEMANA #'+(+wn[1]):'SIN SEMANA')+' '+t.emp,tag:(wn?'S'+(+wn[1]):'S-')+' '+t.emp,label:wn?wkLab(t.wk):'Sin semana',span:wn?wkSpan(t.wk):''};
      groups.set(g,G)}
    G.trips.push(t);t.n=G.trips.length;
  });
  const G=[...groups.values()].sort((a,b)=>String(a.wk).localeCompare(String(b.wk))||a.emp.localeCompare(b.emp));
  const per=rexPeriodo(list);
  const sinP=[];G.forEach(g=>(g.prods||[]).forEach(a=>(a.ents||[]).forEach(x=>{if(x.src==='sin')sinP.push(a.nombre+' ('+fmtDate(x.fecha)+')')})));
  return {groups:G,nTrips:trips.length,per:per,gen:fmtTs(Date.now()),sinCls:[...sinC.values()].sort(),sinPrecio:sinP,mm:mm,kgC:KG_DEF,kgE:KG_DEF,kgS:SEG_KG};
}
async function cvBuild(C){if(typeof ExcelJS==='undefined')throw new Error('sin ExcelJS');const wb=newWb();XL.addCierre(wb,C);return wb}
function cvName(C){const e=C.groups.length&&C.groups.every(g=>g.emp===C.groups[0].emp)&&statsF.emp!=='ALL'?EMPS[C.groups[0].emp].name.replace(/\s+/g,''):'Consolidado';return fileSafe('Cierre_semanal_'+e+'_'+(REX.ped!=='ALL'?REX.ped.split('|')[1]+'_':'')+C.per.f)+'.xlsx'}
const FTABS=[['res','Resumen'],['cxc','Por cobrar'],['cxp','Por pagar'],['fin','Utilidad'],['emb','Embarques'],['pre','Presupuesto'],['ctb','Contabilidad'],['bi','BI'],['rex','Exportar']];
function finSecView(){
  const f=statsF;if(!f.emp)f.emp=emp;const t=FTABS.some(x=>x[0]===f.ftab)?f.ftab:'res';f.ftab=t;
  const tabs=`<div class="tabs stabs ftabs" role="tablist">${FTABS.map(x=>`<button class="tab" role="tab" data-act="ftab:${x[0]}" aria-selected="${t===x[0]}">${x[1]}</button>`).join('')}</div>`;
  const acts=`<div class="finacts"><button class="btn sm" data-act="finset">Precios y costos</button><button class="btn sm" data-act="peropen">Periodos</button><button class="btn sm" data-act="logpar">Bitácora contable</button><button class="btn sm" data-act="cxx">Descargar cuentas</button></div>`;
  const who=isContador()?'<p class="note fwho">Como contador registras cobros y pagos; precios, costos y periodos los ves en solo lectura.</p>':roRole?'<p class="note fwho">Acceso de solo lectura.</p>':'';
  let body;
  if(t==='fin'||t==='bi'||t==='emb'){
    const D=statsData(),T=D.cur.T;
    body=filtersHtml(D)+`<p class="statline" role="status">${infoLine(D)}</p>`+(!T.hojas?`<section class="empty"><h2>Sin datos con estos filtros</h2><p>Las cifras se llenan solas con cada empaque registrado.</p>${t==='bi'&&!roRole&&!cfgOK()?'<button class="btn" data-act="biexample" data-edit>Cargar historial de ejemplo</button>':''}</section>`:t==='bi'?biView(D):t==='emb'?embView(D):`<p class="note" style="margin-top:8px">${cmpTxtOf(D)}</p>`+finView(D));
  }else if(t==='rex'){const D=statsData();body=D.cur.T.hojas?rexView(D):filtersHtml(D)+`<section class="empty"><h2>Sin datos con estos filtros</h2><p>Cambia el periodo o la empresa para exportar resultados.</p></section>`}
  else if(t==='pre')body=empSegHtml()+presView();
  else if(t==='ctb')body=empSegHtml()+ctbView();
  else body=empSegHtml()+(t==='res'?resHtml():cxListHtml(t==='cxc'?'cob':'pag'));
  return topbar('Finanzas','menu')+`<main class="wrap fsec">${who}${tabs}${acts}${wkPanelHtml()}${body}</main>`;
}
/* hoja de movimientos: registrar, ver y anular cobros o pagos de una cuenta */
function movHtml(){
  const S=sheet.S,cob=S==='cob',St=cob?COB:PAG,x=accRow(sheet.ref),can=canMov()&&!ro;
  const L=St.list.filter(y=>y.ref===sheet.ref).sort((a,b)=>String(b.fecha).localeCompare(String(a.fecha))||b.at-a.at);
  if(!x&&!L.length)return `<h3>Cuenta no encontrada</h3><p class="note">El pedido de esta cuenta ya no existe o cambió de empresa.</p><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
  const div=x?x.div:(L[0]&&L[0].div)||(cob?'USD':'MXN'),wk=x&&x.wk,tcDef=x?+parsDe(x.emp,wk||curWk()).tc||'':'';
  const head=x?`<div class="ig tot wkg"><div><span>Total</span><b>${amt(x.monto,div)}</b></div><div><span>${cob?'Cobrado':'Pagado'}</span><b>${amt(x.hecho,div)}</b></div><div><span>Saldo</span><b class="${x.saldo<-0.005?'neg':''}">${amt(x.saldo,div)}</b></div><div><span>Vence</span><b>${x.venc?esc(fmtDate(x.venc)):'—'}</b></div></div>`:'';
  const tipos=cob?['cobro','nota']:['pago','ajuste'];
  const extra=x?(cob?(x.jug?liqFormHtml(x,can):factFormHtml(x,can)):x.tipo==='flete'?realFormHtml(x,can):''):'';
  const form=can&&x?`<div class="sec">${cob?'Registrar cobro':'Registrar pago'}</div><div class="grid2">
<label class="fld" for="mv-f"><span>Fecha</span><input class="in txt" id="mv-f" type="date" value="${esc(sheet.vf||todayISO())}"></label>
<label class="fld" for="mv-t"><span>Tipo</span><select class="in sel" id="mv-t">${tipos.map(k=>`<option value="${k}">${MOV_T[k]}</option>`).join('')}</select></label>
<label class="fld" for="mv-m"><span>Monto (${div})</span><input class="in" id="mv-m" inputmode="decimal" value="${x.saldo>0.005?esc(x.saldo):''}"></label>
${cob&&div==='USD'?`<label class="fld" for="mv-tc"><span>Tipo de cambio del cobro (MXN por 1 USD)</span><input class="in" id="mv-tc" inputmode="decimal" placeholder="${esc(tcDef)}"></label>`:''}
<label class="fld" for="mv-fo"><span>Forma</span><select class="in sel" id="mv-fo">${FORMAS.map(k=>`<option>${k}</option>`).join('')}</select></label>
<label class="fld" for="mv-r"><span>Referencia bancaria</span><input class="in txt" id="mv-r" type="text" autocomplete="off"></label></div>
<label class="fld" for="mv-n"><span>Nota</span><input class="in txt" id="mv-n" type="text" autocomplete="off"></label>${sheet.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.err)}</p>`:''}
<div class="srow2"><button class="btn primary" data-act="movsave">Guardar ${cob?'cobro':'pago'}</button></div>`:'';
  const rows=L.map(y=>{
    const an=sheet.anul===y.id;
    return `<div class="mvr${y.anulado?' anu':''}"><div class="kv"><span><b>${esc(y.tipo==='fact'&&String(y.ref).indexOf('cxj|')===0?'Liquidación de la Juguera':MOV_T[y.tipo]||y.tipo)}</b> · ${esc(fmtDate(y.fecha))}${y.forma?' · '+esc(y.forma):''}${y.num?' · núm. '+esc(y.num):''}${y.tipo==='fact'?' · '+esc(RECLAMO[y.reclamo||'']||''):''}${y.refb?' · ref '+esc(y.refb):''}<br><small class="note">${esc(y.by||'—')} · ${esc(fmtTs(y.at))}${y.tc?' · TC '+esc(y.tc)+' (= '+esc(money(y.monto*y.tc,2))+' MXN)':''}${y.nota?' · '+esc(y.nota):''}${St.dirty.indexOf(y.id)>=0&&cfgOK()?' · sin subir':''}</small>${y.anulado?`<br><small class="note">Anulado por ${esc(y.anulado.by)} (${esc(fmtTs(y.anulado.at))}): ${esc(y.anulado.motivo)}</small>`:''}</span><span class="kvb"><b>${amt(y.monto,y.div||div)}</b>${y.tipo==='fact'||y.tipo==='real'?'<small class="note">no es '+(cob?'cobro':'pago')+'</small>':''}${can&&!y.anulado&&!an?`<button class="btn sm danger" data-act="movanu:${y.id}">Anular</button>`:''}</span></div>${an?`<div class="warnbox"><label class="fld" for="mv-am"><span>Motivo para anular (obligatorio)</span><input class="in txt" id="mv-am" type="text" autocomplete="off"></label>${sheet.aErr?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.aErr)}</p>`:''}<div class="pact"><button class="btn sm" data-act="movanuno">Cancelar</button><button class="btn sm danger" data-act="movanugo:${y.id}">Anular</button></div></div>`:''}</div>`;
  }).join('');
  return `<div class="shhead"><h3>${esc(x?x.nombre:'Movimientos')}</h3><button type="button" class="shx" data-act="closesheet" aria-label="Cerrar">✕</button></div><p class="note">${esc(x?(cob?x.lab+(x.po?' · PO '+x.po:''):x.det)+' · '+EMPS[x.emp].name:'')}</p>${head}${extra}${form}<div class="sec">Movimientos</div>${rows||'<p class="note">Aún no hay movimientos.</p>'}<p class="note" style="margin-top:8px">Los movimientos no se borran: si uno está mal, se anula con su motivo y se registra el correcto. Todo queda en la bitácora.</p><div class="srow2"><button class="btn" data-act="closesheet">Cerrar</button></div>`;
}
function movSave(){
  if(!sheet||sheet.kind!=='mov'||!canMov()||ro)return;
  const x=accRow(sheet.ref);if(!x)return;const cob=sheet.S==='cob',St=cob?COB:PAG;
  const g=id=>String((document.getElementById(id)||{}).value||'').trim(),fe=g('mv-f'),m=num(g('mv-m').replace(',','.')),tc=cob&&x.div==='USD'?num(g('mv-tc').replace(',','.')):null,tipo=g('mv-t')||(cob?'cobro':'pago');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(fe)){sheet.err='Pon la fecha.';renderSheet();return}
  if(!(m>0)){sheet.err='Pon un monto mayor a cero.';renderSheet();return}
  const now=Date.now(),y={id:uid(),emp:x.emp,ref:x.ref,lab:x.lab,nombre:x.nombre,tipo:tipo,fecha:fe,monto:r2(m),div:x.div,tc:tc>0?tc:null,forma:g('mv-fo'),refb:g('mv-r'),nota:g('mv-n'),by:parBy(),uid:(authUser&&authUser.id)||'',at:now,ts:now,anulado:null};
  St.list.push(y);St.dirty.push(y.id);saveMov();
  logAdd({k:cob?'cobro':'pago',where:'Finanzas',ctx:{t:'c',id:x.ref,cod:x.nombre+' · '+x.lab},lab:MOV_T[tipo]+' registrado',o:amt(x.saldo,x.div),n:amt(y.monto,y.div)+' · '+fmtDate(fe)+' · '+y.forma+(y.refb?' · ref '+y.refb:'')+(y.tc?' · TC '+y.tc:'')});
  sheet.err='';const left=r2(x.saldo-y.monto);toast(left<-0.005?'Guardado. Queda un saldo a favor de '+amt(-left,x.div):'Guardado');renderSheet();render();
}
function movAnular(id){
  if(!sheet||sheet.kind!=='mov'||!canMov()||ro)return;
  const St=sheet.S==='cob'?COB:PAG,y=St.list.find(z=>z.id===id),mo=String((document.getElementById('mv-am')||{}).value||'').trim();if(!y||y.anulado)return;
  if(!mo){sheet.aErr='Escribe el motivo.';renderSheet();return}
  const now=Date.now();y.anulado={by:parBy(),at:now,motivo:mo};y.ts=now;if(St.dirty.indexOf(id)<0)St.dirty.push(id);saveMov();
  logAdd({k:sheet.S==='cob'?'cobro':'pago',where:'Finanzas',ctx:{t:'c',id:y.ref,cod:(y.nombre||'')+' · '+(y.lab||'')},lab:(MOV_T[y.tipo]||'Movimiento')+' anulado',o:amt(y.monto,y.div)+' · '+fmtDate(y.fecha),n:'Anulado · motivo: '+mo,motivo:mo});
  sheet.anul=null;sheet.aErr='';toast('Movimiento anulado');renderSheet();render();
}
/* sincronización: cada movimiento es una fila; gana la versión más reciente (solo cambia al anularse) */
async function syncMovTab(S,tb){
  try{
    if(canMov()&&S.dirty.length){
      const send=S.dirty.map(id=>S.list.find(x=>x.id===id)).filter(Boolean);
      for(let i=0;i<send.length;i+=100){const part=send.slice(i,i+100);await sb('/rest/v1/'+tb+'?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:part.map(x=>({id:x.id,updated_at:x.ts,data:x}))});S.dirty=S.dirty.filter(id=>!part.some(x=>x.id===id&&x.ts===(S.list.find(z=>z.id===id)||{}).ts))}
    }
    const rows=(await sb('/rest/v1/'+tb+'?select=id,updated_at,data&order=updated_at.asc&limit=50000'))||[];
    rows.forEach(r=>{if(!r.data)return;const i=S.list.findIndex(x=>x.id===r.id);if(i<0){S.list.push(r.data);remoteN++}else if((+r.data.ts||0)>(+S.list[i].ts||0)&&S.dirty.indexOf(r.id)<0){S.list[i]=r.data;remoteN++}});
    S.noTable=false;saveMov();
  }catch(e){if(e&&(e.status===404||e.status===400))S.noTable=true}
}
/* Excel para contabilidad: por cobrar, por pagar y todos los movimientos */
async function exportCuentas(){
  if(typeof ExcelJS==='undefined'){toast('La descarga en Excel no está disponible aquí');return}
  try{
    const A=accData(),wb=newWb(),stamp=todayISO(),hoy=fmtDate(stamp);
    const add=(name,cols,rows)=>{const ws=wb.addWorksheet(name,{views:[{state:'frozen',ySplit:1}]});ws.columns=cols.map(c=>({header:c[1],key:c[0],width:c[2]||14,style:c[3]?{numFmt:c[3]}:{}}));ws.getRow(1).font={bold:true};rows.forEach(r=>ws.addRow(r));ws.autoFilter={from:{row:1,column:1},to:{row:1,column:cols.length}};return ws};
    const M='#,##0.00';
    const tr=x=>x.b?(BUCKETS.find(b=>b[0]===x.b)||[])[1]:'Saldada',EST={ok:'Saldado',par:'Parcial',pen:'Pendiente'};
    add('Por cobrar',[['emp','Empresa',10],['cliente','Cliente',28],['doc','Factura o pedido',18],['po','PO',10],['fecha','Fecha pedido',12],['ffact','Fecha factura',12],['venc','Vence',12],['dias','Días de atraso',10],['calc','Calculado USD',14,M],['fact','Facturado USD',14,M],['total','Total a cobrar USD',14,M],['cob','Cobrado USD',14,M],['nc','Notas de crédito USD',14,M],['saldo','Saldo USD',14,M],['dif','Cobrado − calculado USD',14,M],['est','Conciliación',12],['rec','Reclamo',22],['tramo','Antigüedad',16]],
      A.cxc.map(x=>({emp:x.emp,cliente:x.nombre,doc:x.lab,po:x.po,fecha:x.fecha,ffact:x.fFact||'',venc:x.venc,dias:x.b?Math.max(0,x.atr):0,calc:x.calc,fact:x.fact==null?'':x.fact,total:x.monto,cob:x.cob,nc:x.nc,saldo:x.saldo,dif:x.dif,est:EST[x.est],rec:RECLAMO[x.reclamo]||'',tramo:tr(x)})));
    add('Por pagar',[['emp','Empresa',10],['tipo','Tipo',12],['nombre','Proveedor o productor',28],['det','Concepto',34],['venc','Vence',12],['dias','Días de atraso',10],['total','Calculado MXN',14,M],['pag','Pagado MXN',14,M],['saldo','Saldo MXN',14,M],['dif','Pagado − calculado MXN',14,M],['est','Conciliación',12],['tramo','Antigüedad',16]],
      A.cxp.map(x=>({emp:x.emp,tipo:x.tipo==='prod'?'Fruta':x.tipo==='jug'?'Juguera':'Flete',nombre:x.nombre,det:x.det,venc:x.venc,dias:x.b?Math.max(0,x.atr):0,total:x.monto,pag:x.hecho,saldo:x.saldo,dif:x.dif,est:EST[x.est],tramo:tr(x)})));
    if(A.cxj.length)add('Juguera por cobrar',[['emp','Empresa',10],['sem','Semana',16],['caj','Cajas',10,'#,##0.0'],['venc','Vence',12],['dias','Días de atraso',10],['calc','Estimado MXN',14,M],['liq','Liquidado MXN',14,M],['total','Total a cobrar MXN',14,M],['cob','Cobrado MXN',14,M],['saldo','Saldo MXN',14,M],['est','Conciliación',12],['tramo','Antigüedad',16]],
      A.cxj.map(x=>({emp:x.emp,sem:wkLab(x.wk),caj:x.caj,venc:x.venc,dias:x.b?Math.max(0,x.atr):0,calc:x.sinPrecio?'':x.calc,liq:x.fact==null?'':x.fact,total:x.monto,cob:x.hecho,saldo:x.saldo,est:EST[x.est],tramo:tr(x)})));
    const grpRows=L=>{const g=new Map();L.forEach(x=>{if(!x.b)return;const k=norm(x.nombre);let a=g.get(k);if(!a){a={nombre:x.nombre,n:0,tot:0};BUCKETS.forEach(b=>a[b[0]]=0);g.set(k,a)}a[x.b]+=x.saldo;a.tot+=x.saldo;a.n++});return [...g.values()].sort((a,b)=>b.tot-a.tot)};
    const gcols=(w,div)=>[['nombre',w,30],['n','Cuentas',9]].concat(BUCKETS.map(b=>[b[0],b[1]+' '+div,15,M]),[['tot','Total '+div,15,M]]);
    add('Antigüedad por cliente',gcols('Cliente','USD'),grpRows(A.cxc));
    add('Antigüedad por productor',gcols('Productor o proveedor','MXN'),grpRows(A.cxp));
    const K=cashKpi();add('Indicadores',[['k','Indicador',46],['v','Valor',18],['u','Unidad',10],['n','Cómo se calcula',70]],[
      {k:'DSO · días para cobrar',v:K.dso==null?'':Math.round(K.dso),u:'días',n:'Saldo por cobrar ÷ ventas de los últimos 90 días × 90'},
      {k:'DPO · días para pagar',v:K.dpo==null?'':Math.round(K.dpo),u:'días',n:'Saldo por pagar ÷ compras (fruta y flete) de los últimos 90 días × 90'},
      {k:'Ciclo de conversión de efectivo',v:K.cce==null?'':Math.round(K.cce),u:'días',n:'DSO − DPO; no incluye días de inventario'},
      {k:'Por cobrar convertido a pesos',v:r2(K.cxcMXN),u:'MXN',n:'Saldo en USD × tipo de cambio de la semana actual'},
      {k:'Por pagar',v:r2(K.cxp),u:'MXN',n:''},
      {k:'Hueco de capital de trabajo',v:r2(K.gap),u:'MXN',n:'Por cobrar en MXN − por pagar'},
      {k:'Umbral',v:K.umbral==null?'sin umbral':K.umbral,u:'MXN',n:'Se captura en Precios y costos'}]);
    const mv=[].concat(COB.list.map(y=>Object.assign({cl:'Cobro'},y)),PAG.list.map(y=>Object.assign({cl:'Pago'},y))).filter(y=>statsF.emp==='ALL'||!statsF.emp||y.emp===statsF.emp).sort((a,b)=>String(a.fecha).localeCompare(String(b.fecha)));
    add('Movimientos',[['fecha','Fecha',12],['emp','Empresa',10],['cl','Clase',8],['tipo','Tipo',22],['nombre','Cliente o proveedor',26],['lab','Cuenta',30],['monto','Monto',14,M],['div','Divisa',8],['tc','TC',8],['forma','Forma',14],['refb','Referencia',16],['nota','Nota',24],['by','Registró',18],['anu','Anulado',36]],
      mv.map(y=>({fecha:y.fecha,emp:y.emp,cl:y.cl,tipo:y.tipo==='fact'&&String(y.ref).indexOf('cxj|')===0?'Liquidación de la Juguera':MOV_T[y.tipo]||y.tipo,nombre:y.nombre||'',lab:y.lab||'',monto:y.monto,div:y.div,tc:y.tc||'',forma:y.forma||'',refb:y.refb||'',nota:y.nota||'',by:y.by||'',anu:y.anulado?'Sí · '+y.anulado.motivo:''})));
    await saveFile('Cuentas_'+(statsF.emp||'ALL')+'_'+stamp+'.xlsx',await wbBlob(wb));
  }catch(e){toast('No se pudo generar el archivo')}
}

/* ---------- v8.2 · costos fijos por categoría ----------
   Cada categoría tiene monto y periodicidad; se lleva a semana: mensual × 12 ÷ 52, anual ÷ 52.
   Mientras no haya ninguna categoría se usa el número único de siempre (costos fijos por semana). */
const FIJO_CAT=[['luz','Luz'],['agua','Agua'],['renta','Renta'],['dep','Depreciación'],['adm','Administración'],['otros','Otros']];
const FIJO_PER=[['sem','Semanal',1],['mes','Mensual',12/52],['anio','Anual',1/52]];
function fijoCats(e,wk){
  const F=wk?parsDe(e,wk):FIN[e],c=F&&F.fijos;if(!c||typeof c!=='object')return null;const out=[];
  FIJO_CAT.forEach(k=>{const x=c[k[0]],m=x?num(x.m):null;if(m==null||!(m>0))return;const p=FIJO_PER.find(q=>q[0]===x.p)||FIJO_PER[1];out.push({k:k[0],l:k[1],m:m,p:p[0],pl:p[1],sem:m*p[2]})});
  return out.length?out:null;
}
function fijoSem(e,wk){const c=fijoCats(e,wk);return c?c.reduce((s,x)=>s+x.sem,0):biPar(e,'fijo',wk)}
/* costos fijos de un mes: las categorías llevadas a mes (semanal × 52 ÷ 12, anual ÷ 12) o el número único × 52 ÷ 12 */
function fijoMes(e,ym){const wk=wkOfDate(ym+'-15'),c=fijoCats(e,wk);return c?c.reduce((s,x)=>s+(x.p==='mes'?x.m:x.p==='sem'?x.m*52/12:x.m/12),0):biPar(e,'fijo',wk)*52/12}
function fijoPeriodo(wks,es){
  const cats={},X={tot:0,cats:cats,nW:wks.length,sep:false};
  es.forEach(e=>wks.forEach(w=>{const c=fijoCats(e,w);if(c){X.sep=true;c.forEach(x=>{cats[x.l]=(cats[x.l]||0)+x.sem;X.tot+=x.sem})}else{const v=biPar(e,'fijo',w),l='Sin separar por categoría';cats[l]=(cats[l]||0)+v;X.tot+=v}}));
  return X;
}
function fijosFormHtml(e,F,inp,ed){
  const c=F.fijos||{},cs=fijoCats(e,sheet&&sheet.desde||curWk());
  const sel=k=>{const v=(c[k]||{}).p||'mes',id='fin-fijos-'+k+'-p';return `<label class="fld" for="${id}"><span>Periodicidad ${esc(k)}</span><select class="in sel" id="${id}" data-fin="${e}.fijos.${k}.p" data-fstr="1"${ed?'':' disabled'}>${FIJO_PER.map(p=>`<option value="${p[0]}"${p[0]===v?' selected':''}>${p[1]}</option>`).join('')}</select></label>`};
  return `<div class="sec">Costos fijos por categoría (MXN)</div><div class="fingrid fijg"><span></span><span class="fh">Monto (MXN)</span><span class="fh">Cada</span>${FIJO_CAT.map(k=>`<span class="fl">${k[1]}</span>${inp('fijos.'+k[0]+'.m',(c[k[0]]||{}).m,k[1]+' (MXN)','—')}${sel(k[0])}`).join('')}</div>
<p class="note">${cs?'Equivalen a <b>'+money(cs.reduce((s,x)=>s+x.sem,0))+' MXN por semana</b> (mensual × 12 ÷ 52; anual ÷ 52). Se reparten entre las cajas para el costo absorbido y el punto de equilibrio.':'Vacías: se usa el número único de costos fijos por semana de abajo. En cuanto captures una categoría, mandan las categorías.'}</p>`;
}
/* costo directo contra costo absorbido (directo + fijos repartidos por caja) */
function absHtml(F,X){
  const fc=F.cajas>0?X.tot/F.cajas:null,ab=F.costoCaja!=null&&fc!=null?F.costoCaja+fc:null,ua=F.util-X.tot,ma=F.ing>0?ua/F.ing:null;
  const cats=Object.keys(X.cats).filter(k=>X.cats[k]>0.005).sort((a,b)=>X.cats[b]-X.cats[a]);
  return `<div class="ig tot wkg abs"><div><span>Costo directo por caja</span><b>${money(F.costoCaja,2)}</b><small>MXN</small></div><div><span>Fijos por caja</span><b>${money(fc,2)}</b><small>MXN</small></div><div><span>Costo absorbido por caja</span><b>${money(ab,2)}</b><small>MXN</small></div></div>
<div class="ig tot wkg abs"><div><span>Margen directo</span><b>${pctTxt(F.margen)}</b><small>antes de fijos</small></div><div><span>Margen absorbido</span><b class="${ma!=null&&ma<0?'neg':''}">${pctTxt(ma)}</b><small>después de fijos</small></div><div><span>Utilidad después de fijos</span><b class="${ua<0?'neg':''}">${money(ua)}</b><small>MXN</small></div></div>
${cats.length?`<div class="abcats">${cats.map(k=>`<div class="kv"><span>${esc(k)}</span><b>${mxn(X.cats[k])}</b></div>`).join('')}<div class="kv tot"><span>Costos fijos del periodo (${X.nW} ${X.nW===1?'semana':'semanas'})</span><b>${mxn(X.tot)}</b></div></div>`:''}
<p class="note">${X.sep?'Costos fijos por categoría de Precios y costos, llevados a semana.':'Aún no hay costos fijos por categoría: se usa el número único por semana de Precios y costos.'} Costo absorbido = costo directo + costos fijos del periodo ÷ cajas de exportación.</p>`;
}

/* ---------- v8.2 · merma valorizada ----------
   Desecho (cajas campo × kg por caja) al precio que se paga por kg, más el material usado en merma si se captura.
   v8.7.1: la Juguera no es merma (se vende); se muestra aparte como dato.
   Ya va dentro del costo de fruta: muestra cuánto de ese pago se fue a merma. */
function mermaData(list){
  const T={des:0,jug:0,kg:0,fruta:0,mat:0,campo:0,kilos:0,mDes:0,mCampo:0,consig:false},pm=new Map();
  list.forEach(o=>{const wk=wkOf(o),F=parsDe(o.emp,wk),M=compute(o),mm=num(F.matMerma)||0;
    M.rows.forEach(r=>{const p=r.p;if(isSob(p)||+p.codigo===SEG_COD||p.segLot)return;
      const d=n0(p.des),j=0,jv=n0(p.jug),key=p.codigo?'c'+p.codigo:'n'+norm(p.nombre||'sin nombre');
      let a=pm.get(key);if(!a){const li=p.codigo?LISTA.find(x=>x.c===p.codigo):null;a={key:key,nombre:(li&&li.n)||p.nombre||'Sin nombre',des:0,jug:0,kg:0,fruta:0,mat:0,campo:0,kilos:0,mDes:0,mCampo:0,consig:false};pm.set(key,a)}
      const ac=(F.acu&&p.codigo&&F.acu[p.codigo])||{},consig=(p.modal||ac.modal)==='consig',pk=pkgOf(F,o,p);
      const kg=(d+j)*M.kg,m=muesOf(p);
      [a,T].forEach(z=>{z.des+=d;z.jug+=j;z.jugV=(z.jugV||0)+jv;z.kg+=kg;z.fruta+=kg*pk;z.mat+=(d+j)*mm;z.kilos+=n0(p.kilos);if(r.campo){z.campo+=r.campo;if(m&&m.des!=null){z.mDes+=m.des/100*r.campo;z.mCampo+=r.campo}}if(consig)z.consig=true});
    })});
  const fin=z=>{z.tot=z.fruta+z.mat;z.desP=z.campo>0?z.des/z.campo:null;z.jugP=z.campo>0?z.jug/z.campo:null;z.mDesP=z.mCampo>0?z.mDes/z.mCampo:null;z.kgP=z.kilos>0?z.kg/z.kilos:null;return z};
  return {T:fin(T),rows:[...pm.values()].map(fin).filter(a=>a.des+a.jug>0).sort((a,b)=>b.tot-a.tot)};
}
function mermaHtml(list){
  const Mm=mermaData(list),T=Mm.T;
  if(!(T.des>0))return '<p class="note">Sin desecho capturado en el periodo.</p>';
  const tiles=tileHtml('Merma valorizada',money(T.tot)+'<em class="cur">MXN</em>','fruta '+mxn(T.fruta)+(T.mat>0?' · material '+mxn(T.mat):' · material sin capturar'))
   +tileHtml('Kilos en merma',fmt(T.kg)+' kg',pctTxt(T.kgP)+' de lo recibido · '+fmt(T.des)+' cajas de desecho')
   +tileHtml('Desecho real',pctTxt(T.desP),T.mDesP!=null?'el muestreo de recepción decía '+pctTxt(T.mDesP):'sin muestreo de recepción',null,T.mDesP!=null&&T.desP!=null&&T.desP>T.mDesP*1.2?'warnt':'');
  const rows=Mm.rows.slice(0,10).map(a=>`<tr><th scope="row">${esc(a.nombre)}${a.consig?'<small>consignación: con el pago general por kg</small>':''}</th><td>${fmt(a.des+a.jug)}</td><td>${fmt(a.kg)}</td><td>${money(a.tot)}</td><td>${pctTxt(a.desP)}</td><td class="${a.mDesP!=null&&a.desP!=null&&a.desP>a.mDesP*1.2?'bv':''}">${pctTxt(a.mDesP)}</td></tr>`).join('');
  return `<div class="tiles">${tiles}</div><div class="tblx" style="margin-top:10px"><table class="ctab"><thead><tr><th>Productor</th><th>Cajas de merma</th><th>Kilos</th><th>MXN</th><th>Desecho real</th><th>Muestreo</th></tr></thead><tbody>${rows}</tbody></table></div><p class="note" style="margin-top:6px">Merma = desecho, en cajas campo × kilos por caja del pedido, al precio por kilo que se paga a cada productor${T.mat>0?', más el material usado en merma':''}. Ya está dentro del costo de fruta: muestra cuánto de ese pago se fue a merma. Desecho real contra el muestreo de Entrada de Fruta; en rojo si pasa por más de 20 %.${T.jugV>0?' La Juguera ('+fmt(T.jugV)+' cajas) no es merma: se vende y la venta queda para el empaque.':''}${Mm.rows.length>10?' Se muestran los 10 con más merma.':''}</p>`;
}

/* ---------- v8.2 · capital de trabajo: DSO, DPO y ciclo de conversión de efectivo ---------- */
function cashKpi(e0){
  const E=e0||statsF.emp||'ALL',A=accData(E),hoy=todayISO(),d90=dayAdd(hoy,-90),inW=x=>x.fecha&&x.fecha>=d90&&x.fecha<=hoy,es=E==='ALL'?['VL','EC']:[E];
  const tcOf=e=>+parsDe(e,curWk()).tc||0;
  const ventas=A.cxc.filter(inW).reduce((s,x)=>s+x.monto,0),compras=A.cxp.filter(inW).reduce((s,x)=>s+x.monto,0);
  const dso=ventas>0?A.agc.tot/ventas*90:null,dpo=compras>0?A.agp.tot/compras*90:null,cce=dso!=null&&dpo!=null?dso-dpo:null;
  const cxcMXN=A.cxc.reduce((s,x)=>s+(x.b?x.saldo*tcOf(x.emp):0),0),gap=cxcMXN-A.agp.tot;
  const us=es.map(e=>num(parsDe(e,curWk()).umbralCT)).filter(v=>v!=null),umbral=us.length?us.reduce((s,v)=>s+v,0):null;
  return {dso:dso,dpo:dpo,cce:cce,cxcMXN:cxcMXN,cxp:A.agp.tot,gap:gap,umbral:umbral,over:umbral!=null&&gap>umbral,ventas:ventas,compras:compras,b60:A.agc.b60p,b60p:A.agp.b60p};
}
function cashTilesHtml(K){
  if(!K)return '';
  return `<div class="tiles">${tileHtml('DSO · días para cobrar',K.dso==null?'–':fmt(K.dso,0)+' días','saldo por cobrar ÷ ventas de 90 días × 90')}${tileHtml('DPO · días para pagar',K.dpo==null?'–':fmt(K.dpo,0)+' días','saldo por pagar ÷ compras de 90 días × 90')}${tileHtml('Ciclo de efectivo',K.cce==null?'–':fmt(K.cce,0)+(Math.abs(Math.round(K.cce))===1?' día':' días'),'DSO − DPO, sin días de inventario')}${tileHtml('Hueco de capital de trabajo',money(K.gap,0)+'<em class="cur">MXN</em>','por cobrar '+mxn(K.cxcMXN,0)+' − por pagar '+mxn(K.cxp,0)+(K.umbral!=null?' · umbral '+mxn(K.umbral,0):' · sin umbral'),K.over?'<span class="chip crit">Arriba del umbral</span>':'',K.over?'warnt':'')}</div>`;
}
/* antigüedad agrupada por cliente o por productor */
const BK_SH={cur:'Por vencer',b30:'0–30 días',b60:'31–60 días',b60p:'+60 días'};
function agingGroupHtml(L,div,who){
  const g=new Map();L.forEach(x=>{if(!x.b)return;const k=norm(x.nombre);let a=g.get(k);if(!a){a={n:x.nombre,c:0,tot:0};BUCKETS.forEach(b=>a[b[0]]=0);g.set(k,a)}a[x.b]+=x.saldo;a.tot+=x.saldo;a.c++});
  const R=[...g.values()].sort((a,b)=>b.tot-a.tot);if(!R.length)return '<p class="note" style="margin-top:8px">Nada pendiente.</p>';
  const T={tot:R.reduce((s,a)=>s+a.tot,0)};BUCKETS.forEach(b=>T[b[0]]=R.reduce((s,a)=>s+a[b[0]],0));
  return `<div class="tblx" style="margin-top:8px"><table class="ctab agt"><thead><tr><th>${who}</th>${BUCKETS.map(b=>`<th><i class="agd ${BK_CLS[b[0]]}" aria-hidden="true"></i>${b[1]}</th>`).join('')}<th>Total ${div}</th></tr></thead><tbody>${R.map(a=>`<tr><th scope="row">${esc(a.n)}<small>${a.c} ${a.c===1?'cuenta':'cuentas'}</small></th>${BUCKETS.map(b=>`<td data-l="${BK_SH[b[0]]}">${a[b[0]]>0.005?money(a[b[0]],0):'–'}</td>`).join('')}<td data-l="Total ${div}"><b>${money(a.tot,0)}</b></td></tr>`).join('')}<tr class="tot"><th scope="row">Total</th>${BUCKETS.map(b=>`<td data-l="${BK_SH[b[0]]}">${money(T[b[0]],0)}</td>`).join('')}<td data-l="Total ${div}"><b>${money(T.tot,0)}</b></td></tr></tbody></table></div>`;
}

/* ---------- v8.2 · factura del pedido y flete real del embarque ----------
   Son registros en cobros y pagos (no cuentan como cobro ni pago); manda el más reciente sin anular. */
function factFormHtml(x,can){
  const fa=lastMov(COB,x.ref,'fact');
  const cur=fa?`<p class="note">Factura vigente: ${esc(fmtDate(fa.fecha))}${fa.num?' · núm. '+esc(fa.num):''} · ${esc(amt(fa.monto,'USD'))} · ${esc(RECLAMO[fa.reclamo||''])}. Calculado con los precios de su semana: ${esc(amt(x.calc,'USD'))}${Math.abs(fa.monto-x.calc)>0.005?' (diferencia '+esc(sgnAmt(r2(fa.monto-x.calc),'USD'))+')':''}.</p>`:`<p class="note">Sin factura registrada: se cobra lo calculado (${esc(amt(x.calc,'USD'))}) y vence desde la fecha del pedido.</p>`;
  if(!can)return `<div class="sec">Factura</div>${cur}`;
  return `<details class="mvx"${sheet.fOpen||!fa?' open':''}><summary>${fa?'Factura y reclamo · actualizar':'Registrar factura'}</summary>${cur}<div class="grid2">
<label class="fld" for="fa-f"><span>Fecha de factura</span><input class="in txt" id="fa-f" type="date" value="${esc((fa&&fa.fecha)||todayISO())}"></label>
<label class="fld" for="fa-n"><span>Número de factura</span><input class="in txt" id="fa-n" type="text" autocomplete="off" value="${esc((fa&&fa.num)||x.factura||'')}"></label>
<label class="fld" for="fa-m"><span>Monto facturado (USD)</span><input class="in" id="fa-m" inputmode="decimal" value="${esc(fa?fa.monto:x.calc)}"></label>
<label class="fld" for="fa-r"><span>Reclamo o nota de crédito</span><select class="in sel" id="fa-r">${Object.keys(RECLAMO).map(k=>`<option value="${k}"${(fa&&fa.reclamo||'')===k?' selected':''}>${RECLAMO[k]}</option>`).join('')}</select></label></div>
<label class="fld" for="fa-o"><span>Nota</span><input class="in txt" id="fa-o" type="text" autocomplete="off"></label>${sheet.fErr?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.fErr)}</p>`:''}
<div class="srow2"><button class="btn" data-act="factsave">${fa?'Guardar cambios de la factura':'Guardar factura'}</button></div><p class="note">La factura no es un cobro: fija el monto a cobrar y la fecha desde la que corren los días de pago. Los montos de nota de crédito se registran abajo como «Nota de crédito o descuento».</p></details>`;
}
function realFormHtml(x,can){
  const fr=lastMov(PAG,x.ref,'real'),F=parsDe(x.emp,wkOf({fecha:x.fecha})),par=(+F.flete||0)+(+F.cruce||0);
  const cur=`<p class="note">${fr?'Se usa el flete real: <b>'+esc(amt(fr.monto,'MXN'))+'</b> (parámetro '+esc(amt(par,'MXN'))+').':'Se usa el parámetro de Precios y costos: '+esc(amt(par,'MXN'))+' (flete más cruce).'}</p>`;
  if(!can)return `<div class="sec">Flete real</div>${cur}`;
  return `<details class="mvx"${sheet.fOpen?' open':''}><summary>${fr?'Flete real · cambiar':'Registrar flete real'}</summary>${cur}<div class="grid2">
<label class="fld" for="fr-f"><span>Fecha</span><input class="in txt" id="fr-f" type="date" value="${esc((fr&&fr.fecha)||x.fecha||todayISO())}"></label>
<label class="fld" for="fr-m"><span>Flete y cruce reales (MXN)</span><input class="in" id="fr-m" inputmode="decimal" value="${esc(fr?fr.monto:'')}" placeholder="${esc(par)}"></label></div>
<label class="fld" for="fr-o"><span>Nota (transportista, factura del flete…)</span><input class="in txt" id="fr-o" type="text" autocomplete="off"></label>${sheet.fErr?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.fErr)}</p>`:''}
<div class="srow2"><button class="btn" data-act="realsave">Guardar flete real</button></div><p class="note">El flete real reemplaza al parámetro en la utilidad, el costeo por embarque y esta cuenta por pagar. No es un pago.</p></details>`;
}
function movRec(St,x,y,lab,o,n){
  const now=Date.now();Object.assign(y,{id:uid(),emp:x.emp,ref:x.ref,lab:x.lab,nombre:x.nombre,by:parBy(),uid:(authUser&&authUser.id)||'',at:now,ts:now,anulado:null});
  St.list.push(y);St.dirty.push(y.id);saveMov();
  logAdd({k:St===COB?'cobro':'pago',where:'Finanzas',ctx:{t:'c',id:x.ref,cod:x.nombre+' · '+x.lab},lab:lab,o:o,n:n});
  sheet.fErr='';sheet.fOpen=false;toast('Guardado');renderSheet();render();
}
function liqFormHtml(x,can){
  const lq=lastMov(COB,x.ref,'fact'),est=x.sinPrecio?'sin precio de venta capturado':'estimado '+amt(x.calc,'MXN')+' ('+fmt(x.caj,x.caj%1?1:0)+' cajas × precio de Precios y costos)';
  const cur=lq?`<p class="note">Liquidación vigente: ${esc(fmtDate(lq.fecha))}${lq.num?' · núm. '+esc(lq.num):''} · ${esc(amt(lq.monto,'MXN'))}. Sin ella: ${esc(est)}.</p>`:`<p class="note">Sin liquidación registrada: ${esc(est)}.</p>`;
  if(!can)return `<div class="sec">Liquidación de la Juguera</div>${cur}`;
  return `<details class="mvx"${sheet.fOpen||!lq?' open':''}><summary>${lq?'Liquidación de la Juguera · actualizar':'Registrar liquidación de la Juguera'}</summary>${cur}<div class="grid2">
<label class="fld" for="fa-f"><span>Fecha</span><input class="in txt" id="fa-f" type="date" value="${esc((lq&&lq.fecha)||todayISO())}"></label>
<label class="fld" for="fa-n"><span>Número o folio</span><input class="in txt" id="fa-n" type="text" autocomplete="off" value="${esc((lq&&lq.num)||'')}"></label>
<label class="fld" for="fa-m"><span>Monto que paga la Juguera (MXN)</span><input class="in" id="fa-m" inputmode="decimal" value="${esc(lq?lq.monto:(x.calc||''))}"></label></div>
<label class="fld" for="fa-o"><span>Nota</span><input class="in txt" id="fa-o" type="text" autocomplete="off"></label>${sheet.fErr?`<p class="note" style="color:var(--crit)" role="alert">${esc(sheet.fErr)}</p>`:''}
<div class="srow2"><button class="btn" data-act="factsave">${lq?'Guardar cambios de la liquidación':'Guardar liquidación'}</button></div><p class="note">La liquidación no es un cobro: fija lo que se cobra a la Juguera por la semana y, en pase íntegro, lo que se reparte a los productores.</p></details>`;
}
function factSave(){
  if(!sheet||sheet.kind!=='mov'||sheet.S!=='cob'||!canMov()||ro)return;const x=accRow(sheet.ref);if(!x)return;
  if(x.jug){const g=id=>String((document.getElementById(id)||{}).value||'').trim(),fe=g('fa-f'),m=num(g('fa-m').replace(',','.'));sheet.fOpen=true;
    if(!/^\d{4}-\d{2}-\d{2}$/.test(fe)){sheet.fErr='Pon la fecha.';renderSheet();return}
    if(m==null||!(m>=0)){sheet.fErr='Pon el monto que paga la Juguera.';renderSheet();return}
    const old=lastMov(COB,x.ref,'fact');
    movRec(COB,x,{tipo:'fact',fecha:fe,monto:r2(m),div:'MXN',num:g('fa-n'),reclamo:'',nota:g('fa-o'),tc:null},old?'Liquidación de Juguera cambiada':'Liquidación de Juguera registrada',old?amt(old.monto,'MXN')+' · '+fmtDate(old.fecha):(x.sinPrecio?'sin precio':'estimado '+amt(x.calc,'MXN')),amt(r2(m),'MXN')+' · '+fmtDate(fe)+(g('fa-n')?' · núm. '+g('fa-n'):''));
    return}
  const g=id=>String((document.getElementById(id)||{}).value||'').trim(),fe=g('fa-f'),m=num(g('fa-m').replace(',','.')),rc=g('fa-r');
  sheet.fOpen=true;
  if(!/^\d{4}-\d{2}-\d{2}$/.test(fe)){sheet.fErr='Pon la fecha de factura.';renderSheet();return}
  if(!(m>0)){sheet.fErr='Pon el monto facturado.';renderSheet();return}
  const old=lastMov(COB,x.ref,'fact');
  movRec(COB,x,{tipo:'fact',fecha:fe,monto:r2(m),div:'USD',num:g('fa-n'),reclamo:RECLAMO[rc]!=null?rc:'',nota:g('fa-o'),tc:null},old?'Factura cambiada':'Factura registrada',old?amt(old.monto,'USD')+' · '+fmtDate(old.fecha)+' · '+RECLAMO[old.reclamo||'']:'calculado '+amt(x.calc,'USD'),amt(r2(m),'USD')+' · '+fmtDate(fe)+(g('fa-n')?' · núm. '+g('fa-n'):'')+' · '+RECLAMO[rc||'']);
}
function realSave(){
  if(!sheet||sheet.kind!=='mov'||sheet.S!=='pag'||!canMov()||ro)return;const x=accRow(sheet.ref);if(!x||x.tipo!=='flete')return;
  const g=id=>String((document.getElementById(id)||{}).value||'').trim(),fe=g('fr-f'),m=num(g('fr-m').replace(',','.'));
  sheet.fOpen=true;
  if(!/^\d{4}-\d{2}-\d{2}$/.test(fe)){sheet.fErr='Pon la fecha.';renderSheet();return}
  if(m==null||m<0){sheet.fErr='Pon el monto real del flete y cruce.';renderSheet();return}
  movRec(PAG,x,{tipo:'real',fecha:fe,monto:r2(m),div:'MXN',nota:g('fr-o'),tc:null},'Flete real registrado',amt(x.calc,'MXN'),amt(r2(m),'MXN'));
}

/* ---------- v8.2 · costeo por embarque (cada pedido es un embarque: contenedor o viaje) ---------- */
function jobData(list){
  const g=new Map();list.forEach(o=>{const k=o.emp+'|'+o.cod;if(!g.has(k))g.set(k,[]);g.get(k).push(o)});
  const J=[];
  g.forEach((os,k)=>{const A=finAgg(os),T=A.T;if(!(T.ing>0||T.cost>0))return;
    const m=mainOf(os[0]),bi=m.bi||{},wk=wkOf(m),tc=+parsDe(m.emp,wk).tc||0,ref='cxc|'+k,fa=lastMov(COB,ref,'fact'),nc=movSum(COB,ref,'nota'),fr=fleteReal(m.emp,m.cod);
    const usd=fa&&+fa.monto>0?+fa.monto:T.ingUSD,ing=usd*tc+T.ingNac,notas=nc*tc,dem=n0(bi.demora),demM=dem*tc,cost=T.fruta+T.mat+T.mo+T.flete+demM,neto=ing-notas-cost;
    J.push({k:k,emp:m.emp,cod:m.cod,wk:wk,fecha:m.fecha||'',cli:String(m.customer||'').trim()||'Sin cliente',cont:bi.contenedor||'',nav:bi.naviera||'',tc:tc,usdCalc:T.ingUSD,usd:usd,fact:!!fa,nac:T.ingNac,jug:T.ingJug,fjug:T.frutaJug,ing:ing,nc:nc,notas:notas,fruta:T.fruta,mat:T.mat,mo:T.mo,flete:T.flete,fr:fr!=null,dem:dem,demM:demM,rech:n0(bi.rech),cajas:T.cajas,kilos:T.kilos,cost:cost,neto:neto,margen:ing>0?neto/ing:null,prods:A.rows.filter(a=>a.kilos>0||a.cajas>0).sort((a,b)=>b.kilos-a.kilos)});
  });
  return J;
}
function embView(D){
  const J=jobData(D.cur.list),f=statsF,s=f.esort||'fecha';
  if(!J.length)return '<p class="note" style="margin-top:8px">Sin embarques con venta en el periodo.</p>';
  J.sort(s==='neto'?(a,b)=>a.neto-b.neto:s==='margen'?(a,b)=>(a.margen==null?-9:a.margen)-(b.margen==null?-9:b.margen):(a,b)=>String(b.fecha).localeCompare(String(a.fecha))||String(b.cod).localeCompare(String(a.cod)));
  const ti=J.reduce((t,j)=>{t.ing+=j.ing;t.neto+=j.neto;t.fr+=j.fr?1:0;t.neg+=j.neto<0?1:0;return t},{ing:0,neto:0,fr:0,neg:0});
  const tiles=tileHtml('Embarques',fmt(J.length),ti.fr+' con flete real · '+(J.length-ti.fr)+' con el parámetro')+tileHtml('Resultado neto',money(ti.neto)+'<em class="cur">MXN</em>','margen neto '+pctTxt(ti.ing>0?ti.neto/ti.ing:null),null,ti.neto<0?'warnt':'')+tileHtml('Con pérdida',fmt(ti.neg),ti.neg===1?'embarque':'embarques',null,ti.neg?'warnt':'');
  const b=(k,t)=>`<button class="btn sm" data-act="esort:${k}" aria-pressed="${s===k}">${t}</button>`;
  const L=(l,v,sub,cls)=>`<div class="kv${cls?' '+cls:''}"><span>${l}${sub?`<br><small class="note">${sub}</small>`:''}</span><b class="${v<0?'negv':''}">${mxn(v)}</b></div>`;
  const card=j=>`<details class="prd job${j.neto<0?' late':''}"><summary><div class="r1"><div class="pnm">${esc(j.cli)}<small>Pedido ${esc(j.cod)} · ${esc(j.emp)} · ${j.fecha?esc(fmtDate(j.fecha)):'sin fecha'}${j.cont?' · '+esc(j.cont):''}</small></div><div class="rend${j.neto<0?' negv':''}">${money(j.neto)}<em class="cur">MXN</em><small>neto · margen ${pctTxt(j.margen)}</small></div></div>
<div class="r3"><span class="chip ${j.fr?'good':''}">${j.fr?'Flete real':'Flete del parámetro'}</span><span class="chip ${j.fact?'good':''}">${j.fact?'Facturado':'Venta calculada'}</span>${j.dem>0?`<span class="chip warn">Demoras ${esc(usd(j.dem))}</span>`:''}${j.rech>0&&!j.nc?`<span class="chip warn">${fmt(j.rech)} cajas en reclamo sin nota de crédito</span>`:''}</div></summary>
<div class="jobd">${L('Venta de exportación',j.usd*j.tc,usd(j.usd,2)+(j.fact?' facturado':' calculado')+' × '+money(j.tc,2)+' MXN/USD'+(j.fact&&Math.abs(j.usd-j.usdCalc)>0.005?' · calculado '+usd(j.usdCalc,2):''))}${j.nac?L('Venta nacional',j.nac,j.jug?'segundas, Torreón y Juguera ('+mxn(j.jug)+')':'segundas y Torreón'):''}${j.notas?L('Notas de crédito y rechazos',-j.notas,usd(j.nc,2)+' registrados en Por cobrar'):''}
${L('Fruta',-j.fruta,fmt(j.kilos)+' kg de '+j.prods.length+(j.prods.length===1?' productor':' productores')+(j.fjug?' · Juguera '+mxn(j.fjug):''))}${L('Material de empaque',-j.mat)}${L('Mano de obra',-j.mo)}${L('Flete y cruce',-j.flete,j.fr?'real, registrado en Por pagar':'parámetro de Precios y costos')}${j.dem?L('Demoras (demurrage)',-j.demM,usd(j.dem,2)+' × '+money(j.tc,2)+' MXN/USD'):''}
${L('Resultado neto del embarque',j.neto,'margen '+pctTxt(j.margen),'tot')}
${j.prods.length?`<div class="tblx"><table class="ctab"><thead><tr><th>Productor</th><th>Kilos</th><th>Cajas</th><th>Fruta MXN</th></tr></thead><tbody>${j.prods.map(a=>`<tr><th scope="row">${esc(a.nombre)}</th><td>${fmt(a.kilos)}</td><td>${fmt(a.cajas)}</td><td>${money(a.pago)}</td></tr>`).join('')}</tbody></table></div>`:''}</div></details>`;
  return `<div class="tiles">${tiles}</div><div class="srt">${b('fecha','Más recientes')}${b('neto','Peor resultado primero')}${b('margen','Menor margen primero')}<button class="btn sm" data-act="embx">Descargar Excel</button></div>
<div class="cgrid">${J.slice(0,f.eN||80).map(card).join('')}</div>
<p class="note" style="margin-top:8px">Cada pedido es un embarque. Resultado neto = venta (facturada si se registró la factura, si no la calculada) − notas de crédito − fruta − material − mano de obra − flete y cruce (real si se registró, si no el parámetro) − demoras convertidas a pesos con el tipo de cambio de su semana. Las cajas en reclamo se restan cuando se registra su nota de crédito.</p>`;
}
async function exportEmb(){
  if(typeof ExcelJS==='undefined'){toast('La descarga en Excel no está disponible aquí');return}
  try{
    const D=statsData(),J=jobData(D.cur.list),wb=newWb(),M='#,##0.00',add=(name,cols,rows)=>{const ws=wb.addWorksheet(name,{views:[{state:'frozen',ySplit:1}]});ws.columns=cols.map(c=>({header:c[1],key:c[0],width:c[2]||14,style:c[3]?{numFmt:c[3]}:{}}));ws.getRow(1).font={bold:true};rows.forEach(r=>ws.addRow(r));ws.autoFilter={from:{row:1,column:1},to:{row:1,column:cols.length}}};
    add('Embarques',[['emp','Empresa',9],['cod','Pedido',12],['fecha','Fecha',12],['cli','Cliente',26],['cont','Contenedor o caja',16],['cajas','Cajas',10],['kilos','Kilos',11],['usd','Venta USD',13,M],['vf','Venta',12],['tc','TC MXN/USD',10,M],['ing','Ingreso MXN',14,M],['notas','Notas de crédito MXN',14,M],['fruta','Fruta MXN',14,M],['mat','Material MXN',13,M],['mo','Mano de obra MXN',13,M],['flete','Flete y cruce MXN',14,M],['ft','Flete',10],['dem','Demoras USD',12,M],['demM','Demoras MXN',12,M],['neto','Resultado neto MXN',15,M],['margen','Margen neto',10,'0.0%']],
      J.map(j=>({emp:j.emp,cod:j.cod,fecha:j.fecha,cli:j.cli,cont:j.cont,cajas:j.cajas,kilos:j.kilos,usd:r2(j.usd),vf:j.fact?'Facturada':'Calculada',tc:j.tc,ing:r2(j.ing),notas:r2(j.notas),fruta:r2(j.fruta),mat:r2(j.mat),mo:r2(j.mo),flete:r2(j.flete),ft:j.fr?'Real':'Parámetro',dem:r2(j.dem),demM:r2(j.demM),neto:r2(j.neto),margen:j.margen==null?'':j.margen})));
    const P=[];J.forEach(j=>j.prods.forEach(a=>P.push({emp:j.emp,cod:j.cod,fecha:j.fecha,prod:a.nombre,codigo:a.codigo?pad(a.codigo,3):'',kilos:a.kilos,cajas:a.cajas,pago:r2(a.pago)})));
    add('Kilos por productor',[['emp','Empresa',9],['cod','Pedido',12],['fecha','Fecha',12],['prod','Productor',30],['codigo','Código',8],['kilos','Kilos',11],['cajas','Cajas',10],['pago','Fruta MXN',14,M]],P);
    await saveFile('Embarques_'+(statsF.emp||'ALL')+'_'+todayISO()+'.xlsx',await wbBlob(wb));
  }catch(e){toast('No se pudo generar el archivo')}
}

/* ---------- v8.2 · presupuesto contra real ----------
   Catálogo «presupuesto»: una entrada por empresa y periodo (semana o mes) con precio por caja (USD), cajas, flete y costos fijos (MXN).
   Solo el administrador lo captura; al sincronizar gana, periodo por periodo, la versión más reciente. */
const LS_PRES='empaque-presupuesto';
var PPTO={d:{},dirty:false};
(function(){try{const j=JSON.parse(localStorage.getItem(LS_PRES)||'null');if(j&&j.d&&typeof j.d==='object')PPTO={d:j.d,dirty:!!j.dirty}}catch(e){}})();
function savePres(){try{localStorage.setItem(LS_PRES,JSON.stringify(PPTO))}catch(e){}setSync()}
const PRES_F=[['precio','Precio por caja','USD',1,2],['cajas','Cajas de exportación','cajas',1,0],['flete','Flete y cruce','MXN',-1,0],['fijos','Costos fijos','MXN',-1,0]];
async function syncPres(){
  try{
    const r=await sb('/rest/v1/catalogos?select=updated_at,data&clave=eq.presupuesto'),rd=(r&&r[0]&&r[0].data&&r[0].data.d)||{};let ch=false;
    Object.keys(rd).forEach(k=>{const a=rd[k],b=PPTO.d[k];if(a&&(!b||(+a.ts||0)>(+b.ts||0))){PPTO.d[k]=a;ch=true;remoteN++}});
    const ahead=Object.keys(PPTO.d).some(k=>!rd[k]||(+PPTO.d[k].ts||0)>(+rd[k].ts||0));
    if(ahead&&isAdmin()){await sb('/rest/v1/catalogos?on_conflict=clave',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{clave:'presupuesto',updated_at:Date.now(),data:{d:PPTO.d}}]});PPTO.dirty=false}
    savePres();if(ch&&view==='fin')render();
  }catch(e){}
}
const presKey=(e,mode,pk)=>e+'|'+mode+':'+pk;
const presLab=(mode,pk)=>mode==='S'?wkLab(pk):(()=>{const p=String(pk).split('-');return p.length===2?MESES[+p[1]-1]+' '+p[0]:pk})();
function presOf(es,mode,pk){
  const R={precio:null,cajas:null,flete:null,fijos:null,any:false};let pc=0,pw=0,pn=0,ps=0;
  es.forEach(e=>{const x=PPTO.d[presKey(e,mode,pk)];if(!x)return;['cajas','flete','fijos'].forEach(k=>{if(num(x[k])!=null){R[k]=(R[k]||0)+num(x[k]);R.any=true}});if(num(x.precio)!=null){R.any=true;ps+=num(x.precio);pn++;if(num(x.cajas)>0){pc+=num(x.precio)*num(x.cajas);pw+=num(x.cajas)}}});
  R.precio=pw>0?pc/pw:pn?ps/pn:null;R.usd=R.precio!=null&&R.cajas!=null?R.precio*R.cajas:null;return R;
}
function presReal(es,mode,pk){
  const L=visible().filter(o=>es.indexOf(o.emp)>=0&&(mode==='S'?wkOf(o)===pk:String(o.fecha||'').slice(0,7)===pk)),T=finAgg(L).T;
  return {precio:T.precio,cajas:T.cajas,flete:T.flete,fijos:es.reduce((s,e)=>s+(mode==='S'?fijoSem(e,pk):fijoMes(e,pk)),0),usd:T.ingUSD,hojas:L.length};
}
function presPeriods(mode){
  const s=new Set(),cw=curWk(),cm=todayISO().slice(0,7);
  visible().forEach(o=>{const k=mode==='S'?wkOf(o):String(o.fecha||'').slice(0,7);if(k)s.add(k)});
  Object.keys(PPTO.d).forEach(k=>{const m=/\|([SM]):(.+)$/.exec(k);if(m&&m[1]===mode)s.add(m[2])});
  if(mode==='S'){let k=cw;s.add(k);for(let i=0;i<4;i++){k=wkNext(k);s.add(k)}}
  else{s.add(cm);let d=cm+'-01';for(let i=0;i<2;i++){d=dayAdd(d,32).slice(0,7)+'-01';s.add(d.slice(0,7))}}
  return [...s].filter(k=>mode==='S'?/^\d{4}-S\d{2}$/.test(k):/^\d{4}-\d{2}$/.test(k)).sort().reverse().slice(0,60);
}
function varOf(p,r,sg,dec){
  if(p==null||r==null)return {t:'–',c:'',chip:''};
  const v=r-p,pc=p?v/Math.abs(p):null,fav=Math.abs(v)<1e-9?0:(v*sg>0?1:-1);
  return {t:(v>0?'+':'')+(dec==null?money(v):fmt(v,dec))+(pc==null?'':'<br>'+(pc>0?'+':'')+fmt(pc*100,1)+'%'),c:fav>0?'gv':fav<0?'bv':'',chip:fav?`<span class="chip ${fav>0?'good':'crit'}">${fav>0?'Favorable':'Desfavorable'}</span>`:'<span class="chip">Igual</span>'};
}
function presView(){
  const f=statsF,E=f.emp||'ALL',mode=f.pmode==='M'?'M':'S',es=E==='ALL'?['VL','EC']:[E],ed=isAdmin()&&E!=='ALL',ops=presPeriods(mode);
  const pk=ops.indexOf(f.ppk)>=0?f.ppk:(mode==='S'?curWk():todayISO().slice(0,7));f.ppk=pk;
  const P=presOf(es,mode,pk),R=presReal(es,mode,pk),x=ed?(PPTO.d[presKey(E,mode,pk)]||{}):null;
  const fm=(k,v)=>v==null?'–':k==='cajas'?fmt(v):money(v,k==='precio'?2:0);
  const card=(lab,u,pres,real,vr,tot)=>`<div class="prw${tot?' sum':''}"><div class="prh"><strong>${lab}</strong><small>${u}</small>${vr.chip}</div><div class="prg"><div>${pres}</div><div><span>Real</span><b>${real}</b></div><div><span>Variación</span><b class="${vr.c}">${vr.t}</b></div></div></div>`;
  const pres=q=>{const k=q[0];if(!ed)return `<span>Presupuesto</span><b>${fm(k,P[k])}</b>`;const id='pre-'+k;return `<label for="${id}"><span>Presupuesto</span><input class="in" id="${id}" inputmode="decimal" data-pres="${esc(presKey(E,mode,pk))}|${k}" value="${x[k]==null?'':esc(x[k])}" placeholder="—"></label>`};
  const cards=PRES_F.map(q=>card(q[1],q[2],pres(q),fm(q[0],R[q[0]]),varOf(P[q[0]],R[q[0]],q[3],q[0]==='cajas'?0:q[0]==='precio'?2:null))).join('')
    +card('Venta de exportación','USD · precio × cajas',`<span>Presupuesto</span><b>${P.usd==null?'–':money(P.usd)}</b>`,money(R.usd),varOf(P.usd,R.usd,1),1);
  const sel=`<label class="fld" for="pre-pk"><span>${mode==='S'?'Semana':'Mes'}</span><select class="in sel" id="pre-pk" data-ppk="1">${ops.map(k=>`<option value="${k}"${k===pk?' selected':''}>${esc(presLab(mode,k))}${mode==='S'?' · '+esc(wkSpan(k)):''}</option>`).join('')}</select></label>`;
  const hist=ops.filter(k=>k<=(mode==='S'?curWk():todayISO().slice(0,7))&&presOf(es,mode,k).any).slice(0,8).map(k=>{const p=presOf(es,mode,k),r=presReal(es,mode,k),v=varOf(p.usd,r.usd,1);return `<tr><th scope="row">${esc(presLab(mode,k))}<small>cajas ${p.cajas==null?'–':fmt(p.cajas)} → ${fmt(r.cajas)}</small></th><td>${p.usd==null?'–':money(p.usd)}<br>${money(r.usd)}</td><td class="${v.c}">${v.t}<br>${v.chip}</td></tr>`}).join('');
  return `<div class="srt">${[['S','Por semana'],['M','Por mes']].map(o=>`<button class="btn sm" data-act="pmode:${o[0]}" aria-pressed="${mode===o[0]}">${o[1]}</button>`).join('')}</div><div class="presel">${sel}</div>
${E==='ALL'?`<p class="note">Vista de ambas empresas: suma de los dos presupuestos.${isAdmin()?' Para capturar, elige Vera Limes o Citrilar.':''}</p>`:!isAdmin()?'<p class="note">Solo el administrador captura el presupuesto.</p>':''}
<div class="prws">${cards}</div>
<p class="note" style="margin-top:6px">Real: ${R.hojas?fmt(R.hojas)+(R.hojas===1?' hoja':' hojas')+' de empaque del periodo con los precios y costos de su semana (flete real donde se registró)':'aún sin empaques en el periodo'}. Los costos fijos reales son los de Precios y costos (la app no captura el gasto pagado). Favorable: más precio, más cajas o más venta; menos flete o menos costos fijos.</p>
${hist?`<div class="sec">Periodos con presupuesto</div><div class="tblx"><table class="ctab phist"><thead><tr><th>Periodo</th><th>Venta USD<small>presupuesto / real</small></th><th>Variación</th></tr></thead><tbody>${hist}</tbody></table></div>`:''}`;
}
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset)return;
  if(t.dataset.ppk){statsF.ppk=t.value;render();return}
  if(!t.dataset.pres||!isAdmin())return;
  const q=t.dataset.pres.split('|'),fk=q.pop(),key=q.join('|'),e0=q[0],v=num(String(t.value).replace(',','.')),cur0=PPTO.d[key]||{},old=cur0[fk];
  if(sv(old)===sv(v))return;
  const nx=Object.assign({},cur0);if(v==null)delete nx[fk];else nx[fk]=v;nx.ts=Date.now();nx.by=parBy();PPTO.d[key]=nx;PPTO.dirty=true;savePres();
  const m=/^([SM]):(.+)$/.exec(q[1]||''),fl=PRES_F.find(x=>x[0]===fk);
  logAdd({k:'param',where:'Presupuesto',ctx:{t:'f',id:e0,cod:EMPS[e0].name+' · '+(m?presLab(m[1],m[2]):'')},path:'pres.'+key+'.'+fk,lab:'Presupuesto · '+(fl?fl[1]+' ('+fl[2]+')':fk),o:sv(old),n:sv(v)});
  render();
});

/* ---------- v8.3 · Fase 3: tipo de cambio, impuestos, pólizas y cierre mensual ----------
   Catálogo «contable» (tabla catalogos, solo lo escribe el administrador): cuentas contables por empresa, tasas de IVA en ventas,
   regímenes fiscales con IVA y retenciones, y el régimen de cada productor. Todo viene vacío: lo define el contador.
   Al sincronizar gana, entrada por entrada, el cambio más reciente. */
const LS_CTB='empaque-contable';
var CTB={d:{}};
(function(){try{const j=JSON.parse(localStorage.getItem(LS_CTB)||'null');if(j&&j.d&&typeof j.d==='object')CTB.d=j.d}catch(e){}})();
function saveCtb(){try{localStorage.setItem(LS_CTB,JSON.stringify(CTB))}catch(e){}invalidateStats();setSync()}
async function syncCtb(){
  try{
    const r=await sb('/rest/v1/catalogos?select=updated_at,data&clave=eq.contable'),rd=(r&&r[0]&&r[0].data&&r[0].data.d)||{};let ch=false;
    Object.keys(rd).forEach(k=>{const a=rd[k],b=CTB.d[k];if(a&&(!b||(+a.ts||0)>(+b.ts||0))){CTB.d[k]=a;ch=true;remoteN++}});
    const ahead=Object.keys(CTB.d).some(k=>!rd[k]||(+CTB.d[k].ts||0)>(+rd[k].ts||0));
    if(ahead&&isAdmin())await sb('/rest/v1/catalogos?on_conflict=clave',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:[{clave:'contable',updated_at:Date.now(),data:{d:CTB.d}}]});
    if(ch){saveCtb();if(view==='fin')render()}
  }catch(e){}
}
const CTAS=[['bancos','Bancos'],['clientes','Clientes'],['ventasExp','Ventas de exportación'],['ventasNac','Ventas nacionales'],['devVentas','Notas de crédito sobre ventas'],['costoFruta','Compra de fruta'],['proveedores','Proveedores de fruta'],['fletes','Fletes y cruce'],['acreedores','Acreedores de flete'],['descCompras','Descuentos sobre compras'],['ivaAcred','IVA acreditable'],['ivaTras','IVA trasladado'],['retIsr','Retenciones de ISR por pagar'],['retIva','Retenciones de IVA por pagar'],['utilCamb','Utilidad cambiaria'],['perdCamb','Pérdida cambiaria']];
const CTA_L={};CTAS.forEach(c=>CTA_L[c[0]]=c[1]);
const TASAS=[['ivaExp','IVA en ventas de exportación (%)'],['ivaNac','IVA en ventas nacionales (%)']];
const ctaOf=(e,k)=>{const x=CTB.d['cta|'+e+'|'+k];return x&&String(x.num||'').trim()?x:null};
const tasaOf=(e,k)=>{const x=CTB.d['tasa|'+e+'|'+k];return x?num(x.v):null};
function regList(){return Object.keys(CTB.d).filter(k=>k.indexOf('reg|')===0&&!CTB.d[k].borrado).map(k=>Object.assign({},CTB.d[k],{id:k.slice(4)})).sort((a,b)=>String(a.nombre||'').localeCompare(String(b.nombre||'')))}
function regOfProd(c){const x=c?CTB.d['pr|'+c]:null;if(!x||!x.reg)return null;const r=CTB.d['reg|'+x.reg];return r&&!r.borrado?Object.assign({},r,{id:x.reg}):null}
function ctbSet(k,f,v,lab){
  const cur=CTB.d[k]||{},old=cur[f];if(sv(old)===sv(v))return false;
  const nx=Object.assign({},cur);if(v==null||v==='')delete nx[f];else nx[f]=v;nx.ts=Date.now();nx.by=parBy();CTB.d[k]=nx;saveCtb();
  const e0=(/^(cta|tasa)\|(VL|EC)\|/.exec(k)||[])[2]||'VL';
  logAdd({k:'param',where:'Contabilidad',ctx:{t:'f',id:e0,cod:'Catálogo contable'},path:'ctb.'+k+'.'+f,lab:lab,o:sv(old),n:sv(v)});return true;
}
const ymOf=d=>String(d||'').slice(0,7);
const ymLab=ym=>{const p=String(ym).split('-');return p.length===2?MESES[+p[1]-1]+' '+p[0]:ym};
function ctbMonths(){const s=new Set([todayISO().slice(0,7)]);visible().forEach(o=>{if(o.fecha)s.add(ymOf(o.fecha))});COB.list.concat(PAG.list).forEach(x=>{if(x.fecha)s.add(ymOf(x.fecha))});return [...s].filter(k=>/^\d{4}-\d{2}$/.test(k)).sort().reverse()}
const ctbEs=E=>E==='ALL'||!E?['VL','EC']:[E];
const tcHoy=e=>+parsDe(e,curWk()).tc||0;
/* tipo de cambio con el que se registró la venta: el de la semana del pedido (el mismo de Utilidad) */
const tcReg=x=>+parsDe(x.emp,x.wk||wkOfDate(x.fecha)).tc||0;

/* pérdida o ganancia cambiaria: realizada en cada cobro (TC del cobro contra el de registro) y no realizada en lo pendiente (TC de hoy) */
function fxData(E,ym){
  const es=ctbEs(E),A=accData(E||'ALL'),reg=new Map();A.cxc.forEach(x=>reg.set(x.ref,x));
  const R=[],sin=[];
  COB.list.forEach(y=>{if(y.anulado||y.tipo!=='cobro'||es.indexOf(y.emp)<0||(ym&&ymOf(y.fecha)!==ym))return;const x=reg.get(y.ref);if(!x)return;const tr=tcReg(x);if(!(+y.tc>0)){sin.push({y:y,x:x});return}R.push({y:y,x:x,tcR:tr,tcC:+y.tc,usd:+y.monto,dif:(+y.monto)*(+y.tc-tr)})});
  const U=A.cxc.filter(x=>x.b).map(x=>{const tr=tcReg(x),th=tcHoy(x.emp);return {x:x,tcR:tr,tcH:th,usd:x.saldo,dif:x.saldo*(th-tr)}});
  return {R:R,U:U,sin:sin,real:R.reduce((s,a)=>s+a.dif,0),noReal:U.reduce((s,a)=>s+a.dif,0),usdAb:A.agc.tot};
}
/* descalce: lo que se tiene y se debe en dólares, y cuánto cambia con ±1 MXN por dólar */
function fxExpo(E,ym){
  const es=ctbEs(E),A=accData(E||'ALL'),L=visible().filter(o=>es.indexOf(o.emp)>=0&&ymOf(o.fecha)===ym),T=finAgg(L).T;
  let dem=0;const ps=new Set();L.forEach(o=>{const k=o.emp+'|'+o.cod;if(ps.has(k))return;ps.add(k);dem+=n0(biOf(o).demora)});
  const tc=es.reduce((s,e)=>s+tcHoy(e),0)/es.length;
  return {act:A.agc.tot,pas:0,net:A.agc.tot,ingUSD:T.ingUSD,demUSD:dem,flujo:T.ingUSD-dem,util:T.util,tc:tc,hojas:L.length};
}
/* impuestos estimados del mes: compras de fruta por productor con su régimen y ventas con las tasas de la empresa */
function taxData(E,ym){
  const es=ctbEs(E),pm=new Map();let sinReg=0;
  es.forEach(e=>accData(e).cxp.forEach(x=>{if((x.tipo!=='prod'&&x.tipo!=='jug')||ymOf(x.fecha)!==ym)return;const k=x.codigo?'c'+x.codigo:'n'+norm(x.nombre);let a=pm.get(k);if(!a){a={nombre:x.nombre,codigo:x.codigo,reg:regOfProd(x.codigo),base:0};pm.set(k,a)}a.base+=x.monto}));
  const P=[...pm.values()].map(a=>{const r=a.reg,t=f=>r&&num(r[f])!=null?num(r[f])/100:0;if(!r)sinReg++;const iva=a.base*t('iva'),isr=a.base*t('isr'),riva=a.base*t('ivaRet');return Object.assign(a,{iva:iva,isr:isr,riva:riva,neto:a.base+iva-isr-riva})}).sort((a,b)=>b.base-a.base);
  const V=es.map(e=>{const T=finAgg(visible().filter(o=>o.emp===e&&ymOf(o.fecha)===ym)).T,te=tasaOf(e,'ivaExp'),tn=tasaOf(e,'ivaNac');return {e:e,exp:T.ingExp,nac:T.ingNac,te:te,tn:tn,iva:T.ingExp*(te||0)/100+T.ingNac*(tn||0)/100}});
  const S=k=>P.reduce((s,a)=>s+a[k],0);
  return {P:P,V:V,sinReg:sinReg,base:S('base'),iva:S('iva'),isr:S('isr'),riva:S('riva'),ivaTras:V.reduce((s,v)=>s+v.iva,0),sinTasa:V.some(v=>v.te==null||v.tn==null)};
}
/* pólizas del mes: ventas, compras y notas (diario), cobros (ingreso) y pagos (egreso), en MXN */
function polizas(E,ym){
  const P=[],miss=new Set(),cnt={};
  for(const e of ctbEs(E)){
    const A=accData(e),cx=new Map();A.cxc.concat(A.cxj).forEach(x=>cx.set(x.ref,x));const cp=new Map();A.cxp.forEach(x=>cp.set(x.ref,x));
    const L=(k,c,a)=>{const ct=ctaOf(e,k);return {k:k,cta:ct?String(ct.num).trim():'',nom:ct&&ct.nombre?ct.nombre:CTA_L[k],c:r2(c||0),a:r2(a||0)}};
    const pol=(t,fecha,con,ref,lines)=>{lines=lines.filter(l=>Math.abs(l.c)>0.004||Math.abs(l.a)>0.004);if(!lines.length)return;lines.forEach(l=>{if(!l.cta)miss.add(e+'|'+l.k)});const ck=e+t;cnt[ck]=(cnt[ck]||0)+1;P.push({e:e,t:t,id:e+'-'+t+'-'+ym.replace('-','')+'-'+pad(cnt[ck],3),fecha:fecha,con:con,ref:ref,lines:lines})};
    const te=(tasaOf(e,'ivaExp')||0)/100,tn=(tasaOf(e,'ivaNac')||0)/100;
    A.cxc.forEach(x=>{const f=x.fFact||x.fecha;if(ymOf(f)!==ym)return;const m=x.monto*tcReg(x),iv=m*te;pol('D',f,'Venta '+x.lab+' · '+x.nombre+' · '+amt(x.monto,'USD')+' a '+money(tcReg(x),2)+' MXN/USD',x.ref,[L('clientes',m+iv,0),L('ventasExp',0,m),L('ivaTras',0,iv)])});
    const nac=finAgg(visible().filter(o=>o.emp===e&&ymOf(o.fecha)===ym)).T.ingNac;if(nac>0.005)pol('D',ym+'-'+pad(new Date(+ym.slice(0,4),+ym.slice(5,7),0).getDate(),2),'Ventas nacionales del mes (segundas, Torreón y Juguera)','',[L('clientes',nac*(1+tn),0),L('ventasNac',0,nac),L('ivaTras',0,nac*tn)]);
    A.cxp.forEach(x=>{if(ymOf(x.fecha)!==ym)return;
      if(x.tipo==='prod'||x.tipo==='jug'){const r=regOfProd(x.codigo),t=f=>r&&num(r[f])!=null?num(r[f])/100:0,iv=x.monto*t('iva'),is=x.monto*t('isr'),ri=x.monto*t('ivaRet');pol('D',x.fecha,(x.tipo==='jug'?'Fruta a Juguera · ':'Compra de fruta · ')+x.nombre+' · '+wkLab(x.wk)+(r?' · '+r.nombre:' · sin régimen'),x.ref,[L('costoFruta',x.monto,0),L('ivaAcred',iv,0),L('retIsr',0,is),L('retIva',0,ri),L('proveedores',0,x.monto+iv-is-ri)])}
      else pol('D',x.fecha,x.det+(x.real?' · flete real':''),x.ref,[L('fletes',x.monto,0),L('acreedores',0,x.monto)]);
    });
    COB.list.forEach(y=>{if(y.anulado||y.emp!==e||ymOf(y.fecha)!==ym||(y.tipo!=='cobro'&&y.tipo!=='nota'))return;
      if(String(y.ref).indexOf('cxj|')===0){const m=+y.monto;if(y.tipo==='nota')pol('D',y.fecha,'Descuento de la Juguera · '+(y.lab||'')+' · '+amt(m,'MXN'),y.ref,[L('devVentas',m,0),L('clientes',0,m)]);else pol('I',y.fecha,'Cobro a la Juguera · '+(y.lab||'')+' · '+amt(m,'MXN')+(y.refb?' · ref '+y.refb:''),y.ref,[L('bancos',m,0),L('clientes',0,m)]);return}
      const x=cx.get(y.ref),tr=x?tcReg(x):+parsDe(e,wkOfDate(y.fecha)).tc||0,base=(+y.monto)*tr;
      if(y.tipo==='nota'){pol('D',y.fecha,'Nota de crédito · '+(y.nombre||'')+' · '+(y.lab||'')+' · '+amt(+y.monto,'USD'),y.ref,[L('devVentas',base,0),L('clientes',0,base)]);return}
      const tc=+y.tc>0?+y.tc:tr,bk=(+y.monto)*tc,d=bk-base;pol('I',y.fecha,'Cobro · '+(y.nombre||'')+' · '+(y.lab||'')+' · '+amt(+y.monto,'USD')+' a '+money(tc,2)+(+y.tc>0?'':' (sin TC del cobro: se usa el de registro)'),y.ref,[L('bancos',bk,0),L('perdCamb',d<0?-d:0,0),L('clientes',0,base),L('utilCamb',0,d>0?d:0)])});
    PAG.list.forEach(y=>{if(y.anulado||y.emp!==e||ymOf(y.fecha)!==ym||(y.tipo!=='pago'&&y.tipo!=='ajuste'))return;const fl=String(y.ref).indexOf('cxp|flete|')===0,k=fl?'acreedores':'proveedores';
      if(y.tipo==='ajuste')pol('D',y.fecha,'Ajuste o descuento · '+(y.nombre||'')+' · '+(y.lab||''),y.ref,[L(k,+y.monto,0),L('descCompras',0,+y.monto)]);
      else pol('E',y.fecha,'Pago · '+(y.nombre||'')+' · '+(y.lab||'')+(y.refb?' · ref '+y.refb:''),y.ref,[L(k,+y.monto,0),L('bancos',0,+y.monto)]);
    });
  }
  P.sort((a,b)=>a.e.localeCompare(b.e)||String(a.fecha).localeCompare(String(b.fecha))||a.t.localeCompare(b.t));
  return {P:P,miss:[...miss],c:P.reduce((s,p)=>s+p.lines.reduce((t,l)=>t+l.c,0),0),a:P.reduce((s,p)=>s+p.lines.reduce((t,l)=>t+l.a,0),0)};
}
/* hoja de cierre mensual */
function cierreData(E,ym){
  const es=ctbEs(E),L=visible().filter(o=>es.indexOf(o.emp)>=0&&ymOf(o.fecha)===ym),T=finAgg(L).T,fijo=es.reduce((s,e)=>s+fijoMes(e,ym),0),fx=fxData(E,ym),tx=taxData(E,ym),po=polizas(E,ym);
  const inE=x=>es.indexOf(x.emp)>=0&&!x.anulado&&ymOf(x.fecha)===ym;
  const usdM=x=>String(x.ref).indexOf('cxj|')!==0,cobJ=COB.list.filter(x=>inE(x)&&x.tipo==='cobro'&&!usdM(x)).reduce((s,x)=>s+(+x.monto||0),0);
  const cobU=COB.list.filter(x=>inE(x)&&x.tipo==='cobro'&&usdM(x)).reduce((s,x)=>s+(+x.monto||0),0),notU=COB.list.filter(x=>inE(x)&&x.tipo==='nota'&&usdM(x)).reduce((s,x)=>s+(+x.monto||0),0),pag=PAG.list.filter(x=>inE(x)&&x.tipo==='pago').reduce((s,x)=>s+(+x.monto||0),0);
  const wks=[...new Set(L.map(wkOf).filter(Boolean))].sort(),abiertas=wks.filter(k=>!wkClosed(k));
  const A=accData(E||'ALL'),sinFact=A.cxc.filter(x=>ymOf(x.fecha)===ym&&x.fact==null).length;
  const chk=[[!abiertas.length,abiertas.length?'Semanas sin cerrar: '+abiertas.map(k=>wkLab(k,true)).join(', '):'Todas las semanas del mes están cerradas'],
    [!sinFact,sinFact?sinFact+(sinFact===1?' venta sin factura registrada':' ventas sin factura registrada'):'Todas las ventas del mes tienen factura'],
    [!fx.sin.length,fx.sin.length?fx.sin.length+(fx.sin.length===1?' cobro sin tipo de cambio':' cobros sin tipo de cambio'):'Todos los cobros tienen tipo de cambio'],
    [!tx.sinReg,tx.sinReg?tx.sinReg+(tx.sinReg===1?' productor sin régimen fiscal':' productores sin régimen fiscal'):'Todos los productores del mes tienen régimen'],
    [!po.miss.length,po.miss.length?po.miss.length+(po.miss.length===1?' cuenta contable sin capturar':' cuentas contables sin capturar'):'Catálogo de cuentas completo'],
    [!tx.sinTasa,tx.sinTasa?'Faltan tasas de IVA en ventas':'Tasas de IVA en ventas capturadas'],
    [!FIN.ejemplo,FIN.ejemplo?'Precios y costos de ejemplo':'Precios y costos reales']];
  return {ym:ym,T:T,fijo:fijo,util:T.util-fijo,fx:fx,tx:tx,po:po,cobU:cobU,cobJ:cobJ,notU:notU,pag:pag,wks:wks,chk:chk,hojas:L.length,cxc:A.agc.tot,cxj:A.agj.tot,cxp:A.agp.tot};
}

/* ----- vista: pestaña Contabilidad ----- */
const CSUB=[['cie','Cierre mensual'],['fx','Tipo de cambio'],['imp','Impuestos'],['pol','Pólizas'],['cat','Catálogos']];
const AVAL='<span class="chip warn">A validar con el contador</span>';
function ctbView(){
  const f=statsF,E=f.emp||'ALL',sub=CSUB.some(x=>x[0]===f.csub)?f.csub:'cie',ms=ctbMonths(),ym=ms.indexOf(f.cym)>=0?f.cym:ms[0];f.cym=ym;
  const subs=`<div class="srt csub">${CSUB.map(x=>`<button class="btn sm" data-act="csub:${x[0]}" aria-pressed="${sub===x[0]}">${x[1]}</button>`).join('')}</div>`;
  const msel=sub==='cat'?'':`<div class="presel"><label class="fld" for="ctb-ym"><span>Mes</span><select class="in sel" id="ctb-ym" data-cym="1">${ms.map(k=>`<option value="${k}"${k===ym?' selected':''}>${esc(ymLab(k))}</option>`).join('')}</select></label></div>`;
  const body=sub==='fx'?fxHtml(E,ym):sub==='imp'?impHtml(E,ym):sub==='pol'?polHtml(E,ym):sub==='cat'?catHtml(E):cieHtml(E,ym);
  return subs+msel+body;
}
function fxHtml(E,ym){
  const X=fxData(E,ym),Z=fxExpo(E,ym),sg=v=>(v>0.005?'+':'')+mxn(v);
  const tiles=tileHtml('Cambiaria realizada · '+ymLab(ym),sg(X.real),X.R.length+(X.R.length===1?' cobro':' cobros')+' con tipo de cambio'+(X.sin.length?' · '+X.sin.length+' sin TC':''),null,X.real<-0.005?'warnt':'')
   +tileHtml('Cambiaria no realizada · hoy',sg(X.noReal),'pendiente por cobrar '+amt(X.usdAb,'USD',0)+' al TC de hoy',null,X.noReal<-0.005?'warnt':'');
  const rr=X.R.slice().sort((a,b)=>String(b.y.fecha).localeCompare(String(a.y.fecha))).slice(0,30).map(a=>`<tr><th scope="row">${esc(a.x.nombre)}<small>${esc(a.x.lab)} · ${esc(fmtDate(a.y.fecha))}</small></th><td>${amt(a.usd,'USD',0)}</td><td>${money(a.tcR,2)} → ${money(a.tcC,2)}</td><td class="${a.dif>0.005?'gv':a.dif<-0.005?'bv':''}">${sg(a.dif)}</td></tr>`).join('');
  const sens=[-1,0,1].map(d=>{const tc=Z.tc+d;return `<tr${d===0?' class="tot"':''}><th scope="row">${money(tc,2)} MXN/USD${d?'':'<small>tipo de cambio de hoy</small>'}</th><td>${mxn(Z.net*tc,0)}</td><td>${mxn(Z.util+d*Z.flujo,0)}${d?'<small>'+(d>0?'+':'−')+mxn(Math.abs(Z.flujo),0)+'</small>':''}</td></tr>`}).join('');
  return `<div class="tiles">${tiles}</div>
<div class="sec">Cobros del mes</div>${rr?`<div class="tblx"><table class="ctab phist"><thead><tr><th>Cliente</th><th>Cobrado</th><th>TC registro → cobro</th><th>Diferencia MXN</th></tr></thead><tbody>${rr}</tbody></table></div>`:'<p class="note">Sin cobros con tipo de cambio en el mes.</p>'}
${X.sin.length?`<p class="note">${X.sin.length} ${X.sin.length===1?'cobro no tiene':'cobros no tienen'} tipo de cambio: no entran en la cambiaria. Captúralo al registrar el cobro.</p>`:''}
<div class="sec">Descalce de monedas y sensibilidad</div>
<div class="ig tot wkg abs"><div><span>En dólares a favor</span><b>${amt(Z.act,'USD',0)}</b><small>por cobrar a clientes</small></div><div><span>En dólares en contra</span><b>${amt(Z.pas,'USD',0)}</b><small>la app no registra deudas en USD</small></div><div><span>Posición neta</span><b>${amt(Z.net,'USD',0)}</b><small>larga en dólares</small></div></div>
<div class="tblx" style="margin-top:8px"><table class="ctab phist"><thead><tr><th>Tipo de cambio</th><th>Por cobrar<small>valuado en MXN</small></th><th>Utilidad<small>${esc(ymLab(ym))}</small></th></tr></thead><tbody>${sens}</tbody></table></div>
<p class="note" style="margin-top:6px">Por cada peso que sube el dólar, lo por cobrar vale ${mxn(Z.net,0)} más y la utilidad de ${esc(ymLab(ym))} sube ${mxn(Z.flujo,0)} (ventas de ${amt(Z.ingUSD,'USD',0)}${Z.demUSD?' menos demoras de '+amt(Z.demUSD,'USD',0):''}); si baja, es al revés. Los costos van en pesos. Es aproximado: no ajusta el pago de fruta en consignación. La cambiaria realizada compara el tipo de cambio del cobro contra el de la semana del pedido (el mismo con el que se calcula la utilidad); la no realizada usa el tipo de cambio de hoy de Precios y costos.</p>`;
}
function impHtml(E,ym){
  const X=taxData(E,ym),regs=regList();
  const rows=X.P.map(a=>`<tr><th scope="row">${esc(a.nombre)}<small>${a.reg?esc(a.reg.nombre||'Régimen'):'<b class="negv">sin régimen</b>'}</small></th><td>${money(a.base)}</td><td>${money(a.iva)}</td><td>${money(a.isr+a.riva)}</td><td><b>${money(a.neto)}</b></td></tr>`).join('')+(X.P.length>1?`<tr class="tot"><th scope="row">Total</th><td>${money(X.base)}</td><td>${money(X.iva)}</td><td>${money(X.isr+X.riva)}</td><td><b>${money(X.P.reduce((s,a)=>s+a.neto,0))}</b></td></tr>`:'');
  const ven=X.V.map(v=>`<div class="kv"><span>${esc(EMPS[v.e].name)}<br><small class="note">exportación ${mxn(v.exp)} a ${v.te==null?'sin tasa':fmt(v.te,2)+' %'} · nacional ${mxn(v.nac)} a ${v.tn==null?'sin tasa':fmt(v.tn,2)+' %'}</small></span><b>${mxn(v.iva)}</b></div>`).join('');
  return `<div class="warnbox" role="note"><strong>Estimado ${AVAL}</strong><div>Las tasas y regímenes los define el contador en Catálogos. Sin ellos, los impuestos salen en cero.${regs.length?'':' Todavía no hay regímenes capturados.'}</div></div>
<div class="tiles" style="margin-top:10px">${tileHtml('Compras de fruta',mxn(X.base),ymLab(ym)+' · '+X.P.length+(X.P.length===1?' productor':' productores'))}${tileHtml('IVA acreditable',mxn(X.iva),'de las compras de fruta')}${tileHtml('Retenciones',mxn(X.isr+X.riva),'ISR '+mxn(X.isr)+' · IVA '+mxn(X.riva))}${tileHtml('IVA trasladado',mxn(X.ivaTras),X.sinTasa?'faltan tasas de IVA en ventas':'en ventas del mes')}</div>
<div class="sec">Por productor</div>${rows?`<div class="tblx"><table class="ctab phist"><thead><tr><th>Productor</th><th>Compra MXN</th><th>IVA MXN</th><th>Retenciones MXN</th><th>Neto MXN</th></tr></thead><tbody>${rows}</tbody></table></div>`:'<p class="note">Sin compras de fruta en el mes.</p>'}
${X.sinReg?`<p class="note">${X.sinReg} ${X.sinReg===1?'productor no tiene':'productores no tienen'} régimen: se asigna en Catálogos.</p>`:''}
<div class="sec">IVA en ventas</div><div class="panel">${ven}</div>
<p class="note" style="margin-top:6px">Neto = compra + IVA − retenciones. Es una estimación para planear y para las pólizas; no cambia lo que se ve en Por pagar ni sustituye la declaración. La compra de cada semana cuenta en el mes en que termina la semana.</p>`;
}
function polHtml(E,ym){
  const X=polizas(E,ym),T={D:'Diario',I:'Ingreso',E:'Egreso'};
  const miss=X.miss.length?`<div class="warnbox" role="alert"><strong>Faltan ${X.miss.length} ${X.miss.length===1?'cuenta contable':'cuentas contables'}</strong><div>${esc(X.miss.map(k=>{const q=k.split('|');return EMPS[q[0]].name+': '+CTA_L[q[1]]}).join(' · '))}. La exportación las marca como «SIN CUENTA». ${isAdmin()?'Captúralas en Catálogos.':'El administrador las captura en Catálogos.'}</div></div>`:'';
  const cards=X.P.slice(0,statsF.polN||40).map(p=>`<details class="prd pol"><summary><div class="r1"><div class="pnm">${esc(T[p.t])} ${esc(p.id)}<small>${esc(fmtDate(p.fecha))} · ${esc(p.con)}</small></div><div class="rend">${money(p.lines.reduce((s,l)=>s+l.c,0),2)}<em class="cur">MXN</em></div></div></summary>
<div class="tblx"><table class="ctab phist"><thead><tr><th>Cuenta</th><th>Cargo MXN</th><th>Abono MXN</th></tr></thead><tbody>${p.lines.map(l=>`<tr><th scope="row">${l.cta?esc(l.cta):'<b class="negv">SIN CUENTA</b>'}<small>${esc(l.nom)}</small></th><td>${l.c?money(l.c,2):''}</td><td>${l.a?money(l.a,2):''}</td></tr>`).join('')}</tbody></table></div></details>`).join('');
  return `${miss}<div class="tiles" style="margin-top:10px">${tileHtml('Pólizas de '+ymLab(ym),fmt(X.P.length),['D','I','E'].map(t=>X.P.filter(p=>p.t===t).length+' de '+T[t].toLowerCase()).join(' · '))}${tileHtml('Cargos = abonos',money(X.c,2)+'<em class="cur">MXN</em>',Math.abs(X.c-X.a)<0.05?'cuadran':'diferencia '+money(X.c-X.a,2),null,Math.abs(X.c-X.a)<0.05?'':'warnt')}</div>
<div class="srt"><button class="btn sm primary" data-act="ctbx:pol">${X.miss.length?'Descargar pólizas de todos modos':'Descargar pólizas (Excel)'}</button></div>
${X.P.length?`<div class="cgrid">${cards}</div>${X.P.length>(statsF.polN||40)?'<button class="btn sm" data-act="polmore">Ver más</button>':''}`:'<p class="note">Sin movimientos en el mes.</p>'}
<p class="note" style="margin-top:8px">Diario: ventas (con la factura si existe, al tipo de cambio de la semana del pedido), ventas nacionales, compras de fruta con IVA y retenciones de su régimen, fletes, notas de crédito y ajustes. Ingreso: cada cobro a su tipo de cambio, con la diferencia a utilidad o pérdida cambiaria. Egreso: cada pago. Todo en MXN. ${AVAL}</p>`;
}
function catHtml(E){
  const ed=isAdmin(),e=E==='ALL'?(statsF.cate||'VL'):E,dis=ed?'':' readonly',sel=ed?'':' disabled';
  const ti=(k,v,lab,ph)=>`<input class="in txt" aria-label="${esc(lab)}" data-ctb="${esc(k)}" value="${v==null?'':esc(v)}"${ph?` placeholder="${esc(ph)}"`:''}${dis}>`;
  const ctas=CTAS.map(c=>{const x=CTB.d['cta|'+e+'|'+c[0]]||{};return `<span class="fl">${c[1]}</span>${ti('cta|'+e+'|'+c[0]+'|num',x.num,'Número de cuenta '+c[1],'—')}${ti('cta|'+e+'|'+c[0]+'|nombre',x.nombre,'Nombre en tu catálogo '+c[1],c[1])}`}).join('');
  const tasas=TASAS.map(t=>{const x=CTB.d['tasa|'+e+'|'+t[0]]||{};return `<label class="fld"><span>${t[1]}</span>${ti('tasa|'+e+'|'+t[0]+'|v',x.v,t[1],'sin capturar')}</label>`}).join('');
  const regs=regList();
  const regH=regs.map(r=>`<div class="prw"><div class="grid4">${['nombre','iva','isr','ivaRet'].map(f=>`<label class="fld"><span>${{nombre:'Régimen',iva:'IVA en compra (%)',isr:'Retención ISR (%)',ivaRet:'Retención IVA (%)'}[f]}</span>${ti('reg|'+r.id+'|'+f,r[f],f,f==='nombre'?'nombre':'—')}</label>`).join('')}</div>${ed?`<div class="pact"><button class="btn sm danger" data-act="ctbregx:${esc(r.id)}">Quitar</button></div>`:''}</div>`).join('');
  const A=accData('ALL'),seen=new Map();A.cxp.forEach(x=>{if(x.tipo==='prod'&&x.codigo&&!seen.has(x.codigo))seen.set(x.codigo,x.nombre)});
  Object.keys(CTB.d).forEach(k=>{if(k.indexOf('pr|')===0){const c=+k.slice(3),li=LISTA.find(y=>y.c===c);if(!seen.has(c))seen.set(c,li?li.n:'#'+c)}});
  if(statsF.prAll)LISTA.forEach(li=>{if(!seen.has(li.c))seen.set(li.c,li.n)});
  const prs=[...seen.entries()].sort((a,b)=>a[0]-b[0]).map(([c,n])=>{const cur=(CTB.d['pr|'+c]||{}).reg||'';return `<div class="kv"><span>#${pad(c,3)} ${esc(n)}</span><select class="in sel prsel" aria-label="Régimen de ${esc(n)}" data-ctb="pr|${c}|reg"${sel}><option value="">Sin régimen</option>${regs.map(r=>`<option value="${esc(r.id)}"${cur===r.id?' selected':''}>${esc(r.nombre||'Régimen sin nombre')}</option>`).join('')}</select></div>`}).join('');
  return `<div class="warnbox" role="note"><strong>Lo define tu contador ${AVAL}</strong><div>Nada viene capturado: la app no supone cuentas, tasas ni regímenes. ${ed?'Lo capturas como administrador; cada cambio queda en la bitácora contable.':'Solo el administrador lo captura.'}</div></div>
${E==='ALL'?`<div class="srt" style="margin-top:10px">${['VL','EC'].map(k=>`<button class="btn sm" data-act="cate:${k}" aria-pressed="${e===k}">${EMPS[k].name}</button>`).join('')}</div>`:''}
<div class="sec">Cuentas contables · ${esc(EMPS[e].name)}</div><div class="fingrid ctag"><span></span><span class="fh">Número</span><span class="fh">Nombre en tu catálogo</span>${ctas}</div>
<div class="sec">IVA en ventas · ${esc(EMPS[e].name)}</div><div class="grid2">${tasas}</div>
<div class="sec">Regímenes fiscales de productores</div>${regH||'<p class="note">Sin regímenes.</p>'}${ed?'<div class="pact"><button class="btn sm" data-act="ctbreg">Agregar régimen</button></div>':''}
<div class="sec">Régimen de cada productor</div><div class="panel">${prs||'<p class="note">Sin productores con compras.</p>'}</div><div class="srt"><button class="btn sm" data-act="prall" aria-pressed="${!!statsF.prAll}">${statsF.prAll?'Solo productores con compras':'Ver toda la lista de productores'}</button></div>`;
}
function cieHtml(E,ym){
  const C=cierreData(E,ym),T=C.T,ok=C.chk.filter(c=>c[0]).length;
  const row=(l,v,sub,cls)=>`<div class="kv${cls?' '+cls:''}"><span>${l}${sub?`<br><small class="note">${sub}</small>`:''}</span><b class="${v<0?'negv':''}">${mxn(v)}</b></div>`;
  return `<div class="tiles">${tileHtml('Utilidad después de fijos',money(C.util+C.fx.real)+'<em class="cur">MXN</em>','con cambiaria realizada · '+ymLab(ym),null,C.util+C.fx.real<0?'warnt':'')}${tileHtml('Lista de cierre',ok+' de '+C.chk.length,ok===C.chk.length?'todo listo':'revisa los pendientes',null,ok===C.chk.length?'':'warnt')}</div>
<div class="dsk fin2"><div class="dcol"><div class="sec">Resultado de ${esc(ymLab(ym))}</div><div class="panel">${row('Ingresos',T.ing,'exportación '+amt(T.ingUSD,'USD',0)+' · nacional '+mxn(T.ingNac)+(T.ingJug?' (Juguera '+mxn(T.ingJug)+')':''))}${row('Costos directos',-T.cost,'fruta, material, mano de obra y flete')}${row('Utilidad bruta',T.util,'margen '+pctTxt(T.margen),'tot')}${row('Costos fijos',-C.fijo,'de Precios y costos, llevados a mes')}${row('Cambiaria realizada',C.fx.real)}${row('Resultado del mes',C.util+C.fx.real,'',  'tot')}</div>
<div class="sec">Cuentas</div><div class="panel"><div class="kv"><span>Cobrado en el mes</span><b>${amt(C.cobU,'USD')}</b></div>${C.cobJ||C.cxj?`<div class="kv"><span>Cobrado a la Juguera en el mes</span><b>${amt(C.cobJ,'MXN')}</b></div>`:''}<div class="kv"><span>Notas de crédito del mes</span><b>${amt(C.notU,'USD')}</b></div><div class="kv"><span>Pagado en el mes</span><b>${amt(C.pag,'MXN')}</b></div><div class="kv"><span>Por cobrar hoy</span><b>${amt(C.cxc,'USD')}</b></div>${C.cxj?`<div class="kv"><span>Por cobrar a la Juguera hoy</span><b>${amt(C.cxj,'MXN')}</b></div>`:''}<div class="kv"><span>Por pagar hoy</span><b>${amt(C.cxp,'MXN')}</b></div></div></div>
<div class="dcol"><div class="sec">Lista de cierre</div><div class="panel">${C.chk.map(c=>`<div class="kv"><span>${esc(c[1])}</span><span class="chip ${c[0]?'good':'warn'}">${c[0]?'Listo':'Pendiente'}</span></div>`).join('')}</div>
<div class="sec">Impuestos estimados</div><div class="panel"><div class="kv"><span>IVA acreditable (compras de fruta)</span><b>${mxn(C.tx.iva)}</b></div><div class="kv"><span>IVA trasladado (ventas)</span><b>${mxn(C.tx.ivaTras)}</b></div><div class="kv"><span>Retenciones por enterar</span><b>${mxn(C.tx.isr+C.tx.riva)}</b></div><p class="note">${AVAL}</p></div>
<div class="sec">Pólizas</div><div class="panel"><div class="kv"><span>${fmt(C.po.P.length)} pólizas del mes</span><b>${money(C.po.c,2)} MXN</b></div>${C.po.miss.length?`<p class="note">Faltan ${C.po.miss.length} cuentas contables.</p>`:''}</div></div></div>
<div class="srt"><button class="btn primary" data-act="ctbx:cie">Descargar cierre mensual (Excel)</button></div>
<p class="note" style="margin-top:6px">El Excel trae las hojas Cierre mensual, Pólizas, Impuestos y Cambiaria. Las cifras salen de lo capturado en la app con los precios y costos de cada semana; no sustituyen la contabilidad oficial.</p>`;
}
async function exportCtb(kind){
  if(typeof ExcelJS==='undefined'){toast('La descarga en Excel no está disponible aquí');return}
  try{
    const f=statsF,E=f.emp||'ALL',ym=f.cym||todayISO().slice(0,7),wb=newWb(),M='#,##0.00';
    const add=(name,cols,rows)=>{const ws=wb.addWorksheet(name,{views:[{state:'frozen',ySplit:1}]});ws.columns=cols.map(c=>({header:c[1],key:c[0],width:c[2]||14,style:c[3]?{numFmt:c[3]}:{}}));ws.getRow(1).font={bold:true};rows.forEach(r=>ws.addRow(r));return ws};
    const X=polizas(E,ym),TT={D:'Diario',I:'Ingreso',E:'Egreso'};
    if(kind==='cie'){
      const C=cierreData(E,ym),T=C.T;
      add('Cierre mensual',[['k','Concepto',44],['v','Monto',18,M],['u','Divisa',8],['n','Nota',60]],[
        {k:'Mes',v:null,u:'',n:ymLab(ym)+' · '+(E==='ALL'?'ambas empresas':EMPS[E].name)},
        {k:'Ventas de exportación',v:r2(T.ingUSD),u:'USD',n:'a los tipos de cambio de cada semana'},{k:'Ingresos',v:r2(T.ing),u:'MXN'},{k:'Costos directos',v:r2(T.cost),u:'MXN'},{k:'Utilidad bruta',v:r2(T.util),u:'MXN'},
        {k:'Costos fijos',v:r2(C.fijo),u:'MXN',n:'de Precios y costos, llevados a mes'},{k:'Cambiaria realizada',v:r2(C.fx.real),u:'MXN'},{k:'Resultado del mes',v:r2(C.util+C.fx.real),u:'MXN'},
        {k:'Cambiaria no realizada (hoy)',v:r2(C.fx.noReal),u:'MXN',n:'informativa'},{k:'Cobrado en el mes',v:r2(C.cobU),u:'USD'},{k:'Notas de crédito del mes',v:r2(C.notU),u:'USD'},{k:'Pagado en el mes',v:r2(C.pag),u:'MXN'},
        {k:'Por cobrar hoy',v:r2(C.cxc),u:'USD'},{k:'Por pagar hoy',v:r2(C.cxp),u:'MXN'},{k:'IVA acreditable estimado',v:r2(C.tx.iva),u:'MXN',n:'a validar con el contador'},{k:'IVA trasladado estimado',v:r2(C.tx.ivaTras),u:'MXN',n:'a validar con el contador'},{k:'Retenciones estimadas',v:r2(C.tx.isr+C.tx.riva),u:'MXN',n:'a validar con el contador'}]
        .concat([{k:'',v:null,u:'',n:''},{k:'Lista de cierre',v:null,u:'',n:''}],C.chk.map(c=>({k:c[1],v:null,u:'',n:c[0]?'Listo':'Pendiente'}))));
      const tx=C.tx;add('Impuestos',[['p','Productor',30],['r','Régimen',24],['b','Compra MXN',14,M],['i','IVA MXN',12,M],['s','Ret. ISR MXN',12,M],['ri','Ret. IVA MXN',12,M],['n','Neto MXN',14,M]],tx.P.map(a=>({p:a.nombre,r:a.reg?a.reg.nombre||'':'SIN RÉGIMEN',b:r2(a.base),i:r2(a.iva),s:r2(a.isr),ri:r2(a.riva),n:r2(a.neto)})));
      add('Cambiaria',[['f','Fecha',12],['c','Cliente',26],['d','Cuenta',22],['u','Cobrado USD',13,M],['tr','TC registro',11,M],['tc','TC cobro',11,M],['dif','Diferencia MXN',14,M]],C.fx.R.map(a=>({f:a.y.fecha,c:a.x.nombre,d:a.x.lab,u:a.usd,tr:a.tcR,tc:a.tcC,dif:r2(a.dif)})));
    }
    const rows=[];X.P.forEach(p=>p.lines.forEach(l=>rows.push({e:p.e,id:p.id,t:TT[p.t],f:p.fecha,con:p.con,cta:l.cta||'SIN CUENTA',nom:l.nom,c:l.c||null,a:l.a||null,ref:p.ref||''})));
    add('Pólizas',[['e','Empresa',9],['id','Póliza',20],['t','Tipo',10],['f','Fecha',12],['con','Concepto',60],['cta','Cuenta',16],['nom','Nombre de la cuenta',30],['c','Cargo MXN',15,M],['a','Abono MXN',15,M],['ref','Referencia',34]],rows);
    if(X.miss.length){const w=add('Avisos',[['m','Aviso',100]],[{m:'Faltan cuentas contables: '+X.miss.map(k=>{const q=k.split('|');return EMPS[q[0]].name+': '+CTA_L[q[1]]}).join('; ')},{m:'Las líneas sin cuenta dicen «SIN CUENTA». Captura las cuentas en Finanzas › Contabilidad › Catálogos.'}]);w.getRow(2).font={bold:true,color:{argb:'FFB3261E'}}}
    if(X.miss.length)toast('Ojo: faltan '+X.miss.length+' cuentas contables; van como «SIN CUENTA»');
    await saveFile((kind==='cie'?'Cierre_':'Polizas_')+E+'_'+ym+'.xlsx',await wbBlob(wb));
  }catch(e){toast('No se pudo generar el archivo')}
}
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset)return;
  if(t.dataset.cym){statsF.cym=t.value;render();return}
  if(!t.dataset.ctb||!isAdmin())return;
  const q=t.dataset.ctb.split('|'),fk=q.pop(),key=q.join('|'),raw=String(t.value||'').trim();
  const isNum=q[0]==='tasa'||(q[0]==='reg'&&fk!=='nombre'),v=isNum?num(raw.replace(',','.')):(raw||null);
  if(isNum&&raw&&v==null){toast('Escribe un número');return}
  const lab=q[0]==='cta'?'Cuenta contable · '+EMPS[q[1]].name+' · '+CTA_L[q[2]]+' · '+(fk==='num'?'número':'nombre'):q[0]==='tasa'?((TASAS.find(x=>x[0]===q[2])||[])[1]||q[2])+' · '+EMPS[q[1]].name:q[0]==='reg'?'Régimen fiscal · '+((CTB.d[key]||{}).nombre||'nuevo')+' · '+fk:'Régimen del productor #'+pad(+q[1],3);
  if(ctbSet(key,fk,v,lab))render();
});


/* ---------- v8.4.1 · seguridad móvil: huella, gesto de regresar y cierre por inactividad ---------- */
const APP_VER='8.26.4';
const BIO_SRV='mx.registro.empaque',LS_BIO='empaque-huella',LS_BIONO='empaque-huella-no',LS_ULT='empaque-ultimo-uso';
const SEG_MIN=30;      /* minutos fuera de la app antes de cerrar la sesión */
const SEG_DBL=800;     /* milisegundos entre dos gestos de regresar para salir de la app */
let segSkew=0,segBackT=0,segBackW=SEG_DBL,segWebOff=false,segHideT=null,segAutoBio=false;
const segNow=()=>Date.now()+segSkew;
/* los plugins nativos solo existen dentro del APK; en el navegador la huella no se ofrece */
function segPlug(n){
  if(window.EMP_FAKE&&window.EMP_FAKE[n])return window.EMP_FAKE[n];
  const C=window.Capacitor;
  if(C&&C.isNativePlatform&&C.isNativePlatform()&&C.Plugins&&C.Plugins[n])return C.Plugins[n];
  return null;
}
function segMobile(){
  if(window.EMP_FAKE)return true;
  const C=window.Capacitor;if(C&&C.isNativePlatform&&C.isNativePlatform())return true;
  try{return matchMedia('(pointer:coarse)').matches&&/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)}catch(e){return false}
}

/* ----- huella ----- */
const FP_ICO='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 10a8.5 8.5 0 0 1 17 0"/><path d="M5.5 13a6.5 6.5 0 0 1 13 0c0 3-.5 5.4-1.8 7.6"/><path d="M8.5 15c.3-1 .5-2.2.5-3.5a3 3 0 0 1 6 0c0 2.4-.5 4.6-1.5 6.5"/><path d="M12 11.5v3c0 2-.6 3.8-1.6 5.3"/></svg>';
function bioMeta(){try{return JSON.parse(localStorage.getItem(LS_BIO)||'null')}catch(e){return null}}
function bioMode(){return cfgOK()?'sb':'loc'}
function bioLinked(){const m=bioMeta();return !!(m&&m.mode===bioMode()&&segPlug('NativeBiometric'))}
async function bioAvail(){
  const B=segPlug('NativeBiometric');if(!B)return false;
  try{const r=await B.isAvailable();return !!(r&&r.isAvailable)}catch(e){return false}
}
function bioErr(e,def){
  const m=String((e&&(e.message||e.code))||'').toLowerCase();
  if(/cancel|user_cancel|negative|10$|13$/.test(m))return 'Cancelaste la verificación de la huella.';
  if(/lock|too many|7$|9$/.test(m))return 'Demasiados intentos con la huella. Espera un momento o usa tu contraseña.';
  return def;
}
function bioBtn(){return bioLinked()?`<button class="btn bio" style="width:100%;margin-top:8px" data-act="lgbio"${lg.busy?' disabled':''}>${FP_ICO}<span>Entrar con huella</span></button>`:''}
async function bioLink(user,pw){
  const B=segPlug('NativeBiometric');
  await B.verifyIdentity({reason:'Vincular tu huella',title:'Vincular huella',subtitle:APP_NAME,description:'Toca el sensor para confirmar que eres tú',maxAttempts:3,useFallback:false});
  await B.setCredentials({username:user,password:pw,server:BIO_SRV});
  try{localStorage.setItem(LS_BIO,JSON.stringify({u:user,mode:bioMode(),t:Date.now()}));localStorage.removeItem(LS_BIONO)}catch(e){}
}
async function bioUnlink(){
  const B=segPlug('NativeBiometric');
  try{if(B)await B.deleteCredentials({server:BIO_SRV})}catch(e){}
  try{localStorage.removeItem(LS_BIO)}catch(e){}
}
async function bioSync(user,pw){
  const m=bioMeta(),B=segPlug('NativeBiometric');
  if(!B||!m||m.mode!=='loc'||unorm(m.u)!==unorm(user))return;
  try{await B.setCredentials({username:m.u,password:pw,server:BIO_SRV})}catch(e){}
}
/* después de entrar con contraseña, ofrece vincular la huella (una vez por usuario) */
async function bioOffer(user,pw){
  try{
    if(!segPlug('NativeBiometric'))return;
    const m=bioMeta();
    if(m&&m.mode===bioMode()&&unorm(m.u)===unorm(user))return;
    if(localStorage.getItem(LS_BIONO)===unorm(user))return;
    if(!await bioAvail())return;
    if(!authUser||sheet)return;
    sheet={kind:'bio',u:user,p:pw,err:''};renderSheet();
  }catch(e){}
}
function bioHtml(){
  const S=sheet,need=!!S.needPw;
  return `<h3>Entrar con huella</h3><p class="note" style="margin-bottom:10px">${need?'Escribe tu contraseña una sola vez y confirma con tu huella. Después entrarás con solo tocar el sensor.':'Vincula tu huella para entrar sin escribir la contraseña. Los datos se guardan cifrados en este teléfono y tu contraseña sigue funcionando.'}</p>
${need?`<label class="fld" for="bio-p"><span>Contraseña</span>${PWI(`<input class="in txt" id="bio-p" type="password" autocomplete="current-password">`)}</label>`:''}
${S.err?`<p class="note" style="color:var(--crit);margin-bottom:8px" role="alert">${esc(S.err)}</p>`:''}
<div class="srow2"><button class="btn" data-act="biono">${need?'Cancelar':'Ahora no'}</button><button class="btn primary" data-act="bioyes"${S.busy?' disabled':''}>${S.busy?'Esperando la huella…':'Vincular huella'}</button></div>`;
}
function bioAcctHtml(){
  if(!segPlug('NativeBiometric')||!authUser)return '';
  const m=bioMeta(),linked=!!(m&&m.mode===bioMode()&&unorm(m.u)===unorm(authUser.user));
  return `<div class="sec">Huella digital</div><p class="note" style="margin-bottom:8px">${linked?'Tu huella está vinculada: puedes entrar sin escribir la contraseña.':'Vincula tu huella para entrar sin escribir la contraseña.'}</p><div class="srow2">${linked?'<button class="btn" data-act="biodel">Quitar huella</button>':'<button class="btn" data-act="bioopen">Vincular huella</button>'}</div>`;
}
function bioOpen(){if(!authUser)return;sheet={kind:'bio',u:authUser.user,p:'',needPw:true,err:''};renderSheet()}
async function bioDel(){await bioUnlink();if(sheet&&sheet.kind==='acct')renderSheet();toast('Huella quitada')}
function bioNo(){
  if(sheet&&sheet.kind==='bio'&&!sheet.needPw){try{localStorage.setItem(LS_BIONO,unorm(sheet.u))}catch(e){}}
  sheet=null;renderSheet();
}
async function bioCheckPw(user,pw){
  if(cfgOK()){
    try{await sb('/auth/v1/token?grant_type=password',{method:'POST',body:{email:user,password:pw},auth:false});return true}
    catch(e){if(e&&e.status>=400&&e.status<500)return false;throw e}
  }
  const x=USERS.find(y=>authUser&&y.id===authUser.id);
  return !!(x&&x.hash===await hashPw(pw,x.salt));
}
async function bioYes(){
  const S=sheet;if(!S||S.kind!=='bio'||S.busy)return;
  if(S.needPw){
    const pw=gv('bio-p');
    if(!pw){S.err='Escribe tu contraseña.';renderSheet();return}
    S.busy=true;S.err='';renderSheet();
    let ok=false;
    try{ok=await bioCheckPw(S.u,pw)}catch(e){if(sheet===S){S.busy=false;S.err='No se pudo conectar. Revisa tu internet e inténtalo otra vez.';renderSheet()}return}
    if(sheet!==S)return;
    if(!ok){S.busy=false;S.err='La contraseña no es correcta.';renderSheet();return}
    S.p=pw;S.needPw=false;
  }
  S.busy=true;S.err='';renderSheet();
  try{await bioLink(S.u,S.p);if(sheet===S){sheet=null;renderSheet()}render();toast('Huella vinculada')}
  catch(e){if(sheet===S){S.busy=false;S.err=bioErr(e,'No se pudo vincular la huella.');renderSheet()}}
}
async function bioLogin(){
  const B=segPlug('NativeBiometric');if(!B||!bioLinked()||lg.busy||authUser)return;
  try{await B.verifyIdentity({reason:'Entrar a '+APP_NAME,title:'Entrar con huella',subtitle:APP_NAME,description:'Toca el sensor para entrar',maxAttempts:3,useFallback:false})}
  catch(e){lg.err=bioErr(e,'No se reconoció la huella. Puedes entrar con tu contraseña.');lg.msg='';render();return}
  let c=null;
  try{c=await B.getCredentials({server:BIO_SRV})}catch(e){c=null}
  if(!c||!c.username||!c.password){await bioUnlink();lg.err='La huella guardada ya no es válida. Entra con tu contraseña y vuelve a vincularla.';render();return}
  await doLogin({username:c.username,password:c.password,bio:true});
}

/* ----- gesto de regresar del teléfono ----- */
/* un gesto = una pantalla atrás; dos gestos rápidos = salir de la app (la sesión sigue abierta) */
function segParent(){
  if(sheet)return 'sheet';
  if(!authUser)return lg.tab==='reg'?'lgin':null;
  switch(view){
    case 'menu':return null;
    case 'order':return 'orders';
    case 'trazo':return 'traz';
    case 'docs':return docFrom==='trazo'?'trazo':docFrom==='dvt'?'dvt':'order';
    case 'dvt':return 'dvback';
    case 'log':return LG.rt?'logmenu':'menu';
    default:return 'menu';
  }
}
function segGoBack(){
  try{const a=document.activeElement;if(a&&a!==document.body&&a.blur)a.blur()}catch(e){}
  const p=segParent();
  if(p===null)return false;
  if(p==='sheet'){closeSheet();return true}
  if(p==='lgin'){lg.tab='in';lg.err='';lg.msg='';render();return true}
  if(view==='docs'){view=p;render();window.scrollTo(0,0);return true}
  /* de un catálogo de logística, al menú de Control Logístico (igual que la flecha de arriba) */
  if(p==='logmenu'){LG.rt=null;LG.q='';LG.edit=null;LG.err='';render();window.scrollTo(0,0);return true}
  goto(p);return true;
}
function segOnBack(){
  const now=Date.now();
  if(segBackT&&now-segBackT<=segBackW){segBackT=0;segExit();return}
  const moved=segGoBack();
  segBackT=now;segBackW=moved?SEG_DBL:2000;
  if(!moved)toast('Haz otro gesto rápido para salir');
}
function segExit(){
  segStamp();
  const A=segPlug('App');
  if(A&&A.exitApp){try{A.exitApp();return}catch(e){}}
  segWebOff=true;try{history.back()}catch(e){}
}

/* ----- cierre automático a los 30 min fuera de la app (móviles) ----- */
function segStamp(){try{localStorage.setItem(LS_ULT,String(segNow()))}catch(e){}}
function segLast(){try{return +localStorage.getItem(LS_ULT)||0}catch(e){return 0}}
function segCheck(){
  if(!segMobile()||!authUser)return false;
  const last=segLast();
  if(last&&segNow()-last>=SEG_MIN*60000){segLogout();return true}
  return false;
}
function segLogout(){
  userAct('ulogout');
  lg.msg='Tu sesión se cerró porque pasaron más de '+SEG_MIN+' minutos fuera de la app. Entra de nuevo.';
  segAutoBio=true;render();
  if(bioLinked())setTimeout(()=>{if(segAutoBio&&!authUser)bioLogin()},500);
}
function segPause(){
  segStamp();clearTimeout(segHideT);
  if(authUser&&segMobile())segHideT=setTimeout(segCheck,SEG_MIN*60000+1000);
}
function segResume(){clearTimeout(segHideT);if(!segCheck())segStamp()}
function segBoot(){try{if(segMobile())document.documentElement.classList.add('gest');segCheck()}catch(e){}}
function segInit(){
  try{
    segStamp();
    document.addEventListener('visibilitychange',()=>{document.hidden?segPause():segResume()});
    window.addEventListener('pagehide',segPause);
    setInterval(()=>{if(!document.hidden&&authUser)segStamp()},15000);
    const A=segPlug('App');
    if(A&&A.addListener){
      A.addListener('backButton',()=>segOnBack());
      A.addListener('appStateChange',st=>{st&&st.isActive?segResume():segPause()});
    }else if(segMobile()&&window.self===window.top&&!window.EMP_FAKE){
      /* navegador o PWA en el teléfono: una entrada de historial de guardia para atrapar el gesto */
      history.replaceState({seg:0},'');history.pushState({seg:1},'');
      window.addEventListener('popstate',e=>{
        if(segWebOff)return;
        if(e.state&&e.state.seg===0){segOnBack();if(!segWebOff){try{history.pushState({seg:1},'')}catch(x){}}}
      });
    }
    if(!authUser&&bioLinked()){segAutoBio=true;setTimeout(()=>{if(segAutoBio&&!authUser)bioLogin()},700)}
  }catch(e){}
  window.EMP_SEG={back:segOnBack,pause:segPause,resume:segResume,check:segCheck,skew:ms=>{segSkew+=ms},now:segNow,linked:bioLinked,ver:APP_VER};
}

/* ---------- v8.25 · Documentos de viaje ----------
   Todos los documentos de cada viaje en un solo lugar, por empresa y semana. Los documentos se siguen generando
   con las mismas funciones de siempre; aquí solo se ordenan y se enlazan con Empaque, Trazabilidad y Productores. */
const DV={e:null,wk:null,ord:'desc'};
function dvTrips(e){return visible().filter(o=>isLeader(o)&&o.emp===e)}
function dvView(){
  const e=DV.e||emp,T=dvTrips(e),cw=wkOfDate(todayISO()),ks=[...new Set(T.map(wkOf).filter(Boolean).concat([cw]))].sort().reverse();
  const sw=DV.wk==='ALL'?'ALL':(ks.indexOf(DV.wk)>=0?DV.wk:(ks.find(k=>T.some(o=>wkOf(o)===k))||cw));
  const L=T.filter(o=>sw==='ALL'||wkOf(o)===sw).sort((a,b)=>{const d=(a.cons||0)-(b.cons||0)||(a.createdAt||0)-(b.createdAt||0);return DV.ord==='asc'?d:-d});
  const cnt=k=>T.filter(o=>wkOf(o)===k).length;
  const tabs=`<div class="dvwk" role="tablist" aria-label="Semana">${ks.slice(0,8).map(k=>`<button class="chipbtn" role="tab" aria-selected="${k===sw}" data-act="dvwk:${k}">${esc(wkLab(k,true))}${cnt(k)?' · '+cnt(k):''}${k===cw?' · vigente':''}</button>`).join('')}<button class="chipbtn" role="tab" aria-selected="${sw==='ALL'}" data-act="dvwk:ALL">Todas</button></div>`;
  const card=o=>{const z=trazCalc(o),cl=manClosed(o);
    return `<button class="dvcard" data-act="dvt:${o.id}"><div class="orow"><span class="oec"><img class="oico" src="${ICO[o.emp]}" alt="">${esc(o.cod)}${o.ejemplo?'<span class="badge">Ejemplo</span>':''}</span>${cl?'<span class="chip good">Manifiesto cerrado</span>':'<span class="chip warn">Manifiesto abierto</span>'}</div><div class="note"><span class="mono">${esc(o.emb||'—')}</span> · ${esc(o.customer||'sin cliente')} · PO ${esc(o.po||'—')} · ${fmtDate(o.fecha)}</div><div class="dvst">${dvDot(z.nPal>0,z.nPal+(z.nPal===1?' tarima':' tarimas'))}${dvDot(!z.borrador,z.borrador?'Código en borrador':'Código listo')}${dvDot(o.estado==='completo',o.estado==='completo'?'Registro completo':'Empaque en proceso')}</div></button>`};
  const body=L.length?`<div class="ogrid dvgrid">${L.map(card).join('')}</div>`:`<section class="empty"><h2>Sin viajes${sw!=='ALL'?' en '+esc(wkLab(sw)):''}</h2><p>Aquí aparece cada viaje de ${esc(EMPS[e].name)} al crearlo en Registro de Empaque.</p></section>`;
  return topbar('Documentos de viaje','menu')+`<main class="wrap">${empToggle(e,'dvemp','Empresa')}<div class="dvbar">${tabs}<div class="seg dvord" role="group" aria-label="Orden"><button data-act="dvord:desc" aria-pressed="${DV.ord!=='asc'}">Más reciente primero</button><button data-act="dvord:asc" aria-pressed="${DV.ord==='asc'}">Por consecutivo</button></div></div><div class="sec">${esc(EMPS[e].name)} · ${sw==='ALL'?'todas las semanas':esc(wkLab(sw))} · ${L.length} ${L.length===1?'viaje':'viajes'}</div>${body}</main>`;
}
function dvDot(ok,t){return `<span class="dvdot${ok?' ok':''}"><i aria-hidden="true"></i>${esc(t)}</span>`}
function dvtView(o){
  const m=mainOf(o),z=trazCalc(m),cl=manClosed(m),np=z.nPal,lab=etqList(m);
  const dc=(t,sub,st,btns)=>`<section class="panel dvdoc"><div class="dvh"><div><strong>${t}</strong><small>${sub}</small></div>${st}</div><div class="pact">${btns}</div></section>`;
  const b=(act,t,pri,dis)=>`<button class="btn sm${pri?' primary':''}" data-act="${act}"${dis?' disabled':''}>${t}</button>`;
  const sh=sheetsOf(m),s15=sh.find(x=>x.variante==='1.5'),mv=multiV(m),VS=[''].concat(ventas(m).map(x=>x.id));
  return topbar(m.cod+' · Documentos','dvback')+`<main class="wrap">${lockBan(m)}<section class="label"><div class="lrow"><div><div class="k">${esc(EMPS[m.emp].name)} · ${esc(m.emb||'—')} · ${esc(wkLab(wkOf(m)))}</div><div class="big">${esc(m.cod)}</div><div class="note">${esc(m.customer||'sin cliente')} · PO ${esc(m.po||'—')} · ${fmtDate(m.fecha)}</div></div><div style="text-align:right">${cl?'<span class="chip good">Manifiesto cerrado</span>':'<span class="chip warn">Manifiesto abierto</span>'}</div></div></section>
${manBanHtml(m)}
<div class="dsk dvcols"><div class="dcol"><div class="sec">Empaque</div>
${VS.map(id=>{const w='@'+(id||'0'),n=palsOfV(m,id).length;return dc(mv?esc(ventaLab(m,id)):'Manifiesto',mv?n+(n===1?' tarima':' tarimas')+(dvv(m,'poCli',id)?' · P.O. '+esc(dvv(m,'poCli',id)):'')+' · una venta':'Una hoja con la carga por calidad y tipo de empaque',cl?'<span class="chip good">Cerrado</span>':'',b('dx:pv:man'+w,'Vista previa',1)+b('dx:dl:man.pdf'+w,'PDF')+b('dx:dl:man.pptx'+w,'PowerPoint')+b('dx:open:man'+w,'Editar datos')+(id?'':b('open:'+m.id,'Ir a Empaque ›')))}).join('')}
${dc('Manifiesto interno',esc((DOC_MX[m.emp]||DOC_MX.VL).name)+(mv?' · todo el viaje':''),'',b('dx:pv:int','Vista previa',1)+b('dx:dl:int.pdf','PDF')+b('dx:dl:int.pptx','PowerPoint')+b('dx:open:man','Editar datos'))}
${dc('Registro de Empaque','Hoja 1'+(s15?' y hoja 1.5':'')+' con productores, calibres y rendimiento',m.estado==='completo'?'<span class="chip good">Completo</span>':'<span class="chip warn">En proceso</span>',b('dx:pv:reg','Vista previa',1)+b('dx:outreg','Generar')+b('open:'+m.id,'Ir a Empaque ›'))}
</div><div class="dcol"><div class="sec">Trazabilidad</div>
${VS.map(id=>{const w='@'+(id||'0'),n=mv?palsOfV(m,id).length:np;return dc(mv?'Packing List · manifiesto '+ventaN(m,id):'Packing List',n+(n===1?' tarima':' tarimas')+(mv?' sombreadas en el thermo, numeradas por lugar':' con su empaque y calidad'),'',b('dx:pv:pl'+w,'Vista previa',1,!n)+b('dx:outpl'+w,'Generar',0,!n)+b('dx:open:pl'+w,'Editar datos')+(id?'':b('totraz:'+m.id,'Ir a Trazabilidad ›')))}).join('')}
${dc('Código de Trazabilidad',z.borrador?'Sale como BORRADOR: '+esc(z.motivos.slice(0,2).join('; ')):'Listo para imprimir',z.borrador?'<span class="chip warn">Borrador</span>':'<span class="chip good">Listo</span>',b('dx:pv:traz','Vista previa',1)+b('dx:outtraz','Generar')+b('totraz:'+m.id,'Ir a Trazabilidad ›'))}
${dc('Etiquetas con QR',lab.length+(lab.length===1?' etiqueta':' etiquetas')+' · una por productor, calidad y presentación','',b('etq:'+m.id,'Generar etiquetas',1,!lab.length)+b('prods','Ir a Productores ›'))}
</div></div></main>`;
}
function dvOpen(id){const o=orders.find(x=>x.id===id);if(!o)return;curId=mainOf(o).id;view='dvt';sheet=null;renderSheet();render();window.scrollTo(0,0)}

/* ---------- v8.25 · Etiquetas con QR por productor ----------
   Mismo contenido que la etiqueta de Publisher (razón social, domicilio, producto, peso, embarque, productor, P.O.,
   calidad, cliente y fecha de empaque) con un QR en lugar del código de barras. El QR lleva el lote:
   EMBARQUE-EMPRESA+CÓDIGO-CALIDAD-AAAAMMDD, por ejemplo JC263301-EC003-1.5-20260812. */
function etqLot(m,code,q){return [String(m.emb||m.cod||'').replace(/\s+/g,''),m.emp+pad(code,3),q==='1.5'?'1.5':'1',String(m.fecha||todayISO()).replace(/-/g,'')].join('-')}
function etqList(m){
  const X=exisData(m),out=[],seen=new Set();
  X.G.forEach(g=>{const code=g.codigo||rmpCodeOf(g.key);g.L.forEach(r=>{if(!(r.reg-r.rmp-r.sent>0))return;const k=g.key+'|'+r.q+'|'+r.tipo;if(seen.has(k))return;seen.add(k);
    out.push({id:k,key:g.key,code:code,nombre:g.nombre||g.key,q:r.q==='1.5'?'1.5':'1',tipo:r.tipo,lot:code?etqLot(m,code,r.q):''})})});
  return out.sort((a,b)=>String(a.key).localeCompare(String(b.key),'es',{numeric:true})||a.q.localeCompare(b.q)||a.tipo.localeCompare(b.tipo));
}
function etqLbs(tipo){return tipo==='CTN10'?10:40}
function qrJpgB64(text,px){
  const q=qrcode(0,'M');q.addData(text);q.make();const n=q.getModuleCount(),qz=2,u=Math.max(4,Math.floor((px||480)/(n+qz*2)));
  const cv=document.createElement('canvas');cv.width=cv.height=u*(n+qz*2);const x=cv.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,cv.width,cv.height);x.fillStyle='#000';
  for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(q.isDark(r,c))x.fillRect((c+qz)*u,(r+qz)*u,u,u);
  return cv.toDataURL('image/jpeg',0.95).split(',')[1];
}
async function etqPages(m,L){
  let lg=null;try{lg=await asset(LOGO[m.emp])}catch(e){}
  const MX=DOC_MX[m.emp]||DOC_MX.VL,INK='#111111',pages=[];
  L.forEach(a=>{
    const ops=[],T=(s,x,y,w,h,p)=>ops.push(Object.assign({t:'t',s:s==null?'':String(s),x,y,w,h,size:16,color:INK},p));
    T(MX.name,10,6,580,34,{size:26,bold:true,align:'center'});ops.push({t:'r',x:12,y:42,w:576,h:5,fill:INK});
    if(lg){const k=Math.min(118/lg.w,74/lg.h);ops.push({t:'i',b64:lg.b64,x:14+(118-lg.w*k)/2,y:54+(74-lg.h*k)/2,w:lg.w*k,h:lg.h*k})}
    T('CARRETERA FEDERAL CÓRDOBA-VERACRUZ KM 56.6 S/N',140,52,300,16,{size:10});T('CUITLÁHUAC, VERACRUZ, MÉXICO.',140,68,300,16,{size:10});
    T('LIMÓN PERSA',140,88,300,22,{size:17,bold:true});T('NET WEIGHT '+etqLbs(a.tipo)+' LBS.',140,110,300,22,{size:17,bold:true});
    ops.push({t:'i',b64:qrJpgB64(a.lot,480),x:462,y:52,w:126,h:126});
    T(a.lot,440,178,150,14,{size:9,align:'center',min:7});
    T(m.emb||m.cod,10,150,180,40,{size:30,bold:true});T(m.emp+' - '+pad(a.code,3),196,150,150,40,{size:30,bold:true,align:'center'});
    T('P.O. '+(m.po||'—'),346,150,110,40,{size:22,bold:true});
    T('Distributed by:',10,198,180,22,{size:14,bold:true});T(m.customer||'',10,222,260,26,{size:16,bold:true});
    ops.push({t:'r',x:206,y:198,w:84,h:50,line:INK,lw:2,rad:6});T('HECHO EN',206,202,84,20,{size:12,bold:true,align:'center'});T('MÉXICO',206,224,84,20,{size:12,bold:true,align:'center'});
    T(a.q==='1.5'?'1½':'1ª',300,192,120,34,{size:30,bold:true,align:'center'});T(TIPO_L[a.tipo]||a.tipo,300,224,120,24,{size:15,align:'center'});
    T('EMP: '+fmtDate(m.fecha),300,252,290,30,{size:20,bold:true,align:'right'});
    T(a.nombre,10,256,286,26,{size:13,color:'#444444'});
    pages.push({w:600,h:300,ops:ops});
  });
  return pages;
}
async function etqPng(pages){
  const cvs=[];for(const pg of pages)cvs.push(await renderPage(pg,300));
  const G=24,W=cvs[0].width,H=cvs.reduce((s,c)=>s+c.height,0)+G*(cvs.length+1),k=Math.min(1,16000/H);
  const cv=document.createElement('canvas');cv.width=Math.round((W+2*G)*k);cv.height=Math.round(H*k);const x=cv.getContext('2d');x.fillStyle='#d9dde1';x.fillRect(0,0,cv.width,cv.height);
  let y=G;cvs.forEach(c=>{x.drawImage(c,G*k,y*k,c.width*k,c.height*k);y+=c.height+G});
  return new Promise((res,rej)=>cv.toBlob(b=>b?res(b):rej(new Error('png')),'image/png'));
}
async function etqWb(m,L){
  const wb=newWb(),ws=wb.addWorksheet('Etiquetas');
  ws.columns=[{header:'Lote (QR)',key:'lot',width:30},{header:'QR',key:'qr',width:14},{header:'Empresa',key:'emp',width:38},{header:'Código',key:'code',width:10},{header:'Productor',key:'nom',width:30},{header:'Calidad',key:'q',width:9},{header:'Presentación',key:'tipo',width:13},{header:'Peso neto',key:'peso',width:12},{header:'Embarque',key:'emb',width:13},{header:'P.O.',key:'po',width:10},{header:'Distributed by',key:'cli',width:26},{header:'Fecha de empaque',key:'fecha',width:15},{header:'Domicilio',key:'dom',width:52}];
  ws.getRow(1).font={bold:true};
  L.forEach((a,i)=>{const r=ws.addRow({lot:a.lot,emp:(DOC_MX[m.emp]||DOC_MX.VL).name,code:m.emp+'-'+pad(a.code,3),nom:a.nombre,q:a.q==='1.5'?'1½':'1',tipo:TIPO_L[a.tipo]||a.tipo,peso:etqLbs(a.tipo)+' LBS',emb:m.emb||m.cod,po:m.po||'',cli:m.customer||'',fecha:fmtDate(m.fecha),dom:'CARRETERA FEDERAL CÓRDOBA-VERACRUZ KM 56.6 S/N, CUITLÁHUAC, VERACRUZ, MÉXICO'});r.height=78;
    const id=wb.addImage({base64:qrJpgB64(a.lot,240),extension:'jpeg'});ws.addImage(id,{tl:{col:1.1,row:i+1.08},ext:{width:96,height:96}})});
  const n=wb.addWorksheet('Cómo usar');n.getCell('A1').value='Para Publisher: Correspondencia › Combinar correspondencia › Usar una lista existente y elige la hoja «Etiquetas». Cada renglón es una etiqueta; la columna «Lote (QR)» es el texto del QR.';n.getColumn(1).width=120;
  return wb;
}
function etqOpen(id){
  const o=orders.find(x=>x.id===id);if(!o)return;const m=mainOf(o),L=etqList(m);if(!L.length){toast('Este viaje todavía no tiene fruta registrada para etiquetar');return}
  const sel={};L.forEach(a=>{if(a.code)sel[a.id]=true});sheet={kind:'etq',oid:m.id,sel:sel};renderSheet();
}
function etqHtml(){
  const m=orders.find(x=>x.id===sheet.oid);if(!m)return '';const L=etqList(m),sel=sheet.sel,n=L.filter(a=>sel[a.id]).length,sin=L.filter(a=>!a.code).length;
  return `<h3>Etiquetas con QR · ${esc(m.cod)}</h3><p class="note">Una etiqueta de 4 × 2 pulgadas por productor, calidad y presentación, con la razón social de ${esc(EMPS[m.emp].name)}. El QR lleva el lote: embarque, productor, calidad y fecha de empaque.</p>
<div class="srow2"><button class="btn sm" data-act="etqall">Seleccionar todo</button><button class="btn sm" data-act="etqnone">Limpiar</button></div>
<div class="s2list">${L.map(a=>`<label class="s2r" for="eq-${esc(a.id)}"><input type="checkbox" id="eq-${esc(a.id)}" data-etqsel="${esc(a.id)}"${sel[a.id]?' checked':''}${a.code?'':' disabled'}><span class="s2d"><b>${esc(a.nombre)}</b><small>${a.code?esc(m.emp+'-'+pad(a.code,3))+' · ':'sin código, no se etiqueta · '}${a.q==='1.5'?'1½':'Primera'} · ${esc(TIPO_L[a.tipo]||a.tipo)}${a.lot?' · <span class="mono">'+esc(a.lot)+'</span>':''}</small></span></label>`).join('')}</div>
${sin?`<p class="note">${sin} sin código de productor: asígnalo en Productores para poder etiquetar.</p>`:''}
<div class="srow2"><button class="btn" data-act="prods">Ir a Productores</button><button class="btn primary" data-act="etqgo"${n?'':' disabled'}>Generar ${n} ${n===1?'etiqueta':'etiquetas'}</button></div>`;
}
function etqGo(){
  const m=orders.find(x=>x.id===(sheet&&sheet.oid));if(!m)return;const L=etqList(m).filter(a=>sheet.sel[a.id]&&a.code);if(!L.length)return;
  const P=()=>etqPages(m,L),f={png:async()=>etqPng(await P()),pdf:async()=>pagesToPdf(await P())};
  if(typeof ExcelJS!=='undefined')f.xlsx=async()=>wbBlob(await etqWb(m,L));
  f.pptx=async()=>pagesToPptx(await P(),'Etiquetas '+m.cod);
  openOut({pages:P,title:'Etiquetas '+m.cod+' · '+L.length,base:'Etiquetas_'+fileSafe(m.emb||m.cod),fmts:f,note:'Una hoja de 4 × 2 pulgadas por etiqueta. El Excel sirve para Combinar correspondencia en Publisher.'});
}

$app.addEventListener('change',e=>{const t=e.target;if(!t||!t.dataset)return;if(t.dataset.ctrip){CT.oid=t.dataset.ctrip;CT.pal='new';render()}else if(t.dataset.cpal){CT.pal=t.dataset.cpal}});
$app.addEventListener('input',e=>{const t=e.target;if(!t||!t.dataset)return;if(t.dataset.ctprod!=null)CT.prod=t.value;else if(t.dataset.ctn){const d=t.value.replace(/\D+/g,'');if(d!==t.value)t.value=d;CT.n[t.dataset.ctn]=d;const o=document.getElementById('cttot');if(o)o.textContent='Total: '+fmt(calsOfTipo(CT.tipo).reduce((s,c)=>s+n0(CT.n[c.k]),0))+' cajas'}});
/* ---------- v8.25 · Conteo de tarimas (rol «tarima») ----------
   El personal de tarima solo cuenta: por productor, calidad, presentación y calibre, cuántas cajas se agregan a qué tarima.
   El conteo queda pendiente hasta que el jefe de empaque lo autoriza en Código de Trazabilidad; al autorizar, las cajas
   entran a la tarima. Se guarda en la tabla «conteos» (supabase-v8.25.sql); sin ella queda en el dispositivo. */
const LS_CONT='empaque-conteos';
let CONT={list:[],dirty:[],noTable:false};
(function(){try{const j=JSON.parse(localStorage.getItem(LS_CONT)||'null');if(j&&Array.isArray(j.list))CONT={list:j.list,dirty:Array.isArray(j.dirty)?j.dirty:[],noTable:false}}catch(e){}})();
function saveCont(){try{localStorage.setItem(LS_CONT,JSON.stringify({list:CONT.list,dirty:CONT.dirty}))}catch(e){}}
function touchC(c){c.updatedAt=Date.now();if(CONT.dirty.indexOf(c.id)<0)CONT.dirty.push(c.id);saveCont();setSync()}
async function syncCont(){
  try{
    const since=Date.now()-60*864e5;
    const rows=(await sb('/rest/v1/conteos?select=id,updated_at,data&updated_at=gt.'+since+'&order=updated_at.desc&limit=1000'))||[];CONT.noTable=false;
    rows.forEach(r=>{if(!r.data)return;const d=Object.assign({},r.data,{id:r.id,updatedAt:Number(r.updated_at)||0}),k=CONT.list.findIndex(x=>x.id===r.id);
      if(k<0)CONT.list.push(d);else if(d.updatedAt>(CONT.list[k].updatedAt||0)&&CONT.dirty.indexOf(r.id)<0)CONT.list[k]=d});
    const send=CONT.dirty.map(id=>CONT.list.find(c=>c.id===id)).filter(Boolean);
    if(send.length){await sb('/rest/v1/conteos?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:send.map(c=>({id:c.id,updated_at:c.updatedAt,data:c}))});CONT.dirty=[]}
    CONT.list=CONT.list.filter(c=>(c.updatedAt||0)>Date.now()-120*864e5||c.estado==='pendiente');saveCont();
  }catch(e){if(e&&(e.status===404||e.status===400))CONT.noTable=true}
}
function contOf(m){return CONT.list.filter(c=>c.oid===m.id)}
function contPend(m){return contOf(m).filter(c=>c.estado==='pendiente')}
function calsOfTipo(tp){return tp==='CTN10'?CAL_MM:CAL_STD.filter(c=>c.k!=='ctn')}
const CT={oid:null,q:'1',tipo:'RPC',pal:'new',prod:'',n:{}};
function contTrips(){return visible().filter(o=>isLeader(o)&&!manClosed(o)&&!orderLocked(o)).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).slice(0,10)}
function contProds(m){const out=[],seen=new Set();sheetsOf(m).forEach(s=>(s.productores||[]).forEach(p=>{if(p.sob2||p.sob)return;const k=prodKey(s,p);if(seen.has(k))return;seen.add(k);out.push({k:k,n:p.nombre||k})}));return out}
function conteoView(){
  const T=contTrips(),m=T.find(o=>o.id===CT.oid)||null;
  const trips=T.length?`<div class="pnopts">${T.map(o=>`<label class="pnopt"><input type="radio" name="ctrip" data-ctrip="${o.id}"${m&&m.id===o.id?' checked':''}><span><b class="mono">${esc(o.cod)}</b><small>${esc(EMPS[o.emp].name)} · ${esc(o.emb||'—')} · ${fmtDate(o.fecha)}</small></span></label>`).join('')}</div>`:'<p class="note">No hay viajes abiertos para contar. Avisa al jefe de empaque.</p>';
  let form='';
  if(m){const P=contProds(m),t=ensureTraz(m),cals=calsOfTipo(CT.tipo),tot=cals.reduce((s,c)=>s+n0(CT.n[c.k]),0);
    const pals=t.tarimas.map((p,i)=>({p:p,i:i})).filter(x=>palTipo(x.p)===CT.tipo&&palTot(x.p)<palCap(palTipo(x.p)));
    form=`<div class="sec">Productor</div><div class="panel"><label class="fld" for="ct-prod"><span>Código o nombre</span><input class="in txt" id="ct-prod" list="ct-plist" autocomplete="off" autocapitalize="characters" data-ctprod="1" value="${esc(CT.prod)}" placeholder="VL-156 o nombre"></label><datalist id="ct-plist">${P.map(x=>`<option value="${esc(x.k)}">${esc(x.n)}</option>`).join('')}</datalist></div>
<div class="sec">Calidad y presentación</div><div class="seg" role="group" aria-label="Calidad"><button data-act="ctq:1" aria-pressed="${CT.q==='1'}">Primera</button><button data-act="ctq:1.5" aria-pressed="${CT.q==='1.5'}">1.5</button></div>
<div class="seg" role="group" aria-label="Presentación" style="margin-top:8px">${TIPO_K.map(k=>`<button data-act="ctt:${k}" aria-pressed="${CT.tipo===k}">${esc(TIPO_L[k])}</button>`).join('')}</div>
<div class="sec">Tarima</div><div class="pnopts">${pals.map(x=>`<label class="pnopt"><input type="radio" name="cpal" data-cpal="${x.p.id}"${CT.pal===x.p.id?' checked':''}><span><b>Tarima ${x.i+1}</b><small>${esc(TIPO_L[palTipo(x.p)])} · ${fmt(palTot(x.p))} de ${fmt(palCap(palTipo(x.p)))} cajas</small></span></label>`).join('')}<label class="pnopt"><input type="radio" name="cpal" data-cpal="new"${CT.pal==='new'||!pals.some(x=>x.p.id===CT.pal)?' checked':''}><span><b>Tarima nueva</b><small>${esc(TIPO_L[CT.tipo])}</small></span></label></div>
<div class="sec">Cajas por calibre</div><div class="panel ctgrid">${cals.map(c=>`<label class="fld" for="ct-${c.k}"><span>${esc(c.l)}</span><input class="in" id="ct-${c.k}" inputmode="numeric" autocomplete="off" data-ctn="${c.k}" value="${CT.n[c.k]!=null?esc(CT.n[c.k]):''}"></label>`).join('')}</div>
<p class="s2tot" id="cttot">Total: ${fmt(tot)} cajas</p><button class="btn primary" style="width:100%" data-act="ctsend">Enviar conteo al jefe de empaque</button>`}
  const mine=CONT.list.filter(c=>c.byU===(authUser&&authUser.user)).sort((a,b)=>(b.at||0)-(a.at||0)).slice(0,15);
  const st=c=>c.estado==='autorizado'?'<span class="chip good">Autorizado</span>':c.estado==='rechazado'?'<span class="chip crit">Rechazado</span>':'<span class="chip warn">Pendiente</span>';
  const hist=mine.length?`<div class="sec">Mis conteos</div><div class="panel">${mine.map(c=>`<div class="kv"><span><b>${esc(c.cod)}</b> · ${esc(c.prod)} · ${c.q==='1.5'?'1.5 · ':''}${esc(TIPO_L[c.tipo])} · ${c.palN?'tarima '+c.palN:'tarima nueva'} · ${fmt(contTot(c))} cajas${c.nota?' · «'+esc(c.nota)+'»':''}</span>${st(c)}</div>`).join('')}</div>`:'';
  return topbar('Conteo de tarimas',null)+`<main class="wrap"><div class="panel info"><p class="note">Cuenta las cajas que salen por productor y calibre y a qué tarima van. El jefe de empaque autoriza cada conteo; hasta entonces no entra a la tarima.</p></div><div class="sec">Viaje</div>${trips}${form}${hist}<div class="pact" style="margin-top:16px"><button class="btn sm" data-act="sync">Sincronizar</button><button class="btn sm" data-act="ulogout">Cerrar sesión</button></div>${legalFoot()}</main>`;
}
function contTot(c){return (c.lines||[]).reduce((s,l)=>s+n0(l.n),0)}
function contSend(){
  const m=orders.find(x=>x.id===CT.oid);if(!m){toast('Elige el viaje');return}
  const pk=resolveProd(sheetsOf(m),CT.prod);if(!pk){toast('Escribe el código o el nombre del productor');return}
  const lines=calsOfTipo(CT.tipo).map(c=>({ck:c.k,n:Math.max(0,Math.floor(n0(CT.n[c.k])))})).filter(l=>l.n>0);if(!lines.length){toast('Escribe cuántas cajas de cada calibre');return}
  const t=ensureTraz(m),pi=t.tarimas.findIndex(p=>p.id===CT.pal);
  if(pi>=0){const P=t.tarimas[pi],room=palCap(palTipo(P))-palTot(P),tot=lines.reduce((x,l)=>x+l.n,0);if(tot>room){toast('A la tarima '+(pi+1)+' le caben '+fmt(Math.max(0,room))+' cajas. Manda el resto a una tarima nueva');return}}
  const nm=(contProds(m).find(x=>x.k===pk)||{}).n||pk;
  const c={id:uid(),oid:m.id,emp:m.emp,cod:m.cod,prod:pk,nombre:nm,q:CT.q,tipo:CT.tipo,pal:pi>=0?CT.pal:'new',palN:pi>=0?pi+1:null,lines:lines,estado:'pendiente',at:Date.now(),by:whoName(),byU:authUser&&authUser.user};
  CONT.list.push(c);touchC(c);CT.n={};CT.prod='';render();toast('Conteo enviado: '+fmt(contTot(c))+' cajas de '+pk+'. Falta que lo autorice el jefe de empaque');if(canAuto())doSync(true);
}
function contAuth(id,ok){
  const c=CONT.list.find(x=>x.id===id);if(!c||c.estado!=='pendiente'||!canManClose()||roRole)return;const m=orders.find(x=>x.id===c.oid);if(!m)return;
  if(ok){if(manClosed(m)||orderLocked(m)){toast('El manifiesto o la semana de '+m.cod+' está cerrado');return}
    const t=ensureTraz(m);let p=c.pal!=='new'?t.tarimas.find(x=>x.id===c.pal):null;
    if(p&&palTot(p)+contTot(c)>palCap(palTipo(p))){toast('Ya no caben en la tarima '+(t.tarimas.indexOf(p)+1)+': le quedan '+fmt(Math.max(0,palCap(palTipo(p))-palTot(p)))+' cajas. Recházalo para que lo manden a otra tarima');return}
    if(!p){p={id:uid(),marca:marcaOfQ(m.emp,c.q),empaque:c.tipo,lines:[]};t.tarimas.push(p)}
    c.lines.forEach(l=>palPut(m,p,c.q,l.ck,c.prod,l.n));c.palN=t.tarimas.indexOf(p)+1;c.pal=p.id;touch(m);
    logAdd({k:'note',ctx:ctxOf(m),lab:'Conteo de tarima autorizado',o:c.by||'',n:'Tarima '+c.palN+' · '+c.prod+' · '+fmt(contTot(c))+' cajas'})}
  else{const v=(document.getElementById('ctr-'+id)||{}).value;c.nota=String(v||'').trim()}
  c.estado=ok?'autorizado':'rechazado';c.autBy=whoName();c.autAt=Date.now();touchC(c);render();toast(ok?'Conteo autorizado: las cajas entraron a la tarima '+c.palN:'Conteo rechazado');
}
function contPanel(m){
  const L=contPend(m);if(!L.length)return '';const can=canManClose()&&!roRole&&!manClosed(m)&&!orderLocked(m);
  return `<div class="panel warn ctpend"><strong>Conteos por autorizar · ${L.length}</strong>${L.map(c=>`<div class="ctrow"><div><b>${esc(c.prod)} · ${esc(c.nombre||'')}</b><small>${c.q==='1.5'?'1.5 · ':''}${esc(TIPO_L[c.tipo])} · ${c.palN?'tarima '+c.palN:'tarima nueva'} · ${esc(c.lines.map(l=>calLab(l.ck)+': '+fmt(l.n)).join(', '))} · ${fmt(contTot(c))} cajas · ${esc(c.by||'—')}, ${esc(fmtTs(c.at))}</small></div>${can?`<div class="pact"><input class="in txt" id="ctr-${c.id}" placeholder="Motivo si se rechaza" aria-label="Motivo"><button class="btn sm" data-act="ctno:${c.id}">Rechazar</button><button class="btn sm primary" data-act="ctok:${c.id}">Autorizar</button></div>`:''}</div>`).join('')}</div>`;
}

/* ---------- v8.25 · Usuarios y roles (con base de datos) ----------
   Solo administradores y superadministradores entran. Los dos ven las cuentas, las agregan y las bloquean o habilitan;
   solo el superadministrador cambia roles. Todo pasa por funciones de Supabase (supabase-v8.25.sql) que revisan el rol
   en el servidor, así que la app nunca necesita la clave secreta. */
const ROL_ORD=['superadmin','admin','jefe','inocuidad','tarima','lector','contador',''];
const ROL_L={superadmin:'Superadministrador',admin:'Administrador',jefe:'Jefe de empaque',inocuidad:'Jefe de inocuidad',tarima:'Personal de tarima',lector:'Dirección (solo lectura)',contador:'Contador','':'Sin rol (sin acceso)'};
const ROL_D={superadmin:'Todo, y además cambia roles',admin:'Todo, menos cambiar roles',jefe:'Empaque, trazabilidad y documentos; autoriza conteos',inocuidad:'Lo del jefe de empaque, y edita productores y logística',tarima:'Solo el conteo de cajas por calibre',lector:'Ve todo, no cambia nada',contador:'Finanzas',' ':''};
function usrOpen(){
  if(!(isAdmin()||perAdmin())){toast('Solo la administración entra a Usuarios');return}
  if(!cfgOK()){userAct('usersopen');return}
  sheet={kind:'usr',list:null,err:'',busy:false,add:false};renderSheet();usrLoad();
}
async function usrLoad(){
  try{await ensureSession();const r=await sb('/rest/v1/rpc/admin_usuarios',{method:'POST',body:{}});if(sheet&&sheet.kind==='usr'){sheet.list=r||[];sheet.err='';renderSheet()}}
  catch(e){if(sheet&&sheet.kind==='usr'){sheet.list=[];sheet.err=e&&e.status===404?'Falta correr supabase-v8.25.sql en Supabase.':e&&e.status===403?'Tu cuenta no tiene permiso para ver usuarios.':'No se pudo cargar la lista. Revisa tu internet.';renderSheet()}}
}
function usrHtml(){
  const S=sheet,sup=isSuper(),me=session&&session.email;
  const rows=(S.list||[]).slice().sort((a,b)=>ROL_ORD.indexOf(a.rol||'')-ROL_ORD.indexOf(b.rol||'')||String(a.email).localeCompare(String(b.email))).map(u=>{
    const r=u.rol||'',self=u.email===me,blk=!!u.bloqueado,top=r==='admin'||r==='superadmin';
    const sel=sup&&!self?`<select class="in sel" data-usrol="${esc(u.id)}" aria-label="Rol de ${esc(u.email)}">${ROL_ORD.map(k=>`<option value="${k}"${k===r?' selected':''}>${esc(ROL_L[k])}</option>`).join('')}</select>`:`<span class="chip${r?'':' warn'}">${esc(ROL_L[r]||r)}</span>`;
    const blkB=self||(top&&!sup)?'':`<button class="btn sm" data-act="${blk?'usrok':'usrblk'}:${esc(u.id)}">${blk?'Habilitar':'Bloquear'}</button>`;
    return `<div class="urow"><div class="rtx"><strong>${esc(u.nombre||u.email)}${self?' (tú)':''}</strong><small>${esc(u.email)} · ${blk?'<b class="neg">bloqueada</b>':'activa'} · último acceso ${u.ultimo?esc(fmtTs(Date.parse(u.ultimo))):'nunca'}</small></div><div class="ubt">${sel}${blkB}</div></div>`}).join('');
  const add=S.add?`<div class="panel"><label class="fld" for="ua-n"><span>Nombre</span><input class="in txt" id="ua-n" autocomplete="off"></label><label class="fld" for="ua-e"><span>Correo</span><input class="in txt" id="ua-e" type="email" autocapitalize="none" autocomplete="off"></label><label class="fld" for="ua-p"><span>Contraseña temporal (mínimo 6)</span><input class="in txt" id="ua-p" type="text" autocomplete="off"></label>${sup?`<label class="fld" for="ua-r"><span>Rol</span><select class="in sel" id="ua-r">${ROL_ORD.filter(k=>k).map(k=>`<option value="${k}"${k==='jefe'?' selected':''}>${esc(ROL_L[k])}</option>`).join('')}</select></label>`:'<p class="note">La cuenta queda sin rol (sin acceso) hasta que el superadministrador le asigne uno.</p>'}<div class="srow2"><button class="btn" data-act="usradd:0">Cancelar</button><button class="btn primary" data-act="usrnew"${S.busy?' disabled':''}>${S.busy?'Creando…':'Crear cuenta'}</button></div></div>`:`<div class="pact"><button class="btn primary sm" data-act="usradd:1">+ Agregar usuario</button><button class="btn sm" data-act="usrload">Actualizar</button></div>`;
  return `<h3>Usuarios y roles</h3><p class="note">${sup?'Como superadministrador cambias roles; el cambio aplica la próxima vez que la persona entre.':'Puedes agregar, bloquear y habilitar cuentas. Los roles los cambia el superadministrador.'}</p>
<details class="panel"><summary>Qué hace cada rol</summary>${ROL_ORD.filter(k=>k).map(k=>`<div class="kv"><span><b>${esc(ROL_L[k])}</b></span><small>${esc(ROL_D[k])}</small></div>`).join('')}</details>
${add}${S.err?`<p class="note" style="color:var(--crit)" role="alert">${esc(S.err)}</p>`:''}${S.list==null?'<p class="note">Cargando…</p>':`<div class="panel">${rows||'<p class="note">Sin cuentas.</p>'}</div>`}<div class="srow2"><button class="btn primary" data-act="closesheet">Cerrar</button></div>`;
}
async function usrRol(uid,rol){
  if(!isSuper()){toast('Solo el superadministrador cambia roles');return}
  try{await ensureSession();await sb('/rest/v1/rpc/asignar_rol',{method:'POST',body:{p_uid:uid,p_rol:rol}});const u=(sheet.list||[]).find(x=>x.id===uid);if(u)u.rol=rol;logAdd({k:'note',ctx:{t:'u'},lab:'Rol cambiado',o:u?u.email:uid,n:ROL_L[rol]||rol});toast('Rol asignado: '+(ROL_L[rol]||rol)+'. Aplica al volver a entrar');renderSheet()}
  catch(e){toast(e&&e.status===403?'Tu cuenta no puede cambiar roles':'No se pudo cambiar el rol');usrLoad()}
}
async function usrBlk(uid,on){
  try{await ensureSession();await sb('/rest/v1/rpc/habilitar_usuario',{method:'POST',body:{p_uid:uid,p_activo:on}});const u=(sheet.list||[]).find(x=>x.id===uid);if(u)u.bloqueado=!on;toast(on?'Cuenta habilitada':'Cuenta bloqueada');renderSheet()}
  catch(e){toast(e&&e.status===403?'No tienes permiso para esa cuenta':'No se pudo cambiar');usrLoad()}
}
/* el registro de Supabase responde 400/422/429 por varias causas; se muestra la causa real */
function usrErr(x){
  const c=String(x&&x.code||''),m=String(x&&x.msg||''),t=(c+' '+m).toLowerCase();
  if(/not.?authorized/.test(t))return 'Supabase no puede mandar el correo de confirmación a esa dirección (su correo de prueba solo envía al equipo del proyecto). Desactiva Authentication › Sign In / Providers › Confirm email y toca Save changes; la cuenta queda lista con la contraseña temporal.';
  if(/signup.?disabled|signups not allowed/.test(t))return 'Supabase no permite registrar cuentas: activa Authentication › Sign In / Providers › Allow new users to sign up.';
  if(/already|exists|registered/.test(t))return 'Ese correo ya tiene cuenta.';
  if(/weak|password/.test(t))return 'Supabase no aceptó la contraseña temporal: usa una más larga o con letras y números.';
  if(/rate|limit/.test(t)||(x&&x.status===429))return 'Supabase limita los correos por hora. Espera un rato o desactiva Confirm email.';
  if(/invalid/.test(t)&&/email/.test(t))return 'Supabase no aceptó ese correo: revisa que esté bien escrito.';
  return 'No se pudo crear la cuenta'+(m?': '+m:x&&x.status?' (error '+x.status+')':'')+'.';
}
async function usrNew(){
  const S=sheet,n=gv('ua-n').trim(),e=gv('ua-e').trim().toLowerCase(),p=gv('ua-p'),r=isSuper()?gv('ua-r'):'';
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)){toast('Escribe un correo válido');return}if(p.length<6){toast('La contraseña lleva al menos 6 caracteres');return}
  S.busy=true;renderSheet();
  try{const j=await sb('/auth/v1/signup',{method:'POST',auth:false,body:{email:e,password:p,data:{nombre:n}}});const id=(j&&(j.user&&j.user.id))||(j&&j.id);
    if(r&&id){await ensureSession();await sb('/rest/v1/rpc/asignar_rol',{method:'POST',body:{p_uid:id,p_rol:r}})}
    S.busy=false;S.add=false;toast('Cuenta creada para '+e+(r?' como '+ROL_L[r]:'')+'. Entrégale su contraseña temporal');usrLoad()}
  catch(x){S.busy=false;S.err=usrErr(x);renderSheet()}
}

/* ---------- v8.24 · buscador de productores en todas las listas ----------
   Después de cada dibujo busca tablas y listas con 5 o más renglones de productor (código VL-/EC- o nombre del
   catálogo) y les pone encima «Buscar productor». Solo oculta renglones en pantalla: no cambia datos, totales ni
   documentos. Las listas que ya tienen su propio buscador se dejan como están. */
const PF={q:{},raf:0,focus:null};
const PF_SKIP='select,.bnav,.pfind,#pvgrid,#plist,#rlist,#tfout,#rexprods,#results,.pdd,[data-nopf]';
const PF_CODE=/\b(?:VL|EC)-\d{1,4}\b(?!-)/;
function pfNames(){const m=lisNameMap();if(PF.nsrc!==m){PF.nsrc=m;PF.names=[...m.keys()].filter(k=>k.length>=5)}return PF.names}
function pfText(el){const w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let t='',x;while((x=w.nextNode()))t+=' '+x.nodeValue;return t}
function pfIsProd(el){const t=pfText(el);if(PF_CODE.test(t))return true;const n=norm(t).replace(/\s+/g,' ');return pfNames().some(k=>n.indexOf(k)>=0)}
/* dentro de una lista de productores, cuenta todo renglón salvo encabezados, totales y títulos (también los productores sin código) */
function pfData(r){if(r.tagName==='TR'&&r.querySelector('th')&&!r.querySelector('td'))return false;if(/(^|\s)(sec|tot|total|thead|hdr|head)(\s|$)/.test(r.className||''))return false;return !/^\s*(total|totales|suma)\b/i.test(pfText(r))}
function pfRowsOf(c){return c.tagName==='TBODY'||c.tagName==='TABLE'?[...c.children].filter(r=>r.tagName==='TR'):[...c.children].filter(r=>!r.classList.contains('pfind'))}
function pfCands(root){
  const out=[];
  root.querySelectorAll('tbody,table,div,ul,ol,section').forEach(c=>{
    if(c.closest(PF_SKIP)||c.children.length<5||c.children.length>3000)return;
    if(c.tagName==='TABLE'&&[...c.children].some(x=>x.tagName==='TBODY'))return;
    const rows=pfRowsOf(c);if(rows.length<5)return;
    let n=0;for(const r of rows){if((r.textContent||'').length<1500&&pfIsProd(r))n++}
    if(n>=5&&n>=rows.length*0.5)out.push(c)});
  return out.filter(c=>!out.some(d=>d!==c&&c.contains(d)))}
function pfAnchor(c){let a=c.tagName==='TBODY'?c.closest('table'):c;while(a.parentElement&&a.parentElement.children.length===1&&a.parentElement!==$app&&a.parentElement!==$sh&&!a.parentElement.classList.contains('panel')&&!a.parentElement.classList.contains('sheet'))a=a.parentElement;return a}
function pfApply(box){
  const c=box._pfc;if(!c)return;const q=norm(box.querySelector('input').value||'').replace(/\s+/g,' ').trim();
  let tot=0,vis=0;
  pfRowsOf(c).forEach(r=>{if(!pfData(r)){r.hidden=false;return}tot++;const ok=!q||norm(pfText(r)).replace(/\s+/g,' ').indexOf(q)>=0;r.hidden=!ok;if(ok)vis++});
  const s=box.querySelector('.pfn');if(s)s.textContent=q?`${vis} de ${tot}`:`${tot} en la lista`}
function pfScan(){
  PF.raf=0;if(!authUser)return;
  const vk=view+'|'+(sheet&&sheet.kind||'');
  [[$app,'a'],[$sh,'s']].forEach(([root,pre])=>{
    pfCands(root).forEach((c,i)=>{
      const key=vk+'|'+pre+i,a=pfAnchor(c);let box=a.previousElementSibling;
      if(!(box&&box.classList.contains('pfind')&&box.dataset.pfk===key)){
        a.insertAdjacentHTML('beforebegin',`<div class="pfind" data-pfk="${esc(key)}"><span class="tfin"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M15.5 15.5L21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg><input class="in txt pfq" type="search" autocomplete="off" enterkeyhint="search" placeholder="Buscar productor" aria-label="Buscar productor en esta lista"></span><span class="pfn" aria-live="polite"></span></div>`);
        box=a.previousElementSibling;const inp=box.querySelector('input');inp.value=PF.q[key]||'';inp.readOnly=false;
        if(PF.focus&&PF.focus.k===key&&(!document.activeElement||document.activeElement===document.body)){inp.focus();try{inp.setSelectionRange(PF.focus.p,PF.focus.p)}catch(e){}}}
      box._pfc=c;pfApply(box)})})}
function pfSched(){if(!PF.raf)PF.raf=requestAnimationFrame(pfScan)}
document.addEventListener('input',e=>{const t=e.target;if(!t||!t.classList||!t.classList.contains('pfq'))return;e.stopPropagation();const box=t.closest('.pfind');PF.q[box.dataset.pfk]=t.value;PF.focus={k:box.dataset.pfk,p:t.selectionStart||t.value.length};pfApply(box)},true);
document.addEventListener('focusout',e=>{const t=e.target;if(t&&t.classList&&t.classList.contains('pfq'))setTimeout(()=>{if(!document.activeElement||!document.activeElement.classList||!document.activeElement.classList.contains('pfq'))PF.focus=null},0)});
document.addEventListener('keydown',e=>{const t=e.target;if(t&&t.classList&&t.classList.contains('pfq')&&e.key==='Enter'){e.preventDefault();e.stopPropagation();t.blur()}},true);
if(typeof MutationObserver!=='undefined'){const mo=new MutationObserver(pfSched);mo.observe($app,{childList:true,subtree:true});mo.observe($sh,{childList:true,subtree:true})}

if(typeof module!=='undefined'&&module.exports){module.exports={compute,blocks,prodText,isoWeek,codesFrom,searchLista,migrate,nextCons,nextPed,CAL,LISTA,setOrders:v=>{orders=v}}}
else{window.EMP_TEST={buildWkTripsWb,entSinAsignar,pendItems,kgCajaChk,jugCandMoney,saveFile,PESOS:()=>PESOS,DEC:()=>DEC,segSemData:typeof segSemData==='function'?segSemData:null,sentOf,sobPend,sobImport,sobRow,nextTripOf,sobPalMode,sobNoteLines,palNextOk,cvData,cvBuild,cvName,pKey,pCode,clsOf,clsExp,prodSet,rexTripFill,LISTA:()=>LISTA,dv,docMain,setDocVal,docLink,setCur:i=>{curId=i},rexData,rexFile,rexName,REX:()=>REX,xlPages,trailerComposite,fxData,fxExpo,jugData,jugPreview,taxData,polizas,cierreData,CTB:()=>CTB,COB:()=>COB,PAG:()=>PAG,accData,cashKpi,jobData,mermaData,fijoSem,fijoMes,fleteReal,presReal,presOf,PPTO:()=>PPTO,PAR:()=>PAR,CIE:()=>CIE,parsDe,parVer,parMigrate,finEdit,finDesdeDef,curWk,LOG:()=>LOG,FIN:()=>FIN,loadBiExample,addLeftover,prevLeftover,autoPal,palAddSeg,palShort,PER:()=>PER,biCalc,biCtx,buildBiWb,biPages,closeWeek,openWeek,wkOf,jugCandidates,weekKeys,finAgg,seg2Lots,seg2Groups,compute,leftoverOf,prevLeftover,trazCalc,aggregate,statsList,statsData,refPeriod,dbRows,dbCsv,buildRegistroWb,buildTrazWb,buildPackingWb,invData,invFill,addEntradaTest:(n,c)=>{const e=newEntrada(n,c);INV.entradas.push(e);return e},manifestPages,internoPages,packingPages,registroPages,trazPdfPages,pagesToPdf,pagesToPptx,docQty,dbManifiestos,wbBlob,sheetsOf,mainOf,ensureTraz,orders:()=>orders,setOrders:v=>{orders=v;render()},statsF:()=>statsF,resolveProd,setEmp,go:v=>{view=v;render()},touch,doSync,INV:()=>INV,touchE};loadLocal();loadSession();authFromSession();segBoot();applyTheme();render();registerSW();autoInit();segInit()}
})();
