/* Generadores de Excel (ExcelJS). Reciben datos ya calculados y escriben hojas con formato, logotipo y fórmulas vivas.
   Los tres formatos: registro (Formato 1), trazabilidad (Formato 2) y base de datos decorada. */
(function (root) {
  'use strict';
  var XL = {};
  var FN = 'Calibri';
  var NUM = '#,##0;-#,##0;"-"';
  var NUM1 = '#,##0.0;-#,##0.0;"-"';
  var thin = { style: 'thin', color: { argb: 'FF000000' } };
  var hair = { style: 'thin', color: { argb: 'FFB7B7B7' } };
  var med = { style: 'medium', color: { argb: 'FF000000' } };
  var BOX = { top: thin, left: thin, bottom: thin, right: thin };
  var HBOX = { top: hair, left: hair, bottom: hair, right: hair };
  var CAL = [
    { k: 'ctn', l: '230 CTN' }, { k: 'c250', l: '250' }, { k: 'c230', l: '230' }, { k: 'c200', l: '200' },
    { k: 'c175', l: '175' }, { k: 'c150', l: '150' }, { k: 'c110', l: '110' }
  ];
  function fill(rgb) { return { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + rgb } }; }
  function font(o) { return Object.assign({ name: FN, size: 10 }, o || {}); }
  function colL(n) { var s = ''; while (n > 0) { var m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }
  function A(c, r, abs) { return (abs ? '$' : '') + colL(c) + (abs ? '$' : '') + r; }
  function put(ws, r, c, v, st) {
    var cell = ws.getCell(r, c);
    if (v !== undefined && v !== null && v !== '') cell.value = v;
    if (st) {
      if (st.font) cell.font = st.font;
      if (st.fill) cell.fill = st.fill;
      if (st.border) cell.border = st.border;
      if (st.al) cell.alignment = st.al;
      if (st.fmt) cell.numFmt = st.fmt;
    }
    return cell;
  }
  function fx(f, res) { return { formula: f, result: res === undefined ? 0 : res }; }
  function merge(ws, r1, c1, r2, c2) { if (r1 !== r2 || c1 !== c2) ws.mergeCells(r1, c1, r2, c2); }
  function border(ws, r1, c1, r2, c2, b) {
    for (var r = r1; r <= r2; r++) for (var c = c1; c <= c2; c++) ws.getCell(r, c).border = b || BOX;
  }
  function fillRange(ws, r1, c1, r2, c2, f) {
    for (var r = r1; r <= r2; r++) for (var c = c1; c <= c2; c++) ws.getCell(r, c).fill = f;
  }
  var CEN = { horizontal: 'center', vertical: 'middle', wrapText: true };
  var LEFT = { horizontal: 'left', vertical: 'middle' };
  function img(wb, ws, logo, col, row, wpx, hmax) {
    if (!logo || !logo.b64) return;
    var id = wb.addImage({ base64: logo.b64, extension: 'jpeg' });
    var h = Math.round(wpx * (logo.h / logo.w));
    if (hmax && h > hmax) { wpx = Math.round(wpx * hmax / h); h = hmax; }
    ws.addImage(id, { tl: { col: col, row: row }, ext: { width: wpx, height: h } });
  }
  function safeName(wb, n) {
    n = String(n || 'Hoja').replace(/[\\\/\?\*\[\]:]/g, '-').slice(0, 31);
    var base = n, i = 2;
    while (wb.getWorksheet(n)) { n = base.slice(0, 27) + ' (' + i + ')'; i++; }
    return n;
  }
  function dmy(s) { if (!s) return ''; var p = String(s).split('-'); return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : s; }
  function usd(s) { if (!s) return ''; var p = String(s).split('-'); return p.length === 3 ? p[1] + '/' + p[2] + '/' + p[0] : s; }
  function numOrStr(v) { var n = parseFloat(v); return (isFinite(n) && String(n) === String(v).trim()) ? n : (v == null ? '' : v); }

  /* ============ FORMATO 1: REGISTRO DE EMPAQUE ============ */
  /* d: {o, M (resultado de compute), logo:{b64,w,h}, sheetName, estado:'proceso'|'completo', tituloExtra, sobrante} */
  XL.addRegistro = function (wb, d) {
    var o = d.o, M = d.M, n = M.rows.length, kg = M.kg;
    var ws = wb.addWorksheet(safeName(wb, d.sheetName || o.cod), {
      views: [{ showGridLines: false }],
      pageSetup: { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: .3, right: .3, top: .4, bottom: .4, header: .2, footer: .2 } }
    });
    ws.properties.tabColor = { argb: d.estado === 'completo' ? 'FF00B050' : 'FFF08030' };
    var lastCol = Math.max(20, 5 + n);
    var widths = { 1: 3, 2: 27, 3: 12 };
    for (var c = 1; c <= lastCol + 1; c++) ws.getColumn(c).width = widths[c] || 11;
    ws.getColumn(2).width = 27;
    [26, 15, 21, 21, 21, 8, 24, 34].forEach(function (h, i) { ws.getRow(i + 1).height = h; });

    /* encabezado */
    img(wb, ws, d.logo, 1, 0, 150, 100);
    put(ws, 2, 16, 'DATE', { font: font({ size: 13, bold: true }), al: { horizontal: 'right', vertical: 'middle' } });
    merge(ws, 2, 17, 2, 18);
    put(ws, 2, 17, d.fechaDate || dmy(o.fecha), { font: font({ size: 14, bold: true }), fill: fill('FFEB9C'), al: CEN, border: BOX });
    ws.getCell(2, 18).border = BOX; ws.getCell(2, 18).fill = fill('FFEB9C');
    put(ws, 3, 4, 'CUSTOMER:', { font: font({ size: 12, bold: true }) });
    merge(ws, 3, 6, 3, 11); put(ws, 3, 6, o.customer || '', { font: font({ size: 12, bold: true }), al: LEFT });
    put(ws, 4, 4, 'Domestic Customer:', { font: font({ size: 12, bold: true }) });
    merge(ws, 4, 6, 4, 11); put(ws, 4, 6, o.domestic || '', { font: font({ size: 12, bold: true }), al: LEFT });
    put(ws, 3, 14, 'Factura', { font: font({ size: 12, bold: true }) });
    merge(ws, 3, 15, 3, 16); put(ws, 3, 15, o.factura || '', { font: font({ size: 12, bold: true }), al: LEFT });
    put(ws, 4, 14, 'PO', { font: font({ size: 12, bold: true }) });
    merge(ws, 4, 15, 4, 16); put(ws, 4, 15, numOrStr(o.po || ''), { font: font({ size: 12, bold: true }), al: LEFT });
    put(ws, 5, 14, 'KG/CAJA', { font: font({ size: 9, bold: true, color: { argb: 'FF555555' } }) });
    merge(ws, 5, 15, 5, 16);
    put(ws, 5, 15, kg, { font: font({ size: 11, bold: true, color: { argb: 'FF0000FF' } }), fill: fill('FFF2CC'), al: CEN, border: BOX, fmt: '0.0' });
    var KG = A(15, 5, true);
    put(ws, 3, 18, 'SEMANA', { font: font({ size: 13, bold: true }), al: { horizontal: 'right', vertical: 'middle' } });
    put(ws, 3, 19, numOrStr(o.semana), { font: font({ size: 13, bold: true }), fill: fill('F4B183'), al: CEN, border: BOX });
    put(ws, 4, 18, o.cod || '', { font: font({ size: 13, bold: true }), al: { horizontal: 'right', vertical: 'middle' } });
    put(ws, 4, 19, o.emb || '', { font: font({ size: 11, bold: true }), al: LEFT });
    var enProceso = d.estado !== 'completo';
    merge(ws, 5, 18, 5, 20);
    put(ws, 5, 18, enProceso ? 'EN PROCESO' : 'COMPLETO', { font: font({ size: 11, bold: true, color: { argb: enProceso ? 'FF9C5700' : 'FF006100' } }), fill: fill(enProceso ? 'FFEB9C' : 'C6EFCE'), al: CEN, border: BOX });

    /* tabla superior: acumulado por calibre */
    var R_T = 7, R_H = 8, R0 = 9, R_TOT = 16, R_INC = 17;
    var cP = 3, cF = 3 + n, cM = cF + 1, cS = cF + 2; /* si n=0 las columnas de resumen empiezan en 3 */
    var title = (d.titulo || o.cod) + (o.variante === '1.5' ? '  ·  1.5 (segunda)' : '');
    var tcEnd = n > 0 ? 2 + n : 3;
    merge(ws, R_T, 3, R_T, Math.max(tcEnd, 3));
    put(ws, R_T, 3, title, { font: font({ size: 20, bold: true }), fill: fill('D5FC79'), al: CEN, border: BOX });
    fillRange(ws, R_T, 3, R_T, Math.max(tcEnd, 3), fill('D5FC79'));
    put(ws, R_T, 2, '', { fill: fill('D5FC79'), border: BOX });
    ws.getRow(R_T).height = 30;
    put(ws, R_H, 2, 'CALIBRE', { font: font({ size: 10, bold: true }), fill: fill('D5FC79'), al: CEN, border: BOX });
    M.rows.forEach(function (r, i) {
      put(ws, R_H, cP + i, r.p.nombre || ('Productor ' + (i + 1)), { font: font({ size: 8, bold: true }), fill: fill('D5FC79'), al: CEN, border: BOX });
    });
    put(ws, R_H, cF, 'ACUMULADO FINAL', { font: font({ size: 8, bold: true }), fill: fill('D5FC79'), al: CEN, border: BOX });
    put(ws, R_H, cM, 'MANIFIESTO', { font: font({ size: 9, bold: true }), fill: fill('65FB27'), al: CEN, border: BOX });
    put(ws, R_H, cS, 'SOBRANTES', { font: font({ size: 9, bold: true }), fill: fill('F4B183'), al: CEN, border: BOX });
    if (n === 0) { /* sin productores: el acumulado final queda al lado */ }
    ws.getRow(R_H).height = 36;
    CAL.forEach(function (c, ci) {
      var r = R0 + ci;
      put(ws, r, 2, c.l, { font: font({ size: 11, bold: true }), fill: ci === 0 ? fill('FFFF00') : undefined, al: CEN, border: BOX });
      M.rows.forEach(function (x, i) {
        put(ws, r, cP + i, x.eff[c.k], { font: font({ size: 11 }), fill: fill('D9D9D9'), al: CEN, border: BOX, fmt: NUM });
      });
      put(ws, r, cF, n > 0 ? fx(A(cP + n - 1, r), M.final[c.k]) : 0, { font: font({ size: 11, bold: true }), fill: fill('EDEDED'), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, cM, M.man[c.k] == null ? null : M.man[c.k], { font: font({ size: 11, bold: true, color: { argb: 'FF0000FF' } }), fill: fill('CCECFF'), al: CEN, border: BOX, fmt: NUM });
      var sob = M.man[c.k] == null ? '' : M.final[c.k] - M.man[c.k];
      put(ws, r, cS, fx('IF(ISNUMBER(' + A(cM, r) + '),' + A(cF, r) + '-' + A(cM, r) + ',"")', sob), { font: font({ size: 11, bold: true }), fill: fill('B4E5A2'), al: CEN, border: BOX, fmt: '#,##0;-#,##0;"-"' });
    });
    put(ws, R_TOT, 2, 'TOTAL', { font: font({ size: 11, bold: true }), fill: fill('E27EDB'), al: CEN, border: BOX });
    var span = n + 3;
    for (var j = 0; j < span; j++) {
      var cc = cP + j, colSum = 0;
      if (j < n) { CAL.forEach(function (c) { colSum += M.rows[j].eff[c.k]; }); }
      else if (j === n) colSum = M.finT;
      else if (j === n + 1) colSum = M.manT;
      else colSum = M.finT - M.manT;
      var isS = j === n + 2;
      var f = isS ? A(cF, R_TOT) + '-' + A(cM, R_TOT) : 'SUM(' + A(cc, R0) + ':' + A(cc, R0 + 6) + ')';
      put(ws, R_TOT, cc, fx(f, colSum), { font: font({ size: 11, bold: true }), fill: fill(j === n + 1 ? 'F4B183' : 'E27EDB'), al: CEN, border: BOX, fmt: NUM });
    }
    put(ws, R_INC, 2, 'Aporte del productor', { font: font({ size: 8, italic: true, color: { argb: 'FF555555' } }), al: { horizontal: 'right', vertical: 'middle' } });
    M.rows.forEach(function (x, i) {
      var f = i === 0 ? A(cP, R_TOT) : A(cP + i, R_TOT) + '-' + A(cP + i - 1, R_TOT);
      put(ws, R_INC, cP + i, fx(f, x.t), { font: font({ size: 9, italic: true, color: { argb: 'FF555555' } }), fill: fill('DDEBF7'), al: CEN, fmt: NUM });
    });

    /* tabla inferior */
    var R_BH = 20, B0 = 21;
    ['PRODUCTOR', 'CODIGO DE TRAZABILIDAD', 'CAJAS 24KL', 'CAJAS 18KL', 'KILOS', 'CAJAS CAMPO', '230 CTN', '250', '230', '200', '175', '150', '110', 'TOTAL LIMON EXPORTACION', 'SEGUNDAS LIMON NACIONAL', 'TORREON / 275s', 'DESECHO', 'RENDIMIENTO 1RAS', 'DIFERENCIA'].forEach(function (h, i) {
      put(ws, R_BH, 2 + i, h, { font: font({ size: 9, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('000000'), al: CEN, border: BOX });
    });
    ws.getRow(R_BH).height = 42;
    var cCamp = 7;
    M.rows.forEach(function (x, i) {
      var r = B0 + 2 * i, kil = (x.p.kilos == null || x.p.kilos === '') ? null : +x.p.kilos;
      ws.getRow(r).height = 22; ws.getRow(r + 1).height = 15;
      put(ws, r, 2, x.p.nombre || ('Productor ' + (i + 1)), { font: font({ size: 10, bold: true }), fill: fill('D9D9D9'), al: { horizontal: 'left', vertical: 'middle', wrapText: true }, border: BOX });
      put(ws, r, 3, x.p.codigo ? (o.emp + '-' + String(x.p.codigo).padStart(3, '0')) : 0, { font: font({ size: 10, bold: true, color: { argb: 'FFFF0000' } }), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 4, x.p.k24 == null ? null : +x.p.k24, { font: font({ size: 11, bold: true }), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 5, x.p.k18 == null ? null : +x.p.k18, { font: font({ size: 11, bold: true }), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 6, kil, { font: font({ size: 11, bold: true }), al: CEN, border: BOX, fmt: NUM1 });
      put(ws, r, 7, fx('IF(' + A(6, r) + '>0,' + A(6, r) + '/' + KG + ',0)', kil ? kil / kg : 0), { font: font({ size: 11, bold: true }), al: CEN, border: BOX, fmt: NUM1 });
      CAL.forEach(function (c, ci) {
        var tr = R0 + ci, f = i === 0 ? A(cP, tr) : A(cP + i, tr) + '-' + A(cP + i - 1, tr);
        put(ws, r, 8 + ci, fx(f, x.delta[c.k]), { font: font({ size: 11 }), al: CEN, border: BOX, fmt: NUM });
      });
      put(ws, r, 15, fx('SUM(' + A(8, r) + ':' + A(14, r) + ')', x.t), { font: font({ size: 11, bold: true }), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 16, x.p.seg == null ? null : +x.p.seg, { font: font({ size: 11 }), fill: fill('D9D9D9'), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 17, x.p.tor == null ? null : +x.p.tor, { font: font({ size: 11 }), fill: fill('D9D9D9'), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 18, x.p.des == null ? null : +x.p.des, { font: font({ size: 11 }), fill: fill('D9D9D9'), al: CEN, border: BOX, fmt: NUM });
      var rr = r;
      put(ws, r, 19, fx('IF(' + A(7, rr) + '>0,(SUM(' + A(9, rr) + ':' + A(14, rr) + ')+' + A(8, rr) + '*16/' + KG + ')/' + A(7, rr) + ',"")', x.rend == null ? '' : x.rend), { font: font({ size: 11, bold: true, color: { argb: 'FFFF0000' } }), al: CEN, border: BOX, fmt: '0.0%' });
      put(ws, r, 20, fx('IF(' + A(7, rr) + '>0,' + A(7, rr) + '-' + A(15, rr) + '-' + A(16, rr) + '-' + A(17, rr) + '-' + A(18, rr) + ',"")', x.dif == null ? '' : x.dif), { font: font({ size: 11, bold: true, color: { argb: 'FFFF0000' } }), al: CEN, border: BOX, fmt: '#,##0.0;-#,##0.0;"-"' });
      merge(ws, r + 1, 2, r + 1, 20);
      put(ws, r + 1, 2, x.p.nota ? ('Notas: ' + x.p.nota) : '', { font: font({ size: 9, italic: true, color: { argb: 'FF444444' } }), al: { horizontal: 'left', vertical: 'middle', wrapText: true } });
      border(ws, r + 1, 2, r + 1, 20, HBOX);
    });
    var rowsEnd = B0 + 2 * n - 1;      /* última fila de captura */
    var RT = n > 0 ? rowsEnd + 1 : B0;   /* fila de totales */
    var a = B0, b = Math.max(rowsEnd, B0);
    put(ws, RT, 2, 'TOTAL', { font: font({ size: 11, bold: true }), al: CEN, fill: fill('EDEDED'), border: BOX });
    put(ws, RT, 3, '', { fill: fill('EDEDED'), border: BOX });
    var tk = M.tot;
    var sums = { 4: tk.k24, 5: tk.k18, 6: tk.kilos, 8: M.final.ctn, 9: M.final.c250, 10: M.final.c230, 11: M.final.c200, 12: M.final.c175, 13: M.final.c150, 14: M.final.c110, 15: tk.exp, 16: tk.seg, 17: tk.tor, 18: tk.des };
    var campoTot = 0; M.rows.forEach(function (x) { campoTot += x.campo || 0; });
    sums[7] = campoTot;
    Object.keys(sums).forEach(function (k) {
      var c = +k;
      put(ws, RT, c, fx(n > 0 ? 'SUM(' + A(c, a) + ':' + A(c, b) + ')' : '0', n > 0 ? sums[c] : 0), { font: font({ size: 11, bold: true }), al: CEN, fill: fill('EDEDED'), border: BOX, fmt: c === 6 || c === 7 ? NUM1 : NUM });
    });
    var G = A(7, a) + ':' + A(7, b);
    var inner = [9, 10, 11, 12, 13, 14].map(function (c) { return A(c, a) + ':' + A(c, b); });
    var wres = '';
    var totEqv = 0, totCampoR = 0; M.rows.forEach(function (x) { if (x.rend != null) { totEqv += x.eqv; totCampoR += x.campo; } });
    var numer = 'SUMPRODUCT((' + G + '>0)*(' + inner.join('+') + '))+SUMPRODUCT((' + G + '>0)*' + A(8, a) + ':' + A(8, b) + ')*16/' + KG;
    put(ws, RT, 19, fx(n > 0 ? 'IF(SUMIF(' + G + ',">0")>0,(' + numer + ')/SUMIF(' + G + ',">0"),"")' : '""', totCampoR > 0 ? totEqv / totCampoR : ''), { font: font({ size: 11, bold: true, color: { argb: 'FFFF0000' } }), al: CEN, fill: fill('EDEDED'), border: BOX, fmt: '0.0%' });
    var difTot = 0; M.rows.forEach(function (x) { if (x.dif != null) difTot += x.dif; });
    put(ws, RT, 20, fx(n > 0 ? 'SUM(' + A(20, a) + ':' + A(20, b) + ')' : '0', difTot), { font: font({ size: 11, bold: true, color: { argb: 'FFFF0000' } }), al: CEN, fill: fill('EDEDED'), border: BOX, fmt: '#,##0.0;-#,##0.0;"-"' });
    ws.getRow(RT).height = 22;
    /* kilos / boxes / total export lemon, como en el formato original */
    var rk = RT + 2, rb = RT + 3, rl = RT + 5;
    put(ws, rk, 14, 'KILOS', { font: font({ size: 10, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('000000'), al: CEN });
    put(ws, rb, 14, 'BOXES', { font: font({ size: 12, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('00B050'), al: CEN });
    [[15, tk.exp], [16, tk.seg], [17, tk.tor], [18, tk.des]].forEach(function (q) {
      var c = q[0];
      put(ws, rk, c, fx(A(c, RT) + '*18', q[1] * 18), { font: font({ size: 10, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('000000'), al: CEN, fmt: NUM });
      put(ws, rb, c, fx(A(c, rk) + '/18', q[1]), { font: font({ size: 12, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('00B050'), al: CEN, fmt: NUM });
    });
    put(ws, rl - 1, 15, 'EXPORTADO', { font: font({ size: 8, bold: true, color: { argb: 'FF555555' } }), al: CEN });
    put(ws, rl - 1, 16, 'MANIFIESTO', { font: font({ size: 8, bold: true, color: { argb: 'FF555555' } }), al: CEN });
    put(ws, rl - 1, 17, 'DIFERENCIA', { font: font({ size: 8, bold: true, color: { argb: 'FF555555' } }), al: CEN });
    merge(ws, rl, 12, rl, 14);
    put(ws, rl, 12, 'TOTAL EXPORT LEMON', { font: font({ size: 12, bold: true }), fill: fill('92D050'), al: CEN, border: BOX });
    fillRange(ws, rl, 12, rl, 14, fill('92D050'));
    put(ws, rl, 15, fx(A(15, RT), tk.exp), { font: font({ size: 12, bold: true }), fill: fill('D5FC79'), al: CEN, border: BOX, fmt: NUM });
    put(ws, rl, 16, fx(A(cM, R_TOT), M.manT), { font: font({ size: 12, bold: true }), al: CEN, border: BOX, fmt: NUM });
    put(ws, rl, 17, fx(A(15, rl) + '-' + A(16, rl), tk.exp - M.manT), { font: font({ size: 12, bold: true }), fill: fill('FFFF00'), al: CEN, border: BOX, fmt: '#,##0;-#,##0;"-"' });
    ws.getRow(rl).height = 24;
    if (d.sobrante && d.sobrante.total > 0) {
      put(ws, rl + 2, 2, 'Sobrante para el siguiente pedido: ' + d.sobrante.text, { font: font({ size: 10, bold: true, color: { argb: 'FF9C5700' } }) });
    }
    ws.pageSetup.printArea = 'A1:' + colL(Math.max(20, cS)) + (rl + 3);
    return ws;
  };

  /* ============ FORMATO 2: CÓDIGO DE TRAZABILIDAD ============ */
  /* d: {o, hdr, pallets:[{n,marca,lines:[{cal,cant,prod}]}], borrador, motivos[], logo, trailer:{b64,w,h}, sheetName, full} */
  XL.addTraz = function (wb, d) {
    var o = d.o, h = d.hdr || {};
    var ws = wb.addWorksheet(safeName(wb, d.sheetName || o.emb || 'TRAZABILIDAD'), {
      views: [{ showGridLines: false }],
      pageSetup: { orientation: 'portrait', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: .3, right: .3, top: .3, bottom: .3, header: .1, footer: .1 } }
    });
    ws.properties.tabColor = { argb: d.borrador ? 'FFC00000' : 'FF00B050' };
    [7, 17, 9, 10, 9, 13, 2.5, 7, 17, 9, 10, 9, 13, 2.5, 12, 12, 12].forEach(function (w, i) { ws.getColumn(i + 1).width = w; });
    var LB = font({ size: 10, bold: true }), VAL = font({ size: 10 });
    merge(ws, 1, 1, 1, 6);
    put(ws, 1, 1, 'CODIGO DE TRAZABILIDAD', { font: font({ size: 15, bold: true }), al: CEN });
    ws.getRow(1).height = 24;
    if (d.borrador) {
      merge(ws, 1, 8, 1, 13);
      put(ws, 1, 8, 'BORRADOR', { font: font({ size: 18, bold: true, color: { argb: 'FFC00000' } }), fill: fill('FDE9E7'), al: CEN, border: { top: med, left: med, bottom: med, right: med } });
    } else if (d.full !== undefined) {
      merge(ws, 1, 8, 1, 13);
      put(ws, 1, 8, d.full ? 'PEDIDO FULL' : 'PEDIDO PARCIAL', { font: font({ size: 12, bold: true, color: { argb: d.full ? 'FF006100' : 'FF9C5700' } }), fill: fill(d.full ? 'C6EFCE' : 'FFEB9C'), al: CEN, border: BOX });
    }
    var L = [['Factura#:', h.factura || o.factura], ['Proveedor:', h.proveedor], ['Vendedor:', h.vendedor], ['Tel:', h.tel]];
    L.forEach(function (p, i) {
      var r = 2 + i;
      merge(ws, r, 1, r, 2); put(ws, r, 1, p[0], { font: LB, al: LEFT, border: BOX });
      merge(ws, r, 3, r, 6); put(ws, r, 3, numOrStr(p[1] || ''), { font: VAL, al: LEFT, border: BOX });
      ws.getRow(r).height = 15;
    });
    var Rr = [['PO# CLIENTE:', h.poCliente || o.po], ['Cliente:', h.cliente || o.customer], ['P. Order', h.pOrder], ['SELLO', h.sello]];
    Rr.forEach(function (p, i) {
      var r = 2 + i;
      merge(ws, r, 8, r, 9); put(ws, r, 8, p[0], { font: LB, al: LEFT, border: BOX });
      merge(ws, r, 10, r, 13); put(ws, r, 10, numOrStr(p[1] || ''), { font: font({ size: 10, bold: true }), al: LEFT, border: BOX });
    });
    put(ws, 6, 1, '', {}); ws.getRow(6).height = 6;
    img(wb, ws, d.logo, 0, 6, 128, 82);
    var T = [['Transporte:', h.transporte], ['Teléfono:', h.telTransporte], ['Conductor:', h.conductor], ['PLACAS:', h.placas], ['#CAJA:', h.caja]];
    T.forEach(function (p, i) {
      var r = 7 + i;
      merge(ws, r, 5, r, 6); put(ws, r, 5, p[0], { font: LB, al: { horizontal: 'right', vertical: 'middle' } });
      merge(ws, r, 8, r, 13); put(ws, r, 8, numOrStr(p[1] || ''), { font: font({ size: 10 }), al: LEFT, border: { bottom: hair } });
      ws.getRow(r).height = 15;
    });
    ws.getRow(12).height = 8;
    /* cabecera de la tabla de tarimas (dos grupos de columnas) */
    var HR = 13;
    [[1, 'PALLET'], [2, 'MARCA'], [3, 'CALIBRE'], [4, 'CANTIDAD'], [8, 'PALLET'], [9, 'MARCA'], [10, 'CALIBRE'], [11, 'CANTIDAD']].forEach(function (p) {
      merge(ws, HR, p[0], HR + 1, p[0]);
      put(ws, HR, p[0], p[1], { font: font({ size: 8, bold: true }), fill: fill('D9D9D9'), al: CEN, border: BOX });
      ws.getCell(HR + 1, p[0]).border = BOX;
    });
    [[5, 'CODIGO DE TRAZABILIDAD'], [12, 'CODIGO DE TRAZABILIDAD']].forEach(function (p) {
      merge(ws, HR, p[0], HR, p[0] + 1);
      put(ws, HR, p[0], p[1], { font: font({ size: 8, bold: true }), fill: fill('D9D9D9'), al: CEN, border: BOX });
      ws.getCell(HR, p[0] + 1).border = BOX;
      put(ws, HR + 1, p[0], 'CAJAS', { font: font({ size: 8, bold: true }), fill: fill('D9D9D9'), al: CEN, border: BOX });
      put(ws, HR + 1, p[0] + 1, 'CODIGO', { font: font({ size: 8, bold: true }), fill: fill('D9D9D9'), al: CEN, border: BOX });
    });
    ws.getRow(HR).height = 14; ws.getRow(HR + 1).height = 14;
    var pal = d.pallets || [], total = 0;
    pal.forEach(function (p) { p.lines = (p.lines && p.lines.length) ? p.lines : [{ cal: '', cant: null, prod: '' }]; total += p.lines.length; });
    /* reparte las tarimas en dos grupos con filas parecidas */
    var left = [], right = [], acc = 0;
    pal.forEach(function (p) { if (acc < total / 2 && left.length < pal.length) { left.push(p); acc += p.lines.length; } else right.push(p); });
    var firstRow = HR + 2, sumCells = { 1: [], 2: [] };
    function draw(list, c0, gi) {
      var r = firstRow;
      list.forEach(function (p) {
        var n = p.lines.length, r2 = r + n - 1, tot = 0;
        p.lines.forEach(function (l) { tot += +l.cant || 0; });
        merge(ws, r, c0, r2, c0); merge(ws, r, c0 + 1, r2, c0 + 1); merge(ws, r, c0 + 3, r2, c0 + 3);
        put(ws, r, c0, p.n, { font: font({ size: 10, bold: true }), al: CEN, border: BOX });
        put(ws, r, c0 + 1, p.marca || '', { font: font({ size: 8, bold: true }), al: CEN, border: BOX });
        var ok = tot === 50 || tot === 54 || tot === 55 || tot === 60;
        var dFill = (tot > 0 && !ok) ? fill('FCE4D6') : undefined;
        put(ws, r, c0 + 3, fx('SUM(' + A(c0 + 4, r) + ':' + A(c0 + 4, r2) + ')', tot), { font: font({ size: 10, bold: true }), fill: dFill, al: CEN, border: BOX, fmt: NUM });
        sumCells[gi].push(A(c0 + 3, r));
        p.lines.forEach(function (l, i) {
          var rr = r + i;
          ws.getRow(rr).height = 13.5;
          put(ws, rr, c0 + 2, numOrStr(l.cal || ''), { font: font({ size: 9, bold: true }), al: CEN, border: BOX });
          put(ws, rr, c0 + 4, l.cant == null || l.cant === '' ? null : +l.cant, { font: font({ size: 9, bold: true }), al: CEN, border: BOX, fmt: NUM });
          put(ws, rr, c0 + 5, l.prod || '', { font: font({ size: 9, bold: true }), al: CEN, border: BOX });
        });
        for (var c = c0; c <= c0 + 5; c++) { var cell = ws.getCell(r2, c), b = Object.assign({}, cell.border || BOX); b.bottom = med; cell.border = b; }
        r = r2 + 1;
      });
      return r;
    }
    var e1 = draw(left, 1, 1), e2 = draw(right, 8, 2);
    var end = Math.max(e1, e2, firstRow + 1);
    /* pie: totales */
    var tr = end + 1, all = sumCells[1].concat(sumCells[2]);
    var cant = 0; pal.forEach(function (p) { p.lines.forEach(function (l) { cant += +l.cant || 0; }); });
    merge(ws, tr, 1, tr, 3); put(ws, tr, 1, 'TOTAL TARIMAS', { font: LB, fill: fill('D9D9D9'), al: CEN, border: BOX });
    put(ws, tr, 4, pal.length, { font: LB, al: CEN, border: BOX });
    merge(ws, tr + 1, 1, tr + 1, 3); put(ws, tr + 1, 1, 'TOTAL CAJAS', { font: LB, fill: fill('D9D9D9'), al: CEN, border: BOX });
    put(ws, tr + 1, 4, fx(all.length ? all.join('+') : '0', cant), { font: LB, al: CEN, border: BOX, fmt: NUM });
    if (d.motivos && d.motivos.length) {
      merge(ws, tr + 3, 1, tr + 3, 13);
      put(ws, tr + 3, 1, 'Pendiente para completar: ' + d.motivos.join(' · '), { font: font({ size: 9, italic: true, color: { argb: 'FFC00000' } }), al: { horizontal: 'left', vertical: 'middle', wrapText: true } });
      ws.getRow(tr + 3).height = 28;
    }
    /* diagrama de la caja */
    if (d.trailer && d.trailer.b64) {
      var id = wb.addImage({ base64: d.trailer.b64, extension: 'png' });
      ws.addImage(id, { tl: { col: 14, row: 6 }, ext: { width: d.trailer.w, height: d.trailer.h } });
    }
    ws.pageSetup.printArea = 'A1:' + (d.trailer ? 'Q' : 'M') + (tr + 4);
    d._lastRow = end;
    return ws;
  };

  /* Resumen: tarimas contra lo empacado, por productor (fórmulas SUMIFS sobre la hoja de trazabilidad) */
  XL.addResumen = function (wb, d) {
    var ws = wb.addWorksheet(safeName(wb, 'Resumen ' + (d.o.cod || '')), { views: [{ showGridLines: false, state: 'frozen', ySplit: 4 }], pageSetup: { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
    ws.getColumn(1).width = 30; ws.getColumn(2).width = 13;
    for (var c = 3; c <= 14; c++) ws.getColumn(c).width = 11;
    merge(ws, 1, 1, 1, 12);
    put(ws, 1, 1, 'Resumen de tarimas · ' + (d.o.cod || '') + ' · ' + (d.o.emb || ''), { font: font({ size: 15, bold: true }), al: LEFT });
    put(ws, 2, 1, d.borrador ? 'BORRADOR: todavía falta cargar o revisar tarimas.' : 'Tarimas completas.', { font: font({ size: 10, bold: true, color: { argb: d.borrador ? 'FFC00000' : 'FF006100' } }) });
    var heads = ['PRODUCTOR', 'CODIGO'].concat(CAL.map(function (c) { return c.l; }), ['EN TARIMAS', 'EMPACADO', 'DIFERENCIA']);
    heads.forEach(function (t, i) { put(ws, 4, 1 + i, t, { font: font({ size: 9, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('1B2C46'), al: CEN, border: BOX }); });
    ws.getRow(4).height = 28;
    var sn = "'" + d.trazSheet.replace(/'/g, "''") + "'!";
    var L = 'C', R = 'F';
    function rng(col) { return sn + '$' + col + '$15:$' + col + '$400'; }
    d.productores.forEach(function (p, i) {
      var r = 5 + i;
      put(ws, r, 1, p.nombre, { font: font({ size: 10 }), border: BOX });
      put(ws, r, 2, p.key, { font: font({ size: 10, bold: true }), al: CEN, border: BOX });
      CAL.forEach(function (c, ci) {
        var crit = c.l === '230 CTN' ? '"230 CTN"' : c.l;
        var f = 'SUMIFS(' + rng('E') + ',' + rng('F') + ',$B' + r + ',' + rng('C') + ',' + crit + ')+SUMIFS(' + rng('L') + ',' + rng('M') + ',$B' + r + ',' + rng('J') + ',' + crit + ')';
        put(ws, r, 3 + ci, fx(f, p.pal[c.k] || 0), { font: font({ size: 10 }), al: CEN, border: BOX, fmt: NUM });
      });
      put(ws, r, 10, fx('SUM(C' + r + ':I' + r + ')', p.palTot), { font: font({ size: 10, bold: true }), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 11, p.emp, { font: font({ size: 10 }), al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 12, fx('J' + r + '-K' + r, p.palTot - p.emp), { font: font({ size: 10, bold: true, color: { argb: 'FFC00000' } }), al: CEN, border: BOX, fmt: '#,##0;-#,##0;"-"' });
    });
    var last = 4 + d.productores.length, tr = last + 1;
    put(ws, tr, 1, 'TOTAL', { font: font({ size: 10, bold: true }), fill: fill('EDEDED'), border: BOX });
    put(ws, tr, 2, '', { fill: fill('EDEDED'), border: BOX });
    for (var c2 = 3; c2 <= 12; c2++) {
      var tot = 0;
      d.productores.forEach(function (p) { if (c2 <= 9) tot += p.pal[CAL[c2 - 3].k] || 0; else if (c2 === 10) tot += p.palTot; else if (c2 === 11) tot += p.emp; else tot += p.palTot - p.emp; });
      put(ws, tr, c2, fx(d.productores.length ? 'SUM(' + A(c2, 5) + ':' + A(c2, last) + ')' : '0', tot), { font: font({ size: 10, bold: true }), fill: fill('EDEDED'), al: CEN, border: BOX, fmt: NUM });
    }
    put(ws, tr + 1, 1, 'El sobrante empacado por encima del manifiesto no se tarima: pasa al siguiente pedido.', { font: font({ size: 8, italic: true, color: { argb: 'FF555555' } }) });
    var r0 = tr + 4;
    put(ws, r0 - 1, 1, 'POR CALIBRE Y CALIDAD', { font: font({ size: 11, bold: true }) });
    ['CALIBRE', 'POR TARIMAR 1RA', 'TARIMAS 1RA', 'POR TARIMAR 1.5', 'TARIMAS 1.5', 'DIFERENCIA'].forEach(function (t, i) { put(ws, r0, 1 + i, t, { font: font({ size: 9, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('1B2C46'), al: CEN, border: BOX }); });
    d.calibres.forEach(function (x, i) {
      var r = r0 + 1 + i;
      put(ws, r, 1, x.l, { font: font({ size: 10, bold: true }), al: CEN, border: BOX });
      put(ws, r, 2, x.e1, { al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 3, x.p1, { al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 4, x.e15, { al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 5, x.p15, { al: CEN, border: BOX, fmt: NUM });
      put(ws, r, 6, fx('(C' + r + '+E' + r + ')-(B' + r + '+D' + r + ')', x.p1 + x.p15 - x.e1 - x.e15), { font: font({ bold: true, color: { argb: 'FFC00000' } }), al: CEN, border: BOX, fmt: '#,##0;-#,##0;"-"' });
    });
    return ws;
  };

  /* ============ BASE DE DATOS DECORADA ============ */
  /* d: {cols:[{h,w,k,fmt}], rows:[{...}], pr:[...resumen productores], cal:[...resumen calibres], titulo, logo} */
  XL.addBase = function (wb, d) {
    var ws = wb.addWorksheet('Base de datos', { views: [{ state: 'frozen', xSplit: 3, ySplit: 4, showGridLines: false }] });
    merge(ws, 1, 1, 1, 8);
    put(ws, 1, 1, d.titulo || 'Base de datos de empaque', { font: font({ size: 16, bold: true, color: { argb: 'FF1B2C46' } }), al: LEFT });
    ws.getRow(1).height = 26;
    put(ws, 2, 1, d.sub || '', { font: font({ size: 9, italic: true, color: { argb: 'FF555555' } }) });
    d.cols.forEach(function (c, i) {
      ws.getColumn(i + 1).width = c.w || 11;
      put(ws, 4, i + 1, c.h, { font: font({ size: 9, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill(c.grp === 'cal' ? '4F6B0A' : c.grp === 'out' ? '9C5700' : '1B2C46'), al: CEN, border: BOX });
    });
    ws.getRow(4).height = 34;
    d.rows.forEach(function (row, ri) {
      var r = 5 + ri, zebra = ri % 2 ? fill('F2F5F0') : undefined;
      d.cols.forEach(function (c, i) {
        var v = row[c.k]; if (v === undefined) v = null;
        put(ws, r, i + 1, v, { font: font({ size: 10 }), fill: zebra, al: c.al ? { horizontal: c.al, vertical: 'middle' } : { vertical: 'middle' }, border: HBOX, fmt: c.fmt });
      });
    });
    var last = 4 + Math.max(d.rows.length, 1);
    ws.autoFilter = { from: { row: 4, column: 1 }, to: { row: last, column: d.cols.length } };
    if (d.pr) {
      var w2 = wb.addWorksheet('Por productor', { views: [{ state: 'frozen', ySplit: 4, showGridLines: false }] });
      merge(w2, 1, 1, 1, 8); put(w2, 1, 1, 'Resumen por productor (rendimiento ponderado)', { font: font({ size: 16, bold: true, color: { argb: 'FF1B2C46' } }) });
      var hs = ['PRODUCTOR', 'CODIGO', 'PEDIDOS', 'KILOS', 'CAJAS EXPORTACION', 'SEGUNDAS', 'TORREON', 'DESECHO', 'RENDIMIENTO 1RAS'];
      var ws2 = [32, 10, 10, 12, 14, 11, 11, 11, 14];
      hs.forEach(function (t, i) { w2.getColumn(i + 1).width = ws2[i]; put(w2, 4, i + 1, t, { font: font({ size: 9, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('1B2C46'), al: CEN, border: BOX }); });
      w2.getRow(4).height = 30;
      d.pr.forEach(function (p, i) {
        var r = 5 + i, z = i % 2 ? fill('F2F5F0') : undefined;
        [p.nombre, p.codigo, p.pedidos, p.kilos, p.exp, p.seg, p.tor, p.des, p.rend].forEach(function (v, k) {
          put(w2, r, k + 1, v == null ? null : v, { font: font({ size: 10, bold: k === 8 }), fill: z, border: HBOX, al: k === 0 ? LEFT : { horizontal: 'center', vertical: 'middle' }, fmt: k === 8 ? '0.0%' : (k >= 3 ? NUM : undefined) });
        });
      });
      w2.autoFilter = { from: { row: 4, column: 1 }, to: { row: 4 + Math.max(d.pr.length, 1), column: 9 } };
    }
    if (d.cal) {
      var w3 = wb.addWorksheet('Por calibre', { views: [{ showGridLines: false }] });
      merge(w3, 1, 1, 1, 6); put(w3, 1, 1, 'Distribución por calibre', { font: font({ size: 16, bold: true, color: { argb: 'FF1B2C46' } }) });
      ['CALIBRE', 'CAJAS', '% DE EXPORTACION'].forEach(function (t, i) { w3.getColumn(i + 1).width = [14, 14, 18][i]; put(w3, 3, i + 1, t, { font: font({ size: 9, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('4F6B0A'), al: CEN, border: BOX }); });
      d.cal.forEach(function (c, i) {
        var r = 4 + i;
        put(w3, r, 1, c.l, { font: font({ bold: true }), al: CEN, border: HBOX });
        put(w3, r, 2, c.n, { al: CEN, border: HBOX, fmt: NUM });
        put(w3, r, 3, fx(A(2, r) + '/SUM($B$4:$B$' + (3 + d.cal.length) + ')', c.pct), { al: CEN, border: HBOX, fmt: '0.0%' });
      });
    }
    (d.extra || []).forEach(function (x) {
      var w = wb.addWorksheet(x.name, { views: [{ state: 'frozen', ySplit: 3, showGridLines: false }] });
      merge(w, 1, 1, 1, 6); put(w, 1, 1, x.name, { font: font({ size: 16, bold: true, color: { argb: 'FF1B2C46' } }) });
      x.cols.forEach(function (c, i) { w.getColumn(i + 1).width = c.w || 11; put(w, 3, i + 1, c.h, { font: font({ size: 9, bold: true, color: { argb: 'FFFFFFFF' } }), fill: fill('1B2C46'), al: CEN, border: BOX }); });
      x.rows.forEach(function (row, ri) {
        x.cols.forEach(function (c, i) { var v = row[c.k]; put(w, 4 + ri, i + 1, v === undefined ? null : v, { font: font({ size: 10 }), fill: ri % 2 ? fill('F2F5F0') : undefined, border: HBOX, al: c.al ? { horizontal: c.al, vertical: 'middle' } : { vertical: 'middle' }, fmt: c.fmt }); });
      });
      w.autoFilter = { from: { row: 3, column: 1 }, to: { row: 3 + Math.max(x.rows.length, 1), column: x.cols.length } };
    });
    return ws;
  };

  XL.CAL = CAL;
  root.XL = XL;
  if (typeof module !== 'undefined' && module.exports) module.exports = XL;
})(typeof window !== 'undefined' ? window : globalThis);
